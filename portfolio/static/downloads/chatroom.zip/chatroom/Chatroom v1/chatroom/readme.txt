run FileClient.main() to recieve latest version of ChatClient programm.

then run ChatClient.main() to join the server.