Welcome, User. This is an extended base of the ChatRooms project.

For accessing the ChatRooms server chat, boot up ChatClient.main() while the Host Server is running.
For receiving updates, boot up FileClient.main() while the File Server is running, and access the new ChatRooms ChatClient code in Downloads.

We hope you enjoy your time here at ChatRooms!

-ChatRooms HQ