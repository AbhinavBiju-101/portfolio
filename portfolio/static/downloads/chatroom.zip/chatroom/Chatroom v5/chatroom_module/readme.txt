open fileserver and run main

send the latest chatclient file to all fileclients.

then open chatserver to start the server.