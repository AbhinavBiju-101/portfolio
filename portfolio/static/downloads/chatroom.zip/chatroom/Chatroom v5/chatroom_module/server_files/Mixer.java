import java.util.*;
public class Mixer
{
    int[] arr;
    int n;
    Mixer (int nn)
    {
        n=nn;
        arr=new int[n];
    }
    void accept()
    {
        Scanner sc=new Scanner(System.in);
        for (int i=0;i<n;i++)
        {
            while (true)
            {
                arr[i]=sc.nextInt();
                if (i==0||arr[i]>arr[i-1])
                    break;
                else
                {
                    System.out.println("Not in ascending order.");
                    continue;
                }
            }
        }
    }
    void display()
    {
        for (int i=0;i<n;i++)
            System.out.print(arr[i]+" ");
        System.out.println("");
    }
    static Mixer mix (Mixer A)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Input the size and elements of the second array.");
        int y=sc.nextInt();
        Mixer B=new Mixer(y);
        B.accept();
        Mixer MixedArray=new Mixer(B.n+A.n);
        int p=0,q=0;
        for (int i=0;i<A.n+B.n;i++)
        {
            /*if (p==A.n)
                MixedArray.arr[i]=B.arr[q];
            if (q==B.n)
                MixedArray.arr[i]=A.arr[p];*/
            if (A.arr[p]<B.arr[q])
            {
                MixedArray.arr[i]=A.arr[p];
                p++;
            }
            else if (A.arr[p]>B.arr[q])
            {
                MixedArray.arr[i]=B.arr[q];
                q++;
            } else {
                System.out.println("equal");
                if (p+1<A.n) {
                    p++;
                }else if (q+1<B.n) {
                    q++;
                }
            }
        }
        return MixedArray;
    }
    public static void main()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Input the size and elements of the first array.");
        int x=sc.nextInt();
        Mixer A=new Mixer(x);
        A.accept();
        System.out.println("Input the details for the second array, then the final merged array will be printd.");
        mix(A).display();
    }
}
