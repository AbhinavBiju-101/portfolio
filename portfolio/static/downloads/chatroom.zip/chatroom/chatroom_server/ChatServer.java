import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class ChatServer {
    private static final int PORT = 12345;
    private static Set<ClientHandler> clients = Collections.synchronizedSet(new HashSet<>());
    private static List<String> messageHistory = Collections.synchronizedList(new LinkedList<>());
    private static final int MAX_HISTORY = 50;
    private static SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
    private static ServerSocket serverSocket;

    // Server commands help text
    private static final String SERVER_HELP =
        "\n📖 Server Commands:\n" +
        "  /help            - Show this help message\n" +
        "  /stop            - Stop the server\n" +
        "  /kick <username> - Kick a specific user\n" +
        "  <message>        - Broadcast a server announcement\n";

    public static void main(String[] args) {
        System.out.println("Chat server started on port " + PORT);
        System.out.println("Type /help for server commands.");

        // Thread for server console commands
        new Thread(() -> {
            try (Scanner scanner = new Scanner(System.in)) {
                while (true) {
                    String line = scanner.nextLine();
                    if (line.equalsIgnoreCase("/stop")) {
                        shutdownServer();
                        break;
                    }
                    if (line.equalsIgnoreCase("/help")) {
                        System.out.println(SERVER_HELP);
                        continue;
                    }
                    if (line.startsWith("/kick ")) {
                        String target = line.substring(6).trim();
                        kickUser(target);
                        continue;
                    }
                    if (!line.trim().isEmpty()) {
                        broadcast("📢 SERVER: " + line);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();

        try (ServerSocket ss = new ServerSocket(PORT)) {
            serverSocket = ss;
            while (true) {
                Socket socket = serverSocket.accept();
                ClientHandler handler = new ClientHandler(socket);
                handler.start(); // don't add yet, only after login
            }
        } catch (IOException e) {
            System.out.println("Server stopped.");
        }
    }

    private static void shutdownServer() {
        broadcast("⚠️ Server disconnected");
        synchronized (clients) {
            for (ClientHandler client : clients) {
                try {
                    client.out.println("SERVER_CLOSED");
                    client.socket.close();
                } catch (IOException ignored) {}
            }
        }
        try { serverSocket.close(); } catch (IOException ignored) {}
        System.exit(0);
    }

    private static void kickUser(String target) {
        synchronized (clients) {
            for (ClientHandler client : clients) {
                if (client.username != null && client.username.equalsIgnoreCase(target)) {
                    client.out.println("[KICK] You have been kicked by the server.");
                    try { client.socket.close(); } catch (IOException ignored) {}
                    clients.remove(client);
                    broadcast("⛔ " + client.username + " was kicked by the server.");
                    break;
                }
            }
        }
    }

    private static String getUniqueUsername(String base) {
        String newName = base;
        int count = 1;
        synchronized (clients) {
            boolean exists;
            do {
                exists = false;
                for (ClientHandler c : clients) {
                    if (c.username != null && c.username.equalsIgnoreCase(newName)) {
                        exists = true;
                        newName = base + "(" + count + ")";
                        count++;
                        break;
                    }
                }
            } while (exists);
        }
        return newName;
    }

    private static class ClientHandler extends Thread {
        private Socket socket;
        private PrintWriter out;
        private BufferedReader in;
        private String username;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);

                // First message is username
                out.println("Enter your username:");
                String requested = in.readLine();
                if (requested == null || requested.trim().isEmpty()) {
                    requested = "Anonymous";
                }
                username = getUniqueUsername(requested);

                // Only now add client to list
                synchronized (clients) {
                    clients.add(this);
                }

                // Send chat history
                synchronized (messageHistory) {
                    for (String oldMsg : messageHistory) {
                        out.println(oldMsg);
                    }
                }

                // Send current user list
                sendUserList();

                // Local tip
                out.println("[INFO] Type /help to view all commands");

                broadcast("🔵 " + username + " has joined the chat!");

                String message;
                while ((message = in.readLine()) != null) {
                    if (message.startsWith("/users")) {
                        sendUserList();
                    } else if (message.startsWith("/typing")) {
                        broadcastTyping(username);
                    } else {
                        String parsedMessage = replaceEmojis(message);
                        broadcast(username + ": " + parsedMessage);
                    }
                }
            } catch (IOException e) {
                System.out.println(username + " disconnected.");
            } finally {
                try { socket.close(); } catch (IOException ignored) {}
                clients.remove(this);
                if (username != null) {
                    broadcast("🔴 " + username + " has left the chat!");
                }
            }
        }

        private void sendUserList() {
            StringBuilder sb = new StringBuilder("👥 Online: ");
            synchronized (clients) {
                for (ClientHandler client : clients) {
                    sb.append(client.username).append(", ");
                }
            }
            if (sb.length() > 2) sb.setLength(sb.length() - 2);
            out.println(sb.toString());
        }
    }

    private static void broadcast(String msg) {
        String time = "[" + timeFormat.format(new Date()) + "] ";
        String message = time + msg;

        synchronized (clients) {
            for (ClientHandler client : clients) {
                client.out.println(message);
            }
        }

        synchronized (messageHistory) {
            messageHistory.add(message);
            if (messageHistory.size() > MAX_HISTORY) {
                messageHistory.remove(0);
            }
        }

        System.out.println(message);
    }

    private static void broadcastTyping(String user) {
        synchronized (clients) {
            for (ClientHandler client : clients) {
                if (client.username != null && !client.username.equals(user)) {
                    client.out.println("[TYPING] " + user + " is typing…");
                }
            }
        }
    }

    private static String replaceEmojis(String msg) {
        return msg.replace(":smile:", "😄")
                  .replace(":heart:", "❤️")
                  .replace(":thumbs:", "👍")
                  .replace(":fire:", "🔥")
                  .replace(":skull:", "💀");
    }
}
