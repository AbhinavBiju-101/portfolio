# Claude Prompt Scheduler (Firefox extension)

Schedules a prompt to be typed and auto-sent into claude.ai at a chosen time.

## Load it in Firefox

1. Go to `about:debugging#/runtime/this-firefox`
2. Click **Load Temporary Add-on**
3. Select the `manifest.json` file in this folder

Note: "Temporary" add-ons are removed when Firefox fully restarts, so you'll
need to reload it each time you restart Firefox. To make it persist, you'd
need to package and self-sign it (Firefox requires signing for permanent
installs) — ask me if you want help with that step.

## How to use it

1. Click the extension's toolbar icon.
2. Type your prompt, pick a date/time, click **Schedule**.
3. Keep Firefox running (minimized is fine) until that time.
4. At the scheduled time, the extension will find an open claude.ai tab
   (or open one if none exists), type your prompt, and click Send.

## Requirements for it to fire

- Firefox must be running (not fully closed) at the scheduled time.
- Your laptop must not be asleep (see your power settings — you mentioned
  you're changing these separately).
- You should be logged into claude.ai already, since the extension doesn't
  handle login.

## If it stops working

claude.ai's page structure can change without notice, which will break the
selectors in `content.js` (the part that finds the input box and send
button). If prompts stop sending:

1. Open claude.ai, press F12 to open devtools.
2. Click into the message box, right-click → Inspect.
3. Note the element's tag/attributes (look for `contenteditable="true"`).
4. Do the same for the send button (look for `aria-label` or `data-testid`).
5. Update the `selectors` / `candidates` arrays at the top of `content.js`
   with whatever you find.

## Features

- **Fixed-time or auto-detect scheduling.** Fixed sends once at a chosen time.
  Auto-detect polls every minute and sends as soon as the page no longer
  looks rate-limited — see the heuristic caveat below.
- **New chat toggle.** Force a fresh conversation instead of reusing an
  already-open claude.ai tab.
- **Auto-retry.** Fixed-time jobs that fail (input box or send button not
  found) automatically retry up to 3 times, 2 minutes apart, before giving up.
- **Dashboard** (`dashboard.html`) — view/search/filter the live queue, edit
  a job's time/prompt/mode/new-chat setting inline, or delete it.
- **History** (`history.html`) — log of every send attempt: sent, failed,
  retrying, or missed (job's time passed while Firefox was closed).

## Auto-detect: how it works, and its limits

There's no official signal for "your usage limit has reset." The content
script guesses using two checks together: the send button appears disabled,
*and* the page text matches patterns like "reached your limit", "try again
later", "usage limit". Both need to match to reduce false positives.

This is inherently fragile — if claude.ai changes its rate-limit UI wording,
auto-detect may never fire (safe failure: it just keeps waiting) or may
misfire. If you notice it's not triggering when you'd expect:

1. Open claude.ai while actually rate-limited, open devtools (F12).
2. Look at the exact text shown and inspect the send button's `disabled`/
   `aria-disabled` state.
3. Update `LIMIT_TEXT_PATTERN` near the top of `content.js` to match.

## Design

The UI follows a "scheduling console / departures board" concept — timestamps,
countdowns, and queued prompt text are set in JetBrains Mono (bundled locally
in `fonts/`, no network dependency), with Space Grotesk for headers and
interface labels. The queue page shows a "next departure" hero card for the
soonest fixed-time job with a live countdown, and the rest of the queue as a
board-style table. Status is shown via small colored LED dots (amber =
retrying, blue pulse = auto-detect watching, green = sent, red = failed)
rather than pill badges. All styling lives in `styles.css`, shared across
`popup.html`, `dashboard.html`, and `history.html`.

## Files

- `manifest.json` — extension config and permissions
- `styles.css` — shared design tokens and components (colors, type, buttons, board table, hero card, switches)
- `fonts/` — bundled Space Grotesk + JetBrains Mono woff2 files
- `popup.html` / `popup.js` — quick-add UI: prompt, mode (fixed/auto-detect), new-chat toggle
- `dashboard.html` / `dashboard.js` — queue view: hero "next up" card, search/filter, inline editing
- `history.html` / `history.js` — log of past send attempts, filterable by status
- `background.js` — owns alarms, retry logic, auto-detect polling, and history logging
- `content.js` — injects prompt text, clicks send, and (for auto-detect) checks whether the limit looks cleared

## Making it permanent (survive Firefox restarts)

By default (Load Temporary Add-on) the extension unloads every time Firefox
fully restarts. To avoid re-loading it manually each time:

1. `npm install --global web-ext`
2. Free account at addons.mozilla.org, then generate API credentials at
   addons.mozilla.org/developers/addon/api/key/
3. From this folder: `web-ext sign --api-key=YOUR_KEY --api-secret=YOUR_SECRET --channel=unlisted`
4. Install the signed `.xpi` it downloads via `about:addons` → gear icon →
   Install Add-on From File.

Note: this makes the *extension* persist across restarts. Firefox itself
still needs to be running (even just minimized) at each scheduled send time
— there's no way around that for a browser extension, since the code can't
execute while the browser process isn't running.
