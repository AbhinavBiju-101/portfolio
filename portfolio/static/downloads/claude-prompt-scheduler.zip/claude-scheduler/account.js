// account.js — this device's identity: linking an email or Google account,
// signing out, and deleting the account. Linking multiple profiles into a
// workspace lives on its own page now — see workspace.js.

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}

function tickClock() {
  const now = new Date();
  document.getElementById('railClock').textContent = now.toLocaleTimeString(undefined, { hour12: false });
  document.getElementById('railDate').textContent = now.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
}
tickClock();
setInterval(tickClock, 1000);

let currentSbUser = null;

function applyAnonymousGating() {
  const linked = !!(currentSbUser && !currentSbUser.is_anonymous);
  document.getElementById('deleteAccountCard').style.display = linked ? 'block' : 'none';
  document.getElementById('anonymousHintCard').style.display = linked ? 'none' : 'block';
}

// --- Email sync (same underlying functions library.js used to call
// directly — see supabase-client.js's "Cross-device sync via email"
// section for how link vs. sign-in is chosen) ------------------------------

const ENABLE_EMAIL_SYNC = false; // see the note in supabase-client.js/library.js history — dormant until SMTP is configured

const emailSyncPanel = document.getElementById('emailSyncPanel');

function renderEmailSyncPanel() {
  if (!currentSbUser) { emailSyncPanel.innerHTML = ''; return; }

  if (!currentSbUser.is_anonymous) {
    emailSyncPanel.innerHTML = `
      <div class="acct-row">
        <span class="acct-msg ok" style="min-height:0;">&#10003; Linked as <b>${escapeHtml(currentSbUser.email)}</b> — your library follows this identity, and you can leave ratings.</span>
        <button type="button" class="btn btn-ghost" id="signOutBtn" style="font-size:11px; padding:4px 10px;">Sign out</button>
      </div>
    `;
    document.getElementById('signOutBtn').addEventListener('click', async () => {
      if (!confirm('Sign out on this device? It switches back to a fresh, empty anonymous identity — nothing in the cloud is deleted, you can sign back in any time.')) return;
      await signOut();
      currentSbUser = await currentUser();
      applyAnonymousGating();
      renderEmailSyncPanel();
    });
    return;
  }

  // Google doesn't depend on custom SMTP at all — only the OTP path below
  // does, so it's the only thing still gated behind ENABLE_EMAIL_SYNC.
  emailSyncPanel.innerHTML = `
    <div class="acct-row">
      <span class="acct-msg" style="min-height:0;">This device is anonymous.</span>
      <button type="button" class="btn btn-primary" id="googleSignInBtn">Sign in with Google</button>
    </div>
    <div class="acct-msg" id="googleMsg"></div>
    ${ENABLE_EMAIL_SYNC ? `
      <div class="acct-row">
        <span style="color:var(--text-faint); font-size:12px;">or</span>
        <button type="button" class="btn btn-ghost" id="syncStartBtn">Link an email</button>
      </div>
      <div id="syncForm" style="display:none;"></div>
    ` : `<div class="acct-sub" style="margin-top:4px;">Email linking is coming soon — needs custom SMTP configured first.</div>`}
  `;
  document.getElementById('googleSignInBtn').addEventListener('click', async () => {
    const msg = document.getElementById('googleMsg');
    msg.textContent = 'Opening Google sign-in…'; msg.className = 'acct-msg';
    try {
      await signInWithGoogle();
      currentSbUser = await currentUser();
      applyAnonymousGating();
      renderEmailSyncPanel();
    } catch (err) { msg.textContent = err.message; msg.className = 'acct-msg error'; }
  });
  if (!ENABLE_EMAIL_SYNC) return;
  document.getElementById('syncStartBtn').addEventListener('click', () => {
    const form = document.getElementById('syncForm');
    form.style.display = 'block';
    form.innerHTML = `
      <div class="acct-row">
        <input type="email" id="syncEmailInput" placeholder="you@example.com">
        <button type="button" class="btn btn-primary" id="syncSendCodeBtn">Send code</button>
      </div>
      <div class="acct-msg" id="syncMsg"></div>
    `;
    document.getElementById('syncSendCodeBtn').addEventListener('click', async () => {
      const email = document.getElementById('syncEmailInput').value.trim();
      const msgEl = document.getElementById('syncMsg');
      if (!email) return;
      msgEl.textContent = 'Sending…'; msgEl.className = 'acct-msg';
      try {
        let mode = 'link';
        try { await startLinkEmail(email); }
        catch (err) { mode = 'signin'; await requestSignInCode(email); }
        form.innerHTML = `
          <div class="acct-row">
            <input type="text" id="syncCodeInput" placeholder="123456" maxlength="6" inputmode="numeric">
            <button type="button" class="btn btn-primary" id="syncVerifyBtn">Verify</button>
          </div>
          <div class="acct-msg" id="syncMsg2"></div>
        `;
        document.getElementById('syncVerifyBtn').addEventListener('click', async () => {
          const code = document.getElementById('syncCodeInput').value.trim();
          const m2 = document.getElementById('syncMsg2');
          if (!code) return;
          m2.textContent = 'Verifying…';
          try {
            if (mode === 'link') await confirmLinkEmail(email, code);
            else await confirmSignIn(email, code);
            currentSbUser = await currentUser();
            applyAnonymousGating();
            renderEmailSyncPanel();
          } catch (err) { m2.textContent = err.message; m2.className = 'acct-msg error'; }
        });
      } catch (err) { msgEl.textContent = err.message; msgEl.className = 'acct-msg error'; }
    });
  });
}

// --- Delete account ------------------------------------------------------

document.getElementById('deleteAccountBtn').addEventListener('click', async () => {
  const confirmInput = document.getElementById('deleteConfirmInput');
  const msg = document.getElementById('deleteMsg');
  if (confirmInput.value.trim() !== 'DELETE') {
    msg.textContent = 'Type DELETE (all caps) in the box first.'; msg.className = 'acct-msg error';
    return;
  }
  if (!confirm('This permanently deletes your account. Jobs, history, and personal templates on THIS device are untouched — only your cloud identity (library, ratings, workspace membership) goes away. Continue?')) return;
  msg.textContent = 'Deleting…'; msg.className = 'acct-msg';
  try {
    await deleteMyAccount();
    currentSbUser = await currentUser();
    applyAnonymousGating();
    confirmInput.value = '';
    renderEmailSyncPanel();
    msg.textContent = 'Account deleted — this device now has a fresh, empty identity.'; msg.className = 'acct-msg ok';
  } catch (err) { msg.textContent = err.message; msg.className = 'acct-msg error'; }
});

(async function init() {
  currentSbUser = await currentUser();
  applyAnonymousGating();
  document.getElementById('redirectUriDisplay').textContent = getGoogleRedirectUri();
  renderEmailSyncPanel();
})();
