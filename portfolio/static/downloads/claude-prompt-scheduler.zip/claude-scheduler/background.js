// background.js
// Owns scheduling via the browser.alarms API. Two job modes:
//   - "fixed": fires once at job.whenISO, retries a few times on failure.
//   - "auto-detect": polls every minute starting at job.whenISO (or now),
//     checking the page for signs the usage limit has cleared, and sends
//     as soon as it looks safe to.
// All outcomes (sent / failed / retrying) are logged to storage under
// "history" so history.html can show a record of what happened.

const CLAUDE_URL = 'https://claude.ai/new';
const MAX_RETRIES = 3;
const RETRY_DELAY_MINUTES = 2;
const AUTODETECT_POLL_MINUTES = 1;
const MAX_HISTORY_ENTRIES = 200;
const WORKSPACE_POLL_MINUTES = 2;

// --- Storage helpers --------------------------------------------------

async function getJobs() {
  const data = await browser.storage.local.get('jobs');
  return data.jobs || [];
}
async function saveJobs(jobs) {
  await browser.storage.local.set({ jobs });
}
async function getHistory() {
  const data = await browser.storage.local.get('history');
  return data.history || [];
}
async function addHistoryEntry(entry) {
  const history = await getHistory();
  history.unshift({ ...entry, at: new Date().toISOString() });
  await browser.storage.local.set({
    history: history.slice(0, MAX_HISTORY_ENTRIES)
  });
}

// --- Alarm naming ---------------------------------------------------
// "claude-job:<id>"        -> fixed-time job, one-shot alarm
// "claude-autodetect:<id>" -> auto-detect job, periodic alarm

function fixedAlarmName(id) { return 'claude-job:' + id; }
function autoAlarmName(id) { return 'claude-autodetect:' + id; }

function scheduleAlarm(job) {
  if (job.mode === 'auto-detect') {
    browser.alarms.create(autoAlarmName(job.id), {
      when: new Date(job.whenISO).getTime(),
      periodInMinutes: AUTODETECT_POLL_MINUTES
    });
  } else {
    browser.alarms.create(fixedAlarmName(job.id), {
      when: new Date(job.whenISO).getTime()
    });
  }
}

function clearAlarmsForJob(id) {
  browser.alarms.clear(fixedAlarmName(id));
  browser.alarms.clear(autoAlarmName(id));
}

// --- Toolbar badge: surfaces failed jobs without opening the dashboard -

async function getFailureBadgeCount() {
  const data = await browser.storage.local.get('failureBadgeCount');
  return data.failureBadgeCount || 0;
}
async function setFailureBadgeCount(n) {
  await browser.storage.local.set({ failureBadgeCount: n });
  browser.browserAction.setBadgeText({ text: n > 0 ? String(n) : '' });
  browser.browserAction.setBadgeBackgroundColor({ color: '#e2634f' }); // matches styles.css's --red
}
async function bumpFailureBadge() {
  await setFailureBadgeCount((await getFailureBadgeCount()) + 1);
}
async function clearFailureBadge() {
  await setFailureBadgeCount(0);
}

// --- Startup reconciliation ------------------------------------------

async function reconcileAlarmsOnStartup() {
  // Repaint the badge from storage — Firefox clears browserAction badge
  // text on restart, but the underlying count should survive.
  setFailureBadgeCount(await getFailureBadgeCount());
  browser.alarms.create('workspace-poll', { periodInMinutes: WORKSPACE_POLL_MINUTES });

  const jobs = await getJobs();
  const now = Date.now();
  const stillValid = [];
  for (const job of jobs) {
    if (job.mode === 'auto-detect') {
      // Auto-detect jobs have no real "expiry" — keep polling.
      scheduleAlarm(job);
      stillValid.push(job);
    } else if (new Date(job.whenISO).getTime() > now) {
      scheduleAlarm(job);
      stillValid.push(job);
    } else {
      // A fixed job whose time passed while Firefox was closed.
      addHistoryEntry({
        jobId: job.id, prompt: job.prompt, mode: job.mode,
        status: 'missed', detail: 'Firefox was closed at the scheduled time.'
      });
    }
  }
  await saveJobs(stillValid);
}
browser.runtime.onStartup.addListener(reconcileAlarmsOnStartup);
browser.runtime.onInstalled.addListener(reconcileAlarmsOnStartup);

// --- Messages from popup.js / dashboard.js -----------------------------

browser.runtime.onMessage.addListener((msg, sender) => {
  if (msg.type === 'schedule-job') {
    clearAlarmsForJob(msg.job.id); // in case mode changed on edit
    scheduleAlarm(msg.job);
  } else if (msg.type === 'cancel-job') {
    clearAlarmsForJob(msg.id);
  } else if (msg.type === 'send-result') {
    handleSendResult(msg);
  } else if (msg.type === 'clear-history') {
    browser.storage.local.set({ history: [] });
  } else if (msg.type === 'get-chat-list') {
    return getChatList(false); // returning a Promise here signals an async reply
  } else if (msg.type === 'get-chat-list-rich') {
    return getChatList(true);
  } else if (msg.type === 'clear-failure-badge') {
    clearFailureBadge();
  } else if (msg.type === 'rate-limit-status') {
    // Store locally (so e.g. a future dashboard indicator could read it
    // without a network round-trip) and relay to the workspace, if any —
    // updateMyWorkspaceStatus() itself no-ops when not in a workspace.
    browser.storage.local.set({ rateLimitStatus: { rateLimited: msg.rateLimited, detail: msg.detail, updatedAt: new Date().toISOString() } });
    updateMyWorkspaceStatus(msg.rateLimited, msg.detail);
  } else if (msg.type === 'chat-list-status') {
    // Same idea as rate-limit-status, but for the sidebar chat list — lets
    // OTHER linked profiles' "send to" chat picker show this profile's
    // chats even though they're on a different machine/browser. See
    // migration-08.sql (chat_list_json column) and profile/chat picker
    // wiring in popup.js.
    updateMyWorkspaceChatList(msg.chats);
  }
});

// --- Fixed-time jobs: fire, retry on failure ---------------------------

browser.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name.startsWith('claude-job:')) {
    const jobId = alarm.name.slice('claude-job:'.length);
    await fireFixedJob(jobId);
  } else if (alarm.name.startsWith('claude-autodetect:')) {
    const jobId = alarm.name.slice('claude-autodetect:'.length);
    await pollAutoDetectJob(jobId);
  } else if (alarm.name === 'workspace-poll') {
    await pollWorkspaceJobs();
  }
});

// Pulls jobs other workspace members have queued for THIS profile (see
// account.html/account.js for how the workspace gets set up, and
// supabase-client.js's pollWorkspaceJobsForMe for the query itself), and
// drops them into the normal local job pipeline so they run exactly like
// a job scheduled from this popup. Silently no-ops if this profile isn't
// in a workspace — most installs never touch this.
async function pollWorkspaceJobs() {
  let pending;
  try {
    pending = await pollWorkspaceJobsForMe();
  } catch (err) {
    return; // offline / not signed in / not in a workspace — nothing to do
  }
  if (!pending.length) return;

  const jobs = await getJobs();
  for (const wj of pending) {
    const job = {
      id: 'wsjob-' + wj.id,
      prompt: wj.prompt,
      whenISO: wj.when_iso,
      mode: wj.mode,
      skipTyping: !!wj.skip_typing,
      retryCount: 0,
      workspaceJobId: wj.id // lets handleSendResult report status back
    };
    if (wj.steps) job.steps = wj.steps;
    if (wj.target) job.target = wj.target;
    if (wj.attachments) job.attachments = wj.attachments;
    jobs.push(job);
    scheduleAlarm(job);
    markWorkspaceJobStatus(wj.id, 'claimed'); // fire-and-forget
  }
  await saveJobs(jobs);
}

async function fireFixedJob(jobId) {
  const jobs = await getJobs();
  const job = jobs.find(j => j.id === jobId);
  if (!job) return; // cancelled

  const tab = await findOrOpenClaudeTab(job);
  if (job.steps && job.steps.length) {
    runSequenceOnTab(tab.id, job, /*checkFirst*/ false);
  } else {
    sendPromptToTab(tab.id, job, /*checkFirst*/ false);
  }
}

async function pollAutoDetectJob(jobId) {
  const jobs = await getJobs();
  const job = jobs.find(j => j.id === jobId);
  if (!job) { clearAlarmsForJob(jobId); return; } // cancelled

  const tab = await findOrOpenClaudeTab(job);
  if (job.steps && job.steps.length) {
    runSequenceOnTab(tab.id, job, /*checkFirst*/ true);
  } else {
    sendPromptToTab(tab.id, job, /*checkFirst*/ true);
  }
}

// job.target: { mode: 'current' | 'new' | 'specific', chatUrl?, chatTitle? }
// Falls back to the legacy job.newChat boolean for jobs saved before target
// selection existed.
async function findOrOpenClaudeTab(job) {
  const target = job.target || { mode: (job.newChat && !job.skipTyping) ? 'new' : 'current' };

  if (target.mode === 'specific' && target.chatUrl) {
    const tabs = await browser.tabs.query({ url: 'https://claude.ai/*' });
    const existing = tabs.find(t => t.url && t.url.startsWith(target.chatUrl));
    if (existing) {
      await browser.tabs.update(existing.id, { active: true });
      return existing;
    }
    return browser.tabs.create({ url: target.chatUrl, active: true });
  }

  // Skip-typing jobs rely on you having already typed the prompt into an
  // existing tab — opening a fresh one would have nothing in it, so always
  // reuse an existing tab for those regardless of the target mode.
  const wantsNewChat = target.mode === 'new' && !job.skipTyping;

  if (!wantsNewChat) {
    const tabs = await browser.tabs.query({ url: 'https://claude.ai/*' });
    if (tabs.length > 0) {
      await browser.tabs.update(tabs[0].id, { active: true });
      return tabs[0];
    }
  }
  return browser.tabs.create({ url: CLAUDE_URL, active: true });
}

// Content script may not be ready immediately, so retry briefly.
async function runSequenceOnTab(tabId, job, checkFirst, attemptsLeft = 20) {
  try {
    await browser.tabs.sendMessage(tabId, {
      type: checkFirst ? 'check-and-maybe-run-sequence' : 'run-sequence',
      jobId: job.id,
      steps: job.steps,
      startStepId: job.steps[0].id,
      attachments: job.attachments || null
    });
    // Result arrives later via the same 'send-result' channel used by the
    // single-prompt path — handleSendResult() doesn't need to know the
    // difference.
  } catch (err) {
    if (attemptsLeft > 0) {
      setTimeout(() => runSequenceOnTab(tabId, job, checkFirst, attemptsLeft - 1), 500);
    } else {
      handleSendResult({ jobId: job.id, success: false, reason: 'content-script-unreachable', notReady: false });
    }
  }
}

// Fetches the visible chat list from a live claude.ai tab, for the "choose
// which chat" target picker in the dashboard editor. Opens a background tab
// briefly if none is already open, then closes it again.
async function getChatList(rich) {
  const tabs = await browser.tabs.query({ url: 'https://claude.ai/*' });
  let tab = tabs[0];
  let createdTemp = false;
  if (!tab) {
    tab = await browser.tabs.create({ url: CLAUDE_URL, active: false });
    createdTemp = true;
    await new Promise(r => setTimeout(r, 2500)); // let the sidebar render
  }
  try {
    const res = await browser.tabs.sendMessage(tab.id, { type: rich ? 'list-chats-rich' : 'list-chats' });
    return (res && res.chats) || [];
  } catch (err) {
    return [];
  } finally {
    if (createdTemp) browser.tabs.remove(tab.id);
  }
}

// Content script may not be ready immediately (fresh tab still loading),
// so retry sending the message for a short window.
async function sendPromptToTab(tabId, job, checkFirst, attemptsLeft = 20) {
  try {
    await browser.tabs.sendMessage(tabId, {
      type: checkFirst ? 'check-and-maybe-send' : 'send-prompt',
      jobId: job.id,
      prompt: job.prompt,
      skipTyping: !!job.skipTyping,
      attachments: job.attachments || null
    });
    // Actual success/failure arrives later via a separate "send-result"
    // message once content.js finishes its attempt.
  } catch (err) {
    if (attemptsLeft > 0) {
      setTimeout(() => sendPromptToTab(tabId, job, checkFirst, attemptsLeft - 1), 500);
    } else {
      // Never even reached the content script.
      handleSendResult({ jobId: job.id, success: false, reason: 'content-script-unreachable', notReady: false });
    }
  }
}

// --- Handling results reported back by content.js -----------------------

async function handleSendResult({ jobId, success, reason, notReady }) {
  const jobs = await getJobs();
  const job = jobs.find(j => j.id === jobId);
  if (!job) return; // already cancelled/removed

  if (success) {
    clearAlarmsForJob(jobId);
    await saveJobs(jobs.filter(j => j.id !== jobId));
    addHistoryEntry({ jobId, prompt: job.prompt, mode: job.mode, status: 'sent' });
    if (job.workspaceJobId) markWorkspaceJobStatus(job.workspaceJobId, 'sent');
    return;
  }

  // Auto-detect jobs that simply aren't ready yet: just wait for next poll,
  // no retry-counting, no history noise.
  if (job.mode === 'auto-detect' && notReady) {
    return;
  }

  // Fixed job failed (or auto-detect hit a real error) — apply retry policy.
  job.retryCount = (job.retryCount || 0) + 1;

  if (job.mode === 'fixed' && job.retryCount <= MAX_RETRIES) {
    const nextTime = new Date(Date.now() + RETRY_DELAY_MINUTES * 60000);
    job.whenISO = nextTime.toISOString();
    const idx = jobs.findIndex(j => j.id === jobId);
    jobs[idx] = job;
    await saveJobs(jobs);
    scheduleAlarm(job);
    addHistoryEntry({
      jobId, prompt: job.prompt, mode: job.mode, status: 'retrying',
      detail: `Attempt ${job.retryCount} failed (${reason || 'unknown'}). Retrying at ${nextTime.toLocaleTimeString()}.`
    });
  } else {
    clearAlarmsForJob(jobId);
    await saveJobs(jobs.filter(j => j.id !== jobId));
    addHistoryEntry({
      jobId, prompt: job.prompt, mode: job.mode, status: 'failed',
      detail: reason || 'Gave up after repeated failures.'
    });
    bumpFailureBadge();
    if (job.workspaceJobId) markWorkspaceJobStatus(job.workspaceJobId, 'failed', reason || 'Gave up after repeated failures.');
  }
}
