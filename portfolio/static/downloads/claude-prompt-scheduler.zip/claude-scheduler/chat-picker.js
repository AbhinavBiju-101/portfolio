// chat-picker.js — searchable "choose which chat" popup, shared by
// popup.js, compose.js (via popup.js) and dashboard.js/target-editor.js.
// Replaces the old plain <select> of chat titles with a modal of cards
// that also shows (best-effort, see content.js's listChats()) which
// sidebar group a chat was last active in and which project it belongs
// to, since claude.ai's sidebar doesn't expose an exact last-message
// timestamp without opening each conversation individually.
//
// window.chatPicker.open({ chats, currentUrl, loading, showCurrentOption,
//                           rich, onSelect, onNewChat, onCurrent })
//   chats:      array of { url, title, group, project } (group/project may
//               be undefined — cards just omit those badges). In rich
//               mode, chats may also carry { lastSentFirstLine, lastSentAt,
//               createdAt } — see content.js's listChatsRich().
//   currentUrl: url to visually mark as "current tab", if known
//   loading:    true to show a loading state instead of the list (caller
//               can call chatPicker.update({chats}) once the real list
//               arrives, e.g. after a cross-profile fetch)
//   showCurrentOption: pin a "Use current tab" card above "+ New chat"
//   rich:       renders fuller cards — last-sent snippet + last-sent/
//               created dates alongside the group/project badges. Used on
//               the full-page views (compose/dashboard); the popup stays
//               on the plain simple cards, both because it's cramped and
//               because the extra fields cost an extra network call this
//               file doesn't hide the cost of (see fetchRichChatMeta()'s
//               own caveats in content.js — it's unverified against a
//               live claude.ai session and can silently come back empty).
//   onSelect(chat) / onNewChat() / onCurrent(): called once, then closes

(function () {
  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
  }

  let closeFn = null;

  function close() {
    if (closeFn) { closeFn(); closeFn = null; }
  }

  function fmtDate(iso) {
    if (!iso) return null;
    try {
      const d = new Date(iso);
      if (isNaN(d.getTime())) return null;
      const sameYear = d.getFullYear() === new Date().getFullYear();
      return d.toLocaleDateString(undefined, sameYear ? { month: 'short', day: 'numeric' } : { month: 'short', day: 'numeric', year: 'numeric' })
        + ' ' + d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
    } catch (e) { return null; }
  }

  function renderList(body, chats, query, currentUrl, rich, onPick) {
    const q = (query || '').trim().toLowerCase();
    const filtered = q ? chats.filter(c => c.title.toLowerCase().includes(q)) : chats;
    if (!chats.length) {
      body.innerHTML = `<div class="sched-modal-empty">No chats found — open claude.ai first, or start a new one above.</div>`;
      return;
    }
    if (!filtered.length) {
      body.innerHTML = `<div class="sched-modal-empty">No chats match "${escapeHtml(query)}"</div>`;
      return;
    }
    body.innerHTML = filtered.map(c => {
      const lastSent = fmtDate(c.lastSentAt);
      const created = fmtDate(c.createdAt);
      return `
      <div class="chat-pick-item${rich ? ' rich' : ''}${c.url === currentUrl ? ' selected' : ''}" data-url="${escapeHtml(c.url)}">
        <div class="cp-title">
          ${escapeHtml(c.title)}
          ${c.url === currentUrl ? '<span class="cp-current-badge">current</span>' : ''}
          ${c.project ? `<span class="cp-project-badge">${escapeHtml(c.project)}</span>` : ''}
        </div>
        ${rich && c.lastSentFirstLine ? `<div class="cp-snippet">${escapeHtml(c.lastSentFirstLine)}</div>` : ''}
        ${rich && (lastSent || created)
          ? `<div class="cp-meta">${lastSent ? `Last sent ${lastSent}` : ''}${lastSent && created ? ' · ' : ''}${created ? `Created ${created}` : ''}</div>`
          : (c.group ? `<div class="cp-meta">last active: ${escapeHtml(c.group)}</div>` : '')}
      </div>
    `;
    }).join('');
    body.querySelectorAll('.chat-pick-item').forEach(el => {
      el.addEventListener('click', () => {
        const chat = chats.find(c => c.url === el.getAttribute('data-url'));
        if (chat) onPick(chat);
      });
    });
  }

  function open(opts) {
    close();
    let chats = opts.chats || [];

    const backdrop = document.createElement('div');
    backdrop.className = 'sched-modal-backdrop';
    backdrop.innerHTML = `
      <div class="sched-modal${opts.rich ? ' rich' : ''}">
        <div class="sched-modal-head">
          <h3>Choose a chat</h3>
          <button type="button" class="sched-modal-close">&times;</button>
        </div>
        <input type="text" class="sched-modal-search" placeholder="Search chats…">
        <div class="sched-modal-body">
          ${opts.showCurrentOption ? `
          <div class="chat-pick-item cp-new" data-current="1">
            <div class="cp-title">&#8594; Use current tab</div>
          </div>` : ''}
          <div class="chat-pick-item cp-new" data-new="1">
            <div class="cp-title">+ Start a new chat</div>
          </div>
          <div class="chat-list-target"></div>
        </div>
      </div>
    `;
    document.body.appendChild(backdrop);

    const searchEl = backdrop.querySelector('.sched-modal-search');
    const listTarget = backdrop.querySelector('.chat-list-target');

    function paint() {
      if (opts.loading && !chats.length) {
        listTarget.innerHTML = `<div class="sched-modal-empty">Loading chats…</div>`;
        return;
      }
      renderList(listTarget, chats, searchEl.value, opts.currentUrl, !!opts.rich, (chat) => {
        if (opts.onSelect) opts.onSelect(chat);
        close();
      });
    }
    paint();

    backdrop.querySelector('[data-new]').addEventListener('click', () => {
      if (opts.onNewChat) opts.onNewChat();
      close();
    });
    backdrop.querySelector('[data-current]')?.addEventListener('click', () => {
      if (opts.onCurrent) opts.onCurrent();
      close();
    });
    searchEl.addEventListener('input', paint);
    backdrop.querySelector('.sched-modal-close').addEventListener('click', close);
    backdrop.addEventListener('click', (e) => { if (e.target === backdrop) close(); });
    const escHandler = (e) => { if (e.key === 'Escape') close(); };
    document.addEventListener('keydown', escHandler);

    closeFn = () => { document.removeEventListener('keydown', escHandler); backdrop.remove(); };
    searchEl.focus();

    window.chatPicker._update = (patch) => {
      if (patch.chats) chats = patch.chats;
      paint();
    };
  }

  window.chatPicker = {
    open,
    close,
    update(patch) { if (window.chatPicker._update) window.chatPicker._update(patch); }
  };
})();
