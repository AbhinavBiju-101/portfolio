// compose.js — the extra, page-only features that don't fit in the popup:
// workspace status at a glance, one-click quick-insert from your personal
// templates and saved library, a running character count, and a keyboard
// shortcut. All the actual scheduling logic (prompt, mode, steps editor,
// send-from, etc.) is popup.js, loaded unchanged before this file —
// compose.html just gives it a bigger home. Relies on popup.js's
// `promptEl` and `escapeHtml` already being in scope (classic <script>
// tags in one document share a global scope, so this works without any
// special wiring).

function tickComposeClock() {
  const now = new Date();
  document.getElementById('railClock').textContent = now.toLocaleTimeString(undefined, { hour12: false });
  document.getElementById('railDate').textContent = now.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
}
tickComposeClock();
setInterval(tickComposeClock, 1000);

// --- Character count + keyboard shortcut ------------------------------------

const charCountEl = document.getElementById('charCount');
promptEl.addEventListener('input', () => {
  const n = promptEl.value.length;
  charCountEl.textContent = `${n.toLocaleString()} character${n === 1 ? '' : 's'}`;
});
promptEl.addEventListener('keydown', (e) => {
  if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
    e.preventDefault();
    document.getElementById('scheduleBtn').click();
  }
});

// --- Workspace status --------------------------------------------------------
// Same status-pill logic as workspace.js — kept as its own small copy
// rather than a shared import, since it's a handful of lines and pulling
// in a whole extra script just for this wasn't worth it.

function composeStatusPillHtml(m) {
  if (!m.status_updated_at) return `<span class="usage-badge">no status</span>`;
  const stale = (Date.now() - new Date(m.status_updated_at).getTime()) > 30 * 60 * 1000;
  if (m.rate_limited) return `<span class="attribution-badge community" style="color:var(--red); background:rgba(226,99,79,0.12);">limited${stale ? ' (stale)' : ''}</span>`;
  return `<span class="attribution-badge official" style="color:var(--amber);">available${stale ? ' (stale)' : ''}</span>`;
}
function composeResetLineHtml(m) {
  if (!m.rate_limited || !m.rate_limit_detail || !window.resetTimeUtil) return '';
  const parsed = window.resetTimeUtil.parseResetLabel(m.rate_limit_detail);
  if (!parsed) return '';
  return `<div style="color:var(--text-faint); font-size:10px; margin-top:-2px; margin-bottom:4px;">${escapeHtml(parsed.label)}</div>`;
}

async function renderWorkspaceStatusSidebar() {
  try {
    await sendFromInitPromise; // reuse popup.js's fetch instead of issuing our own
    const members = Object.values(workspaceMembersById);
    if (members.length <= 1) return;
    document.getElementById('wsStatusCard').style.display = 'block';
    document.getElementById('wsStatusBody').innerHTML = members.map(m => `
      <div class="ws-status-row" style="flex-direction:column; align-items:stretch; gap:0;">
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <span class="name">${escapeHtml(m.profile_label)}${m.profile_label === myProfileLabel ? ' (you)' : ''}</span>
          ${composeStatusPillHtml(m)}
        </div>
        ${composeResetLineHtml(m)}
      </div>
    `).join('');
  } catch (err) { /* sidebar extra — fails quietly, core compose still works */ }
}

// --- Quick insert (personal templates + saved library) ---------------------

async function getPersonalTemplatesLocal() {
  const data = await browser.storage.local.get('personalTemplates');
  return data.personalTemplates || [];
}

async function renderQuickInsertSidebar() {
  try {
    const [templates, catalog, libIds] = await Promise.all([
      getPersonalTemplatesLocal(),
      fetchCatalog(),
      fetchUserLibraryIds()
    ]);
    setCatalog(catalog);
    const saved = catalog.filter(s => libIds.includes(s.id));
    const items = [
      ...templates.map(t => ({ title: t.title, prompt: t.prompt, tag: 'Personal' })),
      ...saved.filter(s => s.examples && s.examples.length).map(s => ({ title: s.title, prompt: s.examples[0].prompt, tag: s.category, id: s.id }))
    ];
    if (!items.length) return; // stays hidden — nothing to show yet
    document.getElementById('quickTplCard').style.display = 'block';
    document.getElementById('quickTplBody').innerHTML = items.slice(0, 12).map((it, i) => `
      <div class="quick-tpl" data-idx="${i}">
        <div class="t" style="font-family:var(--font-ui); font-size:12px; color:var(--text);">${escapeHtml(it.title)}</div>
        <div class="c" style="font-family:var(--font-mono); font-size:10px; color:var(--text-faint);">${escapeHtml(it.tag)}</div>
      </div>
    `).join('');
    document.getElementById('quickTplBody').querySelectorAll('.quick-tpl').forEach((el, i) => {
      el.addEventListener('click', () => {
        const it = items[i];
        const filled = fillPlaceholders(it.prompt);
        if (filled === null) return; // cancelled a placeholder prompt
        promptEl.value = filled;
        promptEl.dispatchEvent(new Event('input')); // updates the char count
        if (it.id) { bumpUsageCount(it.id); bumpExampleUsage(it.id, 0); }
      });
    });
  } catch (err) { /* sidebar extra — fails quietly, core compose still works */ }
}

renderWorkspaceStatusSidebar();
renderQuickInsertSidebar();
