// content.js
// Runs on claude.ai. Two entry points from background.js:
//   "send-prompt"           -> just type + send, report result back.
//   "check-and-maybe-send"  -> first check if the usage limit looks clear;
//                              only type + send if it does.
//
// FRAGILITY WARNING: claude.ai's DOM structure and limit-message wording
// can change without notice. If sends or auto-detect stop working, open
// devtools on claude.ai and update the selectors / text patterns below.

browser.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'send-prompt') {
    if (msg.skipTyping) {
      clickSendOnly(msg.jobId);
    } else {
      attachFilesToClaude(msg.attachments, () => injectAndSend(msg.jobId, msg.prompt));
    }
    sendResponse({ ok: true });
  } else if (msg.type === 'check-and-maybe-send') {
    checkAndMaybeSend(msg.jobId, msg.prompt, msg.skipTyping, msg.attachments);
    sendResponse({ ok: true });
  } else if (msg.type === 'run-sequence') {
    if (!beginSequence(msg.jobId)) { sendResponse({ ok: true, skipped: true }); return true; }
    attachFilesToClaude(msg.attachments, () => runSequence(msg.jobId, msg.steps, msg.startStepId, /*isAutoDetect*/ false));
    sendResponse({ ok: true });
  } else if (msg.type === 'check-and-maybe-run-sequence') {
    // Auto-detect's background alarm re-fires every minute regardless of
    // whether a previous attempt is still running (e.g. still mid rate-limit
    // poll, or waiting on a reply) — ignore re-triggers for a job that's
    // already in flight rather than starting a second concurrent send.
    if (!beginSequence(msg.jobId)) { sendResponse({ ok: true, skipped: true }); return true; }
    const input = findInputBox();
    if (!input) {
      endSequence(msg.jobId);
      reportResult(msg.jobId, false, 'page-not-ready', /*notReady*/ true);
    } else {
      // Auto-detect jobs gate every step on the limit, not just the first —
      // runSequence() itself re-checks looksRateLimited() before each send.
      attachFilesToClaude(msg.attachments, () => runSequence(msg.jobId, msg.steps, msg.startStepId, /*isAutoDetect*/ true));
    }
    sendResponse({ ok: true });
  } else if (msg.type === 'list-chats') {
    sendResponse({ chats: listChats() });
    return true;
  } else if (msg.type === 'list-chats-rich') {
    listChatsRich().then(chats => sendResponse({ chats })).catch(() => sendResponse({ chats: listChats() }));
    return true; // async — keep the message channel open for the Promise above
  }
  return true;
});

// --- Sidebar chat list scraping (for the "choose which chat" target) ------
// FRAGILITY WARNING: relies on claude.ai's sidebar linking to conversations
// as <a href="/chat/<uuid>">Title</a>. Update the selector if that changes.

// Best-effort: claude.ai groups sidebar chats under headings like "Today"
// / "Yesterday" / "Previous 7 Days", and (separately) some chats live
// nested under a project's own link (<a href="/project/...">). Neither is
// a real timestamp — the sidebar doesn't expose exact last-message times
// without opening each chat — so this only ever produces a rough group
// label and an optional project name, never a fabricated date. If
// claude.ai's markup changes, this just silently stops finding
// groups/projects and listChats() still returns titles/urls fine.
function nearestPrecedingHeading(a) {
  let node = a;
  while (node && node !== document.body) {
    let sib = node.previousElementSibling;
    while (sib) {
      if (sib.matches && (sib.matches('h1,h2,h3,[role="heading"]') || /^(today|yesterday|previous|last|older)/i.test((sib.textContent || '').trim()))) {
        const t = (sib.textContent || '').trim();
        if (t && t.length < 40) return t;
      }
      sib = sib.previousElementSibling;
    }
    node = node.parentElement;
  }
  return null;
}
function nearestProjectName(a) {
  // Only fires when the chat link is actually nested inside a project's
  // own container/link in the DOM — no attempt to guess otherwise.
  const projectLink = a.closest('[data-testid*="project" i], a[href^="/project/"]');
  if (projectLink && projectLink !== a) {
    const t = (projectLink.textContent || '').trim();
    if (t && t.length < 60) return t;
  }
  return null;
}

// Best-effort, unverified against a live claude.ai session (this
// extension was developed and tested with scripted jsdom checks only —
// see the project summary's closing note): claude.ai's own web app calls
// an internal REST API to populate the sidebar, roughly shaped like
// GET /api/organizations → [{ uuid, ... }] and
// GET /api/organizations/{orgId}/chat_conversations → [{ uuid, name,
// summary, created_at, updated_at, project: { uuid, name } }, ...].
// This is NOT a documented/stable API — Anthropic could rename or remove
// it at any time with no notice, since it's meant for claude.ai's own
// frontend, not third parties. Every step below is wrapped so a failure
// (404, different field names, auth shape change, etc.) just yields an
// empty map rather than breaking chat listing — listChats()'s DOM scrape
// still works fine on its own, just without the extra rich fields.
async function fetchRichChatMeta() {
  const out = {};
  try {
    const orgsRes = await fetch('/api/organizations', { credentials: 'same-origin' });
    if (!orgsRes.ok) return out;
    const orgs = await orgsRes.json();
    const orgId = Array.isArray(orgs) && orgs[0] && orgs[0].uuid;
    if (!orgId) return out;

    const convRes = await fetch(`/api/organizations/${orgId}/chat_conversations?limit=200`, { credentials: 'same-origin' });
    if (!convRes.ok) return out;
    const conversations = await convRes.json();
    if (!Array.isArray(conversations)) return out;

    for (const c of conversations) {
      if (!c || !c.uuid) continue;
      out[c.uuid] = {
        summary: typeof c.summary === 'string' ? c.summary : (typeof c.name === 'string' ? c.name : null),
        createdAt: c.created_at || null,
        updatedAt: c.updated_at || null,
        project: c.project && c.project.name ? c.project.name : null
      };
    }
  } catch (err) {
    // Any failure here (network, unexpected shape, CORS if this ever runs
    // off-domain, etc.) — just return whatever we managed to collect.
  }
  return out;
}

function chatIdFromUrl(url) {
  const m = /\/chat\/([a-f0-9-]+)/i.exec(url || '');
  return m ? m[1] : null;
}

async function listChatsRich() {
  const [base, meta] = await Promise.all([Promise.resolve(listChats()), fetchRichChatMeta()]);
  return base.map(c => {
    const id = chatIdFromUrl(c.url);
    const m = id ? meta[id] : null;
    if (!m) return c;
    return {
      ...c,
      // Prefer the API's project name over the DOM-scraped one — same
      // idea, but the API isn't dependent on the chat happening to be
      // nested under a project link in the currently-rendered sidebar.
      project: m.project || c.project,
      lastSentFirstLine: m.summary ? m.summary.split('\n')[0].slice(0, 140) : null,
      lastSentAt: m.updatedAt,
      createdAt: m.createdAt
    };
  });
}

function listChats() {
  const links = Array.from(document.querySelectorAll('a[href^="/chat/"]'));
  const seen = new Set();
  const chats = [];
  for (const a of links) {
    const href = a.getAttribute('href');
    if (!href || seen.has(href)) continue;
    seen.add(href);
    const title = (a.textContent || '').trim() || href;
    let group = null, project = null;
    try { group = nearestPrecedingHeading(a); } catch (e) { /* best-effort */ }
    try { project = nearestProjectName(a); } catch (e) { /* best-effort */ }
    chats.push({ url: 'https://claude.ai' + href, title, group: group || undefined, project: project || undefined });
  }
  return chats;
}

// --- Element lookup ------------------------------------------------------

function findInputBox() {
  const selectors = [
    'div.ProseMirror[contenteditable="true"]',
    'div[contenteditable="true"][role="textbox"]',
    'div[contenteditable="true"]'
  ];
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el) return el;
  }
  return null;
}

function findSendButton() {
  const candidates = [
    'button[aria-label="Send message"]',
    'button[aria-label="Send Message"]',
    'button[data-testid="send-button"]'
  ];
  for (const sel of candidates) {
    const el = document.querySelector(sel);
    if (el) return el;
  }
  const buttons = Array.from(document.querySelectorAll('button'));
  return buttons.find(b => (b.getAttribute('aria-label') || '').toLowerCase().includes('send')) || null;
}

// --- Auto-detect heuristic -------------------------------------------------
// No official API for "is the usage limit still active", so this guesses
// from visible page text + button state. Tune the regex below if it's
// misfiring — open devtools on claude.ai while rate-limited and check the
// exact wording claude.ai shows you.

const LIMIT_TEXT_PATTERN = /reached (your|the) (usage|message) limit|try again (later|in)|limit resets|usage limit/i;

function looksRateLimited() {
  const btn = findSendButton();
  const bodyText = document.body.innerText || '';
  const textSuggestsLimit = LIMIT_TEXT_PATTERN.test(bodyText);
  const buttonDisabled = btn ? (btn.disabled || btn.getAttribute('aria-disabled') === 'true') : false;
  // Require both signals to reduce false positives (e.g. button disabled
  // just because the input is empty).
  return textSuggestsLimit && buttonDisabled;
}

// Best-effort short excerpt of WHY it looks limited (e.g. Claude's own
// "Try again at 3:00 PM" wording), for display on the Workspace page —
// not used for any actual gating logic, so a bad extraction here just
// means a slightly-off status message, never a functional bug.
function getRateLimitDetail() {
  const bodyText = document.body.innerText || '';
  const match = LIMIT_TEXT_PATTERN.exec(bodyText);
  if (!match) return null;
  const start = Math.max(0, match.index - 20);
  const end = Math.min(bodyText.length, match.index + 160);
  return bodyText.slice(start, end).replace(/\s+/g, ' ').trim();
}

// --- Periodic status heartbeat (for the workspace's "who's rate limited
// right now" view) ----------------------------------------------------------
// Independent of any specific job — just keeps background.js (and, if
// linked, the workspace's other profiles) up to date on this tab's
// current state. Only reports when the status actually CHANGES, so an
// idle claude.ai tab isn't generating constant traffic.

let lastReportedLimitState = null;

function reportRateLimitStatusIfChanged() {
  const limited = looksRateLimited();
  if (limited === lastReportedLimitState) return;
  lastReportedLimitState = limited;
  browser.runtime.sendMessage({
    type: 'rate-limit-status',
    rateLimited: limited,
    detail: limited ? getRateLimitDetail() : null
  }).catch(() => { /* background page not ready yet — next check will retry */ });
}

setInterval(reportRateLimitStatusIfChanged, 30000);
// Also check shortly after the page finishes loading, rather than waiting
// a full 30s for the first report.
setTimeout(reportRateLimitStatusIfChanged, 3000);

// --- Periodic chat-list heartbeat (so a DIFFERENT linked profile's "send
// to" chat picker has something real to show — see migration-08.sql) -----
// Much lower frequency than the rate-limit heartbeat: the sidebar list
// changes far less often, and it's a bigger payload to ship over REST
// each time, so this only fires every 5 minutes and only when the list
// actually differs from what was last reported.

let lastReportedChatListSig = null;

function reportChatListIfChanged() {
  const chats = listChats();
  if (!chats.length) return; // sidebar not rendered yet, or not on claude.ai's main app shell
  const sig = chats.map(c => c.url).join('|');
  if (sig === lastReportedChatListSig) return;
  lastReportedChatListSig = sig;
  browser.runtime.sendMessage({ type: 'chat-list-status', chats: chats.slice(0, 100) })
    .catch(() => { /* background page not ready yet — next interval will retry */ });
}

setInterval(reportChatListIfChanged, 5 * 60000);
setTimeout(reportChatListIfChanged, 4000);

// --- Typing + sending ------------------------------------------------------

function setTextReactCompatible(el, text) {
  el.focus();
  document.execCommand('selectAll', false, null);
  document.execCommand('delete', false, null);
  const inserted = document.execCommand('insertText', false, text);
  if (!inserted) {
    el.textContent = text;
    el.dispatchEvent(new InputEvent('input', { bubbles: true, data: text, inputType: 'insertText' }));
  }
}

// Tracks sequence jobs currently mid-run in this tab, so a re-triggered
// alarm message for the same job (see check-and-maybe-run-sequence) doesn't
// start a second, overlapping run.
const activeSequenceJobIds = new Set();
function beginSequence(jobId) {
  if (activeSequenceJobIds.has(jobId)) return false;
  activeSequenceJobIds.add(jobId);
  return true;
}
function endSequence(jobId) { activeSequenceJobIds.delete(jobId); }

function reportResult(jobId, success, reason, notReady) {
  endSequence(jobId);
  browser.runtime.sendMessage({ type: 'send-result', jobId, success, reason, notReady });
}

function injectAndSend(jobId, prompt, attemptsLeft = 20) {
  const input = findInputBox();

  if (!input) {
    if (attemptsLeft > 0) {
      setTimeout(() => injectAndSend(jobId, prompt, attemptsLeft - 1), 500);
    } else {
      reportResult(jobId, false, 'input-box-not-found');
    }
    return;
  }

  setTextReactCompatible(input, prompt);

  setTimeout(() => {
    const btn = findSendButton();
    if (btn && !btn.disabled) {
      btn.click();
      // Optimistic: assume the click worked. claude.ai doesn't give an
      // easy synchronous confirmation, so this is the best signal we have.
      reportResult(jobId, true);
    } else if (attemptsLeft > 0) {
      setTimeout(() => injectAndSend(jobId, prompt, attemptsLeft - 1), 500);
    } else {
      reportResult(jobId, false, 'send-button-not-clickable');
    }
  }, 300);
}

function checkAndMaybeSend(jobId, prompt, skipTyping, attachments) {
  const input = findInputBox();
  if (!input) {
    reportResult(jobId, false, 'page-not-ready', /*notReady*/ true);
    return;
  }

  if (looksRateLimited()) {
    reportResult(jobId, false, 'still-rate-limited', /*notReady*/ true);
    return;
  }

  if (skipTyping) {
    clickSendOnly(jobId);
  } else {
    attachFilesToClaude(attachments, () => injectAndSend(jobId, prompt));
  }
}

// --- File attachments --------------------------------------------------
// FRAGILITY WARNING (same caveat as the rest of this file): relies on
// claude.ai exposing a plain <input type="file"> somewhere in the DOM for
// its own paperclip/upload button, and on it accepting a programmatically
// constructed FileList via DataTransfer. If claude.ai starts requiring a
// real user gesture to reveal that input, or changes to a custom
// drag-and-drop-only uploader with no underlying <input>, this silently
// no-ops (attachments just won't be attached — the prompt still sends).
//
// `attachments`: [{ name, type, size, dataUrl }] from popup.js's
// pendingAttachments (or a workspace_job's `attachments` column). `cb` is
// called once files are assigned (or immediately if there's nothing to
// attach) — callers should type/send only after this, so the upload has a
// moment to start before the message goes out.
function dataUrlToFile(att) {
  const [, base64] = att.dataUrl.split(',');
  const bin = atob(base64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new File([bytes], att.name, { type: att.type || 'application/octet-stream' });
}

function findFileInput() {
  return document.querySelector('input[type="file"]');
}

function attachFilesToClaude(attachments, cb) {
  if (!attachments || !attachments.length) { cb(); return; }
  const input = findFileInput();
  if (!input) {
    // No uploader found — proceed without attachments rather than block
    // the whole job on something we can't do anything about.
    cb();
    return;
  }
  try {
    const dt = new DataTransfer();
    attachments.forEach(att => dt.items.add(dataUrlToFile(att)));
    input.files = dt.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
    input.dispatchEvent(new Event('input', { bubbles: true }));
  } catch (err) {
    cb();
    return;
  }
  // No reliable "upload finished" signal to poll for (thumbnails/progress
  // bars are UI-version-specific), so just give it a moment scaled to how
  // much there is to upload before typing the prompt.
  const totalBytes = attachments.reduce((sum, a) => sum + (a.size || 0), 0);
  const waitMs = Math.min(6000, 800 + totalBytes / 20000);
  setTimeout(cb, waitMs);
}

// --- Multi-step scripted sequences with response-based branching -----------
// job.steps: [{ id, prompt, branches: [{ id, keywords: [str], nextStepId }],
//               defaultNextStepId }]
// After a step's prompt is sent, if that step has branches or a
// defaultNextStepId, we wait for Claude's reply to finish, check it against
// each branch's keyword list (case-insensitive substring match, first
// matching branch wins, checked in the order they're defined), and jump to
// that branch's nextStepId — falling back to defaultNextStepId if nothing
// matches, or ending the sequence if there's nowhere left to go.
//
// FRAGILITY WARNING: detecting "response finished" and reading the response
// text both rely on guessed selectors below, same caveat as the rate-limit
// heuristic above. If branching stops working, open devtools mid-response
// and update findAssistantTurns()/isGenerating().

function findAssistantTurns() {
  const selectors = [
    '[data-testid="conversation-turn"]',
    '[data-test-render-count]',
    'main [class*="message"]'
  ];
  for (const sel of selectors) {
    const nodes = Array.from(document.querySelectorAll(sel));
    if (nodes.length) return nodes;
  }
  return [];
}

function isGenerating() {
  return !!document.querySelector(
    'button[aria-label="Stop generating"], button[aria-label="Stop Response"], button[aria-label="Stop"]'
  );
}

function lastResponseText() {
  const turns = findAssistantTurns();
  if (!turns.length) return '';
  return (turns[turns.length - 1].innerText || '').trim();
}

function waitForResponseThen(cb, attemptsLeft = 240) {
  // Polls every 500ms for up to ~2 minutes for generation to finish.
  if (isGenerating()) {
    if (attemptsLeft > 0) {
      setTimeout(() => waitForResponseThen(cb, attemptsLeft - 1), 500);
    } else {
      cb(null); // timed out — caller should not guess a branch blindly
    }
    return;
  }
  // Small settle delay: the DOM can lag a beat after the stop button clears.
  setTimeout(() => cb(lastResponseText()), 400);
}

function matchBranch(step, responseText) {
  const lower = responseText.toLowerCase();
  for (const branch of (step.branches || [])) {
    const words = (branch.keywords || []).map(w => String(w).toLowerCase().trim()).filter(Boolean);
    if (words.some(w => lower.includes(w))) return branch.nextStepId;
  }
  return step.defaultNextStepId || null;
}

// Polls looksRateLimited() every 5s (up to ~6 hours) before letting an
// auto-detect sequence send its next step. Separate from waitForResponseThen
// (which waits for a reply to *finish*) — this waits for permission to send
// in the first place.
const RATE_LIMIT_RECHECK_MS = 5000;
const RATE_LIMIT_MAX_ATTEMPTS = 4320;

function waitUntilClearToSend(cb, attemptsLeft = RATE_LIMIT_MAX_ATTEMPTS) {
  if (!looksRateLimited()) { cb(true); return; }
  if (attemptsLeft <= 0) { cb(false); return; }
  setTimeout(() => waitUntilClearToSend(cb, attemptsLeft - 1), RATE_LIMIT_RECHECK_MS);
}

function runSequence(jobId, steps, stepId, isAutoDetect, attemptNumber = 1) {
  const step = (steps || []).find(s => s.id === stepId);
  if (!step) { reportResult(jobId, false, 'sequence-step-missing'); return; }

  const input = findInputBox();
  if (!input) {
    if (attemptNumber <= 20) {
      setTimeout(() => runSequence(jobId, steps, stepId, isAutoDetect, attemptNumber + 1), 500);
    } else {
      reportResult(jobId, false, 'input-box-not-found');
    }
    return;
  }

  const proceedToSend = () => {
    setTextReactCompatible(input, step.prompt);

    setTimeout(() => {
      const btn = findSendButton();
      if (!btn || btn.disabled) {
        if (attemptNumber <= 20) {
          setTimeout(() => runSequence(jobId, steps, stepId, isAutoDetect, attemptNumber + 1), 500);
        } else {
          reportResult(jobId, false, 'send-button-not-clickable');
        }
        return;
      }
      btn.click();

      const hasMoreSteps = (step.branches && step.branches.length) || step.defaultNextStepId;
      if (!hasMoreSteps) {
        reportResult(jobId, true); // last step in the script — done
        return;
      }

      waitForResponseThen((responseText) => {
        if (responseText === null) {
          // Couldn't confirm the reply actually finished — stop rather than
          // branch on a guess.
          reportResult(jobId, false, 'response-timed-out');
          return;
        }
        const nextId = matchBranch(step, responseText);
        if (!nextId) { reportResult(jobId, true); return; } // no branch matched, no default
        runSequence(jobId, steps, nextId, isAutoDetect, 1);
      });
    }, 300);
  };

  if (isAutoDetect) {
    // Gate every step on the usage limit, not just the first one — a limit
    // hit mid-sequence (e.g. after a long reply) shouldn't blow through on
    // the next send.
    waitUntilClearToSend((cleared) => {
      if (!cleared) { reportResult(jobId, false, 'still-rate-limited'); return; }
      proceedToSend();
    });
  } else {
    proceedToSend();
  }
}

// --- Click-only path: you've already typed the prompt yourself, this just
// finds the Send button and clicks it (falling back to an Enter keypress
// on the input if the button can't be located). Much less fragile than
// the typing path since there's no text-insertion step to break. ---------

function clickSendOnly(jobId, attemptsLeft = 20) {
  const btn = findSendButton();

  if (btn && !btn.disabled) {
    btn.click();
    reportResult(jobId, true);
    return;
  }

  // No usable button yet — try pressing Enter inside the input box instead,
  // which submits in most chat UIs (Shift+Enter is usually the newline
  // escape hatch, so a plain Enter is safe here).
  const input = findInputBox();
  if (input) {
    input.focus();
    const enterDown = new KeyboardEvent('keydown', {
      key: 'Enter', code: 'Enter', keyCode: 13, which: 13,
      bubbles: true, cancelable: true
    });
    input.dispatchEvent(enterDown);
    // If that didn't trigger navigation/send (page unchanged), we still
    // count this as our best-effort attempt for this poll and report
    // success optimistically — there's no reliable way to confirm a plain
    // keypress worked without inspecting the DOM afterward.
    setTimeout(() => {
      const btnNow = findSendButton();
      if (btnNow && !btnNow.disabled) {
        btnNow.click();
      }
      reportResult(jobId, true);
    }, 200);
    return;
  }

  if (attemptsLeft > 0) {
    setTimeout(() => clickSendOnly(jobId, attemptsLeft - 1), 500);
  } else {
    reportResult(jobId, false, 'send-button-not-found');
  }
}
