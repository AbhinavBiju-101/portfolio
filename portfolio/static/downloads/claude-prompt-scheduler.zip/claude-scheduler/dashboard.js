// dashboard.js — Queue page (departures-board layout)
// Reads/writes browser.storage.local "jobs", talks to background.js to
// reschedule/cancel alarms, and renders a live "next up" hero card plus
// the full board with search/filter and inline editing.

const heroSlot = document.getElementById('heroSlot');
const tableEl = document.getElementById('jobTable');
const bodyEl = document.getElementById('jobBody');
const emptyEl = document.getElementById('emptyState');
const searchEl = document.getElementById('searchInput');
const filterSeg = document.getElementById('filterSeg');
const railClock = document.getElementById('railClock');
const railDate = document.getElementById('railDate');
const railStats = document.getElementById('railStats');

let editingId = null;
let currentFilter = 'all';
let heroRenderedForId = null; // avoid re-triggering the reveal animation every poll

// --- Script editor state -------------------------------------------------
// While a job is being edited, its steps/target live here as a working
// copy (editState), synced from the DOM before any structural change and
// written back into the job on Save. This lets us re-render just the
// steps/target panels (e.g. after "add step") without losing focus in the
// rest of the row the way a full table re-render would.
// Step/branch editing itself (newStepId, renderStepsEditorHtml,
// syncStepsFromDOM, attachStepsEditorHandlers, ...) lives in
// steps-editor.js, shared with popup.js's quick-create flow.
let editState = null; // { advanced: bool, steps: [...], target: {...} }

function jobToEditState(job) {
  const target = job.target
    ? { ...job.target }
    : { mode: (job.newChat && !job.skipTyping) ? 'new' : 'current' };
  return {
    advanced: !!(job.steps && job.steps.length),
    steps: stepsFromJob(job), target
  };
}

// renderTargetEditorHtml/attachTargetEditorHandlers now live in
// target-editor.js, shared with popup.js's create flow (see that file for
// the target object shape). getChatsForRow() below is dashboard's
// fetcher, passed in so target-editor.js stays free of any
// browser.runtime specifics. Dashboard is a full page (not the cramped
// popup), so it asks for the rich chat list — see chat-picker.js's `rich`
// option and content.js's listChatsRich().
async function getChatsForRow() {
  return (await browser.runtime.sendMessage({ type: 'get-chat-list-rich' })) || [];
}

// Pulls current DOM values for prompt/keyword/select fields back into
// editState, so structural edits (add/remove step or branch) don't lose
// whatever the user just typed elsewhere in the row. Steps/branches
// themselves delegate to steps-editor.js; this just also grabs the
// simple-prompt textarea when not in advanced mode.
function syncStepsFromDOMWrapper(row) {
  if (!editState) return;
  syncStepsFromDOM(row, editState.steps);
}

function refreshEditorPanels(row) {
  const stepsContainer = row.querySelector('.steps-editor-container');
  if (stepsContainer) {
    stepsContainer.innerHTML = renderStepsEditorHtml(editState.steps);
    attachStepsEditorHandlers(stepsContainer, editState.steps, () => refreshEditorPanels(row));
  }
  const targetContainer = row.querySelector('.target-editor-container');
  if (targetContainer) {
    targetContainer.innerHTML = renderTargetEditorHtml(editState.target);
    attachTargetEditorHandlers(targetContainer, editState.target, () => refreshEditorPanels(row), getChatsForRow, /*richMode*/ true);
  }
}

async function getJobs() {
  const data = await browser.storage.local.get('jobs');
  return data.jobs || [];
}
async function saveJobs(jobs) {
  await browser.storage.local.set({ jobs });
}

function formatWhen(iso) {
  const d = new Date(iso);
  return d.toLocaleString(undefined, {
    weekday: 'short', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
  });
}
function isoToLocalInputValue(iso) {
  const d = new Date(iso);
  const pad = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function countdownParts(job) {
  if (job.mode === 'auto-detect') return { text: 'watching', unit: '' };
  const diffMs = new Date(job.whenISO).getTime() - Date.now();
  if (diffMs <= 0) return { text: 'due', unit: 'now' };
  const mins = Math.floor(diffMs / 60000);
  if (mins < 60) return { text: String(mins), unit: 'm' };
  const hrs = Math.floor(mins / 60);
  const remMins = mins % 60;
  if (hrs < 24) return { text: `${hrs}:${String(remMins).padStart(2,'0')}`, unit: 'h' };
  const days = Math.floor(hrs / 24);
  return { text: String(days), unit: 'd' };
}
function countdownShort(job) {
  const p = countdownParts(job);
  return p.text + (p.unit ? ' ' + p.unit : '');
}
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
function modeTag(job) {
  const cls = job.mode === 'auto-detect' ? 'auto' : 'fixed';
  const label = job.mode === 'auto-detect' ? 'AUTO-DETECT' : 'FIXED TIME';
  const chat = job.newChat ? `<span class="sep">·</span>NEW CHAT` : '';
  const manual = job.skipTyping ? `<span class="sep">·</span><span style="color:var(--blue);">CLICK ONLY</span>` : '';
  return `<span class="mode-tag ${cls}">${label}${chat}${manual}</span>`;
}

function applyFilters(jobs) {
  const q = searchEl.value.trim().toLowerCase();
  return jobs.filter(job => {
    if (currentFilter !== 'all' && job.mode !== currentFilter) return false;
    if (q && !job.prompt.toLowerCase().includes(q)) return false;
    return true;
  });
}

// --- Hero: the single next-to-fire job gets a distinct treatment ---------

function renderHero(jobs) {
  const fixedUpcoming = jobs
    .filter(j => j.mode === 'fixed')
    .sort((a, b) => new Date(a.whenISO) - new Date(b.whenISO))[0];

  if (!fixedUpcoming) {
    heroSlot.innerHTML = '';
    heroRenderedForId = null;
    return;
  }

  const isNew = heroRenderedForId !== fixedUpcoming.id;
  heroRenderedForId = fixedUpcoming.id;
  const cd = countdownParts(fixedUpcoming);

  heroSlot.innerHTML = `
    <div class="hero">
      <div class="hero-eyebrow">NEXT DEPARTURE</div>
      <div class="hero-prompt">${escapeHtml(fixedUpcoming.prompt)}</div>
      <div class="hero-meta">
        <div class="hero-countdown" style="${isNew ? '' : 'animation:none;'}">${cd.text}<span style="font-size:15px; color:var(--text-dim); margin-left:4px;">${cd.unit}</span></div>
        <div class="hero-when">${formatWhen(fixedUpcoming.whenISO)}${fixedUpcoming.newChat ? ' · new chat' : ''}</div>
      </div>
    </div>
  `;
}

// --- Main board ------------------------------------------------------------

async function render() {
  const allJobs = await getJobs();
  const jobs = applyFilters(allJobs);

  renderHero(allJobs);

  const pending = allJobs.length;
  const autoCount = allJobs.filter(j => j.mode === 'auto-detect').length;
  railStats.innerHTML = `<div><b>${pending}</b> pending</div><div><b>${autoCount}</b> auto-detect</div>`;

  if (allJobs.length === 0) {
    tableEl.style.display = 'none';
    emptyEl.style.display = 'block';
    emptyEl.innerHTML = 'Queue is empty. Nothing scheduled<span class="empty-cursor"></span>';
    return;
  }
  if (jobs.length === 0) {
    tableEl.style.display = 'none';
    emptyEl.style.display = 'block';
    emptyEl.innerHTML = 'No jobs match your search or filter<span class="empty-cursor"></span>';
    return;
  }

  tableEl.style.display = 'table';
  emptyEl.style.display = 'none';

  jobs.sort((a, b) => new Date(a.whenISO) - new Date(b.whenISO));
  bodyEl.innerHTML = '';
  const now = Date.now();

  for (const job of jobs) {
    const tr = document.createElement('tr');
    const isPast = job.mode === 'fixed' && new Date(job.whenISO).getTime() <= now;
    if (isPast) tr.classList.add('past');

    if (editingId === job.id) {
      const adv = editState.advanced;
      tr.innerHTML = `
        <td colspan="4">
          <div style="display:flex; gap:16px;">
            <div style="flex:0 0 220px;">
              <div class="edit-field">
                <div class="segmented edit-mode-seg">
                  <button type="button" data-value="fixed" class="${job.mode !== 'auto-detect' ? 'active' : ''}" data-accent="amber">Fixed</button>
                  <button type="button" data-value="auto-detect" class="${job.mode === 'auto-detect' ? 'active' : ''}" data-accent="blue">Auto-detect</button>
                </div>
              </div>
              <div class="edit-field">
                <input type="text" class="edit-when dt-picker-input" readonly
                  value="${escapeHtml(formatWhen(job.whenISO))}"
                  data-raw="${isoToLocalInputValue(job.whenISO)}">
              </div>
              <div class="edit-field edit-checkbox-row">
                <div class="switch ${job.skipTyping ? 'on' : ''}" id="editSkipTyping-${job.id}"></div>
                <span class="switch-label">Click Send only (already typed)</span>
              </div>
              <div class="edit-field edit-checkbox-row">
                <div class="switch ${adv ? 'on' : ''}" id="editAdvanced-${job.id}"></div>
                <span class="switch-label">Multi-step script + branching</span>
              </div>
              <div class="edit-field">
                <div class="section-label">Which chat</div>
                <div class="target-editor-container">${renderTargetEditorHtml(editState.target)}</div>
              </div>
            </div>
            <div style="flex:1;">
              <div class="edit-field simple-editor" style="display:${adv ? 'none' : 'block'};">
                <textarea class="simple-prompt edit-prompt">${escapeHtml(editState.steps[0].prompt)}</textarea>
              </div>
              <div class="edit-field steps-editor-container" style="display:${adv ? 'block' : 'none'};">
                ${renderStepsEditorHtml(editState.steps)}
              </div>
              <button class="btn btn-primary save-btn" data-id="${job.id}">Save</button>
              <button class="btn btn-ghost cancel-edit-btn" data-id="${job.id}">Cancel</button>
            </div>
          </div>
        </td>
      `;
    } else {
      const cd = countdownShort(job);
      const scriptTag = job.steps && job.steps.length > 1 ? `<span class="mode-tag" data-accent="purple">${job.steps.length}-STEP SCRIPT</span>` : '';
      const targetLabel = job.target && job.target.mode === 'specific'
        ? `<span class="sep">·</span>${escapeHtml(job.target.chatTitle || 'specific chat')}`
        : '';
      tr.innerHTML = `
        <td>
          <div class="cell-time">${job.mode === 'auto-detect' ? 'from ' + formatWhen(job.whenISO) : formatWhen(job.whenISO)}</div>
          ${modeTag(job)}
        </td>
        <td class="cell-countdown">${cd}</td>
        <td class="cell-prompt">${escapeHtml(job.prompt)}${scriptTag ? '<br>' + scriptTag : ''}${targetLabel}</td>
        <td class="actions-cell">
          ${jobHasPlaceholders(job) ? `<button class="btn edit-placeholders-btn" data-id="${job.id}" title="Fill in {{placeholders}} without hand-editing the prompt">Edit placeholders</button>` : ''}
          <button class="btn edit-btn" data-id="${job.id}">Edit</button>
          <button class="btn btn-danger delete-btn" data-id="${job.id}">Delete</button>
        </td>
      `;
    }
    bodyEl.appendChild(tr);
  }
  attachHandlers();
}

// --- Edit placeholders modal ---------------------------------------------
// A friendlier alternative to hand-editing {{variable}} tokens in the raw
// prompt text — mostly useful right after importing a Library prompt.
// Scans every prompt on the job (the simple prompt, or every step's
// prompt for a multi-step job) for {{name}} tokens and offers one field
// per unique name. Text values are substituted directly; for a
// file-flavoured placeholder (name contains "file"/"attachment"/"doc")
// picking a small text-like file inlines its contents, otherwise we can't
// truly attach it — see job.attachments (populated separately by the
// paperclip button in popup/compose) — so we substitute a plain marker
// noting the filename instead of pretending automation exists here.

const TEXTY_FILE_TYPES = /^(text\/|application\/json$)/;
const FILE_FIELD_HINT = /file|attachment|doc(ument)?|image|photo|csv|spreadsheet/i;

function jobPrompts(job) {
  return (job.steps && job.steps.length) ? job.steps.map(s => s.prompt) : [job.prompt];
}
function jobHasPlaceholders(job) {
  return jobPrompts(job).some(p => extractPlaceholders(p || '').length);
}
function jobPlaceholderNames(job) {
  const seen = new Set(); const out = [];
  jobPrompts(job).forEach(p => extractPlaceholders(p || '').forEach(n => { if (!seen.has(n)) { seen.add(n); out.push(n); } }));
  return out;
}
function substitutePlaceholders(text, values) {
  let out = text || '';
  for (const [name, value] of Object.entries(values)) {
    out = out.replace(new RegExp(`\\{\\{\\s*${name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*\\}\\}`, 'g'), value);
  }
  return out;
}

function readFileForPlaceholder(file) {
  return new Promise((resolve) => {
    if (TEXTY_FILE_TYPES.test(file.type) && file.size < 200 * 1024) {
      const r = new FileReader();
      r.onload = () => resolve(r.result);
      r.onerror = () => resolve(`[Attached: ${file.name} — couldn't read its contents, attach manually]`);
      r.readAsText(file);
    } else {
      resolve(`[Attached: ${file.name} — a ${(file.size / 1024).toFixed(0)}KB file. This extension can't auto-embed non-text files into the prompt text; attach it manually in claude.ai when this sends, or use the paperclip button to schedule it as a real attachment.]`);
    }
  });
}

function openPlaceholderModal(job) {
  const names = jobPlaceholderNames(job);
  const backdrop = document.createElement('div');
  backdrop.className = 'sched-modal-backdrop';
  backdrop.innerHTML = `
    <div class="sched-modal">
      <div class="sched-modal-head">
        <h3>Edit placeholders</h3>
        <button type="button" class="sched-modal-close">&times;</button>
      </div>
      <div class="sched-modal-body">
        ${names.map(n => `
          <div class="ph-field" data-name="${escapeHtml(n)}">
            <label>${escapeHtml(n)}</label>
            <textarea class="ph-value" rows="2" placeholder="Fill in &quot;${escapeHtml(n)}&quot;…"></textarea>
            ${FILE_FIELD_HINT.test(n) ? `
              <div class="ph-file-row">
                <input type="file" class="ph-file">
              </div>
              <div class="ph-file-note">Small text files (txt/md/csv/json) are inlined; anything else is noted by filename only.</div>
            ` : ''}
          </div>
        `).join('')}
      </div>
      <div class="sched-modal-foot">
        <button type="button" class="btn btn-ghost ph-cancel">Cancel</button>
        <button type="button" class="btn btn-primary ph-save">Fill in</button>
      </div>
    </div>
  `;
  document.body.appendChild(backdrop);

  backdrop.querySelectorAll('.ph-file').forEach(input => {
    input.addEventListener('change', async () => {
      const file = input.files[0];
      if (!file) return;
      const field = input.closest('.ph-field');
      const textarea = field.querySelector('.ph-value');
      textarea.value = await readFileForPlaceholder(file);
    });
  });

  function close() { backdrop.remove(); }
  backdrop.querySelector('.sched-modal-close').addEventListener('click', close);
  backdrop.querySelector('.ph-cancel').addEventListener('click', close);
  backdrop.addEventListener('click', (e) => { if (e.target === backdrop) close(); });

  backdrop.querySelector('.ph-save').addEventListener('click', async () => {
    const values = {};
    backdrop.querySelectorAll('.ph-field').forEach(field => {
      values[field.getAttribute('data-name')] = field.querySelector('.ph-value').value;
    });
    const jobs = await getJobs();
    const idx = jobs.findIndex(j => j.id === job.id);
    if (idx === -1) { close(); return; }
    if (jobs[idx].steps && jobs[idx].steps.length) {
      jobs[idx].steps = jobs[idx].steps.map(s => ({ ...s, prompt: substitutePlaceholders(s.prompt, values) }));
      jobs[idx].prompt = jobs[idx].steps[0].prompt;
    } else {
      jobs[idx].prompt = substitutePlaceholders(jobs[idx].prompt, values);
    }
    await saveJobs(jobs);
    close();
    render();
  });
}

function attachHandlers() {
  bodyEl.querySelectorAll('.edit-placeholders-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-id');
      const jobs = await getJobs();
      const job = jobs.find(j => j.id === id);
      if (job) openPlaceholderModal(job);
    });
  });
  bodyEl.querySelectorAll('.edit-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-id');
      const jobs = await getJobs();
      const job = jobs.find(j => j.id === id);
      if (!job) return;
      editingId = id;
      editState = jobToEditState(job);
      render();
    });
  });
  bodyEl.querySelectorAll('.cancel-edit-btn').forEach(btn => {
    btn.addEventListener('click', () => { editingId = null; editState = null; render(); });
  });
  bodyEl.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-id');
      const jobs = await getJobs();
      await saveJobs(jobs.filter(j => j.id !== id));
      browser.runtime.sendMessage({ type: 'cancel-job', id });
      render();
    });
  });

  // Segmented mode selector within an edit row
  bodyEl.querySelectorAll('.edit-mode-seg').forEach(seg => {
    seg.querySelectorAll('button').forEach(b => {
      b.addEventListener('click', () => {
        seg.querySelectorAll('button').forEach(x => x.classList.remove('active'));
        b.classList.add('active');
      });
    });
  });

  // Click-only switch within an edit row
  bodyEl.querySelectorAll('[id^="editSkipTyping-"]').forEach(sw => {
    sw.addEventListener('click', () => sw.classList.toggle('on'));
  });

  // Advanced script (multi-step + branching) switch within an edit row
  bodyEl.querySelectorAll('[id^="editAdvanced-"]').forEach(sw => {
    sw.addEventListener('click', () => {
      const row = sw.closest('tr');
      syncStepsFromDOMWrapper(row);
      sw.classList.toggle('on');
      editState.advanced = sw.classList.contains('on');
      row.querySelector('.simple-editor').style.display = editState.advanced ? 'none' : 'block';
      row.querySelector('.steps-editor-container').style.display = editState.advanced ? 'block' : 'none';
      if (editState.advanced) refreshEditorPanels(row); // pick up the simple textarea's text as step 1
    });
  });

  // Steps/target editor panels for whichever row is currently being edited
  bodyEl.querySelectorAll('tr').forEach(row => {
    const stepsContainer = row.querySelector('.steps-editor-container');
    if (stepsContainer && editState) attachStepsEditorHandlers(stepsContainer, editState.steps, () => refreshEditorPanels(row));
    const tc = row.querySelector('.target-editor-container');
    if (tc && editState) attachTargetEditorHandlers(tc, editState.target, () => refreshEditorPanels(row), getChatsForRow, /*richMode*/ true);
  });

  bodyEl.querySelectorAll('.save-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-id');
      const row = btn.closest('tr');
      syncStepsFromDOMWrapper(row);

      const activeModeBtn = row.querySelector('.edit-mode-seg button.active');
      const newMode = activeModeBtn ? activeModeBtn.getAttribute('data-value') : 'fixed';
      const newWhenVal = row.querySelector('.edit-when').dataset.raw;
      const skipTyping = row.querySelector(`[id^="editSkipTyping-"]`).classList.contains('on');

      const cleanSteps = editState.steps
        .map(s => ({ ...s, prompt: s.prompt.trim() }))
        .filter(s => s.prompt);
      if (!cleanSteps.length || !newWhenVal) return;

      const jobs = await getJobs();
      const idx = jobs.findIndex(j => j.id === id);
      if (idx === -1) return;

      jobs[idx].mode = newMode;
      jobs[idx].whenISO = new Date(newWhenVal).toISOString();
      jobs[idx].skipTyping = skipTyping;
      jobs[idx].retryCount = 0;
      jobs[idx].prompt = cleanSteps[0].prompt; // kept in sync for popup/history display
      jobs[idx].target = editState.target.mode === 'specific' && !editState.target.chatUrl
        ? { mode: 'current' } // "Choose chat" left unselected — fall back safely
        : editState.target;
      jobs[idx].newChat = jobs[idx].target.mode === 'new'; // legacy field, kept for old code paths

      if (editState.advanced && cleanSteps.length > 1) {
        jobs[idx].steps = cleanSteps;
      } else {
        delete jobs[idx].steps; // simple single-prompt job
      }

      await saveJobs(jobs);
      browser.runtime.sendMessage({ type: 'schedule-job', job: jobs[idx] });

      editingId = null;
      editState = null;
      render();
    });
  });
}

searchEl.addEventListener('input', render);
filterSeg.querySelectorAll('button').forEach(btn => {
  btn.addEventListener('click', () => {
    filterSeg.querySelectorAll('button').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentFilter = btn.getAttribute('data-value');
    render();
  });
});

// --- Rail clock --------------------------------------------------------

function tickClock() {
  const now = new Date();
  railClock.textContent = now.toLocaleTimeString(undefined, { hour12: false });
  railDate.textContent = now.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
}
tickClock();
setInterval(tickClock, 1000);

setInterval(() => { if (editingId === null) render(); }, 15000);

render();
