// datetime-picker.js
// Custom date/time entry that replaces native <input type="datetime-local">.
//
// Two ways to set a date, both fully custom (no native browser widgets):
//   1. Type straight into the field, segment by segment — mm, dd, yyyy,
//      hh, mm — just like the native control used to allow. Arrow
//      Left/Right move between segments, Up/Down bump the value, digits
//      type in, Backspace clears.
//   2. Click the calendar icon to open a small dropdown with a month grid
//      and a few quick-pick chips.
//
// Why not just use native <input type="datetime-local">? Because Firefox's
// native date/time picker renders in a separate OS-level overlay, which in
// an extension popup shows up BEHIND the popup itself — a known Firefox
// stacking bug with no CSS fix. Both entry methods here are ordinary page
// content we fully control, so neither can end up in the wrong layer.
//
// Usage: give a text input the class "dt-picker-input" — this module finds
// it (now, and later if it's added dynamically, e.g. dashboard's inline
// edit rows) and upgrades it automatically. No per-element setup needed.
//
// The input's DISPLAY value is the segmented "DD/MM/YYYY, HH:MM" string.
// The machine-readable value lives in el.dataset.raw as
// "YYYY-MM-DDTHH:MM" (same format the old native control produced), so
// existing code just reads el.dataset.raw.

(function () {
  // --- Segment layout -------------------------------------------------
  // Describes the fixed template the field always shows. Building the
  // segment offsets from this list (rather than hardcoding indices) means
  // the template can change shape without the math falling out of sync.
  const TEMPLATE = [
    { seg: 'day', width: 2, placeholder: 'dd' },
    { sep: '/' },
    { seg: 'month', width: 2, placeholder: 'mm' },
    { sep: '/' },
    { seg: 'year', width: 4, placeholder: 'yyyy' },
    { sep: ', ' },
    { seg: 'hour', width: 2, placeholder: '--' },
    { sep: ':' },
    { seg: 'minute', width: 2, placeholder: '--' },
    { sep: ' ' },
    { seg: 'ampm', width: 2, placeholder: '--' },
  ];
  const SEGMENTS = (() => {
    let pos = 0;
    const out = [];
    for (const part of TEMPLATE) {
      if (part.seg) {
        out.push({ name: part.seg, start: pos, end: pos + part.width, width: part.width, placeholder: part.placeholder });
        pos += part.width;
      } else {
        pos += part.sep.length;
      }
    }
    return out;
  })();
  const SEG_ORDER = SEGMENTS.map(s => s.name);
  // hour is 12-hour (1-12) here — state.ampm carries AM/PM separately, and
  // rawFromState()/stateFromRaw() do the 24-hour conversion at the
  // boundary, so every typing/clamping helper below only ever deals in
  // the 1-12 range a person actually types.
  const MIN = { month: 1, day: 1, year: 1970, hour: 1, minute: 0 };
  const MAX = { month: 12, day: 31, year: 9999, hour: 12, minute: 59 };
  // If the first digit typed is >= this, the segment can't possibly take a
  // second digit (e.g. month "4" can only mean April, never "4_"), so we
  // commit immediately instead of waiting for a second keystroke. (hour
  // isn't listed: with MAX.hour=12, the generic overflow check in
  // handleDigit already early-advances any first digit 2-9 on its own —
  // only "1" needs a second digit, for 10/11/12.)
  const EARLY_ADVANCE = { month: 2, day: 4, minute: 6 };

  function pad(n) { return String(n).padStart(2, '0'); }
  function daysInMonth(year, month) {
    if (!year || !month) return 31;
    return new Date(year, month, 0).getDate();
  }
  function clamp(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); }

  function segFor(name) { return SEGMENTS.find(s => s.name === name); }
  function segAtPos(pos) {
    for (const s of SEGMENTS) { if (pos <= s.end) return s; }
    return SEGMENTS[SEGMENTS.length - 1];
  }
  function nextSeg(name) {
    const i = SEG_ORDER.indexOf(name);
    return i < SEG_ORDER.length - 1 ? SEG_ORDER[i + 1] : null;
  }
  function prevSeg(name) {
    const i = SEG_ORDER.indexOf(name);
    return i > 0 ? SEG_ORDER[i - 1] : null;
  }

  function emptyState() { return { month: null, day: null, year: null, hour: null, minute: null, ampm: null }; }
  function isComplete(state) { return SEG_ORDER.every(n => state[n] != null); }

  // The only two places that ever touch 24-hour time — everything else
  // (typing, clamping, the wheel picker) works in 12-hour + state.ampm.
  function to12(h24) { return { hour: (h24 % 12) || 12, ampm: h24 < 12 ? 'AM' : 'PM' }; }
  function to24(hour12, ampm) { return (hour12 % 12) + (ampm === 'PM' ? 12 : 0); }

  function stateFromRaw(raw) {
    const s = emptyState();
    if (!raw) return s;
    const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec(raw);
    if (!m) return s;
    s.year = parseInt(m[1], 10);
    s.month = parseInt(m[2], 10);
    s.day = parseInt(m[3], 10);
    const h12 = to12(parseInt(m[4], 10));
    s.hour = h12.hour; s.ampm = h12.ampm;
    s.minute = parseInt(m[5], 10);
    return s;
  }
  function stateFromDate(date) {
    const h12 = to12(date.getHours());
    return {
      month: date.getMonth() + 1, day: date.getDate(), year: date.getFullYear(),
      hour: h12.hour, ampm: h12.ampm, minute: date.getMinutes()
    };
  }
  function rawFromState(state) {
    return `${state.year}-${pad(state.month)}-${pad(state.day)}T${pad(to24(state.hour, state.ampm))}:${pad(state.minute)}`;
  }

  // Renders the state to the segmented display string. `buf` (if given)
  // shows a segment mid-type: the digits typed so far, left-aligned,
  // padded out with the segment's placeholder characters — e.g. typing
  // "1" into the month segment shows "1m" rather than jumping straight to
  // a misleading "01".
  function render(state, buf) {
    let out = '';
    for (const part of TEMPLATE) {
      if (!part.seg) { out += part.sep; continue; }
      if (buf && buf.seg === part.seg) {
        out += (buf.str + part.placeholder.slice(buf.str.length)).slice(0, part.width);
      } else {
        const v = state[part.seg];
        out += v == null ? part.placeholder : String(v).padStart(part.width, '0');
      }
    }
    return out;
  }

  function formatDisplay(date) {
    return date.toLocaleString(undefined, {
      month: 'short', day: 'numeric', year: 'numeric',
      hour: '2-digit', minute: '2-digit'
    });
  }

  // --- Wiring a single input into a segmented editor -------------------

  // The field's true in-progress state lives on the element itself
  // (input._dtState), not in dataset.raw — dataset.raw is only ever
  // written once every segment is filled in, so it can't hold a
  // half-typed date without losing it on the next keystroke.
  function getState(input) {
    if (!input._dtState) input._dtState = stateFromRaw(input.dataset.raw);
    return input._dtState;
  }

  function commit(input, state) {
    input._dtState = state;
    input.value = render(state);
    if (isComplete(state)) {
      input.dataset.raw = rawFromState(state);
      input.dispatchEvent(new Event('change', { bubbles: true }));
    } else {
      delete input.dataset.raw;
    }
  }

  function activeSegName(input) {
    return input.dataset.activeSeg || SEG_ORDER[0]; // first segment, whatever the template order is
  }
  function selectSegment(input, name) {
    const seg = segFor(name);
    input.dataset.activeSeg = name;
    input.setSelectionRange(seg.start, seg.end);
  }

  function handleDigit(input, digit) {
    const name = activeSegName(input);
    if (name === 'ampm') return; // AM/PM isn't digit-typed — see handleAmPmKey
    const state = getState(input);
    const seg = segFor(name);
    const sameSeg = input._dtBufSeg === name;
    const buf = (sameSeg ? input._dtBuf : '') + digit;
    const num = parseInt(buf, 10);
    const max = name === 'day' ? daysInMonth(state.year, state.month) : MAX[name];

    const wouldOverflowNext = buf.length < seg.width && (num * 10) > max;
    const hitWidth = buf.length >= seg.width;
    const earlyAdvance = buf.length === 1 && EARLY_ADVANCE[name] != null && digit.charCodeAt(0) - 48 >= EARLY_ADVANCE[name];

    if (hitWidth || wouldOverflowNext || earlyAdvance) {
      state[name] = clamp(num, MIN[name], max);
      input._dtBuf = '';
      input._dtBufSeg = null;
      commit(input, state);
      const nxt = nextSeg(name);
      selectSegment(input, nxt || name);
    } else {
      input._dtBuf = buf;
      input._dtBufSeg = name;
      input.value = render(state, { seg: name, str: buf });
      selectSegment(input, name);
    }
  }

  // 'A'/'P' keys while the AM/PM segment is active — the equivalent of
  // handleDigit(), just for a two-value segment instead of a numeric one.
  function handleAmPmKey(input, letter) {
    const state = getState(input);
    state.ampm = letter === 'A' ? 'AM' : 'PM';
    input._dtBuf = ''; input._dtBufSeg = null;
    commit(input, state);
    selectSegment(input, 'ampm');
  }

  function handleBackspace(input) {
    const name = activeSegName(input);
    if (input._dtBufSeg === name && input._dtBuf) {
      input._dtBuf = input._dtBuf.slice(0, -1);
      const state = getState(input);
      input.value = render(state, { seg: name, str: input._dtBuf });
      selectSegment(input, name);
      return;
    }
    const state = getState(input);
    if (state[name] != null) {
      state[name] = null;
      input._dtBuf = ''; input._dtBufSeg = null;
      commit(input, state);
      selectSegment(input, name);
    } else {
      const prev = prevSeg(name);
      if (prev) selectSegment(input, prev);
    }
  }

  function handleStep(input, delta) {
    const name = activeSegName(input);
    const state = getState(input);
    if (name === 'ampm') {
      state.ampm = state.ampm === 'AM' ? 'PM' : 'AM';
      input._dtBuf = ''; input._dtBufSeg = null;
      commit(input, state);
      selectSegment(input, name);
      return;
    }
    const max = name === 'day' ? daysInMonth(state.year, state.month) : MAX[name];
    const base = state[name] != null ? state[name] : (MIN[name] - delta);
    let v = base + delta;
    const span = max - MIN[name] + 1;
    v = ((v - MIN[name]) % span + span) % span + MIN[name];
    state[name] = v;
    input._dtBuf = ''; input._dtBufSeg = null;
    commit(input, state);
    selectSegment(input, name);
  }

  function initInput(input) {
    if (input.dataset.dtWired) return;
    input.dataset.dtWired = '1';
    input.readOnly = false;
    input.autocomplete = 'off';
    input.spellcheck = false;
    input.inputMode = 'numeric';
    input.classList.add('dt-seg-input');
    input.value = render(getState(input));

    // Wrap so a calendar-icon button can sit inside the field without
    // disturbing surrounding layout/width rules that already target the
    // bare input (e.g. `#when { width: 100%; }`).
    if (!input.parentElement.classList.contains('dt-input-wrap')) {
      const wrap = document.createElement('span');
      wrap.className = 'dt-input-wrap';
      input.parentNode.insertBefore(wrap, input);
      wrap.appendChild(input);
      const calBtn = document.createElement('button');
      calBtn.type = 'button';
      calBtn.className = 'dt-cal-btn';
      calBtn.setAttribute('aria-label', 'Open calendar');
      calBtn.tabIndex = -1;
      calBtn.innerHTML = '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.3"><rect x="1.5" y="2.8" width="13" height="11.5" rx="1.5"/><path d="M1.5 6.3h13M4.5 1.3v3M11.5 1.3v3"/></svg>';
      wrap.appendChild(calBtn);
      calBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        openPickerFor(input);
      });
    }

    input.addEventListener('keydown', (e) => {
      if (e.key >= '0' && e.key <= '9') { e.preventDefault(); handleDigit(input, e.key); return; }
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        const p = prevSeg(activeSegName(input));
        input._dtBuf = ''; input._dtBufSeg = null;
        if (p) selectSegment(input, p);
        return;
      }
      if (e.key === 'ArrowRight') {
        e.preventDefault();
        const n = nextSeg(activeSegName(input));
        input._dtBuf = ''; input._dtBufSeg = null;
        if (n) selectSegment(input, n);
        return;
      }
      if (e.key === 'ArrowUp') { e.preventDefault(); handleStep(input, 1); return; }
      if (e.key === 'ArrowDown') { e.preventDefault(); handleStep(input, -1); return; }
      if ((e.key === 'a' || e.key === 'A' || e.key === 'p' || e.key === 'P') && activeSegName(input) === 'ampm') {
        e.preventDefault(); handleAmPmKey(input, e.key.toUpperCase()); return;
      }
      if (e.key === 'Backspace' || e.key === 'Delete') { e.preventDefault(); handleBackspace(input); return; }
      if (e.key === 'Escape') { input.blur(); return; }
      if (e.key === 'Tab') return;
      if (e.ctrlKey || e.metaKey) return; // allow copy/select-all/etc.
      // Block any other character from being typed into the field —
      // it's a real text input under the hood, but the display is a
      // fixed template we render ourselves, so free-form text would
      // desync it.
      e.preventDefault();
    });

    input.addEventListener('paste', (e) => e.preventDefault());
    input.addEventListener('click', () => {
      selectSegment(input, segAtPos(input.selectionStart || 0).name);
    });
    input.addEventListener('focus', () => {
      if (document.activeElement === input && input.selectionStart === input.selectionEnd) {
        selectSegment(input, activeSegName(input));
      }
    });
  }

  function scan(root) {
    (root.querySelectorAll ? root.querySelectorAll('.dt-picker-input') : []).forEach(initInput);
  }

  // --- Calendar dropdown (mouse-driven date pick + quick-pick chips) ---

  let openPanel = null;
  let openInput = null;

  function closePanel() {
    if (openPanel) {
      openPanel.remove();
      openPanel = null;
      openInput = null;
    }
  }

  function buildPanel(input) {
    let state = getState(input);
    const seed = isComplete(state) ? new Date(rawFromState(state)) : (() => {
      const d = new Date(); d.setMinutes(d.getMinutes() + 5, 0, 0); return d;
    })();
    if (!isComplete(state)) state = stateFromDate(seed);

    let viewYear = seed.getFullYear();
    let viewMonth = seed.getMonth();

    const panel = document.createElement('div');
    panel.className = 'dt-panel';
    panel.innerHTML = `
      <div class="dt-time-row">
        <label>Time</label>
        <div class="dt-wheel-row">
          <div class="dt-wheel dt-hour-wheel" tabindex="0"><div class="dt-wheel-center-line"></div></div>
          <span class="dt-colon">:</span>
          <div class="dt-wheel dt-minute-wheel" tabindex="0"><div class="dt-wheel-center-line"></div></div>
          <div class="dt-wheel dt-ampm-wheel" tabindex="0"><div class="dt-wheel-center-line"></div></div>
        </div>
      </div>
      <div class="dt-header">
        <button type="button" class="dt-nav" data-dir="-1">&#8249;</button>
        <div class="dt-month-label"></div>
        <button type="button" class="dt-nav" data-dir="1">&#8250;</button>
      </div>
      <div class="dt-weekdays">
        ${['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map(d => `<span>${d}</span>`).join('')}
      </div>
      <div class="dt-grid"></div>
      <div class="dt-chips">
        <button type="button" class="dt-chip" data-offset="15m">+15m</button>
        <button type="button" class="dt-chip" data-offset="1h">+1h</button>
        <button type="button" class="dt-chip" data-offset="tomorrow9">Tomorrow 9am</button>
      </div>
      <div class="dt-footer">
        <button type="button" class="btn btn-ghost dt-cancel">Cancel</button>
        <button type="button" class="btn btn-primary dt-set">Set</button>
      </div>
    `;

    const monthLabel = panel.querySelector('.dt-month-label');
    const grid = panel.querySelector('.dt-grid');
    const hourWheel = panel.querySelector('.dt-hour-wheel');
    const minuteWheel = panel.querySelector('.dt-minute-wheel');
    const ampmWheel = panel.querySelector('.dt-ampm-wheel');

    // Custom scroll-snap "wheel" instead of a native <select size> — lets
    // us fade every row except the centered value and its immediate
    // neighbours (an iOS-style picker look), which a native <select> has
    // no styling hook for. ROW_H must match .dt-wheel-item's height in
    // styles.css. Takes a list of {value, label} rather than assuming a
    // numeric 0..max range, so the same function builds the hour wheel
    // (1-12), the minute wheel (00-59), and the two-row AM/PM wheel.
    const ROW_H = 36;
    function buildWheel(el, items, selected, onPick) {
      el.querySelectorAll('.dt-wheel-item, .dt-wheel-pad').forEach(n => n.remove());
      const pad = () => { const p = document.createElement('div'); p.className = 'dt-wheel-pad'; return p; };
      el.appendChild(pad());
      items.forEach((it, idx) => {
        const item = document.createElement('div');
        item.className = 'dt-wheel-item';
        item.textContent = it.label;
        item.dataset.index = String(idx);
        item.addEventListener('click', () => { el.scrollTo({ top: idx * ROW_H, behavior: 'smooth' }); el._value = it.value; onPick(it.value); });
        el.appendChild(item);
      });
      el.appendChild(pad());
      el._items = items;
      el._value = selected;
      const selIdx = Math.max(0, items.findIndex(it => it.value === selected));
      el.scrollTop = selIdx * ROW_H;
      updateWheelFade(el);
      el.addEventListener('scroll', () => {
        clearTimeout(el._settleTimer);
        updateWheelFade(el);
        // Debounced snap-settle: once scrolling stops, lock to the
        // nearest row and report its value, same as a native select's
        // "closest option wins" behavior.
        el._settleTimer = setTimeout(() => {
          const idx = clamp(Math.round(el.scrollTop / ROW_H), 0, items.length - 1);
          el._value = items[idx].value;
          onPick(el._value);
        }, 120);
      });
      // Type-to-jump: with a wheel focused, typing digits (hour/minute) or
      // "A"/"P" (AM/PM) scrolls straight to the matching row — the same
      // idea as handleDigit() above for the segmented text field, just
      // driving a scroll position instead of a state object. Digits are
      // buffered briefly so "1" then "2" within the window reaches 12
      // rather than jumping to 1 and then to 2.
      el.addEventListener('keydown', (e) => {
        if (e.key === 'Tab' || e.key === 'Escape') return; // let these fall through to normal navigation
        e.preventDefault();
        if (/^[0-9]$/.test(e.key)) {
          const sameField = el._typeBuf && (Date.now() - el._typeBufAt) < 700;
          const buf = (sameField ? el._typeBuf : '') + e.key;
          el._typeBuf = buf; el._typeBufAt = Date.now();
          const num = parseInt(buf, 10);
          let idx = items.findIndex(it => it.value === num);
          if (idx === -1) idx = items.findIndex(it => it.value === parseInt(e.key, 10));
          if (idx !== -1) {
            el.scrollTo({ top: idx * ROW_H, behavior: 'smooth' });
            el._value = items[idx].value;
            onPick(el._value);
          }
        } else if (e.key === 'a' || e.key === 'A' || e.key === 'p' || e.key === 'P') {
          const want = e.key.toUpperCase() === 'A' ? 'AM' : 'PM';
          const idx = items.findIndex(it => it.value === want);
          if (idx !== -1) {
            el.scrollTo({ top: idx * ROW_H, behavior: 'smooth' });
            el._value = items[idx].value;
            onPick(el._value);
          }
        } else if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
          const curIdx = items.findIndex(it => it.value === el._value);
          const nextIdx = clamp(curIdx + (e.key === 'ArrowUp' ? -1 : 1), 0, items.length - 1);
          el.scrollTo({ top: nextIdx * ROW_H, behavior: 'smooth' });
          el._value = items[nextIdx].value;
          onPick(el._value);
        }
      });
    }
    function pad2(n) { return String(n).padStart(2, '0'); }
    function updateWheelFade(el) {
      const centerIdx = el.scrollTop / ROW_H;
      el.querySelectorAll('.dt-wheel-item').forEach(item => {
        const idx = parseInt(item.dataset.index, 10);
        const dist = Math.abs(idx - centerIdx);
        item.classList.toggle('center', dist < 0.5);
        item.classList.toggle('near', dist >= 0.5 && dist < 1.5);
      });
    }
    const hourItems = Array.from({ length: 12 }, (_, i) => ({ value: i + 1, label: pad2(i + 1) }));
    const minuteItems = Array.from({ length: 60 }, (_, i) => ({ value: i, label: pad2(i) }));
    const ampmItems = [{ value: 'AM', label: 'AM' }, { value: 'PM', label: 'PM' }];
    buildWheel(hourWheel, hourItems, state.hour, (v) => { hourWheel._value = v; });
    buildWheel(minuteWheel, minuteItems, state.minute, (v) => { minuteWheel._value = v; });
    buildWheel(ampmWheel, ampmItems, state.ampm, (v) => { ampmWheel._value = v; });

    function currentTimeVals() {
      return {
        hour: clamp(hourWheel._value != null ? hourWheel._value : 12, 1, 12),
        minute: clamp(minuteWheel._value != null ? minuteWheel._value : 0, 0, 59),
        ampm: ampmWheel._value === 'PM' ? 'PM' : 'AM'
      };
    }

    function renderGrid() {
      monthLabel.textContent = new Date(viewYear, viewMonth, 1)
        .toLocaleString(undefined, { month: 'long', year: 'numeric' });

      grid.innerHTML = '';
      const firstOfMonth = new Date(viewYear, viewMonth, 1);
      const startOffset = firstOfMonth.getDay();
      const days = new Date(viewYear, viewMonth + 1, 0).getDate();
      const today = new Date();

      for (let i = 0; i < startOffset; i++) grid.appendChild(document.createElement('span'));
      for (let day = 1; day <= days; day++) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'dt-day';
        btn.textContent = day;

        const isSelected = state.year === viewYear && state.month === viewMonth + 1 && state.day === day;
        const isToday = today.getFullYear() === viewYear && today.getMonth() === viewMonth && today.getDate() === day;
        if (isSelected) btn.classList.add('selected');
        if (isToday) btn.classList.add('today');

        btn.addEventListener('click', () => {
          state.year = viewYear; state.month = viewMonth + 1; state.day = day;
          renderGrid();
        });
        grid.appendChild(btn);
      }
    }

    panel.querySelectorAll('.dt-nav').forEach(btn => {
      btn.addEventListener('click', () => {
        viewMonth += parseInt(btn.dataset.dir, 10);
        if (viewMonth < 0) { viewMonth = 11; viewYear--; }
        if (viewMonth > 11) { viewMonth = 0; viewYear++; }
        renderGrid();
      });
    });

    panel.querySelector('.dt-cancel').addEventListener('click', closePanel);
    panel.querySelector('.dt-set').addEventListener('click', () => {
      const t = currentTimeVals();
      state.hour = t.hour; state.minute = t.minute; state.ampm = t.ampm;
      if (state.year == null) { state.year = viewYear; state.month = viewMonth + 1; state.day = seed.getDate(); }
      commit(input, state);
      closePanel();
    });

    panel.querySelectorAll('.dt-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const now = new Date();
        const offset = chip.dataset.offset;
        let result;
        if (offset === '15m') result = new Date(now.getTime() + 15 * 60000);
        else if (offset === '1h') result = new Date(now.getTime() + 60 * 60000);
        else if (offset === 'tomorrow9') {
          result = new Date(now);
          result.setDate(result.getDate() + 1);
          result.setHours(9, 0, 0, 0);
        }
        commit(input, stateFromDate(result));
        closePanel();
      });
    });

    renderGrid();
    return panel;
  }

  function positionPanel(panel, input) {
    document.body.appendChild(panel);
    const rect = input.parentElement.getBoundingClientRect(); // .dt-input-wrap, matches visible field
    const panelRect = panel.getBoundingClientRect();

    // Open ABOVE the field by default — in a small extension popup the
    // field is often low enough that a panel opening downward runs past
    // the bottom of the popup and gets clipped. Fall back to opening
    // below only when there's genuinely more room there.
    const spaceAbove = rect.top;
    const spaceBelow = window.innerHeight - rect.bottom;
    const openAbove = spaceAbove >= panelRect.height + 8 || spaceAbove >= spaceBelow;

    let top = openAbove ? rect.top - panelRect.height - 6 : rect.bottom + 6;
    let left = rect.left;

    const maxLeft = window.innerWidth - panelRect.width - 8;
    if (left > maxLeft) left = Math.max(8, maxLeft);
    top = clamp(top, 8, Math.max(8, window.innerHeight - panelRect.height - 8));

    panel.style.top = top + 'px';
    panel.style.left = left + 'px';
  }

  function openPickerFor(input) {
    if (openInput === input) { closePanel(); return; }
    closePanel();
    const panel = buildPanel(input);
    panel.style.position = 'fixed';
    panel.style.visibility = 'hidden';
    document.body.appendChild(panel);
    positionPanel(panel, input);
    panel.style.visibility = 'visible';
    openPanel = panel;
    openInput = input;
  }

  document.addEventListener('click', (e) => {
    if (!openPanel) return;
    // composedPath(), not .contains(e.target) — a day click rebuilds the
    // grid (renderGrid() replaces grid.innerHTML) before this listener
    // runs, so e.target is often already detached from the document by
    // the time it bubbles here. .contains() on a detached node is always
    // false, which was closing the panel on every day click before the
    // click could ever reach the Set button. composedPath() is a fixed
    // snapshot taken when the event was dispatched, so it's unaffected by
    // any DOM changes an earlier handler made in the meantime.
    const path = e.composedPath();
    const clickedInsidePanel = path.includes(openPanel);
    const clickedCalBtn = path.some(el => el.classList && el.classList.contains('dt-cal-btn'));
    if (!clickedInsidePanel && !clickedCalBtn) closePanel();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closePanel();
  });

  // Pick up inputs already in the DOM, and any added later (e.g. dashboard
  // re-rendering a row into edit mode).
  scan(document);
  new MutationObserver((mutations) => {
    for (const m of mutations) {
      m.addedNodes.forEach(node => {
        if (node.nodeType !== 1) return;
        if (node.matches && node.matches('.dt-picker-input')) initInput(node);
        scan(node);
      });
    }
  }).observe(document.body, { childList: true, subtree: true });

  // Exposed helpers for popup.js / dashboard.js
  window.dtPicker = {
    clear(input) {
      input._dtState = emptyState();
      input.value = render(input._dtState);
      delete input.dataset.raw;
      input._dtBuf = ''; input._dtBufSeg = null;
    },
    setFromISO(input, iso) {
      commit(input, stateFromDate(new Date(iso)));
    }
  };
})();
