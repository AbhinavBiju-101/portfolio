// history.js — History page (console layout)
// Renders the "history" array written by background.js, with filter pills
// and the same LED-status language used on the queue page.

const tableEl = document.getElementById('historyTable');
const bodyEl = document.getElementById('historyBody');
const emptyEl = document.getElementById('emptyState');
const clearBtn = document.getElementById('clearBtn');
const filterSeg = document.getElementById('filterSeg');
const railClock = document.getElementById('railClock');
const railDate = document.getElementById('railDate');
const railStats = document.getElementById('railStats');

let currentFilter = 'all';

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
function formatAt(iso) {
  const d = new Date(iso);
  return d.toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

const LED_CLASS = { sent: 'led-sent', failed: 'led-failed', retrying: 'led-retry', missed: 'led-missed' };
const ROW_CLASS = { sent: 'status-sent', failed: 'status-failed', retrying: 'status-retry', missed: 'status-missed' };
const LABEL = { sent: 'Sent', failed: 'Failed', retrying: 'Retrying', missed: 'Missed' };

async function render() {
  const data = await browser.storage.local.get('history');
  const history = data.history || [];

  const counts = { sent: 0, failed: 0, retrying: 0, missed: 0 };
  history.forEach(e => { if (counts[e.status] !== undefined) counts[e.status]++; });
  railStats.innerHTML = `<div><b>${counts.sent}</b> sent</div><div><b>${counts.failed}</b> failed</div>`;

  const filtered = currentFilter === 'all' ? history : history.filter(e => e.status === currentFilter);

  if (history.length === 0) {
    tableEl.style.display = 'none';
    emptyEl.style.display = 'block';
    emptyEl.innerHTML = 'No history yet<span class="empty-cursor"></span>';
    return;
  }
  if (filtered.length === 0) {
    tableEl.style.display = 'none';
    emptyEl.style.display = 'block';
    emptyEl.innerHTML = 'Nothing matches this filter<span class="empty-cursor"></span>';
    return;
  }

  tableEl.style.display = 'table';
  emptyEl.style.display = 'none';
  bodyEl.innerHTML = '';

  for (const entry of filtered) {
    const tr = document.createElement('tr');
    tr.className = ROW_CLASS[entry.status] || '';
    tr.innerHTML = `
      <td class="cell-time">${formatAt(entry.at)}</td>
      <td><span class="led ${LED_CLASS[entry.status] || ''}"></span><span class="status-text">${LABEL[entry.status] || entry.status}</span></td>
      <td class="cell-prompt">
        ${escapeHtml(entry.prompt)}
        ${entry.detail ? `<div style="color:var(--text-faint); font-size:11px; margin-top:4px;">${escapeHtml(entry.detail)}</div>` : ''}
      </td>
    `;
    bodyEl.appendChild(tr);
  }
}

filterSeg.querySelectorAll('button').forEach(btn => {
  btn.addEventListener('click', () => {
    filterSeg.querySelectorAll('button').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentFilter = btn.getAttribute('data-value');
    render();
  });
});

clearBtn.addEventListener('click', async () => {
  await browser.storage.local.set({ history: [] });
  browser.runtime.sendMessage({ type: 'clear-history' });
  render();
});

function tickClock() {
  const now = new Date();
  railClock.textContent = now.toLocaleTimeString(undefined, { hour12: false });
  railDate.textContent = now.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
}
tickClock();
setInterval(tickClock, 1000);

render();
