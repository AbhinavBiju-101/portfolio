// library.js — browsing the bundled prompt marketplace and managing the
// user's personal saved-prompts library.
// Storage: browser.storage.local["userLibrary"] = array of snippet ids.

const searchEl = document.getElementById('searchInput');
const viewSeg = document.getElementById('viewSeg');
const chipsEl = document.getElementById('categoryChips');
const gridEl = document.getElementById('cardGrid');
const emptyEl = document.getElementById('emptyState');
const overlay = document.getElementById('detailOverlay');
const overlayBody = document.getElementById('overlayBody');
const overlayClose = document.getElementById('overlayClose');
const railClock = document.getElementById('railClock');
const railDate = document.getElementById('railDate');
const myLibCount = document.getElementById('myLibCount');
const totalLibCount = document.getElementById('totalLibCount');

let currentView = 'all';
let currentCategory = 'all';
let userLibraryIds = [];
let currentSbUser = null;
let loadError = null;
let ratingSummaries = {}; // snippet_id -> { avg, count }
let personalTemplates = []; // local-only, never touches Supabase

// --- Personal templates (browser.storage.local only) -----------------------

async function getPersonalTemplates() {
  const data = await browser.storage.local.get('personalTemplates');
  return data.personalTemplates || [];
}
async function savePersonalTemplates(list) {
  personalTemplates = list;
  await browser.storage.local.set({ personalTemplates: list });
}
// Personal templates reuse the catalog card/detail rendering by shaping
// themselves like a snippet — keeps cardHtml()/openDetail() from needing a
// parallel implementation just for this.
function templateAsSnippet(t) {
  return {
    id: t.id, title: t.title, category: 'Personal', tags: t.tags || [],
    description: t.prompt, descriptionFormat: 'markdown',
    examples: [{ label: 'Prompt', prompt: t.prompt }],
    isPersonal: true
  };
}

async function isSaved(id) {
  return userLibraryIds.includes(id);
}
async function toggleSaved(id) {
  const wasSaved = userLibraryIds.includes(id);
  try {
    if (wasSaved) {
      await removeFromLibrary(id);
      userLibraryIds = userLibraryIds.filter(x => x !== id);
    } else {
      await addToLibrary(id);
      userLibraryIds.push(id);
    }
  } catch (err) {
    alert(err.message);
  }
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}

// --- Tiny markdown renderer --------------------------------------------
// Deliberately minimal: headings, bold/italic, inline code, links, and
// paragraph/bullet-list breaks. Snippet content ships with the extension
// (not user-submitted), so no sanitization concerns beyond basic escaping.
function renderMarkdown(md) {
  const escaped = escapeHtml(md);
  const lines = escaped.split(/\r?\n/);
  let html = '';
  let inList = false;
  for (const line of lines) {
    const trimmed = line.trim();
    if (/^#{1,3}\s+/.test(trimmed)) {
      if (inList) { html += '</ul>'; inList = false; }
      const level = trimmed.match(/^#{1,3}/)[0].length;
      html += `<h${level + 2}>${inlineMd(trimmed.replace(/^#{1,3}\s+/, ''))}</h${level + 2}>`;
    } else if (/^[-*]\s+/.test(trimmed)) {
      if (!inList) { html += '<ul>'; inList = true; }
      html += `<li>${inlineMd(trimmed.replace(/^[-*]\s+/, ''))}</li>`;
    } else if (trimmed === '') {
      if (inList) { html += '</ul>'; inList = false; }
    } else {
      if (inList) { html += '</ul>'; inList = false; }
      html += `<p>${inlineMd(trimmed)}</p>`;
    }
  }
  if (inList) html += '</ul>';
  return html;
}
function inlineMd(text) {
  return text
    .replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')
    .replace(/(?<!\*)\*(?!\*)(.+?)\*(?!\*)/g, '<i>$1</i>')
    .replace(/`(.+?)`/g, '<code>$1</code>')
    .replace(/\[(.+?)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
}
function renderRich(snippet, field) {
  const text = snippet[field];
  if (!text) return '';
  // Each rich-text field has its own format column (descriptionFormat /
  // recommendedContextFormat) rather than one shared "format" — a snippet
  // could reasonably want e.g. a markdown description but pre-built HTML
  // for recommended context, or vice versa.
  const fmt = snippet[field + 'Format'];
  return fmt === 'html' ? text : renderMarkdown(text);
}
function plainPreview(snippet, maxLen = 130) {
  const text = (snippet.description || '').replace(/[#*`_]/g, '').replace(/\s+/g, ' ').trim();
  return text.length > maxLen ? text.slice(0, maxLen).trim() + '…' : text;
}

// --- Filtering -----------------------------------------------------------

let currentSort = 'newest'; // 'newest' | 'trending' | 'top-rated'
let workspaceShared = []; // loaded lazily when the Workspace view is first opened

function filteredSnippets() {
  const q = searchEl.value.trim().toLowerCase();
  if (currentView === 'personal') {
    return personalTemplates.map(templateAsSnippet).filter(s => {
      if (!q) return true;
      const haystack = [s.title, s.description, ...(s.tags || [])].join(' ').toLowerCase();
      return haystack.includes(q);
    });
  }
  if (currentView === 'workspace') {
    return workspaceShared.map(sharedAsSnippet).filter(s => {
      if (!q) return true;
      const haystack = [s.title, s.description, ...(s.tags || [])].join(' ').toLowerCase();
      return haystack.includes(q);
    });
  }
  let items = SNIPPET_LIBRARY.filter(s => {
    if (currentView === 'mine' && !userLibraryIds.includes(s.id)) return false;
    if (currentView === 'submissions' && !(currentSbUser && s.createdBy === currentSbUser.id)) return false;
    if (currentView === 'all' || currentView === 'mine') {
      if (currentCategory !== 'all' && s.category !== currentCategory) return false;
    }
    if (!q) return true;
    const haystack = [s.title, s.description, s.category, ...(s.tags || [])].join(' ').toLowerCase();
    return haystack.includes(q);
  });
  if (currentView === 'all' || currentView === 'mine') {
    if (currentSort === 'trending') {
      items = [...items].sort((a, b) => (b.usageCount || 0) - (a.usageCount || 0));
    } else if (currentSort === 'top-rated') {
      items = [...items].sort((a, b) => (ratingSummaries[b.id]?.avg || 0) - (ratingSummaries[a.id]?.avg || 0));
    } else {
      items = [...items].sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
    }
  }
  return items;
}

// Workspace shared prompts are plain rows (title/prompt/tags), not full
// catalog snippets — this reuses the card/detail rendering the same way
// templateAsSnippet() does for personal templates.
function sharedAsSnippet(row) {
  return {
    id: row.id, title: row.title, category: 'Workspace', tags: row.tags || [],
    description: row.prompt, descriptionFormat: 'markdown',
    examples: [{ label: 'Prompt', prompt: row.prompt }],
    isWorkspaceShared: true, addedBy: row.added_by
  };
}

// --- Rendering -------------------------------------------------------------

function renderChips() {
  const usageByCategory = {};
  SNIPPET_LIBRARY.forEach(s => { usageByCategory[s.category] = (usageByCategory[s.category] || 0) + (s.usageCount || 0); });
  const cats = snippetCategories().sort((a, b) => (usageByCategory[b] || 0) - (usageByCategory[a] || 0));
  chipsEl.innerHTML = `<button type="button" class="chip ${currentCategory === 'all' ? 'active' : ''}" data-cat="all">All categories</button>` +
    cats.map(c => `<button type="button" class="chip ${currentCategory === c ? 'active' : ''}" data-cat="${escapeHtml(c)}">${escapeHtml(c)}${usageByCategory[c] ? ` <span class="chip-count">${usageByCategory[c]}</span>` : ''}</button>`).join('');
  chipsEl.querySelectorAll('.chip').forEach(btn => {
    btn.addEventListener('click', () => {
      currentCategory = btn.getAttribute('data-cat');
      render();
    });
  });
}

function attributionBadge(snippet) {
  if (snippet.isPersonal) return '';
  if (snippet.isOfficial !== false) return `<span class="attribution-badge official">Official</span>`;
  return `<span class="attribution-badge community">by ${escapeHtml(snippet.authorLabel || 'community')}</span>`;
}
function ratingBadge(snippet) {
  if (snippet.isPersonal) return '';
  const r = ratingSummaries[snippet.id];
  if (!r || !r.count) return `<span class="usage-badge">${snippet.usageCount || 0} uses</span>`;
  return `<span class="rating-badge">&#9733; ${r.avg.toFixed(1)} (${r.count})</span><span class="usage-badge">${snippet.usageCount || 0} uses</span>`;
}

function cardHtml(snippet) {
  if (snippet.isPersonal) {
    return `
      <div class="snippet-card" data-id="${snippet.id}">
        <div class="snippet-card-top">
          <span class="snippet-category">Personal</span>
        </div>
        <div class="snippet-title">${escapeHtml(snippet.title)}</div>
        <div class="snippet-preview">${escapeHtml(plainPreview(snippet))}</div>
        <div class="snippet-tags">${(snippet.tags || []).map(t => `<span class="tag-pill">${escapeHtml(t)}</span>`).join('')}</div>
        <div style="display:flex; gap:6px;">
          <button type="button" class="btn btn-ghost view-btn" data-id="${snippet.id}" style="flex:1;">View</button>
          <button type="button" class="btn btn-danger delete-template-btn" data-id="${snippet.id}">Delete</button>
        </div>
      </div>
    `;
  }
  if (snippet.isWorkspaceShared) {
    const mineShared = currentSbUser && snippet.addedBy === currentSbUser.id;
    return `
      <div class="snippet-card" data-id="${snippet.id}">
        <div class="snippet-card-top">
          <span class="snippet-category">Workspace</span>
        </div>
        <div class="snippet-title">${escapeHtml(snippet.title)}</div>
        <div class="snippet-preview">${escapeHtml(plainPreview(snippet))}</div>
        <div class="snippet-tags">${(snippet.tags || []).map(t => `<span class="tag-pill">${escapeHtml(t)}</span>`).join('')}</div>
        <div style="display:flex; gap:6px;">
          <button type="button" class="btn btn-ghost view-btn" data-id="${snippet.id}" style="flex:1;">View</button>
          ${mineShared ? `<button type="button" class="btn btn-danger delete-shared-btn" data-id="${snippet.id}">Delete</button>` : ''}
        </div>
      </div>
    `;
  }
  const saved = userLibraryIds.includes(snippet.id);
  const mine = currentSbUser && snippet.createdBy === currentSbUser.id;
  const pending = mine && snippet.moderationStatus === 'pending';
  const rejected = mine && snippet.moderationStatus === 'rejected';
  return `
    <div class="snippet-card" data-id="${snippet.id}">
      <div class="snippet-card-top">
        <span class="snippet-category">${escapeHtml(snippet.category)}</span>
        ${mine ? '' : `<button type="button" class="save-toggle-btn ${saved ? 'saved' : ''}" data-id="${snippet.id}" title="${saved ? 'Remove from My Library' : 'Add to My Library'}">${saved ? '★ Saved' : '☆ Save'}</button>`}
      </div>
      <div class="snippet-title">${escapeHtml(snippet.title)}</div>
      <div class="snippet-preview">${escapeHtml(plainPreview(snippet))}</div>
      <div class="snippet-badge-row">
        ${attributionBadge(snippet)}${ratingBadge(snippet)}
        ${snippet.forkedFrom ? `<span class="usage-badge">forked</span>` : ''}
        ${pending ? `<span class="attribution-badge community" style="color:var(--text-dim);">Pending review</span>` : ''}
        ${rejected ? `<span class="attribution-badge community" style="color:var(--red);">Not approved</span>` : ''}
      </div>
      <div class="snippet-tags">${(snippet.tags || []).map(t => `<span class="tag-pill">${escapeHtml(t)}</span>`).join('')}</div>
      <div style="display:flex; gap:6px;">
        <button type="button" class="btn btn-ghost view-btn" data-id="${snippet.id}" style="flex:1;">View & examples</button>
        ${mine ? `<button type="button" class="btn btn-danger delete-submission-btn" data-id="${snippet.id}">Delete</button>` : `<button type="button" class="btn btn-ghost fork-btn" data-id="${snippet.id}" title="Submit your own edited copy">Fork</button>`}
      </div>
    </div>
  `;
}

function render() {
  document.getElementById('loadingState').style.display = 'none';

  if (loadError && currentView !== 'personal' && currentView !== 'workspace') {
    gridEl.style.display = 'none';
    emptyEl.style.display = 'block';
    emptyEl.textContent = loadError;
    return;
  }

  document.getElementById('personalToolbar').style.display = currentView === 'personal' ? 'block' : 'none';
  document.getElementById('workspaceToolbar').style.display = currentView === 'workspace' ? 'block' : 'none';
  document.getElementById('submitToolbar').style.display = (currentView === 'personal' || currentView === 'workspace') ? 'none' : 'block';
  chipsEl.style.display = (currentView === 'all' || currentView === 'mine') ? 'flex' : 'none';
  document.getElementById('sortSelect').style.display = (currentView === 'all' || currentView === 'mine') ? 'block' : 'none';

  const items = filteredSnippets();
  myLibCount.textContent = userLibraryIds.length;
  totalLibCount.textContent = SNIPPET_LIBRARY.length;

  if (items.length === 0) {
    gridEl.style.display = 'none';
    emptyEl.style.display = 'block';
    emptyEl.textContent = currentView === 'personal'
      ? "No personal templates yet — click \"+ New personal template\" above. These stay on this device only."
      : currentView === 'workspace'
        ? "Nothing shared with your workspace yet — click \"+ Share a prompt\" above."
        : currentView === 'submissions'
          ? "You haven't submitted any prompts yet — click \"+ Submit a prompt\" above."
          : currentView === 'mine' && userLibraryIds.length === 0
            ? "You haven't saved any prompts yet — browse All and hit Save on ones you like."
            : 'No prompts match your search or filter.';
    return;
  }
  gridEl.style.display = 'grid';
  emptyEl.style.display = 'none';
  gridEl.innerHTML = items.map(cardHtml).join('');

  gridEl.querySelectorAll('.save-toggle-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      await toggleSaved(btn.getAttribute('data-id'));
      render();
    });
  });
  gridEl.querySelectorAll('.view-btn').forEach(btn => {
    btn.addEventListener('click', () => openDetail(btn.getAttribute('data-id')));
  });
  gridEl.querySelectorAll('.fork-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      if (!currentSbUser || currentSbUser.is_anonymous) {
        alert('Link an email or sign in with Google on the Account page to fork prompts.');
        return;
      }
      const source = findAnySnippet(btn.getAttribute('data-id'));
      if (source) openSubmissionEditor(null, source);
    });
  });
  gridEl.querySelectorAll('.delete-template-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const id = btn.getAttribute('data-id');
      if (!confirm('Delete this personal template? This can\'t be undone.')) return;
      await savePersonalTemplates(personalTemplates.filter(t => t.id !== id));
      render();
    });
  });
  gridEl.querySelectorAll('.delete-shared-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const id = btn.getAttribute('data-id');
      if (!confirm('Remove this from your workspace\'s shared library?')) return;
      try {
        await deleteWorkspaceSharedPrompt(id);
        workspaceShared = workspaceShared.filter(w => w.id !== id);
        render();
      } catch (err) { alert(err.message); }
    });
  });
  gridEl.querySelectorAll('.delete-submission-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const id = btn.getAttribute('data-id');
      if (!confirm('Delete this submission from the catalog? This can\'t be undone.')) return;
      try {
        await deleteMySnippet(id);
        setCatalog(SNIPPET_LIBRARY.filter(s => s.id !== id));
        render();
      } catch (err) { alert(err.message); }
    });
  });
}

function findAnySnippet(id) {
  const personal = personalTemplates.find(t => t.id === id);
  if (personal) return templateAsSnippet(personal);
  const shared = workspaceShared.find(w => w.id === id);
  if (shared) return sharedAsSnippet(shared);
  return findSnippet(id);
}

function starRow(current, interactive) {
  let html = '<div class="star-row' + (interactive ? ' interactive' : '') + '">';
  for (let i = 1; i <= 5; i++) {
    html += `<span class="star ${i <= current ? 'filled' : ''}" data-val="${i}">&#9733;</span>`;
  }
  html += '</div>';
  return html;
}

async function ratingSectionHtml(s) {
  if (s.isPersonal) return '';
  const summary = ratingSummaries[s.id];
  const summaryLine = summary && summary.count
    ? `${summary.avg.toFixed(1)} average from ${summary.count} rating${summary.count === 1 ? '' : 's'}`
    : 'No ratings yet';

  if (!currentSbUser || currentSbUser.is_anonymous) {
    return `
      <div class="overlay-context-box" style="margin-top:14px;">
        <div class="overlay-col-label">Ratings</div>
        <div class="overlay-rich" style="margin-top:2px;">${summaryLine}. <a href="account.html">Link an email</a> to leave your own.</div>
      </div>
    `;
  }
  const mine = await fetchMyRating(s.id);
  return `
    <div class="overlay-context-box" style="margin-top:14px;">
      <div class="overlay-col-label">Ratings — ${summaryLine}</div>
      <div class="rating-input-row" data-id="${s.id}">
        ${starRow(mine ? mine.rating : 0, true)}
        <span class="rating-save-msg"></span>
      </div>
    </div>
  `;
}

function openDetail(id) {
  const s = findAnySnippet(id);
  if (!s) return;
  const saved = userLibraryIds.includes(id);
  const examples = s.examples || [];
  const mineSubmission = currentSbUser && s.createdBy === currentSbUser.id;
  const mineShared = currentSbUser && s.addedBy === currentSbUser.id;
  const forkedFromSnippet = s.forkedFrom ? findSnippet(s.forkedFrom) : null;

  overlayBody.innerHTML = `
    <div class="overlay-head">
      <div class="snippet-category">${escapeHtml(s.category)}</div>
      <h2 class="overlay-title">${escapeHtml(s.title)}</h2>
      <div class="overlay-meta">
        <div class="snippet-tags">${(s.tags || []).map(t => `<span class="tag-pill">${escapeHtml(t)}</span>`).join('')}</div>
        ${attributionBadge(s)}
        ${examples.length ? `<span class="overlay-example-count">${examples.length} example prompt${examples.length === 1 ? '' : 's'}</span>` : ''}
      </div>
      ${s.forkedFrom ? `<div class="overlay-rich" style="margin-top:2px; font-size:12px;">Forked from ${forkedFromSnippet ? `<a href="#" class="fork-source-link" data-id="${s.forkedFrom}">${escapeHtml(forkedFromSnippet.title)}</a>` : 'a since-removed prompt'}</div>` : ''}
    </div>

    <div class="overlay-body-grid">
      <div class="overlay-desc-col">
        <div class="overlay-col-label">About this prompt</div>
        <div class="overlay-rich">${renderRich(s, 'description')}</div>
        ${s.recommendedContext ? `
          <div class="overlay-context-box">
            <div class="overlay-col-label">Recommended context to add</div>
            <div class="overlay-rich" style="margin-top:0;">${renderRich(s, 'recommendedContext')}</div>
          </div>
        ` : ''}
        <div id="ratingSection"></div>
        <div class="overlay-actions">
          ${s.isPersonal ? `
            <button type="button" class="btn btn-ghost edit-template-btn" data-id="${s.id}">Edit</button>
            <button type="button" class="btn btn-danger delete-template-btn" data-id="${s.id}">Delete</button>
          ` : s.isWorkspaceShared ? (mineShared ? `
            <button type="button" class="btn btn-ghost edit-shared-btn" data-id="${s.id}">Edit</button>
            <button type="button" class="btn btn-danger delete-shared-btn" data-id="${s.id}">Delete</button>
          ` : '') : mineSubmission ? `
            <button type="button" class="btn btn-ghost edit-submission-btn" data-id="${s.id}">Edit your submission</button>
            <button type="button" class="btn btn-danger delete-submission-btn" data-id="${s.id}">Delete</button>
          ` : `
            <button type="button" class="btn ${saved ? 'btn-ghost' : 'btn-primary'} overlay-save-btn" data-id="${s.id}">
              ${saved ? '★ Saved to My Library' : '+ Save to My Library'}
            </button>
            <button type="button" class="btn btn-ghost fork-btn" data-id="${s.id}">Fork</button>
            <button type="button" class="btn btn-ghost report-btn" data-id="${s.id}">Report</button>
          `}
        </div>
      </div>

      <div class="overlay-examples-col-wrap">
        <div class="overlay-col-label">${examples.length ? 'Example prompts' : ''}</div>
        <div class="overlay-examples-col">
          ${examples.length ? examples.map((ex, i) => `
            <div class="example-block">
              <div class="example-block-top">
                <span class="example-label">${escapeHtml(ex.label || `Example ${i + 1}`)}</span>
                <span style="display:flex; align-items:center; gap:6px;">
                  ${!s.isPersonal && !s.isWorkspaceShared && (s.exampleUsage || {})[i] ? `<span class="usage-badge">${s.exampleUsage[i]} used</span>` : ''}
                  <button type="button" class="example-copy-btn" data-idx="${i}">Copy</button>
                </span>
              </div>
              <pre class="example-prompt">${escapeHtml(ex.prompt)}</pre>
            </div>
          `).join('') : '<div class="empty" style="text-align:left; padding:6px 0;">No example prompts yet.</div>'}
        </div>
      </div>
    </div>
  `;
  overlay.style.display = 'flex';

  if (!s.isPersonal && !s.isWorkspaceShared) {
    ratingSectionHtml(s).then(html => {
      const el = document.getElementById('ratingSection');
      if (!el) return; // overlay closed/re-opened before this resolved
      el.innerHTML = html;
      el.querySelectorAll('.star').forEach(star => {
        star.addEventListener('click', async () => {
          const row = star.closest('.rating-input-row');
          const val = parseInt(star.getAttribute('data-val'), 10);
          const msgEl = row.querySelector('.rating-save-msg');
          msgEl.textContent = 'Saving…';
          try {
            await rateSnippet(s.id, val, null);
            row.querySelectorAll('.star').forEach((st, i) => st.classList.toggle('filled', i < val));
            msgEl.textContent = 'Saved';
            ratingSummaries = await fetchRatingSummaries();
          } catch (err) { msgEl.textContent = err.message; }
        });
      });
    });
  }

  overlayBody.querySelector('.fork-source-link')?.addEventListener('click', (e) => {
    e.preventDefault();
    openDetail(e.target.getAttribute('data-id'));
  });
  overlayBody.querySelector('.overlay-save-btn')?.addEventListener('click', async () => {
    await toggleSaved(s.id);
    openDetail(s.id); // refresh button state
    render();
  });
  overlayBody.querySelector('.fork-btn')?.addEventListener('click', () => {
    if (!currentSbUser || currentSbUser.is_anonymous) {
      alert('Link an email or sign in with Google on the Account page to fork prompts.');
      return;
    }
    overlay.style.display = 'none';
    openSubmissionEditor(null, s);
  });
  overlayBody.querySelector('.report-btn')?.addEventListener('click', async () => {
    if (!currentSbUser || currentSbUser.is_anonymous) {
      alert('Link an email or sign in with Google on the Account page to file a report.');
      return;
    }
    const reason = prompt('Why are you reporting this prompt? (e.g. spam, broken, offensive)');
    if (!reason) return;
    try {
      await reportSnippet(s.id, reason);
      alert('Thanks — this has been reported for review.');
    } catch (err) { alert(err.message); }
  });
  overlayBody.querySelector('.edit-template-btn')?.addEventListener('click', () => {
    overlay.style.display = 'none';
    openTemplateEditor(personalTemplates.find(t => t.id === s.id));
  });
  overlayBody.querySelector('.delete-template-btn')?.addEventListener('click', async () => {
    if (!confirm('Delete this personal template? This can\'t be undone.')) return;
    await savePersonalTemplates(personalTemplates.filter(t => t.id !== s.id));
    overlay.style.display = 'none';
    render();
  });
  overlayBody.querySelector('.edit-shared-btn')?.addEventListener('click', () => {
    overlay.style.display = 'none';
    openSharedPromptEditor(workspaceShared.find(w => w.id === s.id));
  });
  overlayBody.querySelector('.delete-shared-btn')?.addEventListener('click', async () => {
    if (!confirm('Remove this from your workspace\'s shared library?')) return;
    try {
      await deleteWorkspaceSharedPrompt(s.id);
      workspaceShared = workspaceShared.filter(w => w.id !== s.id);
      overlay.style.display = 'none';
      render();
    } catch (err) { alert(err.message); }
  });
  overlayBody.querySelector('.edit-submission-btn')?.addEventListener('click', () => {
    overlay.style.display = 'none';
    openSubmissionEditor(s);
  });
  overlayBody.querySelector('.delete-submission-btn')?.addEventListener('click', async () => {
    if (!confirm('Delete this submission from the catalog? This can\'t be undone.')) return;
    try {
      await deleteMySnippet(s.id);
      setCatalog(SNIPPET_LIBRARY.filter(x => x.id !== s.id));
      overlay.style.display = 'none';
      render();
    } catch (err) { alert(err.message); }
  });
  overlayBody.querySelectorAll('.example-copy-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const idx = parseInt(btn.getAttribute('data-idx'), 10);
      const ex = examples[idx];
      if (!ex) return;
      const filled = fillPlaceholders(ex.prompt);
      if (filled === null) return; // cancelled a placeholder prompt
      try {
        await navigator.clipboard.writeText(filled);
        const original = btn.textContent;
        btn.textContent = 'Copied';
        btn.classList.add('copied');
        setTimeout(() => { btn.textContent = original; btn.classList.remove('copied'); }, 1200);
        if (!s.isPersonal && !s.isWorkspaceShared) { bumpUsageCount(s.id); bumpExampleUsage(s.id, idx); }
      } catch (err) { /* clipboard unavailable — silently ignore */ }
    });
  });
}
overlayClose.addEventListener('click', () => { overlay.style.display = 'none'; });
overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.style.display = 'none'; });

searchEl.addEventListener('input', render);
document.getElementById('sortSelect').addEventListener('change', (e) => { currentSort = e.target.value; render(); });
viewSeg.querySelectorAll('button').forEach(btn => {
  btn.addEventListener('click', async () => {
    viewSeg.querySelectorAll('button').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentView = btn.getAttribute('data-value');
    if (currentView === 'workspace' && !workspaceShared.length) {
      try { workspaceShared = await fetchWorkspaceSharedPrompts(); } catch (err) { /* stays empty, empty-state message covers it */ }
    }
    render();
  });
});

// --- Personal template create/edit overlay ----------------------------------

const templateEditOverlay = document.getElementById('templateEditOverlay');
const templateEditBody = document.getElementById('templateEditBody');
document.getElementById('templateEditClose').addEventListener('click', () => templateEditOverlay.style.display = 'none');
templateEditOverlay.addEventListener('click', (e) => { if (e.target === templateEditOverlay) templateEditOverlay.style.display = 'none'; });

function openTemplateEditor(existing) {
  templateEditBody.innerHTML = `
    <h2 class="overlay-title">${existing ? 'Edit' : 'New'} personal template</h2>
    <div class="overlay-rich" style="margin-top:0; margin-bottom:12px;">Stored only on this device — never sent to Supabase, never visible to anyone else.</div>
    <div class="field">
      <label>Title</label>
      <input type="text" id="tplTitle" style="width:100%;" value="${escapeHtml(existing ? existing.title : '')}" placeholder="e.g. My weekly retro prompt">
    </div>
    <div class="field">
      <label>Prompt</label>
      <textarea id="tplPrompt" style="width:100%; min-height:100px;" placeholder="Type the prompt…">${escapeHtml(existing ? existing.prompt : '')}</textarea>
    </div>
    <div class="field">
      <label>Tags <span style="font-weight:400; color:var(--text-faint);">(comma separated, optional)</span></label>
      <input type="text" id="tplTags" style="width:100%;" value="${escapeHtml((existing && existing.tags || []).join(', '))}">
    </div>
    <button type="button" class="btn btn-primary" id="tplSaveBtn">Save</button>
    <span class="acct-msg" id="tplMsg" style="margin-left:8px;"></span>
  `;
  templateEditOverlay.style.display = 'flex';
  document.getElementById('tplSaveBtn').addEventListener('click', async () => {
    const title = document.getElementById('tplTitle').value.trim();
    const prompt = document.getElementById('tplPrompt').value.trim();
    const tags = document.getElementById('tplTags').value.split(',').map(t => t.trim()).filter(Boolean);
    const msg = document.getElementById('tplMsg');
    if (!title || !prompt) { msg.textContent = 'Title and prompt are both required.'; return; }

    const list = await getPersonalTemplates();
    if (existing) {
      const idx = list.findIndex(t => t.id === existing.id);
      if (idx > -1) list[idx] = { ...list[idx], title, prompt, tags };
    } else {
      list.push({ id: 'tpl-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), title, prompt, tags, createdAt: new Date().toISOString() });
    }
    await savePersonalTemplates(list);
    templateEditOverlay.style.display = 'none';
    render();
  });
}
document.getElementById('newTemplateBtn').addEventListener('click', () => openTemplateEditor(null));
document.getElementById('newSharedPromptBtn').addEventListener('click', () => openSharedPromptEditor(null));

function openSharedPromptEditor(existing) {
  templateEditBody.innerHTML = `
    <h2 class="overlay-title">${existing ? 'Edit' : 'Share'} a workspace prompt</h2>
    <div class="overlay-rich" style="margin-top:0; margin-bottom:12px;">Visible to every profile linked in your workspace — not the public catalog.</div>
    <div class="field">
      <label>Title</label>
      <input type="text" id="shTitle" style="width:100%;" value="${escapeHtml(existing ? existing.title : '')}">
    </div>
    <div class="field">
      <label>Prompt</label>
      <textarea id="shPrompt" style="width:100%; min-height:100px;">${escapeHtml(existing ? existing.prompt : '')}</textarea>
    </div>
    <div class="field">
      <label>Tags <span style="font-weight:400; color:var(--text-faint);">(comma separated, optional)</span></label>
      <input type="text" id="shTags" style="width:100%;" value="${escapeHtml((existing && existing.tags || []).join(', '))}">
    </div>
    <button type="button" class="btn btn-primary" id="shSaveBtn">Save</button>
    <span class="acct-msg" id="shMsg" style="margin-left:8px;"></span>
  `;
  templateEditOverlay.style.display = 'flex';
  document.getElementById('shSaveBtn').addEventListener('click', async () => {
    const title = document.getElementById('shTitle').value.trim();
    const prompt = document.getElementById('shPrompt').value.trim();
    const tags = document.getElementById('shTags').value.split(',').map(t => t.trim()).filter(Boolean);
    const msg = document.getElementById('shMsg');
    if (!title || !prompt) { msg.textContent = 'Title and prompt are both required.'; msg.className = 'acct-msg error'; return; }
    msg.textContent = 'Saving…'; msg.className = 'acct-msg';
    try {
      if (existing) {
        await updateWorkspaceSharedPrompt(existing.id, title, prompt, tags);
        const idx = workspaceShared.findIndex(w => w.id === existing.id);
        if (idx > -1) Object.assign(workspaceShared[idx], { title, prompt, tags });
      } else {
        const saved = await addWorkspaceSharedPrompt(title, prompt, tags);
        workspaceShared.push(saved);
      }
      templateEditOverlay.style.display = 'none';
      render();
    } catch (err) { msg.textContent = err.message; msg.className = 'acct-msg error'; }
  });
}

// --- Catalog submission editor -----------------------------------------

document.getElementById('submitPromptBtn').addEventListener('click', () => {
  if (!currentSbUser || currentSbUser.is_anonymous) {
    alert('Link an email or sign in with Google on the Account page to submit prompts to the catalog.');
    return;
  }
  openSubmissionEditor(null);
});

function exampleEditorRowHtml(ex, i) {
  return `
    <div class="example-block" data-idx="${i}">
      <div class="example-block-top">
        <input type="text" class="sub-ex-label" placeholder="Label (e.g. Short, Detailed)" value="${escapeHtml(ex.label || '')}" style="flex:1;">
        <button type="button" class="btn btn-danger remove-example-btn" data-idx="${i}">&times;</button>
      </div>
      <textarea class="sub-ex-prompt" style="width:100%; min-height:60px;" placeholder="Example prompt text…">${escapeHtml(ex.prompt || '')}</textarea>
    </div>
  `;
}

async function openSubmissionEditor(existing, forkSource) {
  const seed = existing || forkSource;
  let examples = seed ? seed.examples.map(e => ({ ...e })) : [{ label: '', prompt: '' }];
  const authorLabel = (await getAuthorLabel()) || '';

  function renderExamples() {
    const container = document.getElementById('subExamplesContainer');
    container.innerHTML = examples.map(exampleEditorRowHtml).join('') +
      `<button type="button" class="btn btn-ghost" id="addExampleBtn">+ Add example</button>`;
    document.getElementById('addExampleBtn').addEventListener('click', () => {
      syncExamplesFromDOM();
      examples.push({ label: '', prompt: '' });
      renderExamples();
    });
    container.querySelectorAll('.remove-example-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        syncExamplesFromDOM();
        examples.splice(parseInt(btn.getAttribute('data-idx'), 10), 1);
        if (!examples.length) examples.push({ label: '', prompt: '' });
        renderExamples();
      });
    });
  }
  function syncExamplesFromDOM() {
    document.querySelectorAll('#subExamplesContainer .example-block').forEach((el, i) => {
      examples[i].label = el.querySelector('.sub-ex-label').value;
      examples[i].prompt = el.querySelector('.sub-ex-prompt').value;
    });
  }

  const history = (existing && existing.versionHistory) || [];
  const historyHtml = history.length ? `
    <div class="field">
      <label>Version history <span style="font-weight:400; color:var(--text-faint);">(${history.length} earlier version${history.length === 1 ? '' : 's'})</span></label>
      <div style="max-height:160px; overflow-y:auto; display:flex; flex-direction:column; gap:6px;">
        ${history.slice().reverse().map(v => `
          <div class="overlay-context-box" style="margin-top:0;">
            <div class="overlay-col-label">${v.saved_at ? new Date(v.saved_at).toLocaleString() : 'Earlier version'}</div>
            <div class="overlay-rich" style="margin-top:2px;"><b>${escapeHtml(v.title || '')}</b> — ${escapeHtml((v.description || '').slice(0, 140))}${(v.description || '').length > 140 ? '…' : ''}</div>
          </div>
        `).join('')}
      </div>
    </div>
  ` : '';

  templateEditBody.innerHTML = `
    <h2 class="overlay-title">${existing ? 'Edit' : forkSource ? `Fork "${escapeHtml(forkSource.title)}"` : 'Submit'} a catalog prompt</h2>
    <div class="overlay-rich" style="margin-top:0; margin-bottom:12px;">
      Visible to everyone in the shared library, tagged "by @your-name" — not stored only on this device (that's what personal templates are for).
      ${existing ? ' Editing sends this back for review before your changes go live.' : ''}
      ${forkSource ? ` Starting from ${forkSource.isOfficial ? 'the official version' : `@${escapeHtml(forkSource.authorLabel || 'their')} version`} — edit freely, this becomes your own submission.` : ''}
    </div>
    <div class="field">
      <label>Your display name <span style="font-weight:400; color:var(--text-faint);">(shown on all your submissions)</span></label>
      <input type="text" id="subAuthorLabel" style="width:100%;" value="${escapeHtml(authorLabel)}" placeholder="e.g. jane-doe">
    </div>
    <div class="field">
      <label>Title</label>
      <input type="text" id="subTitle" style="width:100%;" value="${escapeHtml(seed ? seed.title : '')}">
    </div>
    <div class="field">
      <label>Category</label>
      <input type="text" id="subCategory" style="width:100%;" list="subCategoryList" value="${escapeHtml(seed ? seed.category : '')}" placeholder="e.g. Productivity">
      <datalist id="subCategoryList">${snippetCategories().map(c => `<option value="${escapeHtml(c)}">`).join('')}</datalist>
    </div>
    <div class="field">
      <label>Tags <span style="font-weight:400; color:var(--text-faint);">(comma separated)</span></label>
      <input type="text" id="subTags" style="width:100%;" value="${escapeHtml((seed && seed.tags || []).join(', '))}">
    </div>
    <div class="field">
      <label>Description</label>
      <textarea id="subDescription" style="width:100%; min-height:70px;">${escapeHtml(seed ? seed.description : '')}</textarea>
    </div>
    <div class="field">
      <label>Recommended context <span style="font-weight:400; color:var(--text-faint);">(optional)</span></label>
      <textarea id="subRecContext" style="width:100%; min-height:50px;">${escapeHtml(seed ? (seed.recommendedContext || '') : '')}</textarea>
    </div>
    <div class="field">
      <label>Example prompts</label>
      <div id="subExamplesContainer"></div>
    </div>
    ${historyHtml}
    <button type="button" class="btn btn-primary" id="subSaveBtn">${existing ? 'Save changes' : forkSource ? 'Submit your fork' : 'Submit'}</button>
    <span class="acct-msg" id="subMsg" style="margin-left:8px;"></span>
  `;
  templateEditOverlay.style.display = 'flex';
  renderExamples();

  document.getElementById('subSaveBtn').addEventListener('click', async () => {
    syncExamplesFromDOM();
    const msg = document.getElementById('subMsg');
    const label = document.getElementById('subAuthorLabel').value.trim();
    const title = document.getElementById('subTitle').value.trim();
    const category = document.getElementById('subCategory').value.trim();
    const description = document.getElementById('subDescription').value.trim();
    const recommendedContext = document.getElementById('subRecContext').value.trim();
    const tags = document.getElementById('subTags').value.split(',').map(t => t.trim()).filter(Boolean);
    const cleanExamples = examples.map(e => ({ label: e.label.trim(), prompt: e.prompt.trim() })).filter(e => e.prompt);

    if (!label || !title || !category || !description) {
      msg.textContent = 'Display name, title, category, and description are all required.'; msg.className = 'acct-msg error';
      return;
    }
    msg.textContent = 'Saving…'; msg.className = 'acct-msg';
    try {
      await setAuthorLabel(label);
      if (existing) {
        await updateMySnippet(existing.id, { title, category, tags, description, recommendedContext, examples: cleanExamples });
        const idx = SNIPPET_LIBRARY.findIndex(s => s.id === existing.id);
        if (idx > -1) Object.assign(SNIPPET_LIBRARY[idx], { title, category, tags, description, recommendedContext, examples: cleanExamples, moderationStatus: 'pending' });
      } else {
        const id = 'user-' + label.toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-' + Date.now().toString(36);
        const forkedFrom = forkSource ? forkSource.id : null;
        const saved = await submitSnippet({ id, title, category, tags, description, recommendedContext, examples: cleanExamples, authorLabel: label, forkedFrom });
        setCatalog([...SNIPPET_LIBRARY, {
          id: saved.id, title, category, tags, description, descriptionFormat: 'markdown',
          recommendedContext, recommendedContextFormat: 'markdown', examples: cleanExamples,
          usageCount: 0, isOfficial: false, authorLabel: label, createdBy: currentSbUser.id,
          moderationStatus: 'pending', forkedFrom
        }]);
      }
      templateEditOverlay.style.display = 'none';
      alert(existing ? "Saved — your changes are back in review before they're visible to everyone." : "Submitted — it'll show up in the catalog once reviewed. Check \"My Submissions\" for status.");
      render();
    } catch (err) { msg.textContent = err.message; msg.className = 'acct-msg error'; }
  });
}

function tickClock() {
  const now = new Date();
  railClock.textContent = now.toLocaleTimeString(undefined, { hour12: false });
  railDate.textContent = now.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
}
tickClock();
setInterval(tickClock, 1000);

(async function init() {
  personalTemplates = await getPersonalTemplates(); // local-only, loads regardless of Supabase reachability
  try {
    currentSbUser = await currentUser();
    const [catalog, libIds, ratings] = await Promise.all([fetchCatalog(), fetchUserLibraryIds(), fetchRatingSummaries()]);
    setCatalog(catalog);
    userLibraryIds = libIds;
    ratingSummaries = ratings;
  } catch (err) {
    loadError = err.message || 'Could not load the library. Check your connection and try again.';
  }
  try {
    const { workspaceId } = await getLocalWorkspaceInfo();
    if (workspaceId) document.getElementById('workspaceViewBtn').style.display = 'inline-block';
  } catch (err) { /* not a big deal — Workspace tab just stays hidden */ }
  renderChips();
  renderSyncPanel();
  render();
})();

// --- Account status panel ------------------------------------------------
// Full email-link/sign-in flow now lives on account.html (see account.js) —
// this is just a status line + link, so the two don't drift out of sync.

const syncPanel = document.getElementById('syncPanel');

function renderSyncPanel() {
  if (!currentSbUser) { syncPanel.innerHTML = ''; return; }
  syncPanel.innerHTML = currentSbUser.is_anonymous
    ? `<a href="account.html" class="sync-pill"><span class="dot"></span>On this device only — connect account</a>`
    : `<a href="account.html" class="sync-pill linked"><span class="dot"></span>Synced as ${escapeHtml(currentSbUser.email)}</a>`;
}
