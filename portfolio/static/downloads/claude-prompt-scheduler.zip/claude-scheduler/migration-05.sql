-- migration-05.sql — run after migration-04.sql. Safe to re-run.
-- Fixes a real bug (deleting the workspace owner's account cascaded and
-- destroyed the whole workspace for every member) and hardens join codes,
-- which were previously a permanent, reusable 6-hex-character code —
-- brute-forceable given enough attempts, and reusable by anyone who ever
-- saw it, forever.

-- ── 1. Stop deleting the whole workspace when its owner deletes their
--       account — ownership is informational, not load-bearing; the
--       workspace and its other members should survive. ──────────────────
alter table public.workspaces alter column owner_id drop not null;
alter table public.workspaces drop constraint if exists workspaces_owner_id_fkey;
alter table public.workspaces add constraint workspaces_owner_id_fkey
  foreign key (owner_id) references auth.users(id) on delete set null;

-- ── 2. Harden join codes ─────────────────────────────────────────────────
-- Old: upper(substr(md5(...), 1, 6)) — 6 hex chars, ~16.7M possibilities,
-- reusable forever, no rate limiting anywhere in front of it. New: 32
-- hex chars (~1.5×10^38 possibilities — brute force is not a practical
-- concern at that size even unthrottled), the code is consumed
-- (auto-rotated) on every successful join so a code someone saw once
-- stops working after one use, and it expires after 24 hours regardless.
-- To add a SECOND member, re-open the Account page for the current code
-- (rotates automatically after each join) or use the new "Regenerate
-- code" button.
alter table public.workspaces add column if not exists join_code_expires_at timestamptz;

create or replace function public.generate_join_code()
returns text
language sql
as $$
  -- gen_random_uuid() is built into core Postgres (no extension needed,
  -- unlike gen_random_bytes()/pgcrypto — which Supabase installs into an
  -- "extensions" schema outside the default search_path, causing a
  -- "function does not exist" error if called unqualified). One UUID
  -- stripped of dashes gives 32 hex chars (128 bits) — plenty.
  select upper(replace(gen_random_uuid()::text, '-', ''));
$$;

create or replace function public.create_workspace(p_profile_label text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_workspace_id uuid;
begin
  insert into public.workspaces (owner_id, join_code, join_code_expires_at)
    values (auth.uid(), public.generate_join_code(), now() + interval '24 hours')
    returning id into v_workspace_id;
  insert into public.workspace_members (workspace_id, user_id, profile_label)
    values (v_workspace_id, auth.uid(), p_profile_label);
  return v_workspace_id;
end;
$$;

create or replace function public.join_workspace(p_join_code text, p_profile_label text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_workspace_id uuid;
begin
  select id into v_workspace_id from public.workspaces
    where join_code = upper(p_join_code) and join_code_expires_at > now();
  if v_workspace_id is null then
    raise exception 'That code is invalid or has expired — ask for a fresh one.';
  end if;
  insert into public.workspace_members (workspace_id, user_id, profile_label)
    values (v_workspace_id, auth.uid(), p_profile_label)
    on conflict (workspace_id, user_id) do update set profile_label = excluded.profile_label;
  -- Consume the code — one join per code, so a code shared once (in a
  -- chat log, a screenshot, etc.) can't be reused by someone else later.
  update public.workspaces
    set join_code = public.generate_join_code(), join_code_expires_at = now() + interval '24 hours'
    where id = v_workspace_id;
  return v_workspace_id;
end;
$$;

grant execute on function public.generate_join_code() to authenticated;
grant execute on function public.create_workspace(text) to authenticated;
grant execute on function public.join_workspace(text, text) to authenticated;

-- Lets any current member pull a fresh invite code on demand (e.g. right
-- before inviting a second profile), without having to wait for someone
-- else to join first to rotate it.
create or replace function public.rotate_workspace_join_code(p_workspace_id uuid)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  v_code text;
begin
  if not exists (
    select 1 from public.workspace_members
    where workspace_id = p_workspace_id and user_id = auth.uid()
  ) then
    raise exception 'Not a member of this workspace';
  end if;
  v_code := public.generate_join_code();
  update public.workspaces
    set join_code = v_code, join_code_expires_at = now() + interval '24 hours'
    where id = p_workspace_id;
  return v_code;
end;
$$;
grant execute on function public.rotate_workspace_join_code(uuid) to authenticated;

-- Backfill existing workspaces created before this migration with a
-- freshly hardened code, so no workspace is left on an old, weak code.
update public.workspaces set join_code = public.generate_join_code(), join_code_expires_at = now() + interval '24 hours';
