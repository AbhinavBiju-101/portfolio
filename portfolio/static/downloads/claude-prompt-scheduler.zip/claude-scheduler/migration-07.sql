-- migration-07.sql — run after migration-06.sql. Safe to re-run.
-- Adds live status to workspace_members — whether a profile currently
-- looks rate-limited on claude.ai (best-effort, scraped from the page,
-- same caveat as looksRateLimited() in content.js) and when it was last
-- seen — so other linked profiles can see it on the Workspace page and in
-- the popup's "Send from" picker, instead of the workspace only being a
-- job-history log.

alter table public.workspace_members add column if not exists rate_limited boolean not null default false;
alter table public.workspace_members add column if not exists rate_limit_detail text;
alter table public.workspace_members add column if not exists status_updated_at timestamptz;

-- No new policy needed: the existing "members can update their own
-- profile label" UPDATE policy (using (user_id = auth.uid())) already
-- covers writing these columns too, since it isn't scoped to specific
-- columns — and the existing SELECT policy (fixed in migration-06.sql)
-- already lets every member read every row in their workspace.
