-- migration-08.sql — run after migration-07.sql. Safe to re-run.
--
-- Two additions:
--
-- 1. workspace_members.chat_list_json / chat_list_updated_at — a
--    best-effort copy of a profile's own claude.ai sidebar chat list
--    (title/url/group/project, from content.js's listChats()), reported
--    periodically the same way rate_limited/status_updated_at already
--    are (migration-07.sql). This is what lets the "Send to" chat picker
--    on a DIFFERENT linked profile show real chats instead of an empty
--    "no chats found" state when you're composing a job for someone
--    else's profile.
--
-- 2. workspace_jobs.target / workspace_jobs.attachments — carries the
--    "which chat" target object and any file attachments along with a
--    cross-profile job, so a job pushed to another profile via
--    pushWorkspaceJob() can still open a specific chat / attach files,
--    not just fixed-time prompt + steps like before.

alter table public.workspace_members add column if not exists chat_list_json jsonb;
alter table public.workspace_members add column if not exists chat_list_updated_at timestamptz;

alter table public.workspace_jobs add column if not exists target jsonb;
alter table public.workspace_jobs add column if not exists attachments jsonb;

-- No new RLS policy needed for either table: workspace_members' existing
-- "members can update their own row" UPDATE policy isn't column-scoped
-- (same reasoning as migration-07.sql), and workspace_jobs' existing
-- INSERT policy for "any member can create a job in their own workspace"
-- already covers these two extra columns on the same row.
