// nav.js — included on every page with the sidebar nav. Shows the
// "Workspace" link once this profile is synced (email or Google linked) —
// workspace features (multi-profile linking) need that first, so there's
// nothing actionable behind the link before then. Requires
// supabase-config.js + supabase-client.js to be loaded first.
(async function () {
  const link = document.getElementById('workspaceNavLink');
  if (!link) return;
  try {
    const user = await currentUser();
    link.style.display = (user && !user.is_anonymous) ? 'inline-block' : 'none';
  } catch (err) { /* stays hidden — matches its default inline style in the HTML */ }
})();
