// placeholders.js — {{variable}} support in example prompts. Shared by
// popup.js (inserting a library example into the textarea) and library.js
// (copying an example from the detail overlay), so both fill placeholders
// the same way.

function extractPlaceholders(text) {
  const seen = new Set();
  const out = [];
  const re = /\{\{\s*([a-zA-Z0-9_ -]+?)\s*\}\}/g;
  let m;
  while ((m = re.exec(text))) {
    const name = m[1];
    if (!seen.has(name)) { seen.add(name); out.push(name); }
  }
  return out;
}

// Prompts once per unique placeholder (via window.prompt — fine in an
// extension page, not a content script) and substitutes every occurrence.
// Returns null if the user cancels any prompt, so callers can abort
// cleanly rather than inserting a half-filled template.
function fillPlaceholders(text) {
  const names = extractPlaceholders(text);
  if (!names.length) return text;
  const values = {};
  for (const name of names) {
    const v = window.prompt(`Fill in "${name}":`, '');
    if (v === null) return null; // cancelled
    values[name] = v;
  }
  let out = text;
  for (const name of names) {
    out = out.replace(new RegExp(`\\{\\{\\s*${name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*\\}\\}`, 'g'), values[name]);
  }
  return out;
}
