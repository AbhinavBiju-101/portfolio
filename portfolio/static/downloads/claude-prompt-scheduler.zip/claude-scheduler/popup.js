// popup.js — quick-add UI
// Jobs stored in browser.storage.local under "jobs":
//   { id, prompt, whenISO, mode, target, skipTyping, attachments, retryCount }
// target: { mode: 'current'|'new'|'specific', chatUrl?, chatTitle? } — see
// target-editor.js. attachments: [{ name, type, size, dataUrl }] — see
// content.js's attachFilesToClaude().

const promptEl = document.getElementById('prompt');
const promptFieldEl = promptEl.closest('.field');
const promptOptionalTag = document.getElementById('promptOptionalTag');
const skipTypingSwitch = document.getElementById('skipTypingSwitch');
const modeSeg = document.getElementById('modeSeg');
const whenFieldEl = document.getElementById('whenField');
const whenEl = document.getElementById('when');
const targetFieldEl = document.getElementById('targetField');
const targetEditorContainer = document.getElementById('targetEditorContainer');
const advancedSwitch = document.getElementById('advancedSwitch');
const stepsEditorContainer = document.getElementById('stepsEditorContainer');
const sendFromField = document.getElementById('sendFromField');
const sendFromBtn = document.getElementById('sendFromBtn');
const sendFromBtnLabel = document.getElementById('sendFromBtnLabel');
const attachInput = document.getElementById('attachInput');
const attachListEl = document.getElementById('attachList');
const scheduleBtn = document.getElementById('scheduleBtn');
const statusEl = document.getElementById('status');
const jobListEl = document.getElementById('jobList');

let currentMode = 'fixed';
let myProfileLabel = null;
let sendFromLabel = null; // which linked profile this job should run on — defaults to this profile
let workspaceMembersById = {}; // profile_label -> member row, so the "send from" change handler can check status
let popupTarget = { mode: 'current' }; // see target-editor.js — which chat to send into
let pendingAttachments = []; // [{ name, type, size, dataUrl }]

// compose.html is the only page with #wsStatusCard (see renderWorkspaceStatusSidebar
// in compose.js) — used here to tell popup.html and compose.html apart, since
// both run this exact same script. The popup keeps the plain, cheap chat list
// (small window, and a second network round-trip isn't worth it there); the
// full-page compose view gets the richer cards with last-sent snippets/dates.
const IS_COMPOSE_PAGE = !!document.getElementById('wsStatusCard');

function renderPopupTargetEditor() {
  targetEditorContainer.innerHTML = renderTargetEditorHtml(popupTarget);
  attachTargetEditorHandlers(targetEditorContainer, popupTarget, renderPopupTargetEditor, async () => {
    // If sending from a DIFFERENT linked profile, that profile's own chat
    // list lives on its workspace_members row (chat_list_json — see
    // migration-08.sql + content.js's periodic chat-list heartbeat), not
    // on any tab open in THIS browser. Sending from "this profile" (or no
    // workspace at all) still just asks the local background page. Either
    // way this is always the plain (non-rich) list — the cross-profile
    // heartbeat only ever reports title/url/group/project, never the
    // rich fields, on any page.
    if (sendFromLabel && sendFromLabel !== myProfileLabel) {
      const m = workspaceMembersById[sendFromLabel];
      try { return m && m.chat_list_json ? JSON.parse(m.chat_list_json) : []; }
      catch (e) { return []; }
    }
    return (await browser.runtime.sendMessage({ type: IS_COMPOSE_PAGE ? 'get-chat-list-rich' : 'get-chat-list' })) || [];
  }, IS_COMPOSE_PAGE);
}
renderPopupTargetEditor();

function renderSendFromBtn() {
  sendFromBtnLabel.textContent = (sendFromLabel && sendFromLabel !== myProfileLabel) ? sendFromLabel : 'This profile';
}

function setMode(mode) {
  currentMode = mode;
  modeSeg.querySelectorAll('button').forEach(b => b.classList.toggle('active', b.getAttribute('data-value') === mode));
  whenFieldEl.style.display = mode === 'auto-detect' ? 'none' : 'block';
}

// Only shown at all if this profile is linked to others via a workspace
// (see account.html) — most installs never see this field.
// Exposed as a promise (not just fire-and-forget) so compose.js can await
// it and reuse the same fetch — see its renderWorkspaceStatusSidebar(),
// which used to issue its own separate, redundant fetchWorkspaceMembers()
// call for the exact same data.
const sendFromInitPromise = (async function initSendFrom() {
  try {
    const info = await getLocalWorkspaceInfo();
    myProfileLabel = info.profileLabel;
    sendFromLabel = myProfileLabel;
    if (!info.workspaceId) return;
    const members = await fetchWorkspaceMembers();
    if (members.length <= 1) return;
    members.forEach(m => { workspaceMembersById[m.profile_label] = m; });
    sendFromField.style.display = 'block';
    renderSendFromBtn();
    sendFromBtn.addEventListener('click', () => {
      window.profilePicker.open({
        members, myProfileLabel, selectedLabel: sendFromLabel,
        onSelect: (m) => {
          sendFromLabel = m.profile_label;
          renderSendFromBtn();
          // Sending from a different, currently-open chat doesn't carry
          // over to a different profile's browser — reset to "current
          // tab" (that profile's own current tab) rather than silently
          // keeping a chat URL that belongs to this profile's session.
          if (sendFromLabel !== myProfileLabel && popupTarget.mode === 'specific') {
            popupTarget = { mode: 'current' };
            renderPopupTargetEditor();
          }
          // Picking a profile that's currently rate-limited: a fixed send
          // time might still land inside the limit window, so default to
          // auto-detect instead — it waits for that profile's own
          // claude.ai tab to clear before sending. Still just a default;
          // the mode toggle above is right there to override it.
          if (m.rate_limited) setMode('auto-detect');
        }
      });
    });
  } catch (err) { /* offline, or not signed in yet — field just stays hidden */ }
})();

// Multi-step + branching state, mirroring dashboard.js's editState but for
// the "create" flow rather than "edit an existing job" — see
// steps-editor.js for the shared rendering/handler logic.
let popupSteps = stepsFromSimplePrompt('');

function renderPopupStepsEditor() {
  stepsEditorContainer.innerHTML = renderStepsEditorHtml(popupSteps);
  attachStepsEditorHandlers(stepsEditorContainer, popupSteps, renderPopupStepsEditor);
}

advancedSwitch.addEventListener('click', () => {
  const on = advancedSwitch.classList.toggle('on');
  if (on) {
    // Carry over whatever's already typed as step 1, so switching modes
    // doesn't lose text.
    if (promptEl.value.trim()) popupSteps[0].prompt = promptEl.value;
    renderPopupStepsEditor();
  }
  promptFieldEl.style.display = on ? 'none' : 'block';
  stepsEditorContainer.style.display = on ? 'block' : 'none';
});

modeSeg.querySelectorAll('button').forEach(btn => {
  btn.addEventListener('click', () => setMode(btn.getAttribute('data-value')));
});

skipTypingSwitch.addEventListener('click', () => {
  const on = skipTypingSwitch.classList.toggle('on');
  promptOptionalTag.style.display = on ? 'inline' : 'none';
  promptEl.placeholder = on
    ? "Optional — jot a note for yourself, e.g. 'daily summary ask'"
    : 'Type the message to auto-send…';
  // You're already sitting in the chat you want when using this mode, so
  // "which chat" doesn't apply — hide it and fall back to "current tab".
  targetFieldEl.style.display = on ? 'none' : 'block';
  if (on) { popupTarget = { mode: 'current' }; renderPopupTargetEditor(); }
});

// --- File attachments ---------------------------------------------------
// Read as base64 up front (rather than at send time) so the job object is
// fully self-contained in storage — content.js reconstructs File objects
// from this and assigns them to claude.ai's uploader. See
// attachFilesToClaude() in content.js for the (best-effort, DOM-dependent)
// automation itself.
const MAX_ATTACHMENT_BYTES = 15 * 1024 * 1024;
function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(new Error(`Couldn't read ${file.name}`));
    r.readAsDataURL(file);
  });
}
function renderAttachList() {
  if (!attachListEl) return; // popup.html has no attach list — attaching only happens via compose.html now
  attachListEl.innerHTML = pendingAttachments.map((f, i) => `
    <span class="attach-chip" data-i="${i}">${escapeHtml(f.name)} <span class="attach-size">${(f.size / 1024).toFixed(0)}KB</span><span class="rm" data-i="${i}">&times;</span></span>
  `).join('');
  attachListEl.querySelectorAll('.rm').forEach(el => {
    el.addEventListener('click', () => {
      pendingAttachments.splice(parseInt(el.getAttribute('data-i'), 10), 1);
      renderAttachList();
    });
  });
}
attachInput?.addEventListener('change', async () => {
  for (const file of Array.from(attachInput.files)) {
    if (file.size > MAX_ATTACHMENT_BYTES) {
      setStatus(`${file.name} is over 15MB — skipped.`, true);
      continue;
    }
    try {
      const dataUrl = await fileToDataUrl(file);
      pendingAttachments.push({ name: file.name, type: file.type, size: file.size, dataUrl });
    } catch (err) { setStatus(err.message, true); }
  }
  attachInput.value = '';
  renderAttachList();
});

function setStatus(msg, isError) {
  statusEl.textContent = msg;
  statusEl.classList.toggle('error', !!isError);
}

async function getJobs() {
  const data = await browser.storage.local.get('jobs');
  return data.jobs || [];
}
async function saveJobs(jobs) {
  await browser.storage.local.set({ jobs });
}

function formatWhen(iso) {
  const d = new Date(iso);
  return d.toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

async function renderJobs() {
  const jobs = await getJobs();
  jobListEl.innerHTML = '';

  if (jobs.length === 0) {
    jobListEl.innerHTML = '<div class="section-label">Queue</div><div class="empty">Nothing scheduled</div>';
    return;
  }

  jobListEl.innerHTML = '<div class="section-label">Queue</div>';
  jobs.sort((a, b) => new Date(a.whenISO) - new Date(b.whenISO));

  for (const job of jobs) {
    const div = document.createElement('div');
    div.className = 'mini-job' + (job.mode === 'auto-detect' ? ' auto' : '');
    const whenLabel = job.mode === 'auto-detect' ? 'AUTO-DETECT' : formatWhen(job.whenISO);
    const manualTag = job.skipTyping ? ' · <span style="color:var(--blue);">CLICK ONLY</span>' : '';
    const stepsTag = job.steps && job.steps.length > 1 ? ` · <span style="color:var(--purple, #b58ce0);">${job.steps.length} STEPS</span>` : '';
    div.innerHTML = `
      <button class="del" data-id="${job.id}" title="Cancel">&times;</button>
      <div class="when">${whenLabel}${manualTag}${stepsTag}</div>
      <div class="prompt">${escapeHtml(job.prompt)}</div>
    `;
    jobListEl.appendChild(div);
  }

  jobListEl.querySelectorAll('.del').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const id = e.currentTarget.getAttribute('data-id');
      const jobs = await getJobs();
      await saveJobs(jobs.filter(j => j.id !== id));
      browser.runtime.sendMessage({ type: 'cancel-job', id });
      renderJobs();
    });
  });
}

scheduleBtn.addEventListener('click', async () => {
  const advanced = advancedSwitch.classList.contains('on');
  if (advanced) syncStepsFromDOM(stepsEditorContainer, popupSteps);

  const prompt = promptEl.value.trim();
  const skipTyping = skipTypingSwitch.classList.contains('on');

  let cleanSteps = null;
  if (advanced) {
    cleanSteps = cleanStepsForSave(popupSteps);
    if (!cleanSteps && !popupSteps.some(s => s.prompt.trim()) && !skipTyping) {
      setStatus('Enter at least one step\'s prompt.', true);
      return;
    }
  } else if (!prompt && !skipTyping) {
    setStatus('Enter a prompt first.', true);
    return;
  }

  let whenISO;
  if (currentMode === 'auto-detect') {
    whenISO = new Date().toISOString();
  } else {
    const whenVal = whenEl.dataset.raw || '';
    if (!whenVal) {
      setStatus('Pick a date and time.', true);
      return;
    }
    const whenDate = new Date(whenVal);
    if (whenDate.getTime() <= Date.now()) {
      setStatus('Pick a time in the future.', true);
      return;
    }
    whenISO = whenDate.toISOString();
  }

  const job = {
    id: 'job-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7),
    prompt: cleanSteps ? cleanSteps[0].prompt : (prompt || (skipTyping ? '(already typed in Claude)' : '')),
    whenISO,
    mode: currentMode,
    target: popupTarget,
    newChat: popupTarget.mode === 'new', // legacy field, kept for old code paths that still read it
    skipTyping,
    retryCount: 0
  };
  if (cleanSteps) job.steps = cleanSteps;
  if (pendingAttachments.length) job.attachments = pendingAttachments.map(f => ({ ...f }));

  const sendingElsewhere = sendFromField.style.display !== 'none'
    && sendFromLabel && sendFromLabel !== myProfileLabel;

  if (sendingElsewhere) {
    try {
      await pushWorkspaceJob(job, sendFromLabel);
      setStatus(`Queued for "${sendFromLabel}" — it'll send once that profile is online.`);
    } catch (err) {
      setStatus(err.message, true);
      return;
    }
  } else {
    const jobs = await getJobs();
    jobs.push(job);
    await saveJobs(jobs);
    browser.runtime.sendMessage({ type: 'schedule-job', job });
    setStatus(currentMode === 'auto-detect' ? 'Watching — will click Send once the limit clears.' : ('Scheduled for ' + formatWhen(job.whenISO)));
  }

  promptEl.value = '';
  window.dtPicker.clear(whenEl);
  popupSteps = stepsFromSimplePrompt('');
  popupTarget = { mode: 'current' };
  renderPopupTargetEditor();
  pendingAttachments = [];
  renderAttachList();
  if (advanced) { advancedSwitch.classList.remove('on'); promptFieldEl.style.display = 'block'; stepsEditorContainer.style.display = 'none'; }
  renderJobs();
});

// Guarded with ?. — these footer buttons only exist in the popup's own
// layout; compose.html reuses this whole script but navigates via the
// page-shell rail nav instead, so these elements are legitimately absent
// there. An unguarded getElementById(...).addEventListener() would throw
// on compose.html and silently kill everything below it in this file
// (including renderJobs() at the very end) — not just these four lines.
document.getElementById('dashboardBtn')?.addEventListener('click', () => {
  browser.tabs.create({ url: browser.runtime.getURL('dashboard.html') });
});
document.getElementById('historyBtn')?.addEventListener('click', () => {
  browser.tabs.create({ url: browser.runtime.getURL('history.html') });
});
document.getElementById('libraryBtn')?.addEventListener('click', () => {
  browser.tabs.create({ url: browser.runtime.getURL('library.html') });
});
document.getElementById('composeBtn')?.addEventListener('click', () => {
  browser.tabs.create({ url: browser.runtime.getURL('compose.html') });
});

// --- Hand off to compose.html for file attachments -----------------------
// Firefox closes an extension popup the instant a native file picker
// opens (it's a separate OS-level window stealing focus), so there's no
// way to attach a file from inside the popup itself. Instead: save
// whatever's already been filled in, open the full-page compose view
// (which isn't a popup and doesn't have this problem), and restore it
// there — see restoreDraftHandoff() below, which runs on compose.html.
document.getElementById('attachViaComposeBtn')?.addEventListener('click', async () => {
  const advanced = advancedSwitch.classList.contains('on');
  if (advanced) syncStepsFromDOM(stepsEditorContainer, popupSteps);
  await browser.storage.local.set({
    draftHandoff: {
      prompt: promptEl.value,
      whenRaw: whenEl.dataset.raw || null,
      mode: currentMode,
      target: popupTarget,
      skipTyping: skipTypingSwitch.classList.contains('on'),
      advanced,
      steps: advanced ? popupSteps : null,
      sendFromLabel
    }
  });
  browser.tabs.create({ url: browser.runtime.getURL('compose.html') });
});

// Runs only on compose.html (popup.html has no #wsStatusCard) — picks up
// a draft saved by the handoff above, if there is one, then clears it so
// it doesn't resurface on a later, unrelated visit to compose.html.
(async function restoreDraftHandoff() {
  if (!document.getElementById('wsStatusCard')) return;
  const { draftHandoff } = await browser.storage.local.get('draftHandoff');
  if (!draftHandoff) return;
  await browser.storage.local.remove('draftHandoff');

  promptEl.value = draftHandoff.prompt || '';
  if (draftHandoff.whenRaw) window.dtPicker.setFromISO(whenEl, draftHandoff.whenRaw);
  if (draftHandoff.mode) setMode(draftHandoff.mode);
  if (draftHandoff.target) { popupTarget = draftHandoff.target; renderPopupTargetEditor(); }
  if (draftHandoff.skipTyping) skipTypingSwitch.classList.add('on');
  if (draftHandoff.sendFromLabel) {
    sendFromLabel = draftHandoff.sendFromLabel;
    await sendFromInitPromise; // wait for members/renderSendFromBtn to be ready before overwriting the label
    renderSendFromBtn();
  }
  if (draftHandoff.advanced && draftHandoff.steps) {
    advancedSwitch.classList.add('on');
    promptFieldEl.style.display = 'none';
    stepsEditorContainer.style.display = 'block';
    popupSteps = draftHandoff.steps;
    renderPopupStepsEditor();
  }
  setStatus('Draft restored — attach your file(s) below, then Schedule.');
})();

// --- "From Library" picker: pick a saved prompt to drop into the textarea --

const fromLibraryBtn = document.getElementById('fromLibraryBtn');
const libraryPicker = document.getElementById('libraryPicker');

async function renderLibraryPicker() {
  libraryPicker.innerHTML = `<div class="lib-picker-empty">Loading…</div>`;
  let ids = [];
  try {
    await ensureSession();
    const [catalog, libIds] = await Promise.all([fetchCatalog(), fetchUserLibraryIds()]);
    setCatalog(catalog);
    ids = libIds;
  } catch (err) {
    libraryPicker.innerHTML = `<div class="lib-picker-empty">${escapeHtml(err.message)}</div>`;
    return;
  }
  const saved = ids.map(id => findSnippet(id)).filter(Boolean);

  if (saved.length === 0) {
    libraryPicker.innerHTML = `<div class="lib-picker-empty">Nothing saved yet.<br><a href="#" id="openLibraryLink">Browse the Library</a> to add some.</div>`;
    libraryPicker.querySelector('#openLibraryLink').addEventListener('click', (e) => {
      e.preventDefault();
      browser.tabs.create({ url: browser.runtime.getURL('library.html') });
    });
    return;
  }

  libraryPicker.innerHTML = saved.map(s => `
    <div class="lib-picker-item" data-id="${s.id}">
      <div class="t">${escapeHtml(s.title)}</div>
      <div class="c">${escapeHtml(s.category)}</div>
    </div>
  `).join('');

  libraryPicker.querySelectorAll('.lib-picker-item').forEach(el => {
    el.addEventListener('click', () => {
      const s = findSnippet(el.getAttribute('data-id'));
      if (s && s.examples && s.examples.length) {
        const filled = fillPlaceholders(s.examples[0].prompt);
        if (filled !== null) {
          promptEl.value = filled;
          bumpUsageCount(s.id); // fire-and-forget, see supabase-client.js
          bumpExampleUsage(s.id, 0);
        }
      }
      libraryPicker.style.display = 'none';
    });
  });
}

fromLibraryBtn.addEventListener('click', async (e) => {
  e.stopPropagation();
  const opening = libraryPicker.style.display === 'none';
  if (opening) await renderLibraryPicker();
  libraryPicker.style.display = opening ? 'block' : 'none';
});
document.addEventListener('click', (e) => {
  if (!libraryPicker.contains(e.target) && e.target !== fromLibraryBtn) {
    libraryPicker.style.display = 'none';
  }
});

renderJobs();
browser.runtime.sendMessage({ type: 'clear-failure-badge' }); // opening the popup counts as "seen"
