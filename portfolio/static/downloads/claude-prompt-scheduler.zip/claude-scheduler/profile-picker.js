// profile-picker.js — the "Send from" picker, as a searchable card modal
// instead of a plain <select>, matching chat-picker.js's look. Also used
// standalone by workspace.js if it ever wants a "send a test job to..."
// affordance (not wired up there yet, but the API supports it).
//
// window.profilePicker.open({ members, myProfileLabel, selectedLabel, onSelect })
//   members: rows from fetchWorkspaceMembers() (profile_label, user_id,
//            rate_limited, rate_limit_detail, status_updated_at, ...)

(function () {
  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
  }

  function statusText(m) {
    if (!m.status_updated_at) return 'no status yet';
    return m.rate_limited ? 'rate limited' : 'available';
  }
  function statusColor(m) {
    if (!m.status_updated_at) return 'var(--text-faint)';
    return m.rate_limited ? 'var(--red)' : 'var(--amber)';
  }
  function resetText(m) {
    if (!m.rate_limited || !m.rate_limit_detail) return '';
    const parsed = window.resetTimeUtil ? window.resetTimeUtil.parseResetLabel(m.rate_limit_detail) : null;
    return parsed ? parsed.label : m.rate_limit_detail;
  }

  let closeFn = null;
  function close() { if (closeFn) { closeFn(); closeFn = null; } }

  function open(opts) {
    close();
    const members = opts.members || [];

    const backdrop = document.createElement('div');
    backdrop.className = 'sched-modal-backdrop';
    backdrop.innerHTML = `
      <div class="sched-modal">
        <div class="sched-modal-head">
          <h3>Send from</h3>
          <button type="button" class="sched-modal-close">&times;</button>
        </div>
        <div class="sched-modal-body">
          ${members.map(m => `
            <div class="profile-pick-item${m.profile_label === opts.selectedLabel ? ' selected' : ''}" data-label="${escapeHtml(m.profile_label)}">
              <div>
                <div class="pp-name">${escapeHtml(m.profile_label)}${m.profile_label === opts.myProfileLabel ? ' (this profile)' : ''}</div>
                ${resetText(m) ? `<div class="pp-reset">${escapeHtml(resetText(m))}</div>` : ''}
              </div>
              <span style="font-family:var(--font-mono); font-size:10.5px; color:${statusColor(m)};">${statusText(m)}</span>
            </div>
          `).join('')}
        </div>
      </div>
    `;
    document.body.appendChild(backdrop);

    backdrop.querySelectorAll('.profile-pick-item').forEach(el => {
      el.addEventListener('click', () => {
        const m = members.find(x => x.profile_label === el.getAttribute('data-label'));
        if (m && opts.onSelect) opts.onSelect(m);
        close();
      });
    });
    backdrop.querySelector('.sched-modal-close').addEventListener('click', close);
    backdrop.addEventListener('click', (e) => { if (e.target === backdrop) close(); });
    const escHandler = (e) => { if (e.key === 'Escape') close(); };
    document.addEventListener('keydown', escHandler);
    closeFn = () => { document.removeEventListener('keydown', escHandler); backdrop.remove(); };
  }

  window.profilePicker = { open, close };
})();
