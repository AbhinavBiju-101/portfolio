// reset-time.js — turns content.js's best-effort rate-limit detail text
// (a raw excerpt like "You've reached your usage limit. Try again at 3:00
// PM" — see getRateLimitDetail() in content.js) into a short, consistent
// "resets …" label, shared by workspace.js and profile-picker.js so both
// surfaces describe a linked profile's rate limit the same way.
//
// This is inherently best-effort: it's regexing free text scraped from
// claude.ai's UI, not a real API value. If nothing matches, callers should
// just fall back to showing the raw detail text.

function parseResetLabel(detail) {
  if (!detail) return null;

  // "Try again at 3:00 PM" / "resets at 3:00 PM" / "available at 3:00pm"
  let m = /\b(?:try again|resets?|available)\s*(?:at)?\s*(\d{1,2}(?::\d{2})?\s*[ap]\.?m\.?)/i.exec(detail);
  if (m) return { label: `resets ${m[1].replace(/\./g, '').toUpperCase().replace(/\s+/g, ' ')}`, atText: m[1] };

  // "Try again in 2 hours" / "in 45 minutes" / "in 3 hours 20 minutes"
  m = /\bin\s+(\d+)\s*(hour|hr|minute|min)s?\b(?:\s+(\d+)\s*(hour|hr|minute|min)s?\b)?/i.exec(detail);
  if (m) {
    const parts = [];
    const unit1 = /h/i.test(m[2]) ? 'h' : 'm';
    parts.push(`${m[1]}${unit1}`);
    if (m[3]) { const unit2 = /h/i.test(m[4]) ? 'h' : 'm'; parts.push(`${m[3]}${unit2}`); }
    return { label: `resets in ${parts.join(' ')}`, inText: parts.join(' ') };
  }

  return null;
}

// Best-effort absolute Date for a "resets HH:MM AM/PM" match, assuming the
// reset is today or (if that time has already passed) tomorrow. Returns
// null when the detail didn't parse to a clock time (e.g. relative "in 2
// hours" form) — callers should just show the text label in that case
// rather than fabricate a countdown.
function resetLabelToDate(parsed) {
  if (!parsed || !parsed.atText) return null;
  const m = /(\d{1,2})(?::(\d{2}))?\s*([ap])/i.exec(parsed.atText);
  if (!m) return null;
  let hour = parseInt(m[1], 10) % 12;
  if (m[3].toLowerCase() === 'p') hour += 12;
  const min = m[2] ? parseInt(m[2], 10) : 0;
  const d = new Date();
  d.setHours(hour, min, 0, 0);
  if (d.getTime() <= Date.now()) d.setDate(d.getDate() + 1);
  return d;
}

window.resetTimeUtil = { parseResetLabel, resetLabelToDate };
