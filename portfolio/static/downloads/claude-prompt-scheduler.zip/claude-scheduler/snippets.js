// snippets.js — runtime cache of the prompt catalog, fetched from Supabase
// (see supabase-client.js). Kept as a separate global (rather than folded
// into library.js/popup.js) since both the library page and the popup's
// "From Library" picker need to read the same in-memory catalog.

let SNIPPET_LIBRARY = [];

// Called after fetchCatalog() resolves. Mutates in place so any closures
// that already grabbed a reference to SNIPPET_LIBRARY see the update too.
function setCatalog(items) {
  SNIPPET_LIBRARY.length = 0;
  SNIPPET_LIBRARY.push(...items);
}

function snippetCategories() {
  return Array.from(new Set(SNIPPET_LIBRARY.map(s => s.category))).sort();
}

function findSnippet(id) {
  return SNIPPET_LIBRARY.find(s => s.id === id) || null;
}
