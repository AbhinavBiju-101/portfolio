// steps-editor.js
// Shared "multi-step sequence with conditional branching" editor UI.
// Used by both popup.js (creating a new job) and dashboard.js (editing an
// existing one), so the branching UX and step-object shape stay identical
// in both places instead of drifting.
//
// A step looks like: { id, prompt, branches: [{id, keywords, nextStepId}],
//                       defaultNextStepId }
// See content.js's matchBranch()/runSequence() for how this is executed.
//
// Callers own their own state object (an array of steps) and pass it in —
// this module has no module-level state of its own, so popup.js and
// dashboard.js can each keep independent editors on screen at once.

function newStepId() { return 'step-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
function newBranchId() { return 'branch-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }

function stepsFromSimplePrompt(prompt) {
  return [{ id: newStepId(), prompt: prompt || '', branches: [], defaultNextStepId: null }];
}
function stepsFromJob(job) {
  return (job.steps && job.steps.length)
    ? job.steps.map(s => ({
        id: s.id, prompt: s.prompt,
        branches: (s.branches || []).map(b => ({ ...b })),
        defaultNextStepId: s.defaultNextStepId || null
      }))
    : stepsFromSimplePrompt(job.prompt);
}

function stepOptionsHtml(steps, excludeId, selectedId) {
  let html = `<option value="">— end sequence —</option>`;
  steps.forEach((s, i) => {
    if (s.id === excludeId) return;
    html += `<option value="${s.id}" ${selectedId === s.id ? 'selected' : ''}>Step ${i + 1}</option>`;
  });
  return html;
}

function renderStepsEditorHtml(steps) {
  let html = '';
  steps.forEach((step, i) => {
    html += `
      <div class="step-card" data-step-id="${step.id}">
        <div class="step-card-head">
          <b>Step ${i + 1}</b>
          ${steps.length > 1 ? `<button type="button" class="btn btn-danger remove-step-btn" data-step-id="${step.id}">Remove step</button>` : ''}
        </div>
        <textarea class="step-prompt edit-prompt" data-step-id="${step.id}" rows="2">${escapeHtml(step.prompt)}</textarea>
        <div class="branches">
          <div class="section-label">Response branches — checked in order, first keyword match wins</div>
          ${step.branches.map(b => `
            <div class="branch-row" data-branch-id="${b.id}">
              <input type="text" class="branch-keywords" data-branch-id="${b.id}"
                placeholder="keywords, comma, separated"
                value="${escapeHtml((b.keywords || []).join(', '))}">
              <span class="branch-arrow">&rarr;</span>
              <select class="branch-target" data-branch-id="${b.id}">${stepOptionsHtml(steps, step.id, b.nextStepId)}</select>
              <button type="button" class="btn btn-danger remove-branch-btn" data-step-id="${step.id}" data-branch-id="${b.id}">&times;</button>
            </div>
          `).join('')}
          <button type="button" class="btn btn-ghost add-branch-btn" data-step-id="${step.id}">+ Add response branch</button>
          <div class="step-default-row">
            <span class="switch-label">If nothing matches, go to:</span>
            <select class="step-default-next" data-step-id="${step.id}">${stepOptionsHtml(steps, step.id, step.defaultNextStepId)}</select>
          </div>
        </div>
      </div>
    `;
  });
  html += `<button type="button" class="btn btn-ghost add-step-btn">+ Add step</button>`;
  return html;
}

// Pulls current DOM field values back into `steps` before a structural
// change (add/remove step or branch) re-renders the panel, so in-progress
// typing elsewhere in the same editor isn't lost.
function syncStepsFromDOM(root, steps) {
  root.querySelectorAll('.step-prompt').forEach(el => {
    const step = steps.find(s => s.id === el.dataset.stepId);
    if (step) step.prompt = el.value;
  });
  root.querySelectorAll('.branch-keywords').forEach(el => {
    for (const step of steps) {
      const b = step.branches.find(b => b.id === el.dataset.branchId);
      if (b) { b.keywords = el.value.split(',').map(w => w.trim()).filter(Boolean); break; }
    }
  });
  root.querySelectorAll('.branch-target').forEach(el => {
    for (const step of steps) {
      const b = step.branches.find(b => b.id === el.dataset.branchId);
      if (b) { b.nextStepId = el.value || null; break; }
    }
  });
  root.querySelectorAll('.step-default-next').forEach(el => {
    const step = steps.find(s => s.id === el.dataset.stepId);
    if (step) step.defaultNextStepId = el.value || null;
  });
  const simplePrompt = root.querySelector('.simple-prompt');
  if (simplePrompt && steps[0]) steps[0].prompt = simplePrompt.value;
}

// onChange() is called after every structural mutation (add/remove step or
// branch) — the caller is expected to re-render the panel from `steps` and
// call attachStepsEditorHandlers() again (a fresh DOM needs fresh listeners).
function attachStepsEditorHandlers(root, steps, onChange) {
  root.querySelectorAll('.add-step-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      syncStepsFromDOM(root, steps);
      steps.push({ id: newStepId(), prompt: '', branches: [], defaultNextStepId: null });
      onChange();
    });
  });
  root.querySelectorAll('.remove-step-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      syncStepsFromDOM(root, steps);
      const id = btn.getAttribute('data-step-id');
      const idx = steps.findIndex(s => s.id === id);
      if (idx > -1) steps.splice(idx, 1);
      for (const s of steps) {
        if (s.defaultNextStepId === id) s.defaultNextStepId = null;
        s.branches.forEach(b => { if (b.nextStepId === id) b.nextStepId = null; });
      }
      onChange();
    });
  });
  root.querySelectorAll('.add-branch-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      syncStepsFromDOM(root, steps);
      const step = steps.find(s => s.id === btn.getAttribute('data-step-id'));
      if (step) step.branches.push({ id: newBranchId(), keywords: [], nextStepId: null });
      onChange();
    });
  });
  root.querySelectorAll('.remove-branch-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      syncStepsFromDOM(root, steps);
      const step = steps.find(s => s.id === btn.getAttribute('data-step-id'));
      if (step) step.branches = step.branches.filter(b => b.id !== btn.getAttribute('data-branch-id'));
      onChange();
    });
  });
}

// Strips working-editor-only fields down to what background.js/content.js
// actually need, and drops the whole "steps" shape entirely for a
// single-step job with no branching (kept as plain job.prompt, matching
// jobs saved before the sequence feature existed).
function cleanStepsForSave(steps) {
  const trimmed = steps
    .map(s => ({ ...s, prompt: (s.prompt || '').trim() }))
    .filter(s => s.prompt);
  if (trimmed.length <= 1 && !(trimmed[0] && trimmed[0].branches && trimmed[0].branches.length)) {
    return null; // caller should fall back to a plain job.prompt
  }
  return trimmed;
}
