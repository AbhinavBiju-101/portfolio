// supabase-client.js — plain fetch() wrapper around Supabase's REST (PostgREST)
// and Auth (GoTrue) APIs. Deliberately not using the official supabase-js SDK:
// bundling it would work against the "keep the extension small" goal, and
// Mozilla's review policy prohibits loading it from a CDN at runtime, so it'd
// have to be vendored in anyway — a hand-rolled ~150-line wrapper is smaller
// and easier to audit for an AMO reviewer than a full SDK bundle.
//
// Session model: one Supabase Auth session per browser (stored in
// browser.storage.local under "sbSession"). New installs get a silent
// anonymous identity on first use — that's enough for a private, per-device
// library immediately. Linking an email upgrades that SAME identity to a
// permanent one (same user id, so existing saved items carry over) and lets
// the same email be used to sign back into that identity on another device.

const AUTH_URL = `${SUPABASE_URL}/auth/v1`;
const REST_URL = `${SUPABASE_URL}/rest/v1`;

async function getStoredSession() {
  const data = await browser.storage.local.get('sbSession');
  return data.sbSession || null;
}
async function storeSession(session) {
  await browser.storage.local.set({ sbSession: session });
  return session;
}

function authHeaders(session) {
  return {
    'apikey': SUPABASE_ANON_KEY,
    'Authorization': `Bearer ${session.access_token}`,
    'Content-Type': 'application/json'
  };
}

async function readError(res, fallback) {
  try {
    const body = await res.json();
    return body.msg || body.error_description || body.message || fallback;
  } catch { return fallback; }
}

async function signInAnonymously() {
  const res = await fetch(`${AUTH_URL}/signup`, {
    method: 'POST',
    headers: { 'apikey': SUPABASE_ANON_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({})
  });
  if (!res.ok) throw new Error(await readError(res, 'Anonymous sign-in failed'));
  return storeSession(await res.json());
}

async function refreshSession(session) {
  const res = await fetch(`${AUTH_URL}/token?grant_type=refresh_token`, {
    method: 'POST',
    headers: { 'apikey': SUPABASE_ANON_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({ refresh_token: session.refresh_token })
  });
  if (!res.ok) return null;
  return storeSession(await res.json());
}

// Returns a valid session, transparently refreshing or creating an
// anonymous one as needed. Call this before any authenticated request.
async function ensureSession() {
  let session = await getStoredSession();
  if (!session) return signInAnonymously();

  const expiresAtMs = (session.expires_at || 0) * 1000;
  if (Date.now() > expiresAtMs - 60000) {
    const refreshed = await refreshSession(session);
    if (refreshed) return refreshed;
    return signInAnonymously(); // refresh token dead — fall back to a fresh anonymous identity
  }
  return session;
}

async function currentUser() {
  return (await ensureSession()).user;
}
function isAnonymous(user) {
  return !!(user && user.is_anonymous);
}

// --- Cross-device sync via email --------------------------------------------

// Upgrades the CURRENT (anonymous) identity to a permanent one tied to this
// email — same user id, so everything already saved stays saved. Sends a
// 6-digit code to the email (requires the template change noted in
// supabase-schema.sql).
async function startLinkEmail(email) {
  const session = await ensureSession();
  const res = await fetch(`${AUTH_URL}/user`, {
    method: 'PUT',
    headers: authHeaders(session),
    body: JSON.stringify({ email })
  });
  if (!res.ok) throw new Error(await readError(res, 'Could not start linking that email'));
}
async function confirmLinkEmail(email, token) {
  return verifyEmailCode(email, token, 'email_change');
}

// For a second/third device: signs into an ALREADY-linked email, replacing
// this device's local session with the synced identity's.
async function requestSignInCode(email) {
  const res = await fetch(`${AUTH_URL}/otp`, {
    method: 'POST',
    headers: { 'apikey': SUPABASE_ANON_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, create_user: false })
  });
  if (!res.ok) throw new Error(await readError(res, 'Could not send a sign-in code — is this email linked yet?'));
}
async function confirmSignIn(email, token) {
  return verifyEmailCode(email, token, 'email');
}

async function verifyEmailCode(email, token, type) {
  const res = await fetch(`${AUTH_URL}/verify`, {
    method: 'POST',
    headers: { 'apikey': SUPABASE_ANON_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, token, type })
  });
  if (!res.ok) throw new Error(await readError(res, 'That code is invalid or expired'));
  return storeSession(await res.json());
}

// --- Catalog (public, read-only) --------------------------------------------

async function fetchCatalog() {
  const res = await fetch(`${REST_URL}/snippets?select=*&order=created_at.desc`, {
    headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${SUPABASE_ANON_KEY}` }
  });
  if (!res.ok) throw new Error('Could not load the prompt library — check your connection');
  const rows = await res.json();
  // Normalize the DB's snake_case columns (see supabase-schema.sql) to the
  // camelCase shape the rest of the extension reads, in one place — so
  // library.js/popup.js never have to know or care what the raw column
  // names are.
  return rows.map(row => ({
    id: row.id,
    title: row.title,
    category: row.category,
    tags: row.tags || [],
    description: row.description,
    descriptionFormat: row.description_format,
    recommendedContext: row.recommended_context,
    recommendedContextFormat: row.recommended_context_format,
    examples: row.examples || [],
    usageCount: row.usage_count || 0,
    exampleUsage: row.example_usage || {},
    isOfficial: row.is_official !== false,
    authorLabel: row.author_label || null,
    createdBy: row.created_by || null,
    moderationStatus: row.moderation_status || 'approved',
    moderationNote: row.moderation_note || null,
    forkedFrom: row.forked_from || null,
    versionHistory: row.version_history || [],
    createdAt: row.created_at,
    updatedAt: row.updated_at
  }));
}

// --- User library (per-user, RLS-protected) ---------------------------------

async function fetchUserLibraryIds() {
  const session = await ensureSession();
  const res = await fetch(`${REST_URL}/user_library?select=snippet_id&user_id=eq.${session.user.id}`, {
    headers: authHeaders(session)
  });
  if (!res.ok) throw new Error('Could not load your saved library');
  return (await res.json()).map(r => r.snippet_id);
}

async function addToLibrary(snippetId) {
  const session = await ensureSession();
  const res = await fetch(`${REST_URL}/user_library`, {
    method: 'POST',
    headers: { ...authHeaders(session), Prefer: 'resolution=ignore-duplicates' },
    body: JSON.stringify({ user_id: session.user.id, snippet_id: snippetId })
  });
  if (!res.ok) throw new Error('Could not save that to your library');
}

async function removeFromLibrary(snippetId) {
  const session = await ensureSession();
  const res = await fetch(`${REST_URL}/user_library?user_id=eq.${session.user.id}&snippet_id=eq.${snippetId}`, {
    method: 'DELETE',
    headers: authHeaders(session)
  });
  if (!res.ok) throw new Error('Could not remove that from your library');
}

// --- Usage counts (anonymous included) --------------------------------------

// Fire-and-forget by design (callers shouldn't block scheduling a job on
// this) — call it whenever a catalog prompt is actually used, e.g. dropped
// into the popup's textarea.
async function bumpUsageCount(snippetId) {
  try {
    const session = await ensureSession();
    await fetch(`${REST_URL}/rpc/increment_snippet_usage`, {
      method: 'POST',
      headers: authHeaders(session),
      body: JSON.stringify({ p_snippet_id: snippetId })
    });
  } catch (err) { /* non-critical — never block the caller on this */ }
}

// --- Ratings (email-linked accounts only — see supabase-schema.sql RLS) ----

async function fetchRatingSummaries() {
  const res = await fetch(`${REST_URL}/snippet_rating_summary?select=*`, {
    headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${SUPABASE_ANON_KEY}` }
  });
  if (!res.ok) return {};
  const rows = await res.json();
  const byId = {};
  for (const r of rows) byId[r.snippet_id] = { avg: parseFloat(r.avg_rating), count: r.rating_count };
  return byId;
}

async function fetchMyRating(snippetId) {
  const session = await ensureSession();
  const res = await fetch(`${REST_URL}/snippet_ratings?select=rating,review&snippet_id=eq.${snippetId}&user_id=eq.${session.user.id}`, {
    headers: authHeaders(session)
  });
  if (!res.ok) return null;
  const rows = await res.json();
  return rows[0] || null;
}

// Throws a clear message if the current session is anonymous — the RLS
// policy would reject the write anyway, but a friendly error beats a raw
// 401/403 from PostgREST.
async function rateSnippet(snippetId, rating, review) {
  const session = await ensureSession();
  if (isAnonymous(session.user)) {
    throw new Error('Link an email on the Account page to leave ratings.');
  }
  const res = await fetch(`${REST_URL}/snippet_ratings`, {
    method: 'POST',
    headers: { ...authHeaders(session), Prefer: 'resolution=merge-duplicates' },
    body: JSON.stringify({ snippet_id: snippetId, user_id: session.user.id, rating, review: review || null })
  });
  if (!res.ok) throw new Error(await readError(res, 'Could not save your rating'));
}

// --- Sign in with Google ----------------------------------------------------
// Runs entirely inside the extension — no hosted redirect page needed.
// Uses Google's OIDC implicit flow (response_type=id_token) via
// browser.identity.launchWebAuthFlow() to get an ID token directly, then
// hands that to Supabase's signInWithIdToken(), which is the pattern
// Supabase itself recommends for native/mobile apps (an extension has the
// same "no web page to land on" constraint). This upgrades the CURRENT
// identity (anonymous or already-email-linked) rather than creating a
// separate account — same one-identity-per-profile model as email linking.

function getGoogleRedirectUri() {
  return browser.identity.getRedirectURL(); // stable as long as manifest's gecko.id is pinned
}

function randomNonce() {
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
}

// Supabase hashes whatever nonce you give signInWithIdToken/the id_token
// grant with SHA-256 and compares that against the id_token's own `nonce`
// claim — for EVERY provider, not just Apple as commonly assumed (this
// was the actual bug behind the "nonce mismatch" error: sending the same
// raw value to both Google and Supabase can never match, since Supabase
// hashes its copy before comparing). So: Google gets the HASH (so the
// token it mints contains the hash as its nonce claim), Supabase gets the
// original RAW value (it hashes its own copy internally to compare).
async function sha256Hex(text) {
  const data = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, '0')).join('');
}

function decodeJwtPayload(jwt) {
  let b64 = jwt.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
  b64 += '='.repeat((4 - (b64.length % 4)) % 4); // restore JWT's stripped base64 padding
  return JSON.parse(atob(b64));
}

async function signInWithGoogle() {
  if (GOOGLE_CLIENT_ID.startsWith('YOUR-CLIENT-ID')) {
    throw new Error('Google sign-in is not configured yet — set GOOGLE_CLIENT_ID in supabase-config.js.');
  }
  const rawNonce = randomNonce();
  const hashedNonce = await sha256Hex(rawNonce);
  const redirectUri = getGoogleRedirectUri();
  const authUrl = 'https://accounts.google.com/o/oauth2/v2/auth?' + new URLSearchParams({
    client_id: GOOGLE_CLIENT_ID,
    redirect_uri: redirectUri,
    response_type: 'id_token',
    scope: 'openid email profile', // basic scopes only — no sensitive-scope verification review needed
    nonce: hashedNonce, // the HASH goes to Google — see sha256Hex()'s comment above
    prompt: 'select_account'
  });

  const resultUrl = await browser.identity.launchWebAuthFlow({ url: authUrl, interactive: true });
  const fragment = new URLSearchParams(new URL(resultUrl).hash.slice(1));
  const idToken = fragment.get('id_token');
  if (!idToken) {
    const err = fragment.get('error');
    throw new Error(err === 'access_denied' ? 'Sign-in was cancelled.' : ('Google sign-in failed' + (err ? `: ${err}` : '')));
  }

  const session = await ensureSession();

  // Try LINKING the Google identity to the current session first — this
  // is what preserves an anonymous session's saved library (same user id
  // throughout, exactly like startLinkEmail() does for email). Requires
  // "Allow manual linking" enabled in Supabase Dashboard → Authentication
  // → Settings; see migration-03.sql's header comment.
  let res = await fetch(`${AUTH_URL}/token?grant_type=id_token`, {
    method: 'POST',
    headers: authHeaders(session),
    body: JSON.stringify({ provider: 'google', id_token: idToken, nonce: rawNonce, link_identity: true }) // the RAW value goes to Supabase
  });

  if (!res.ok) {
    // Most likely cause: this Google account is already linked to a
    // DIFFERENT identity (e.g. set up on another profile already) — same
    // situation startLinkEmail() hits when an email is already claimed.
    // Fall back to a plain sign-in, which switches this device over to
    // that existing identity (its library, not this session's).
    res = await fetch(`${AUTH_URL}/token?grant_type=id_token`, {
      method: 'POST',
      headers: { 'apikey': SUPABASE_ANON_KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify({ provider: 'google', id_token: idToken, nonce: rawNonce })
    });
  }
  if (!res.ok) throw new Error(await readError(res, 'Google sign-in failed'));
  return (await storeSession(await res.json())).user;
}

// Drops this device back to a fresh anonymous identity. Anything saved
// under the signed-in identity stays in Supabase (nothing is deleted) —
// this only forgets the LOCAL session, same as signing out anywhere else.
async function signOut() {
  const session = await getStoredSession();
  if (session) {
    try {
      await fetch(`${AUTH_URL}/logout`, { method: 'POST', headers: authHeaders(session) });
    } catch (err) { /* best-effort — proceed to clear locally either way */ }
  }
  await browser.storage.local.remove(['sbSession', 'workspaceId', 'profileLabel']);
  return signInAnonymously();
}

// --- Community catalog submissions (email/Google-linked accounts only —
// same jwt_is_anonymous() RLS gate as ratings; see migration-03.sql) --------

async function submitSnippet(snippet) {
  const session = await ensureSession();
  if (isAnonymous(session.user)) throw new Error('Link an email or sign in with Google to submit prompts.');
  const res = await fetch(`${REST_URL}/snippets`, {
    method: 'POST',
    headers: { ...authHeaders(session), Prefer: 'return=representation' },
    body: JSON.stringify({
      id: snippet.id,
      title: snippet.title,
      category: snippet.category,
      tags: snippet.tags || [],
      description: snippet.description,
      recommended_context: snippet.recommendedContext || null,
      examples: snippet.examples || [],
      created_by: session.user.id,
      is_official: false,
      author_label: snippet.authorLabel,
      moderation_status: 'pending',
      forked_from: snippet.forkedFrom || null
    })
  });
  if (!res.ok) throw new Error(await readError(res, 'Could not submit that prompt'));
  return (await res.json())[0];
}

async function updateMySnippet(id, patch) {
  const session = await ensureSession();
  const body = {};
  if (patch.title != null) body.title = patch.title;
  if (patch.category != null) body.category = patch.category;
  if (patch.tags != null) body.tags = patch.tags;
  if (patch.description != null) body.description = patch.description;
  if (patch.recommendedContext !== undefined) body.recommended_context = patch.recommendedContext || null;
  if (patch.examples != null) body.examples = patch.examples;
  const res = await fetch(`${REST_URL}/snippets?id=eq.${id}`, {
    method: 'PATCH',
    headers: authHeaders(session),
    body: JSON.stringify(body)
  });
  if (!res.ok) throw new Error(await readError(res, 'Could not save your changes'));
}

async function deleteMySnippet(id) {
  const session = await ensureSession();
  const res = await fetch(`${REST_URL}/snippets?id=eq.${id}`, {
    method: 'DELETE',
    headers: authHeaders(session)
  });
  if (!res.ok) throw new Error(await readError(res, 'Could not delete that submission'));
}

// A stable, user-chosen display name shown as "by @handle" on their
// submissions — stored locally (not worth a whole profile-name concept in
// the DB yet) and sent with each new submission's author_label.
async function getAuthorLabel() {
  const data = await browser.storage.local.get('authorLabel');
  return data.authorLabel || null;
}
async function setAuthorLabel(label) {
  await browser.storage.local.set({ authorLabel: label });
}

// --- Reports (email/Google-linked accounts only) ---------------------------

async function reportSnippet(snippetId, reason, detail) {
  const session = await ensureSession();
  if (isAnonymous(session.user)) throw new Error('Link an email or sign in with Google to file a report.');
  const res = await fetch(`${REST_URL}/snippet_reports`, {
    method: 'POST',
    headers: authHeaders(session),
    body: JSON.stringify({ snippet_id: snippetId, reporter_id: session.user.id, reason, detail: detail || null })
  });
  if (!res.ok) throw new Error(await readError(res, 'Could not file that report'));
}

// --- Per-example usage ("variants") -----------------------------------------

async function bumpExampleUsage(snippetId, exampleIndex) {
  try {
    const session = await ensureSession();
    await fetch(`${REST_URL}/rpc/increment_example_usage`, {
      method: 'POST',
      headers: authHeaders(session),
      body: JSON.stringify({ p_snippet_id: snippetId, p_example_index: exampleIndex })
    });
  } catch (err) { /* non-critical, same as bumpUsageCount */ }
}

// --- Account deletion --------------------------------------------------------

async function deleteMyAccount() {
  const session = await ensureSession();
  const res = await fetch(`${REST_URL}/rpc/delete_my_account`, {
    method: 'POST', headers: authHeaders(session)
  });
  if (!res.ok) throw new Error(await readError(res, 'Could not delete your account'));
  await browser.storage.local.remove(['sbSession', 'workspaceId', 'profileLabel', 'authorLabel']);
  return signInAnonymously(); // leaves this device with a fresh, empty identity
}

async function createWorkspace(profileLabel) {
  const session = await ensureSession();
  const res = await fetch(`${REST_URL}/rpc/create_workspace`, {
    method: 'POST', headers: authHeaders(session),
    body: JSON.stringify({ p_profile_label: profileLabel })
  });
  if (!res.ok) throw new Error(await readError(res, 'Could not create a workspace'));
  const workspaceId = await res.json();
  await browser.storage.local.set({ workspaceId, profileLabel });
  return workspaceId;
}

async function joinWorkspace(joinCode, profileLabel) {
  const session = await ensureSession();
  const res = await fetch(`${REST_URL}/rpc/join_workspace`, {
    method: 'POST', headers: authHeaders(session),
    body: JSON.stringify({ p_join_code: joinCode.trim().toUpperCase(), p_profile_label: profileLabel })
  });
  if (!res.ok) throw new Error(await readError(res, 'Could not join — check the code and try again'));
  const workspaceId = await res.json();
  await browser.storage.local.set({ workspaceId, profileLabel });
  return workspaceId;
}

async function getLocalWorkspaceInfo() {
  const data = await browser.storage.local.get(['workspaceId', 'profileLabel']);
  return { workspaceId: data.workspaceId || null, profileLabel: data.profileLabel || null };
}

async function leaveWorkspace() {
  const { workspaceId } = await getLocalWorkspaceInfo();
  if (!workspaceId) return;
  const session = await ensureSession();
  await fetch(`${REST_URL}/workspace_members?workspace_id=eq.${workspaceId}&user_id=eq.${session.user.id}`, {
    method: 'DELETE', headers: authHeaders(session)
  });
  await browser.storage.local.remove(['workspaceId', 'profileLabel']);
}

async function fetchWorkspaceMembers() {
  const { workspaceId } = await getLocalWorkspaceInfo();
  if (!workspaceId) return [];
  const session = await ensureSession();
  const res = await fetch(`${REST_URL}/workspace_members?select=*&workspace_id=eq.${workspaceId}&order=joined_at.asc`, {
    headers: authHeaders(session)
  });
  // Throws on failure now rather than silently returning [] — a fetch
  // error (network, auth, RLS) is NOT the same thing as "this workspace
  // genuinely has zero members," and callers (see account.js's
  // renderWorkspaceBody) need to tell those two apart instead of treating
  // every failure as "the workspace must have been deleted."
  if (!res.ok) throw new Error(await readError(res, 'Could not load your workspace\'s members'));
  return res.json();
}

async function fetchWorkspaceJoinCode() {
  const { workspaceId } = await getLocalWorkspaceInfo();
  if (!workspaceId) return null;
  const session = await ensureSession();
  const res = await fetch(`${REST_URL}/workspaces?select=join_code&id=eq.${workspaceId}`, {
    headers: authHeaders(session)
  });
  if (!res.ok) throw new Error(await readError(res, 'Could not load your workspace'));
  const rows = await res.json();
  return rows[0] ? rows[0].join_code : null; // null here now genuinely means "0 rows, no error"
}

// Pulls a fresh code right now, without waiting for someone to join first
// (join_workspace() auto-rotates the code on every successful join).
async function rotateWorkspaceJoinCode() {
  const { workspaceId } = await getLocalWorkspaceInfo();
  if (!workspaceId) throw new Error('Not part of a workspace');
  const session = await ensureSession();
  const res = await fetch(`${REST_URL}/rpc/rotate_workspace_join_code`, {
    method: 'POST', headers: authHeaders(session),
    body: JSON.stringify({ p_workspace_id: workspaceId })
  });
  if (!res.ok) throw new Error(await readError(res, 'Could not generate a new code'));
  return res.json();
}

async function updateMyProfileLabel(label) {
  const { workspaceId } = await getLocalWorkspaceInfo();
  const session = await ensureSession();
  if (workspaceId) {
    await fetch(`${REST_URL}/workspace_members?workspace_id=eq.${workspaceId}&user_id=eq.${session.user.id}`, {
      method: 'PATCH', headers: authHeaders(session),
      body: JSON.stringify({ profile_label: label })
    });
  }
  await browser.storage.local.set({ profileLabel: label });
}

// Best-effort presence/rate-limit status, reported by content.js's
// periodic self-check (see reportRateLimitStatus() there) and relayed
// here by background.js. Silently no-ops if not in a workspace — most
// installs never call this.
async function updateMyWorkspaceStatus(rateLimited, detail) {
  try {
    const { workspaceId } = await getLocalWorkspaceInfo();
    if (!workspaceId) return;
    const session = await ensureSession();
    await fetch(`${REST_URL}/workspace_members?workspace_id=eq.${workspaceId}&user_id=eq.${session.user.id}`, {
      method: 'PATCH', headers: authHeaders(session),
      body: JSON.stringify({ rate_limited: !!rateLimited, rate_limit_detail: detail || null, status_updated_at: new Date().toISOString() })
    });
  } catch (err) { /* best-effort — a missed status update isn't worth surfacing an error for */ }
}

// Best-effort chat-list heartbeat — mirrors updateMyWorkspaceStatus above,
// but for the sidebar chat list rather than rate-limit state. Stored as
// jsonb text; capped client-side (see content.js's reportChatList) so one
// very active profile can't blow past a reasonable row size. Silently
// no-ops outside a workspace, same as the status heartbeat.
async function updateMyWorkspaceChatList(chats) {
  try {
    const { workspaceId } = await getLocalWorkspaceInfo();
    if (!workspaceId) return;
    const session = await ensureSession();
    await fetch(`${REST_URL}/workspace_members?workspace_id=eq.${workspaceId}&user_id=eq.${session.user.id}`, {
      method: 'PATCH', headers: authHeaders(session),
      body: JSON.stringify({ chat_list_json: JSON.stringify(chats || []), chat_list_updated_at: new Date().toISOString() })
    });
  } catch (err) { /* best-effort — a missed chat-list update isn't worth surfacing an error for */ }
}

// Push a job to be executed by a DIFFERENT profile in the workspace. The
// creating profile never runs this job locally — the target profile's
// background.js polls for it (see pollWorkspaceJobsForMe below).
async function pushWorkspaceJob(job, targetProfileLabel) {
  const { workspaceId } = await getLocalWorkspaceInfo();
  if (!workspaceId) throw new Error('Not part of a workspace');
  const session = await ensureSession();
  const res = await fetch(`${REST_URL}/workspace_jobs`, {
    method: 'POST', headers: { ...authHeaders(session), Prefer: 'return=representation' },
    body: JSON.stringify({
      workspace_id: workspaceId,
      created_by: session.user.id,
      target_profile_label: targetProfileLabel,
      prompt: job.prompt,
      steps: job.steps || null,
      target: job.target || null,
      attachments: job.attachments || null,
      when_iso: job.whenISO,
      mode: job.mode,
      skip_typing: !!job.skipTyping
    })
  });
  if (!res.ok) throw new Error(await readError(res, 'Could not queue that on the other profile'));
  return (await res.json())[0];
}

// Called from background.js on a polling alarm. Returns pending jobs
// addressed to THIS profile (by its saved profileLabel) so they can be
// scheduled/executed exactly like a local job.
async function pollWorkspaceJobsForMe() {
  const { workspaceId, profileLabel } = await getLocalWorkspaceInfo();
  if (!workspaceId || !profileLabel) return [];
  const session = await ensureSession();
  const res = await fetch(
    `${REST_URL}/workspace_jobs?select=*&workspace_id=eq.${workspaceId}` +
    `&target_profile_label=eq.${encodeURIComponent(profileLabel)}&status=eq.pending`,
    { headers: authHeaders(session) }
  );
  if (!res.ok) return [];
  return res.json();
}

async function markWorkspaceJobStatus(id, status, result) {
  try {
    const session = await ensureSession();
    await fetch(`${REST_URL}/workspace_jobs?id=eq.${id}`, {
      method: 'PATCH', headers: authHeaders(session),
      body: JSON.stringify({ status, result: result || null, updated_at: new Date().toISOString() })
    });
  } catch (err) { /* best-effort status report — a missed update just means
                      the dashboard shows "claimed" a bit longer, not a
                      functional problem */ }
}

// Recent workspace_jobs across all members — everything an activity feed
// needs already exists on that table (migration-02.sql), no new schema.
async function fetchWorkspaceActivity(limit) {
  const { workspaceId } = await getLocalWorkspaceInfo();
  if (!workspaceId) return [];
  const session = await ensureSession();
  const res = await fetch(
    `${REST_URL}/workspace_jobs?select=id,created_by,target_profile_label,prompt,status,created_at,updated_at` +
    `&workspace_id=eq.${workspaceId}&order=created_at.desc&limit=${limit || 20}`,
    { headers: authHeaders(session) }
  );
  if (!res.ok) return [];
  return res.json();
}

// --- Workspace-level shared library (distinct from the public catalog —
// only visible to members of the same workspace) ---------------------------

async function fetchWorkspaceSharedPrompts() {
  const { workspaceId } = await getLocalWorkspaceInfo();
  if (!workspaceId) return [];
  const session = await ensureSession();
  const res = await fetch(`${REST_URL}/workspace_shared_prompts?select=*&workspace_id=eq.${workspaceId}&order=created_at.desc`, {
    headers: authHeaders(session)
  });
  if (!res.ok) return [];
  return res.json();
}

async function addWorkspaceSharedPrompt(title, prompt, tags) {
  const { workspaceId } = await getLocalWorkspaceInfo();
  if (!workspaceId) throw new Error('Not part of a workspace');
  const session = await ensureSession();
  const res = await fetch(`${REST_URL}/workspace_shared_prompts`, {
    method: 'POST', headers: { ...authHeaders(session), Prefer: 'return=representation' },
    body: JSON.stringify({ workspace_id: workspaceId, added_by: session.user.id, title, prompt, tags: tags || [] })
  });
  if (!res.ok) throw new Error(await readError(res, 'Could not share that prompt'));
  return (await res.json())[0];
}

async function updateWorkspaceSharedPrompt(id, title, prompt, tags) {
  const session = await ensureSession();
  const res = await fetch(`${REST_URL}/workspace_shared_prompts?id=eq.${id}`, {
    method: 'PATCH', headers: authHeaders(session),
    body: JSON.stringify({ title, prompt, tags: tags || [], updated_at: new Date().toISOString() })
  });
  if (!res.ok) throw new Error(await readError(res, 'Could not save your changes'));
}

async function deleteWorkspaceSharedPrompt(id) {
  const session = await ensureSession();
  const res = await fetch(`${REST_URL}/workspace_shared_prompts?id=eq.${id}`, {
    method: 'DELETE', headers: authHeaders(session)
  });
  if (!res.ok) throw new Error(await readError(res, 'Could not delete that'));
}
