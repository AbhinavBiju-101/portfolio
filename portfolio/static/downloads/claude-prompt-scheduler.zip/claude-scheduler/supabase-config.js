// supabase-config.js — fill these in with YOUR project's values
// (Supabase Dashboard → Project Settings → API).
//
// SUPABASE_ANON_KEY is the PUBLIC "anon" key — it's meant to be shipped in
// client code and is safe here because access is governed entirely by the
// Row Level Security policies in supabase-schema.sql.
//
// NEVER put the service_role key anywhere in this extension. That key
// bypasses Row Level Security completely — anyone who extracted it from
// your shipped extension could read and write every user's data.

const SUPABASE_URL = 'https://rukjqckfrwvngvlshgue.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_CP-Xjs9NMG-mEqFjRhmeEA_b9kI_xWU';

// Google Cloud Console → APIs & Services → Credentials → Create Credentials
// → OAuth client ID → Application type: "Web application". Add the redirect
// URI printed by getGoogleRedirectUri() (see account.js — it shows this on
// the Account page so you don't have to compute it by hand) under
// "Authorized redirect URIs". Then enable Google as a provider in
// Supabase Dashboard → Authentication → Providers, pasting the same
// client ID there (and its secret, though the secret isn't used by the
// flow below — Supabase just wants it on file).
const GOOGLE_CLIENT_ID = '416426734752-28rhci8faltr0la38lqs4j5pdsauj7ut.apps.googleusercontent.com';
