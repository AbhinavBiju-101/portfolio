-- Run this once in your Supabase project's SQL editor.
-- (Dashboard → SQL Editor → New query → paste → Run)

-- ── Catalog: public, read-only from the extension ──────────────────────────
create table public.snippets (
  id                          text primary key,
  title                       text not null,
  category                    text not null,
  tags                        text[] not null default '{}',
  description                 text not null,
  description_format          text not null default 'markdown', -- 'markdown' | 'html'
  recommended_context         text,
  recommended_context_format  text not null default 'markdown',
  examples                    jsonb not null default '[]',       -- [{label, prompt}, ...]
  created_at                  timestamptz not null default now(),
  updated_at                  timestamptz not null default now()
);

alter table public.snippets enable row level security;

-- Anyone (anon key) can read the catalog.
create policy "snippets are publicly readable"
  on public.snippets for select
  using (true);

-- Deliberately NO insert/update/delete policy for anon/authenticated —
-- only you can write, via the Supabase dashboard's table editor or a
-- service_role key you keep server-side / on your own machine, never in
-- the extension.

-- ── Per-user library: which snippets each signed-in user has saved ────────
create table public.user_library (
  user_id     uuid not null references auth.users(id) on delete cascade,
  snippet_id  text not null references public.snippets(id) on delete cascade,
  saved_at    timestamptz not null default now(),
  primary key (user_id, snippet_id)
);

alter table public.user_library enable row level security;

create policy "users can view their own library"
  on public.user_library for select
  using (auth.uid() = user_id);

create policy "users can save to their own library"
  on public.user_library for insert
  with check (auth.uid() = user_id);

create policy "users can remove from their own library"
  on public.user_library for delete
  using (auth.uid() = user_id);

-- ── Auth setup (do this in the dashboard, not SQL) ─────────────────────────
-- 1. Authentication → Sign In / Providers → enable "Allow anonymous sign-ins".
-- 2. Authentication → Email Templates → for "Confirm signup" and
--    "Change Email Address", replace the {{ .ConfirmationURL }} link with
--    {{ .Token }} so users get a 6-digit code instead of a clickable link —
--    a browser extension has no good page to redirect a link back to.
