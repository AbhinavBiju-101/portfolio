-- Additional prompts (batch 2) — appended to supabase-seed.sql, no id overlaps with the
-- original 14. Run after supabase-schema.sql and supabase-seed.sql are already applied.

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$morning-news-briefing$$,
  $$Morning News Briefing$$,
  $$Research$$,
  ARRAY[$$news$$,$$research$$,$$briefing$$]::text[],
  $$A scheduled prompt that asks Claude to search and summarize before you've even had coffee — waiting for you instead of something you have to remember to ask for. Name specific topics or sources for a tighter, less generic result, and ask for links so you can jump straight to full articles that interest you.$$,
  NULL,
  $$[{"label":"General briefing","prompt":"Search for today's top news in tech, world affairs, and markets. Give me a 5-bullet summary, one line each, with a source link per item."},{"label":"Industry-specific","prompt":"Search for news from the last 24 hours about [your industry/competitors]. Summarize anything relevant to our business in 3-4 bullets, and flag anything that needs a fast response."},{"label":"Just the headlines","prompt":"Search for today's biggest headlines across 3-4 major outlets and just list them, no commentary, ranked by how significant they seem."}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$weekly-learning-digest$$,
  $$Weekly Learning Digest$$,
  $$Learning$$,
  ARRAY[$$learning$$,$$study$$,$$weekly$$]::text[],
  $$Set this to fire once a week to turn whatever you've been asking Claude about into a study aid — a recap of concepts covered, plus a few questions to test whether they actually stuck. Best used in a dedicated, ongoing "learning" chat you keep coming back to over the week, since this works from what's already in the conversation.$$,
  $$This reads from whatever's already in the current chat — most useful in a dedicated learning conversation you keep returning to over the week, not a fresh chat each time.$$,
  $$[{"label":"Concept recap","prompt":"Based on everything we've covered in this chat this week, summarize the 5 most important concepts in plain language, one or two sentences each."},{"label":"Quiz me","prompt":"Write 5 quiz questions based on what we've discussed this week, mixing multiple choice and short answer. Don't show the answers yet — I'll reply with mine first."},{"label":"Spaced repetition cards","prompt":"Turn the key ideas from this week's conversation into 8-10 flashcard-style question/answer pairs I can review later."}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$evening-reflection-journal$$,
  $$Evening Reflection Journal$$,
  $$Personal$$,
  ARRAY[$$journaling$$,$$reflection$$,$$personal$$]::text[],
  $$A low-effort way to build a journaling habit — schedule it for the same time every evening and just reply with a few lines when it comes in. Claude asks the questions so you don't have to stare at a blank page; keep the same chat going over time and occasionally ask it to summarize patterns it's noticed.$$,
  NULL,
  $$[{"label":"Simple check-in","prompt":"Ask me three short reflection questions about today: one thing that went well, one thing that was hard, and one thing I'm looking forward to tomorrow."},{"label":"Gratitude focused","prompt":"Ask me to name three things from today I'm grateful for, then ask one follow-up question about whichever one I write the most about."},{"label":"Goal tracking","prompt":"Ask how today went relative to the 2-3 goals I mentioned earlier this week, and whether I want to adjust anything for tomorrow."}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$meeting-prep-brief$$,
  $$Meeting Prep Brief$$,
  $$Productivity$$,
  ARRAY[$$meetings$$,$$prep$$,$$productivity$$]::text[],
  $$Schedule this 15-30 minutes before a meeting so you walk in with a clear one-pager instead of scrambling beforehand. Most useful when you've already got notes, an agenda, or background on attendees pasted into the same chat before it fires.$$,
  $$Paste the agenda, past meeting notes, or background on attendees/topics into the chat before scheduling.$$,
  $$[{"label":"Quick brief","prompt":"Based on everything above, give me a 5-bullet prep brief for this meeting: goal, key context, likely questions, my talking points, and one thing to watch out for."},{"label":"Questions to ask","prompt":"Based on the context above, suggest 3-5 sharp questions I should ask in this meeting to move things forward."},{"label":"Recap-ready","prompt":"Summarize the context above into a short opening statement I can use to kick off the meeting, framing where things stand and what we need to decide today."}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$habit-check-in$$,
  $$Habit Check-in$$,
  $$Personal$$,
  ARRAY[$$habits$$,$$accountability$$,$$personal$$]::text[],
  $$A lightweight accountability nudge — schedule it daily or a few times a week and reply with a quick update. Works best as an ongoing chat you return to, so Claude can reference how things have been trending rather than treating each check-in as a blank slate.$$,
  $$Mention the specific habit(s) you're tracking the first time you use this, so later check-ins have something to reference.$$,
  $$[{"label":"Single habit","prompt":"Ask me a single yes/no question: did I [do the habit] today? If yes, ask what made it easy. If no, ask what got in the way — no judgment, just curious."},{"label":"Multiple habits","prompt":"Ask me to quickly rate today 1-5 on each of the habits we've been tracking, then note if any pattern stands out from the past week."},{"label":"Weekly streak recap","prompt":"Based on my check-ins this week, give me a short streak recap and one specific, realistic suggestion for next week."}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$market-pulse-check$$,
  $$Market Pulse Check$$,
  $$Finance$$,
  ARRAY[$$markets$$,$$finance$$,$$briefing$$]::text[],
  $$A neutral, factual market-news scan you can schedule for market open or close. This is a research/summary prompt, not investment advice — it's designed to surface what happened and why, so you can form your own view. Name specific tickers, sectors, or indices for a more targeted result than a generic market wrap.$$,
  NULL,
  $$[{"label":"General wrap-up","prompt":"Search for today's market news and summarize in 4-5 bullets: major index moves, the biggest single-stock stories, and any notable economic data released. Cite sources."},{"label":"Watchlist focused","prompt":"Search for news on [tickers/sector] specifically. Summarize what moved and any stated reasons, citing sources. Keep it factual, no recommendations."},{"label":"Macro focus","prompt":"Search for today's major economic releases and central bank news. Summarize what was reported vs. what was expected, and why markets reacted the way they did."}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$daily-writing-warmup$$,
  $$Daily Writing Warm-up$$,
  $$Creative$$,
  ARRAY[$$writing$$,$$creative$$,$$practice$$]::text[],
  $$A scheduled writing prompt to lower the barrier to a daily practice — it arrives with the prompt already picked, so there's no time lost deciding what to write about. Reply with your piece and optionally ask for feedback afterward.$$,
  NULL,
  $$[{"label":"Random prompt","prompt":"Give me one short creative writing prompt (a scenario, an opening line, or an image) to write about for 10 minutes. Keep it open-ended, not a full outline."},{"label":"Genre-specific","prompt":"Give me a writing prompt in the style of [genre, e.g. noir / sci-fi / literary fiction] — a single evocative line or situation, not a full plot."},{"label":"With feedback after","prompt":"Give me a short writing prompt. After I reply with what I wrote, give me one specific thing that worked well and one specific suggestion — nothing generic."}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$release-notes-writer$$,
  $$Merged PRs → Release Notes$$,
  $$Coding$$,
  ARRAY[$$code$$,$$release notes$$,$$engineering$$]::text[],
  $$Turns a batch of commit messages or merged PR titles into release notes someone outside the team could actually read — grouped into Features / Fixes / Other, with the internal jargon translated into plain English. Different job from a code review: this is about explaining what shipped, not checking it before it ships.$$,
  $$Paste the raw commit log or list of merged PR titles/descriptions before scheduling. Mention your audience (end users vs. internal team) since that changes how much detail belongs in each line.$$,
  $$[{"label":"User-facing","prompt":"Turn this list of merged PRs into user-facing release notes, grouped into New / Improved / Fixed. Translate technical terms into plain language a non-engineer would understand:\n\n[paste PR list here]"},{"label":"Internal changelog","prompt":"Turn this commit log into an internal changelog for the engineering team — keep the technical detail, group by area of the codebase, and flag anything that's a breaking change:\n\n[paste commit log here]"},{"label":"Tweet-length summary","prompt":"Summarize what shipped this release in 2-3 sentences, casual tone, suitable for a product update post — based on this PR list:\n\n[paste PR list here]"}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$customer-feedback-theme-finder$$,
  $$Customer Feedback → Themes$$,
  $$Data & Analysis$$,
  ARRAY[$$feedback$$,$$reviews$$,$$analysis$$]::text[],
  $$Paste in a pile of reviews, support tickets, or survey responses and get back the recurring themes instead of reading each one individually — what people keep bringing up, roughly how often, and a rough positive/negative split. Complements a messy-spreadsheet cleanup: this is for unstructured text, not numeric data.$$,
  $$Paste raw feedback text (reviews, tickets, survey free-text). The more items you include, the more reliable the themes — a handful of reviews won't reveal a real pattern.$$,
  $$[{"label":"Theme summary","prompt":"Read through this batch of customer feedback and identify the 4-6 most common themes. For each, note roughly how many mentions it got and whether it skews positive or negative:\n\n[paste feedback here]"},{"label":"Feature requests only","prompt":"Go through this feedback and pull out only the actual feature requests or specific asks — skip general praise or complaints with no actionable ask. Group similar requests together:\n\n[paste feedback here]"},{"label":"Prioritized for the team","prompt":"Based on this feedback, give me a short prioritized list of what to address first — weighing how often something comes up against how severe it sounds:\n\n[paste feedback here]"}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$pre-launch-checklist$$,
  $$Pre-Launch Sanity Check$$,
  $$Productivity$$,
  ARRAY[$$launch$$,$$checklist$$,$$productivity$$]::text[],
  $$Before shipping something — a feature, a campaign, a blog post, an email to a big list — have Claude build a checklist tailored to what you're actually launching, rather than working from a generic template that misses what matters for your specific case.$$,
  $$Describe what you're launching and its scale/audience. The more specific, the more the checklist catches things a generic list wouldn't.$$,
  $$[{"label":"General launch","prompt":"I'm about to launch [describe what you're launching] to [audience/scale]. Build me a pre-launch checklist tailored to this specific case — not a generic list, think about what could actually go wrong here."},{"label":"Second pair of eyes","prompt":"Here's my current launch checklist for [describe launch]. Review it and tell me what's missing, based on what you know can go wrong with this kind of launch:\n\n[paste your checklist]"},{"label":"Rollback plan","prompt":"For this launch — [describe it] — what's a sensible rollback or mitigation plan if something goes wrong in the first hour?"}]$$::jsonb
);
