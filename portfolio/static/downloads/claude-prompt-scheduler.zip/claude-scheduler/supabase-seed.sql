-- Generated seed data — run after supabase-schema.sql

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$daily-standup-summarizer$$,
  $$Daily Standup Summarizer$$,
  $$Productivity$$,
  ARRAY['work','meetings','summarization']::text[],
  $$Turns a wall of raw meeting notes, a Slack thread, or a call transcript into a clean, skimmable standup update — organized into **Done / Doing / Blocked**, with names attached so nothing gets lost.$$,
  $$Paste the raw notes or transcript directly into the chat before sending this, or attach it as a file — Claude can read .txt, .md, .docx, and even scanned PDFs.$$,
  $$[{"label":"Basic","prompt":"Turn these raw meeting notes into a clean standup summary organized by Done / Doing / Blocked, with names attached to each item:\n\n[paste notes here]"},{"label":"Slack thread version","prompt":"Here's a Slack thread from our team channel. Summarize it into a standup-style update — who did what, what's in progress, and any blockers mentioned:\n\n[paste thread here]"}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$code-review-second-opinion$$,
  $$Code Review Second Opinion$$,
  $$Coding$$,
  ARRAY['code','review','engineering']::text[],
  $$A structured second pair of eyes on a diff or file before you open a PR — checks for correctness, edge cases, naming, and whether the code matches its own comments, not just style nitpicks.$$,
  $$Paste the diff or full file. Mention the language/framework and anything unusual about the codebase's conventions if it matters.$$,
  $$[{"label":"Basic","prompt":"Review this code like a thoughtful senior engineer would before I open a PR. Flag correctness issues, missed edge cases, and anything the comments claim but the code doesn't actually do. Don't nitpick pure style unless it hides a bug:\n\n[paste code here]"}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$explain-like-im-new-to-this$$,
  $$Explain Like I'm New To This$$,
  $$Learning$$,
  ARRAY['learning','explanation']::text[],
  $$A layered explanation of any concept — starts with a plain-English mental model, then adds precision and nuance, then flags common misconceptions. Good for genuinely learning something rather than just getting a definition.$$,
  $$Just name the topic. If you already know something adjacent to it, mention that so Claude can build on it instead of starting from zero.$$,
  $$[{"label":"Basic","prompt":"Explain [topic] to me in three layers: first a plain-English mental model with an analogy, then the more precise/technical version, then 2-3 common misconceptions people have about it."}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$inbox-triage$$,
  $$Inbox / Message Triage$$,
  $$Productivity$$,
  ARRAY['email','work','organization']::text[],
  $$Sorts a pile of emails or messages into what actually needs a reply today, what can wait, and what's just noise — with a one-line reason for each so you're not just trusting a black box.$$,
  $$Paste a batch of subject lines + first lines, or forward/paste full email text. Mention your role if it affects urgency (e.g. "I'm the only approver on X").$$,
  $$[{"label":"Basic","prompt":"Here's a batch of emails (subject + first line each). Sort them into 'reply today', 'can wait', and 'ignore/archive', with a one-line reason for each:\n\n[paste emails here]"}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$devils-advocate$$,
  $$Devil's Advocate on My Plan$$,
  $$Decision-making$$,
  ARRAY['planning','critical thinking','business']::text[],
  $$Before you commit to a plan, have Claude argue the strongest case against it — not a wishy-washy "have you considered..." but the sharpest realistic objection, plus what evidence would change its mind.$$,
  $$Describe your plan and the decision you're about to make. The more concrete the plan, the sharper the pushback.$$,
  $$[{"label":"Basic","prompt":"I'm about to do this: [describe your plan]. Play devil's advocate — give me the strongest realistic case against it, not a generic list of risks. Then tell me what evidence would actually change your mind."}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$data-cleanup-analyst$$,
  $$Messy Spreadsheet → Clean Analysis$$,
  $$Data & Analysis$$,
  ARRAY['data','excel','csv','analysis']::text[],
  $$Upload a messy CSV/Excel export and have Claude clean it up, find the actual patterns, and chart what matters — using its code execution to actually run the numbers rather than eyeballing them.$$,
  $$Attach the file directly (.csv/.xlsx work well). Say what question you're trying to answer, not just "analyze this" — that's what determines what's worth charting.$$,
  $$[{"label":"Basic","prompt":"I've attached a messy spreadsheet export. Clean it up (fix headers, missing values, inconsistent formatting), then answer: [your actual question]. Show your work and chart anything that clarifies the answer."}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$tone-check-before-sending$$,
  $$Tone Check Before Sending$$,
  $$Writing$$,
  ARRAY['email','writing','communication']::text[],
  $$Catches messages that read colder, pushier, or more passive-aggressive than you meant — before a coworker or client reads them that way. Gives you the read plus one or two alternate phrasings, not a full rewrite you didn't ask for.$$,
  $$Paste the exact message and who it's going to (manager, client, direct report) — tone expectations shift a lot by audience.$$,
  $$[{"label":"Basic","prompt":"I'm about to send this to [who it's going to]. How does the tone actually read — could it come across as colder, pushier, or more passive-aggressive than I mean? Give me 1-2 alternate phrasings for the risky parts, not a full rewrite:\n\n[paste message here]"}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$debug-rubber-duck-plus$$,
  $$Rubber Duck Debugging, Upgraded$$,
  $$Coding$$,
  ARRAY['code','debugging']::text[],
  $$Instead of just fixing your bug, this walks through the reasoning with you Socratically first — often you'll spot it yourself halfway through — and only gives the direct fix if you ask for it.$$,
  $$Paste the error/stack trace and the relevant code. Mention what you expected to happen vs what actually happened.$$,
  $$[{"label":"Basic","prompt":"Walk through this bug with me like rubber-duck debugging — ask me clarifying questions and reason out loud step by step instead of just handing me the fix. Only give me the direct answer if I explicitly ask for it.\n\nExpected: [what should happen]\nActual: [what happens instead]\n\n[paste code/error here]"}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$learn-a-skill-study-plan$$,
  $$Realistic Study/Skill Plan$$,
  $$Learning$$,
  ARRAY['learning','planning','skills']::text[],
  $$Builds a week-by-week plan to actually learn a skill in the time you realistically have — accounting for the boring-but-necessary fundamentals, not just a list of cool projects.$$,
  $$Say the skill, your current level, hours per week you can realistically commit, and any deadline.$$,
  $$[{"label":"Basic","prompt":"Build me a realistic week-by-week plan to learn [skill], starting from [current level]. I have about [X hours/week]. Include the unglamorous fundamentals I actually need, not just fun project ideas. [Optional: deadline is X]."}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$negotiation-prep$$,
  $$Negotiation / Hard Conversation Prep$$,
  $$Decision-making$$,
  ARRAY['negotiation','work','communication']::text[],
  $$Role-plays the other side of a salary negotiation, difficult client conversation, or pushback from a manager — so you walk in having already heard the objections once.$$,
  $$Describe the situation, what you want, and what you know or guess about the other person's position/incentives.$$,
  $$[{"label":"Basic","prompt":"I have this negotiation/hard conversation coming up: [describe situation and what you want]. Play the other side realistically — including their likely objections and incentives — so I can practice responding. After, give me honest feedback on how I did."}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$summarize-long-doc-with-questions$$,
  $$Long Document Summary + My Own Questions$$,
  $$Research$$,
  ARRAY['research','reading','documents']::text[],
  $$Summarizes a long report, paper, or contract — then, instead of stopping there, surfaces the 3-5 questions a careful reader would actually want answered, so you know what to dig into.$$,
  $$Attach the PDF/doc directly. If it's a contract, mention what role you're reading it from (the party signing, reviewing on someone's behalf, etc).$$,
  $$[{"label":"Basic","prompt":"Summarize the attached document in a few tight paragraphs, then list the 3-5 questions a careful, skeptical reader would want answered before acting on it — and answer them from the document if it can be answered from the text."}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$creative-brainstorm-with-constraints$$,
  $$Brainstorm With Real Constraints$$,
  $$Creative$$,
  ARRAY['brainstorming','creative','ideation']::text[],
  $$Generates ideas that actually respect your real-world constraints (budget, timeline, team size, audience) instead of the generic "10 fun ideas!" list that ignores them.$$,
  $$List your actual constraints up front — budget, timeline, team size, audience, anything off-limits. The more real constraints you give, the less generic the output.$$,
  $$[{"label":"Basic","prompt":"I need ideas for [goal]. My real constraints: [budget], [timeline], [team size/resources], [audience]. Give me ideas that actually fit inside these, not a generic list I'd have to filter myself."}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$artifact-quick-tool$$,
  $$Turn a Task Into a Little Tool$$,
  $$Productivity$$,
  ARRAY['artifacts','automation','tools']::text[],
  $$A lot of one-off spreadsheet/calculator tasks are better as a tiny interactive tool than a static answer — Claude can build a working calculator, tracker, or generator you can actually use and reuse, right in the chat.$$,
  $$Describe the inputs and what you want calculated or generated. Mention if you'll want to reuse it repeatedly (worth building as a proper little tool) vs. it being a one-off.$$,
  $$[{"label":"Basic","prompt":"Instead of just answering this once, build me a small interactive tool for it: [describe the calculation/tracker/generator you need, and what inputs it should take]."}]$$::jsonb
);

insert into public.snippets (id, title, category, tags, description, recommended_context, examples) values (
  $$research-with-sources$$,
  $$Current-Events Research With Sources$$,
  $$Research$$,
  ARRAY['research','news','search']::text[],
  $$For anything time-sensitive or recent, this explicitly asks Claude to search the web and cite what it finds, instead of relying on (possibly outdated) built-in knowledge.$$,
  $$Be specific about what's recent or time-sensitive in your question — that's the cue to actually search rather than answer from memory.$$,
  $$[{"label":"Basic","prompt":"Search for current information and answer with sources: [your question about something recent/time-sensitive]. Flag anywhere the sources disagree with each other."}]$$::jsonb
);


