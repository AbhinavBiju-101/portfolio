// target-editor.js — shared "which chat should this send to" control.
// Used by dashboard.js's inline row editor and by popup.js/compose.js's
// create form, so the picker UX and the target object shape stay in sync
// in both places (mirrors steps-editor.js's role for the steps/branching
// editor).
//
// A target looks like: { mode: 'current' | 'new' | 'specific', chatUrl?,
//                         chatTitle? }
// "current" reuses whichever claude.ai tab is already open (or the tab
// the popup was opened from); "new" starts a fresh chat; "specific" sends
// into the exact chat the person picked from chat-picker.js.
//
// Callers own the target object and re-render via renderTargetEditorHtml
// after any change — same pattern as steps-editor.js.

function targetLabel(target) {
  if (!target) return 'Current tab';
  if (target.mode === 'new') return 'New chat';
  if (target.mode === 'specific') return target.chatTitle || target.chatUrl || 'Choose a chat…';
  return 'Current tab';
}

function renderTargetEditorHtml(target) {
  return `
    <button type="button" class="btn target-pick-btn" id="targetPickBtn-${target._uid || ''}" data-target-btn="1">
      <span>${escapeHtml(targetLabel(target))}</span>
      <span class="caret">▾</span>
    </button>
  `;
}

// container: the element wrapping the button (re-rendered by the caller
// after every change via its own onChange re-render loop).
// getChats(cb): async — cb(chats array). Kept as a callback (rather than
// baking in browser.runtime.sendMessage directly) so dashboard.js can
// pass a cross-profile-aware fetcher once "Send from" targets a different
// linked profile (see profile-picker.js + chat-picker's `loading` state).
// richMode: passed straight through to chat-picker.js's `rich` option —
// full cards (last-sent snippet + dates) on the full-page views, plain
// simple cards in the popup (see chat-picker.js's own doc comment for why).
function attachTargetEditorHandlers(container, target, onChange, getChats, richMode) {
  const btn = container.querySelector('[data-target-btn]');
  if (!btn) return;
  btn.addEventListener('click', async () => {
    window.chatPicker.open({
      chats: [],
      loading: true,
      currentUrl: target.mode === 'specific' ? target.chatUrl : null,
      showCurrentOption: true,
      rich: !!richMode,
      onCurrent: () => { Object.assign(target, { mode: 'current', chatUrl: null, chatTitle: null }); onChange(); },
      onNewChat: () => { Object.assign(target, { mode: 'new', chatUrl: null, chatTitle: null }); onChange(); },
      onSelect: (chat) => { Object.assign(target, { mode: 'specific', chatUrl: chat.url, chatTitle: chat.title }); onChange(); }
    });
    try {
      const chats = await getChats();
      window.chatPicker.update({ chats });
    } catch (err) {
      window.chatPicker.update({ chats: [] });
    }
  });
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str == null ? '' : str;
  return div.innerHTML;
}
