// workspace.js — linking multiple browser profiles/Claude accounts
// together, and the activity feed for jobs routed between them. Split out
// from account.js (which now only handles this device's identity —
// linking an email/Google account, and deleting it) so each page has one
// clear job.

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}

function tickClock() {
  const now = new Date();
  document.getElementById('railClock').textContent = now.toLocaleTimeString(undefined, { hour12: false });
  document.getElementById('railDate').textContent = now.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
}
tickClock();
setInterval(tickClock, 1000);

let currentSbUser = null;

// --- Profile label ----------------------------------------------------------

const profileLabelInput = document.getElementById('profileLabelInput');
const labelMsg = document.getElementById('labelMsg');

document.getElementById('saveLabelBtn').addEventListener('click', async () => {
  const label = profileLabelInput.value.trim();
  if (!label) { labelMsg.textContent = 'Give this profile a name first.'; labelMsg.className = 'acct-msg error'; return; }
  labelMsg.textContent = 'Saving…'; labelMsg.className = 'acct-msg';
  try {
    await updateMyProfileLabel(label);
    labelMsg.textContent = 'Saved.'; labelMsg.className = 'acct-msg ok';
    renderWorkspaceBody(); // so your own row in the member list updates too
  } catch (err) { labelMsg.textContent = err.message; labelMsg.className = 'acct-msg error'; }
});

// --- Workspace (linked profiles) --------------------------------------------

const workspaceBody = document.getElementById('workspaceBody');

// A profile only reports status once its content.js has actually run on a
// claude.ai tab (see content.js's reportRateLimitStatusIfChanged) — so
// status_updated_at being null just means "hasn't checked in yet," not an
// error. Stale (>30 min old) is called out too, since a profile whose
// Firefox isn't currently open won't be reporting anything new.
function statusPillHtml(m) {
  if (!m.status_updated_at) {
    return `<span class="usage-badge">no status yet</span>`;
  }
  const ageMs = Date.now() - new Date(m.status_updated_at).getTime();
  const stale = ageMs > 30 * 60 * 1000;
  if (m.rate_limited) {
    return `<span class="attribution-badge community" style="color:var(--red); background:rgba(226,99,79,0.12);">rate limited${stale ? ' (stale)' : ''}</span>`;
  }
  return `<span class="attribution-badge official" style="color:var(--amber);">available${stale ? ' (stale)' : ''}</span>`;
}

// Short "resets 3:00 PM" / "resets in 2h" line under a rate-limited
// member's row, parsed from the raw scraped detail text via
// reset-time.js. Falls back to the raw detail if it doesn't parse into
// either shape — still better than nothing.
function resetLineHtml(m) {
  if (!m.rate_limited || !m.rate_limit_detail) return '';
  const parsed = window.resetTimeUtil.parseResetLabel(m.rate_limit_detail);
  const text = parsed ? parsed.label : m.rate_limit_detail;
  return `<div class="mb-reset">${escapeHtml(text)}</div>`;
}

async function renderWorkspaceBody() {
  const { workspaceId } = await getLocalWorkspaceInfo();

  if (!workspaceId) {
    workspaceBody.innerHTML = `
      <div class="acct-row">
        <button type="button" class="btn btn-primary" id="createWsBtn">Create a workspace</button>
        <span style="color:var(--text-faint); font-size:12px;">or</span>
        <input type="text" id="joinCodeInput" placeholder="Enter a join code" maxlength="32" style="max-width:220px; text-transform:uppercase;">
        <button type="button" class="btn btn-ghost" id="joinWsBtn">Join</button>
      </div>
      <div class="acct-msg" id="wsMsg"></div>
    `;
    document.getElementById('createWsBtn').addEventListener('click', async () => {
      const msg = document.getElementById('wsMsg');
      msg.textContent = 'Creating…'; msg.className = 'acct-msg';
      try {
        await createWorkspace(profileLabelInput.value.trim() || 'This profile');
        renderWorkspaceBody();
      } catch (err) { msg.textContent = err.message; msg.className = 'acct-msg error'; }
    });
    document.getElementById('joinWsBtn').addEventListener('click', async () => {
      const code = document.getElementById('joinCodeInput').value.trim();
      const msg = document.getElementById('wsMsg');
      if (!code) return;
      msg.textContent = 'Joining…'; msg.className = 'acct-msg';
      try {
        await joinWorkspace(code, profileLabelInput.value.trim() || 'This profile');
        renderWorkspaceBody();
      } catch (err) { msg.textContent = err.message; msg.className = 'acct-msg error'; }
    });
    return;
  }

  workspaceBody.innerHTML = `<div class="acct-msg">Loading…</div>`;
  let joinCode, members;
  try {
    [joinCode, members] = await Promise.all([fetchWorkspaceJoinCode(), fetchWorkspaceMembers()]);
  } catch (err) {
    // A real failure (network, auth, RLS) — NOT the same thing as "this
    // workspace has zero members," so this must never trigger the
    // self-heal/delete-local-reference path below. Show the actual error
    // and offer a retry instead of guessing what went wrong.
    workspaceBody.innerHTML = `
      <div class="acct-msg error" style="margin-bottom:8px;">Couldn't load your workspace: ${escapeHtml(err.message)}</div>
      <button type="button" class="btn btn-ghost" id="retryWsBtn">Retry</button>
    `;
    document.getElementById('retryWsBtn').addEventListener('click', renderWorkspaceBody);
    return;
  }
  const myId = currentSbUser ? currentSbUser.id : null;

  // Self-heal: a cached workspaceId can go stale (the workspace was
  // deleted, or this identity got removed from it elsewhere) — both
  // queries succeeding but coming back empty is the signal (note: this
  // only runs now if BOTH calls above actually succeeded — see the catch
  // block above for the "something went wrong" case, which is different).
  if (!joinCode && members.length === 0) {
    await browser.storage.local.remove('workspaceId');
    workspaceBody.innerHTML = `<div class="acct-msg error" style="margin-bottom:10px;">Your previous workspace isn't available anymore (it may have been deleted) — create a new one or join with a fresh code.</div>`;
    return renderWorkspaceBody();
  }

  workspaceBody.innerHTML = `
    <div class="acct-sub" style="margin-bottom:6px;">Give this code to your other profile(s) — open this same Workspace page there and enter it under "Join". Each code works once and expires after 24 hours; grab a fresh one below whenever you need to add another profile.</div>
    <div class="join-code-display">${escapeHtml(joinCode || '——————')}</div>
    <div class="acct-row" style="justify-content:center; margin-top:8px;">
      <button type="button" class="btn btn-ghost" id="rotateCodeBtn" style="font-size:11px; padding:4px 10px;">Generate a new code</button>
    </div>
    <div class="section-label" style="margin:14px 0 6px;">Linked profiles (${members.length})</div>
    ${members.map(m => `
      <div class="member-board-row">
        <span class="mb-name">${escapeHtml(m.profile_label)}${m.user_id === myId ? '<span class="you-tag">THIS PROFILE</span>' : ''}</span>
        ${statusPillHtml(m)}
        ${resetLineHtml(m)}
      </div>
    `).join('')}
    <button type="button" class="btn btn-ghost" id="leaveWsBtn" style="margin-top:10px;">Leave this workspace</button>
    <div class="acct-msg" id="wsMsg"></div>
  `;
  document.getElementById('rotateCodeBtn').addEventListener('click', async () => {
    const msg = document.getElementById('wsMsg');
    msg.textContent = 'Generating…'; msg.className = 'acct-msg';
    try {
      await rotateWorkspaceJoinCode();
      renderWorkspaceBody();
    } catch (err) { msg.textContent = err.message; msg.className = 'acct-msg error'; }
  });
  document.getElementById('leaveWsBtn').addEventListener('click', async () => {
    if (!confirm('Leave this workspace? Jobs already queued for this profile from other members will stop being delivered.')) return;
    await leaveWorkspace();
    document.getElementById('activityCard').style.display = 'none';
    renderWorkspaceBody();
  });

  document.getElementById('activityCard').style.display = 'block';
  renderActivityBody(members, myId);
}

// --- Activity feed -----------------------------------------------------------
// Every field this needs already exists on workspace_jobs (migration-02.sql)
// — this is purely a read + render, no new schema.

async function renderActivityBody(members, myId) {
  const activityBody = document.getElementById('activityBody');
  activityBody.innerHTML = `<div class="acct-msg">Loading…</div>`;
  const labelByUserId = {};
  members.forEach(m => { labelByUserId[m.user_id] = m.profile_label; });

  const rows = await fetchWorkspaceActivity(20);
  if (!rows.length) {
    activityBody.innerHTML = `<div class="acct-sub" style="margin:0;">No activity yet — jobs sent between linked profiles will show up here.</div>`;
    return;
  }
  const statusColor = { sent: 'var(--amber)', failed: 'var(--red)', pending: 'var(--text-faint)', claimed: 'var(--blue)', cancelled: 'var(--text-faint)' };
  activityBody.innerHTML = rows.map(r => {
    const from = (r.created_by === myId) ? 'you' : (labelByUserId[r.created_by] || 'a linked profile');
    return `
      <div class="member-row" style="align-items:flex-start; flex-direction:column; gap:2px;">
        <div style="display:flex; justify-content:space-between; width:100%;">
          <span>${escapeHtml(from)} &rarr; <b>${escapeHtml(r.target_profile_label)}</b></span>
          <span style="color:${statusColor[r.status] || 'var(--text-dim)'}; font-family:var(--font-mono); font-size:10px; text-transform:uppercase;">${escapeHtml(r.status)}</span>
        </div>
        <div style="color:var(--text-faint); font-size:11px;">${escapeHtml((r.prompt || '').slice(0, 80))}${(r.prompt || '').length > 80 ? '…' : ''}</div>
        <div style="color:var(--text-faint); font-size:10px;">${new Date(r.created_at).toLocaleString()}</div>
      </div>
    `;
  }).join('');
}

(async function init() {
  currentSbUser = await currentUser();
  if (!currentSbUser || currentSbUser.is_anonymous) {
    document.getElementById('notLinkedHint').style.display = 'block';
    document.getElementById('workspacePages').style.display = 'none';
    return;
  }
  document.getElementById('notLinkedHint').style.display = 'none';
  document.getElementById('workspacePages').style.display = 'block';

  const { profileLabel } = await getLocalWorkspaceInfo();
  profileLabelInput.value = profileLabel || '';
  renderWorkspaceBody();
})();
