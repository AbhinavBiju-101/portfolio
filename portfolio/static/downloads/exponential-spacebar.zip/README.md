# Exponential Spacebar

A Replit-hosted incremental/clicker game: press spacebar to score points,
with an increasing per-press boost, persistent accounts (username/password),
a world-record leaderboard, and an experience/level system — all in the
terminal.

## Run (on Replit)

This was built and run inside a Replit repl, so it depends on Replit's
`replit` package for persistent key-value storage (`replit.db`) and on
`sshkeyboard` for raw spacebar/`x` key detection. Import this project into
a Repl (or `pip install replit sshkeyboard` and provide your own storage/
input handling) and run:

```bash
python main.py
```

For a dependency-free version that runs anywhere (including this site's
in-browser Preview), see the adapted build under the site's
`static/previews/exponential-spacebar/` — it swaps `replit.db` for a local
dict and spacebar detection for line input, since neither works over a
piped browser terminal.
