import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;

class Inventory{
    HashMap<String,Item> storage;
    
    Inventory() {
        storage = new HashMap<String,Item>();
        storage.put("Apple",new Apple());
        storage.put("Wood",new Wood());
        storage.put("Sticks",new Sticks());
        //storage.put("Logs",new Logs());
        storage.put("Berries",new Berries());
        storage.put("Poisonous_Berries",new Poisonous_Berries());
        storage.put("Vines",new Vines());
        storage.put("Stone",new Stone());
        storage.put("Axe",new Axe());
        storage.put("Bow",new Bow());
        storage.put("Arrows",new Arrows());
        storage.put("Poison_Arrows",new Poison_Arrows());
        storage.put("Coal",new Coal());
        storage.put("Fire",new Fire());
        storage.put("Salmon",new Salmon());
        storage.put("Cooked_Salmon",new Cooked_Salmon());
    }
    
    void set(String key, int value) {
        storage.get(key).set(value);
    }
    
    Item get(String key){
        return storage.get(key);
    }
    
    ArrayList<String> getFiltered(Class<? extends Container> itemType,boolean contain){
        ArrayList<String> filtered = new ArrayList<String>();
        /*for (Map.Entry<String,Item> entry: storage.entrySet()) {
            if ((entry.getValue().type == type)||(entry.getValue().type==itemType.Weapon&&type==itemType.Craftable)) {
                if (contain == true) {
                    if (contains(entry.getKey())) {
                        filtered.add(entry.getKey());
                    }
                } else {
                    filtered.add(entry.getKey());
                }
            }
        }
        return filtered;*/
        
        /*for (String itemName: getItemList()) {
            if (get(itemName).type.equals(type)) {
                filtered.add(itemName);
            }
        }
        return filtered;*/
        
        for (Map.Entry<String,Item> entry: storage.entrySet()) {
            if (itemType.isInstance(entry.getValue()) && (!contain || (contain&&contains(entry.getKey())))) {
                filtered.add(entry.getKey());
            }
        }
        return filtered;
    }
    
    ArrayList<String> getItemList() {
        ArrayList<String> list = new ArrayList<String>();
        for (String entry: storage.keySet()) {
            if (contains(entry)) {
                list.add(entry);
            }
        }
        return list;
    }
    
    boolean canCraft(String itemName) {
        boolean craftable = true;
        
        Craftable item = (Craftable) storage.get(itemName);
        
        HashMap<String,Integer> recipie = item.recipie();
        for (Map.Entry<String,Integer> entry:recipie.entrySet()) {
            if (storage.get(entry.getKey()).units < entry.getValue()) {
                craftable = false;
            }
        }
        
        return craftable;
    }
    
    ArrayList<String> getCraftable() {
        //ArrayList<String> filtered = new ArrayList<String>();
        /*filtered.add("Sticks");
        filtered.add("Logs");
        filtered.add("Axe");
        filtered.add("Bow");
        filtered.add("Arrows");
        filtered.add("Poison_Arrows");
        */
        /*for (int i=0; i<filtered.size();i++) {
            if (canCraft(filtered.get(i)) == false) {
                filtered.remove(filtered.get(i));
            }
        }*/
        
        //return filtered.stream().filter(x-> canCraft(x)==true).collect();
    
        /*for (String key:storage.keySet()) {
            if (storage.get(key).type == itemType.Craftable) {
                if (canCraft(key)) {
                    filtered.add(key);
                }
            }
        }
        return filtered;*/
        
        ArrayList<String> filtered = new ArrayList<String>();
        for (String key:getFiltered(Craftable.class,false)) {
            if (canCraft(key)) filtered.add(key);
        }
        return filtered;
    }
    
    ArrayList<String> getUseableWeapons() {
        ArrayList<String> filtered = new ArrayList<String>();
        for (String key:getFiltered(Weapon.class,false)) {
            Weapon item = (Weapon) storage.get(key);
            if (item.canUse(this)) filtered.add(key);
        }
        return filtered;
    }
    
    boolean contains(String key){
        if (storage.get(key).units > 0) {
            return true;
        }
        
        return false;
    }
    
    HashMap<String,Item> getInventory() {return storage;}
}