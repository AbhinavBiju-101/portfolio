import java.util.HashMap;
import java.util.Map;


abstract class Item {
    int units;
    String name;
        
    Item(String name){
        this.units = 0;
        this.name = name;
    }
    
    void set(int units) {
        this.units=units;
    }
    
    void consume() {units--;}
    
    static void displayIndex() {
        /*System.out.println("--Item Index--");
        
        Inventory inventory = new Inventory();
        for (Map.Entry<String, Item>entry : inventory.inventory.entrySet()) {
            String information = entry.getKey()+" ("+entry.getValue().type.toString()+") : ";
            switch (entry.getValue().type) {
                case Resource:
                    information += "used for crafting other materials";
                    break;
                case Edible:
                    information += "Restores "+((Edible)(entry.getValue())).getHungerUnits() + " hunger.";
                    break;
                case Craftable:
                    information += "Requires ";
                    for (Map.Entry<String,Integer>e :((Craftable)(entry.getValue())).recipie().entrySet()) {
                        information += e.getKey()+"x" + e.getValue()+ " ";
                    }
                    information += " to craft "+entry.getKey()+"x"+((Craftable)(entry.getValue())).getCraftUnits();
                    break;
                case Weapon:
                    information += "Requires ";
                    for (Map.Entry<String,Integer>e :((Craftable)(entry.getValue())).recipie().entrySet()) {
                        information += e.getKey()+"x" + e.getValue()+ " ";
                    }
                    information += " to craft "+entry.getKey()+"x"+((Craftable)(entry.getValue())).getCraftUnits();
                    
                    information += ". Can be used to deal "+((Weapon)(entry.getValue())).getAttackUnits() + " damage ";
                    if (entry.getKey() == "Bow") {
                        information += ", it must be loaded with Arrowsx1 or Poison_Arrowsx1";
                    } else if (entry.getKey() == "Arrow") {
                        information += ", it can only be used with a Bow.";
                    } else if (entry.getKey()== "Poison_Arrows") {
                        information += ", and can inflict 'Poisoned'. it can only be used with a Bow.";
                    }
                    break;
            }
            System.out.println(information+"\n");
        }*/
    }
}

interface Container {

}