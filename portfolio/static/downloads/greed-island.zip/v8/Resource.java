import java.util.HashMap;
import java.util.ArrayList;

interface Resource extends Container {
    
}

interface Edible extends Container{
    int getHungerUnits();
    void eat();
}

interface Craftable extends Container{
    int getCraftUnits();
    HashMap<String,Integer> recipie();
}

interface Weapon extends Container{
    int getAttackUnits();
    boolean canUse(Inventory i);
    void use(Inventory i);
}


class Apple extends Item implements Edible {
    final int hungerUnits;
    
    Apple(){
        super("Apple");        
        this.hungerUnits = 60;
    }
    
    public int getHungerUnits() {
        return hungerUnits;
    }
    
    public void eat() {
        consume();
    }
}

class Salmon extends Item implements Edible {
    final int hungerUnits;
    
    Salmon(){
        super("Salmon");        
        this.hungerUnits = 110;
    }
    
    public int getHungerUnits() {
        return hungerUnits;
    }
    
    public void eat() {
        consume();
    }
}

class Berries extends Item implements Edible {
    final int hungerUnits;
    
    Berries(){
        super("Berries");        
        this.hungerUnits = 40;
    }
    
    public int getHungerUnits() {
        return hungerUnits;
    }
    
    public void eat() {
        consume();
    }
}

class Poisonous_Berries extends Item implements Edible {
    final int hungerUnits;
    
    Poisonous_Berries(){
        super("Poisonous_Berries");
        this.hungerUnits = 25;
    }
    
    public int getHungerUnits() {
        return hungerUnits;
    }
    
    public void eat() {
        consume();
    }
}

class Wood extends Item implements Resource {        
    Wood() {
        super("Wood");
    }
}

class Coal extends Item implements Resource {        
    Coal() {
        super("Coal");
    }
}

class Stone extends Item implements Resource {
    Stone() {
        super("Stone");
    }
}

class Vines extends Item implements Resource {
    Vines() {
        super("Vines");
    }
}

class Sticks extends Item implements Craftable {
    HashMap<String,Integer> recipie;
    final int craftUnits;
    
    Sticks() {
        super("Sticks");
        
        recipie = new HashMap<String,Integer>();
        recipie.put("Wood",3);
        craftUnits = 5;
    }
    
    @Override
    public HashMap<String,Integer> recipie() {
        return recipie;
    }
    
    @Override
    public int getCraftUnits() {
        return craftUnits;
    }
}

class Fire extends Item implements Craftable {
    HashMap<String,Integer> recipie;
    final int craftUnits;
    
    Fire() {
        super("Fire");
        
        recipie = new HashMap<String,Integer>();
        recipie.put("Sticks",4);
        recipie.put("Coal",3);
        craftUnits = 2;
    }
    
    @Override
    public HashMap<String,Integer> recipie() {
        return recipie;
    }
    
    @Override
    public int getCraftUnits() {
        return craftUnits;
    }
}

class Cooked_Salmon extends Item implements Craftable, Edible {
    HashMap<String,Integer> recipie;
    final int craftUnits;
    final int hungerUnits;
    
    Cooked_Salmon() {
        super("Cooked_Salmon");
        
        recipie = new HashMap<String,Integer>();
        recipie.put("Fire",1);
        recipie.put("Salmon",1);
        craftUnits = 1;
        this.hungerUnits = 190;
    }
    
    @Override
    public HashMap<String,Integer> recipie() {
        return recipie;
    }
    
    @Override
    public int getCraftUnits() {
        return craftUnits;
    }
    
    public int getHungerUnits() {
        return hungerUnits;
    }
    
    public void eat() {
        consume();
    }
}

class Logs extends Item implements Craftable {
    HashMap<String,Integer> recipie;
    final int craftUnits;
    
    Logs() {
        super("Logs");
        
        recipie = new HashMap<String,Integer>();
        recipie.put("Wood",3);
        craftUnits = 5;
    }
    
    @Override
    public HashMap<String,Integer> recipie() {
        return recipie;
    }
    
    @Override
    public int getCraftUnits() {
        return craftUnits;
    }
}

class Arrows extends Item implements Craftable,Weapon {
    HashMap<String,Integer> recipie;
    final int attackUnits;
    final int craftUnits;
    
    Arrows() {
        super("Arrows");
        
        this.attackUnits = 20;
        recipie = new HashMap<String,Integer>();
        recipie.put("Sticks",3);
        recipie.put("Stone",3);
        craftUnits = 3;
    }
    
    @Override
    public HashMap<String,Integer> recipie() {
        return recipie;
    }
    
    @Override
    public int getAttackUnits() {
        return attackUnits;
    }
    
    @Override
    public int getCraftUnits() {
        return craftUnits;
    }
    
    @Override
    public boolean canUse(Inventory i) {
        return false;
    }
    
    @Override
    public void use(Inventory i) {
        consume();    
    }
}

class Poison_Arrows extends Item implements Craftable,Weapon {
    HashMap<String,Integer> recipie;
    final int attackUnits;
    final int craftUnits;
    
    Poison_Arrows() {
        super("Poison_Arrows");
        
        this.attackUnits = 25;
        recipie = new HashMap<String,Integer>();
        recipie.put("Sticks",3);
        recipie.put("Stone",3);
        recipie.put("Poisonous_Berries",3);
        craftUnits = 3;
    }
    
    @Override
    public HashMap<String,Integer> recipie() {
        return recipie;
    }
    
    @Override
    public int getAttackUnits() {
        return attackUnits;
    }
    
    @Override
    public int getCraftUnits() {
        return craftUnits;
    }
    
    @Override
    public boolean canUse(Inventory i) {
        return false;
    }
    
    @Override
    public void use(Inventory i) {
        consume();    
    }
}

class Axe extends Item implements Craftable, Weapon {
    HashMap<String,Integer> recipie;
    final int attackUnits;
    final int craftUnits;
    
    Axe() {
        super("Axe");
        
        this.attackUnits = 50;
        recipie = new HashMap<String,Integer>();
        recipie.put("Sticks",2);
        recipie.put("Stone",4);
        craftUnits = 1;
    }
    
    @Override
    public HashMap<String,Integer> recipie() {
        return recipie;
    }
    
    @Override
    public int getAttackUnits() {
        return attackUnits;
    }
    
    @Override
    public int getCraftUnits() {
        return craftUnits;
    }
    
    @Override
    public boolean canUse(Inventory i) {
        return i.contains(name);
    }
    
    @Override
    public void use(Inventory i) {}
}

class Bow extends Item implements Craftable, Weapon {
    HashMap<String,Integer> recipie;
    final int attackUnits;
    final int craftUnits;
    
    Bow() {
        super("Bow");
        
        this.attackUnits = 50;
        recipie = new HashMap<String,Integer>();
        recipie.put("Sticks",3);
        recipie.put("Vines",3);
        craftUnits = 1;
    }
    
    @Override
    public HashMap<String,Integer> recipie() {
        return recipie;
    }
    
    @Override
    public int getAttackUnits() {
        return attackUnits;
    }
    
    @Override
    public int getCraftUnits() {
        return craftUnits;
    }
    
    @Override
    public boolean canUse(Inventory i) {
        return (i.contains(name))&&(i.contains("Arrows")||i.contains("Poison_Arrows"));
    }
    
    @Override
    public void use(Inventory i) {
        String[] preRequisites = new String[]{"Arrows","Poison_Arrows"};
        
        ArrayList<String> Choices = new ArrayList<String>();
        for (String c:preRequisites) {
            if (i.contains(c)) Choices.add(c);
        }
        
        String Choice = Choices.get(RarityPool.randInt(Choices.size()));
        Weapon w = (Weapon) i.get(Choice); //because arrows are weapons, we use use() insteaed of consume().
        w.use(i);
    }
}