class Def {
    int value;
    int duration;
    Def next;
    
    Def(int value, int duration) {
        this.value = value;
        this.duration = duration;
        next = null;
    }
}