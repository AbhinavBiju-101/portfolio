
abstract class Effect{
    Effect next;
    Spell from;
    int priority;
    EffectType effectType;
    
    Effect(Spell from, int priority, EffectType effectType){
        next = null;
        this.from = from;
        this.priority = priority;
        this.effectType = effectType;
    }
    
    /*
        case "Passive":
            priority = 6;
        case "Buff/Debuff":
            priority = 5;
        case "Heal":
            priority = 4;
        case "Defence":
            priority = 3;
        case "in between":
            priority = 2;
        case "Attack":
            priority = 1;
        default:
            priority = 0; //checked at last
    */
       
    abstract void apply();
}

class AttackEffect extends Effect {
    int value;
    double pierce;
    
    AttackEffect(Spell from, int value) {
        super(from, 1, EffectType.Attack);
        this.value = value;
        pierce = 1.0;
    }
    
    @Override
    void apply() {      
        int defsum = from.caster.opponent.defSum();        
        int dmg = (int)(value*pierce);
        if (defsum-dmg > 0) {
            from.caster.opponent.dealDamage(dmg);
        } else {
            from.caster.opponent.dealDamage(defsum);
            from.caster.opponent.dealDamage((int)((dmg-defsum)/pierce));
        }
    }
}

class HealEffect extends Effect {
    int value;
    
    HealEffect(Spell from, int value) {
        super(from, 4, EffectType.Healing);
        this.value = value;
    }
    
    @Override
    void apply() {
        from.caster.heal(value);
    }
}

class DefenceEffect extends Effect {
    int value;
    int duration;
    
    DefenceEffect(Spell from, int value, int duration) {
        super(from, 3, EffectType.Defence);
        this.value = value;
        this.duration = duration;
    }
    
    @Override
    void apply() {
        from.caster.applyDef(value, duration);
    }
}

class CritEffect extends Effect {
    
    CritEffect(Spell from) {
        super(from, 6, EffectType.Buff);
    }
    
    @Override
    void apply() {
        Effect current = from.caster.game.currentTurn.pointer;
        boolean found = false;
        while (current != null) {
            if (current.effectType == EffectType.Attack && current.from.caster == from.caster) {
                AttackEffect A = (AttackEffect) current; //type casting
                if (A.value <= 0) {
                    current = current.next;
                    continue;
                }
                A.value = (int)(A.value*1.5);
                found = true;
                if (from.caster.game.A == from.caster) {
                    from.caster.game.currentTurn.row.addLeft("+Critical",1);
                } else {
                    from.caster.game.currentTurn.row.addRight("+Critical",6);
                }
                break;
            }
            current = current.next;
        }
        if (!found) {
            from.caster.game.currentTurn.next.addEffect(new CritEffect(from));
        }
    }
}

class CapacitorEffect extends Effect {
    int capacity;
    int life;
    
    CapacitorEffect(Spell from) {
        super(from, 6, EffectType.Buff);
        life = 4;
        capacity = 0;
    }
    CapacitorEffect(Spell from, int life, int capacity) {
        super(from, 6, EffectType.Buff);
        this.life = life;
        this.capacity = capacity;
    }
    
    @Override
    void apply() {
        Effect current = from.caster.game.currentTurn.pointer;
        while (current != null) {
            if (current.effectType == EffectType.Attack && current.from.caster == from.caster) {
                AttackEffect A = (AttackEffect) current; //type casting
                capacity += A.value;
                A.value = 0;
            }
            current = current.next;
        }
        if (life == 1) {
            from.caster.game.currentTurn.addEffect(new AttackEffect(from, (int)(capacity*1.3)));
        } else {
            from.caster.game.currentTurn.next.addEffect(new CapacitorEffect(from, life-1, capacity));
        }
        if (from.caster.game.A == from.caster) {
            from.caster.game.currentTurn.row.addLeft("+Capacitor ("+capacity+" charge)",1);
        } else {
            from.caster.game.currentTurn.row.addRight("+Capacitor ("+capacity+" charge)",6);
        }
    }
}

class MultiplierEffect extends Effect {
    double factor;
    EffectType filter;
    Player target;
    String text;
    
    MultiplierEffect(Spell from, EffectType filter, double factor, boolean self) {
        super(from, 5, (factor>1 ? EffectType.Buff : EffectType.Debuff));
        this.filter = filter;
        this.factor = factor;
        target = self ? from.caster : from.caster.opponent;
        if (filter == EffectType.Attack) {
            text = "Atk";
        } else if (filter == EffectType.Healing) {
            text = "Healing";
        } else if (filter == EffectType.Pierce) {
            text = "Def Pierce";
        }
    }
    
    @Override
    void apply() {
        Effect current = from.caster.game.currentTurn.pointer;
        if (current == null) {
            return;
        }
        while (current != null) {
            if (((filter == EffectType.Pierce && current.effectType == EffectType.Attack)||current.effectType == filter) && current.from.caster == target) {
                if (filter == EffectType.Attack) {
                    AttackEffect A = (AttackEffect) current; //type casting
                    A.value = (int)(A.value*factor);
                } else if (filter == EffectType.Healing) {
                    HealEffect A = (HealEffect) current; //type casting
                    A.value = (int)(A.value*factor);
                } else if (filter == EffectType.Pierce) {
                    AttackEffect A = (AttackEffect) current; //type casting
                    A.pierce = factor;
                }
            }
            current = current.next;
        }
        int percentage = (int) Math.round((factor - 1) * 100);
        if (from.caster.game.A == from.caster) {
            from.caster.game.currentTurn.row.addLeft((percentage > 0 ? "+":"")+percentage+"% "+text,(from.caster == target ? 1 : 6));
        } else {
            from.caster.game.currentTurn.row.addLeft((percentage > 0 ? "+":"")+percentage+"% "+text,(from.caster == target ? 6 : 1));
        }
    }
}

