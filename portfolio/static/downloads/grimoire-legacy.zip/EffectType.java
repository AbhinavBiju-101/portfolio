
public enum EffectType
{
    Attack,
    Defence,
    Healing,
    Buff,
    Debuff,
    Pierce,
}
