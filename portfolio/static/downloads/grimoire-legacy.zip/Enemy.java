
class Enemy extends Player {
    String attackSequence;
    int sequenceIteration;
    int lightspeedSlot;
    
    static final String[] names = {
        "Dummy",
        /*"Knight_I",
        "Knight_II",
        "Knight_III",
        "Knight_IV",*/
        "Zeus",
        "Clerik",
        "Overlord",
        "Menace",
        "LordSlayer",
        "Healey",
        "Shieldey",
        "Abomination",
        "Goliath",
        "Zombie",
        "Wraith",
        "Werewolf",
        "Treant",
        "Vampire",
        "Demon",
        "Devil",
        "Snowman",
    }; 
    
    Enemy(Game game, String name){
        super(game, name);
        initialize();
        sequenceIteration = -1;
    }
    
    @Override
    Enemy Clone() {
        Enemy clone = new Enemy(game, name);
        return clone;
    }
    
    void initialize() {
        loadout = new Spell[5];
        /*if (name.equalsIgnoreCase("Knight_I")){
            loadout[0] = grimoire.get("Flame Cutter");
            loadout[1] = grimoire.get("Prayer");
            loadout[2] = grimoire.get("-");
            loadout[3] = grimoire.get("-");
            loadout[4] = grimoire.get("-");
            attackSequence = "12";
        } else if (name.equalsIgnoreCase("Knight_II")){
            loadout[0] = grimoire.get("Golem");
            loadout[1] = grimoire.get("Barrier");
            loadout[2] = grimoire.get("Wind Bullet");
            loadout[3] = grimoire.get("-");
            loadout[4] = grimoire.get("-");
            attackSequence = "1233";
            
        } else if (name.equalsIgnoreCase("Knight_III")){
            loadout[0] = grimoire.get("Pressure beam");
            loadout[1] = grimoire.get("Flame Cutter");
            loadout[2] = grimoire.get("Focus");
            loadout[3] = grimoire.get("Tenacity");
            loadout[4] = grimoire.get("-");
            attackSequence = "312";
        } else if (name.equalsIgnoreCase("Knight_IV")){
            loadout[0] = grimoire.get("Emblaze");
            loadout[1] = grimoire.get("Golem");
            loadout[2] = grimoire.get("Spikes");
            loadout[3] = grimoire.get("Pressure Beam");
            loadout[4] = grimoire.get("-");
            attackSequence = "1234";
        } else*/ if (name.equalsIgnoreCase("Zeus")){
            loadout[0] = grimoire.get("Electrify");
            loadout[1] = grimoire.get("Blood Sucker");
            loadout[2] = grimoire.get("-");
            loadout[3] = grimoire.get("-");
            loadout[4] = grimoire.get("-");
            attackSequence = "1";
        } else if (name.equalsIgnoreCase("Clerik")){
            loadout[0] = grimoire.get("Holy Decree");
            loadout[1] = grimoire.get("Poison Bomb");
            loadout[2] = grimoire.get("-");
            loadout[3] = grimoire.get("-");
            loadout[4] = grimoire.get("-");
            attackSequence = "12";
        }else if (name.equalsIgnoreCase("Snowman")){
            loadout[0] = grimoire.get("Iron talisman");
            loadout[1] = grimoire.get("skeleton battalion");
            loadout[2] = grimoire.get("absolute zero");
            loadout[3] = grimoire.get("-");
            loadout[4] = grimoire.get("-");
            attackSequence = "123";
        }else if (name.equalsIgnoreCase("Necromancer")){
            loadout[0] = grimoire.get("skeleton battalion");
            loadout[1] = grimoire.get("undead warrior spawn");
            loadout[2] = grimoire.get("bladestorm");
            loadout[3] = grimoire.get("holy decree");
            loadout[4] = grimoire.get("-");
            attackSequence = "123142134";
        } else if (name.equalsIgnoreCase("Overlord")){
            loadout[0] = grimoire.get("Magic minigun");
            loadout[1] = grimoire.get("vitality");
            loadout[2] = grimoire.get("Blood sucker");
            loadout[3] = grimoire.get("parry");
            loadout[4] = grimoire.get("tenacity");
            attackSequence = "1";
        } else if (name.equalsIgnoreCase("Dummy")){
            loadout[0] = grimoire.get("-");
            loadout[1] = grimoire.get("-");
            loadout[2] = grimoire.get("-");
            loadout[3] = grimoire.get("parry");
            loadout[4] = grimoire.get("tenacity");
            attackSequence = "1";
            hp = 10000;
        }else if (name.equalsIgnoreCase("Menace")){
            loadout[0] = grimoire.get("Revive");
            loadout[1] = grimoire.get("Absolute Zero");
            loadout[2] = grimoire.get("Capacitor");
            loadout[3] = grimoire.get("Bladestorm");
            loadout[4] = grimoire.get("Sand Tempest");
            attackSequence = "12345";
        } else if (name.equalsIgnoreCase("LordSlayer")){
            loadout[0] = grimoire.get("Slime monster");
            loadout[1] = grimoire.get("Thorns");
            loadout[2] = grimoire.get("Bladestorm");
            loadout[3] = grimoire.get("Revive");
            loadout[4] = grimoire.get("Health Siphon");
            attackSequence = "1341313";
        } else if (name.equalsIgnoreCase("Healey")){
            loadout[0] = grimoire.get("Inductive stone");
            loadout[1] = grimoire.get("Health Siphon");
            loadout[2] = grimoire.get("Parry");
            loadout[3] = grimoire.get("Thorns");
            loadout[4] = grimoire.get("Tenacity");
            attackSequence = "1";
        }else if (name.equalsIgnoreCase("Shieldey")){
            loadout[0] = grimoire.get("Slime monster");
            loadout[1] = grimoire.get("Iron talisman");
            loadout[2] = grimoire.get("Neuter");
            loadout[3] = grimoire.get("Barrier");
            loadout[4] = grimoire.get("Parry");
            attackSequence = "1234";
        }else if (name.equalsIgnoreCase("Abomination")){
            loadout[0] = grimoire.get("sanguine aura");
            loadout[1] = grimoire.get("parry");
            loadout[2] = grimoire.get("tenacity");
            loadout[3] = grimoire.get("slime monster");
            loadout[4] = grimoire.get("magic minigun");
            attackSequence = "4555";
        }else if (name.equalsIgnoreCase("Zombie")){
            loadout[0] = grimoire.get("absolute zero");
            loadout[1] = grimoire.get("iron talisman");
            loadout[2] = grimoire.get("skeleton battalion");
            loadout[3] = grimoire.get("vitality");
            loadout[4] = grimoire.get("tenacity");
            attackSequence = "123";
        }else if (name.equalsIgnoreCase("Goliath")){
            loadout[0] = grimoire.get("Slime monster");
            loadout[1] = grimoire.get("Parry");
            loadout[2] = grimoire.get("Iron talisman");
            loadout[3] = grimoire.get("hectasphere");
            loadout[4] = grimoire.get("thorns");
            attackSequence = "1443";
        }else if (name.equalsIgnoreCase("Wraith")){
            loadout[0] = grimoire.get("Paralyze");
            loadout[1] = grimoire.get("Critical");
            loadout[2] = grimoire.get("Revive");
            loadout[3] = grimoire.get("Last Struggle");
            loadout[4] = grimoire.get("Tenacity");
            attackSequence = "23124";
        }else if (name.equalsIgnoreCase("Werewolf")){
            loadout[0] = grimoire.get("Lightspeed");
            loadout[1] = grimoire.get("Undead warrior spawn");
            loadout[2] = grimoire.get("soul convergance");
            loadout[3] = grimoire.get("Iron talisman");
            loadout[4] = grimoire.get("Blood sucker");
            attackSequence = "234";
            lightspeedSlot = 2;
        }else if (name.equalsIgnoreCase("Treant")){
            loadout[0] = grimoire.get("Plasma cannon");
            loadout[1] = grimoire.get("Sanguine aura");
            loadout[2] = grimoire.get("Paralyze");
            loadout[3] = grimoire.get("Ancient scripture");
            loadout[4] = grimoire.get("Rage");
            attackSequence = "35141";
        }else if (name.equalsIgnoreCase("Vampire")){
            loadout[0] = grimoire.get("absolute zero");
            loadout[1] = grimoire.get("lightspeed");
            loadout[2] = grimoire.get("plasma cannon");
            loadout[3] = grimoire.get("sanguine aura");
            loadout[4] = grimoire.get("blood sucker");
            attackSequence = "13";
            lightspeedSlot = 1;
        }else if (name.equalsIgnoreCase("Demon")){
            loadout[0] = grimoire.get("plasma cannon");
            loadout[1] = grimoire.get("lightspeed");
            loadout[2] = grimoire.get("tenacity");
            loadout[3] = grimoire.get("sanguine aura");
            loadout[4] = grimoire.get("blood sucker");
            attackSequence = "1";
            lightspeedSlot = 1;
        }else if (name.equalsIgnoreCase("Devil")){
            loadout[0] = grimoire.get("Godly wrath");
            loadout[1] = grimoire.get("paralyze");
            loadout[2] = grimoire.get("last struggle");
            loadout[3] = grimoire.get("tenacity");
            loadout[4] = grimoire.get("blood sucker");
            attackSequence = "123";
        }

        for (int i = 0; i<5; i++) {
            loadout[i].caster = this;
        }        
    }
    
    int choice() {
        sequenceIteration++;
        if (sequenceIteration >= attackSequence.length()) {
            sequenceIteration = 0;
        }
        
        return Integer.parseInt(""+attackSequence.charAt(sequenceIteration));
    }
    
    static void display(Game game){
        int c = -1;
        for (String i : names) {
            if (c++ % 5 == 0) {
                System.out.println("------------------------------------------------------------------------------------------");
                System.out.println("ENEMY SET "+(1+c/5)+"\n");
            }
            Enemy e = new Enemy(game, i);
            System.out.println("Enemy ("+i+")");            
            for (int j=0; j<5; j++){
                System.out.println((j+1)+". "+e.loadout[j].name);
            }
            System.out.println();
        }
        System.out.println("------------------------------------------------------------------------------------------");
    }
    
    static boolean validate(String name) {
        for (String i:names) {
            if (i.equalsIgnoreCase(name)) {return true;}
        }
        return false;
    }
}