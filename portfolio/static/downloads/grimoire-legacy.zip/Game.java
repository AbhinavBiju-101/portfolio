import java.util.Scanner;
//import java.util.Random;
import java.util.InputMismatchException;

class Game {
    Player A;
    Turn currentTurn;
    Grimoire grimoire;
    
    Game(){
        grimoire = new Grimoire(this);
        resetTurns();
    }
    void resetTurns() {
        Turn current = new Turn(1);
        currentTurn = current;
        for (int i = 0;i<45;i++){
            Turn New = new Turn(i+2);
            current.next = New;
            current = current.next;
        }
    }
    
    void setPlayers(Player A, Player B) {
        this.A = A;
        A.opponent = B;
        B.opponent = A;
        //this.A = (new Random().nextInt(1) == 0) ? A : B;
    }
    void resetPlayers() {
        setPlayers(A.Clone(), A.opponent.Clone());
    }
    
    void fight_duel() {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter Player A's name: ");String aName = sc.next();
        System.out.print("Enter Player B's name: ");String bName = sc.next();
        
        sc.close();
        grimoire.display();
        
        Player A = new Player(this, aName); A.setLoadout();
        Player B = new Player(this, bName); B.setLoadout();        
        setPlayers(A, B);
    }
    
    void fight_enemy() {
        Scanner sc = new Scanner(System.in);        
        
        System.out.print("Enter Enemy's name: ");String eName = sc.next();     
        while (!Enemy.validate(eName)) {
            System.out.println("Invalid Enemy!");
            System.out.print("Enter Enemy's name: ");
            eName = sc.next();
        }     
        System.out.print("Enter Player's name: "); String pName = sc.next();
        sc.close();        
        grimoire.display();
        sc = new Scanner(System.in);
        
        Player A = new Player(this, pName); A.setLoadout();
        Enemy B = new Enemy(this, eName);        
        setPlayers(A, B);
    }
    
    void nextTurn() {
        if (currentTurn.turnNumber > 40) {
            System.out.println("The game has gone for too long");
            return;
        }
        Scanner sc = new Scanner(System.in);
        
        A.reduceCooldown();
        A.opponent.reduceCooldown();
        for (int i=0; i<5; i++) {
            if (A.loadout[i].initial_cooldown == 0) {
                A.cast(i); // cast passive spells
            }
            if (A.opponent.loadout[i].initial_cooldown == 0) {
                A.opponent.cast(i);
            }
        }
        
        int choiceA;
        if (A.canCast()) {
            System.out.print("A: ");
            while (true) {
                try {
                    choiceA = sc.nextInt();
                } catch (InputMismatchException e) {
                    System.out.println("Enter the spell slot (1,2,3,4,5), not name!");
                    sc.next();
                    System.out.print("A: ");
                    continue;
                }
                if (choiceA < 1 || choiceA > 5) {
                    System.out.print("Out of range! Choose from (1,2,3,4,5)\nA: ");
                    choiceA = sc.nextInt();
                    continue;
                }
                if (A.loadout[choiceA-1].initial_cooldown == 0) {
                    System.out.print("That is a passive spell!\nA: ");
                    choiceA = sc.nextInt();
                    continue;
                }
                if (A.loadout[choiceA-1].cooldown != 0) {
                    System.out.println("That is on Cooldown!");
                    System.out.print("Cooldowns: ");
                    for (int i=0; i<5; i++) {
                        if (A.loadout[i].initial_cooldown == 0) {continue;}
                        System.out.print((i+1)+"."+A.loadout[i].name+"("+A.loadout[i].cooldown+") ");
                    }
                    System.out.print("\nA: ");
                    choiceA = sc.nextInt();
                    continue;
                }
                break;
            }
        } else {
            System.out.println("A: "+(A.skipTurn ? "(Turn skipped)" : "(all spells on cooldown)"));
            A.skipTurn = false;
            choiceA = 0;
        }
        
        int choiceB;
        if (A.opponent instanceof Enemy) {
            Enemy opponent = (Enemy) A.opponent;
            if (opponent.canCast()) {            
                choiceB = opponent.choice();
                System.out.println("B: "+choiceB);
            } else {
                System.out.println("B: "+(A.opponent.skipTurn ? "(Turn skipped)" : "(all spells on cooldown)"));
                A.opponent.skipTurn = false;
                choiceB = 0;
            }
        } else if (A.opponent.canCast()) {
            System.out.print("B: ");
            while (true) {
                try {
                    choiceB = sc.nextInt();
                } catch (InputMismatchException e) {
                    System.out.println("Enter the spell slot (1,2,3,4,5), not name!");
                    sc.next();
                    System.out.print("B: ");
                    continue;
                }
                if (choiceB < 1 || choiceB > 5) {
                    System.out.print("Out of range! Choose from (1,2,3,4,5)\nB: ");
                    choiceB = sc.nextInt();
                    continue;
                }
                if (A.opponent.loadout[choiceB-1].initial_cooldown == 0) {
                    System.out.print("That is a passive spell!\nB: ");
                    choiceB = sc.nextInt();
                    continue;
                }
                if (A.opponent.loadout[choiceB-1].cooldown != 0) {
                    System.out.println("That is on Cooldown!");
                    System.out.print("Cooldowns: ");
                    for (int i=0; i<5; i++) {
                        if (A.opponent.loadout[i].initial_cooldown == 0) {continue;}
                        System.out.print((i+1)+"."+A.opponent.loadout[i].name+"("+A.opponent.loadout[i].cooldown+" CD) ");
                    }
                    System.out.print("\nB: ");
                    choiceB = sc.nextInt();
                    continue;
                }
                break;
            }
        } else {
            System.out.println("B: "+(A.opponent.skipTurn ? "(Turn skipped)" : "(all spells on cooldown)"));
            A.opponent.skipTurn = false;
            choiceB = 0;
        }
        
        
        A.cast(choiceA-1);
        A.opponent.cast(choiceB-1);
        currentTurn.applyEffects(); //breakpoint here to debug 
        
        currentTurn.display();        
        Row result = new Row(8,10);
        result.addLeft("= "+A.hp,3);
        result.addRight(".",3);
        result.addLeft("= "+A.defSum(),2);
        result.addRight("= "+A.opponent.hp,4);
        result.addLeft(".",4);
        result.addRight("= "+A.opponent.defSum(),5);
        result.addLeft("..........",0);
        result.addRight("..........",7);
        result.display();
                
        System.out.println();
        System.out.println();
        currentTurn = currentTurn.next;        
        sc.close();
        
        if (A.hp>0 && A.opponent.hp>0) {
            nextTurn();
        } else {
            if (A.opponent.hp<=0 && A.hp > 0) {
                System.out.println(((A.opponent instanceof Enemy)? "Enemy":"Player")+" ("+A.opponent.name+") has died.");                
            } else if (A.hp <= 0 && A.opponent.hp > 0){
                System.out.println("Player ("+A.name+") has died.");
            } else {
                System.out.println("Both Players have died.");
            }
        }
    }
    
    void initializeDisplay() {
        int size = 80;
        
        Row header = new Row(2,size/2);
        header.addLeft("Player A ("+A.name+")",0);
        header.addRight(((A.opponent instanceof Enemy)? "Enemy":"Player")+" B ("+A.opponent.name+")",1);
        header.display();
        
        System.out.println();
        for (int i=0; i<5; i++) {
            Row row = new Row(2,size/2);
            row.addLeft((i+1)+". "+A.loadout[i].name+" ("+A.loadout[i].duration+" D, "+(A.loadout[i].initial_cooldown == 0 ? "passive)" : A.loadout[i].initial_cooldown+" CD)"),0);
            row.addRight("("+A.opponent.loadout[i].duration+" D, "+(A.opponent.loadout[i].initial_cooldown == 0 ? "passive)" : A.opponent.loadout[i].initial_cooldown+" CD) ")+A.opponent.loadout[i].name+" ."+(i+1),1);
            row.display();
        }
        System.out.println("--------------------------------------------------------------------------------");
        
        Row labels = new Row(8,10);
        labels.addLeft("Turn",0);
        //labels.addRight("|",0);
        labels.addLeft("Effects",1);
        labels.addLeft("Defence",2);
        labels.addLeft("Health",3);
        labels.addRight(".",3);
        labels.addRight("Health",4);
        labels.addLeft(".",4);
        labels.addRight("Defence",5);
        labels.addRight("Effects",6);
        labels.addRight("Turn",7);
        //labels.addLeft("|",7);
        labels.display();
        System.out.println("--------------------------------------------------------------------------------");        
    }
    
    public static void main(String[] args) {
        Game game = new Game();
        Scanner sc = new Scanner(System.in);
        
        Menu gameMenu = new Menu();
        gameMenu.add("1. View Grimoire Spells");
        gameMenu.add("2. Duel (1v1 PVP)");
        gameMenu.add("3. Fight Enemies");
        gameMenu.add("4. Exit");
        
            Menu grimoireMenu = new Menu();
            grimoireMenu.add("1. Sort");
            grimoireMenu.add("2. Filter");
            grimoireMenu.add("3. Go Back");
    
                Menu sortMenu = new Menu();
                sortMenu.add("1. Sort by Set");
                sortMenu.add("2. Sort by Cooldown");
                sortMenu.add("3. Sort by Duration");
                sortMenu.add("4. Go Back");
        
                    Menu filterMenu = new Menu();
                    filterMenu.add("1. Attack");
                    filterMenu.add("2. Defence");
                    filterMenu.add("3. Buff");
                    filterMenu.add("4. Debuff");
                    filterMenu.add("5. Passive");
                    filterMenu.add("6. Go Back");
        
        Menu rematchMenu = new Menu();
        rematchMenu.add("1. Rematch");
        rematchMenu.add("2. Go Back");
        
        
        System.out.println("==========================================================================================");
        System.out.println("=                                                                                        =");
        System.out.println("=                                     GRIMOIRE LEGACY                                    =");
        System.out.println("=                                                                                        =");
        System.out.println("==========================================================================================");
        
        while (!gameMenu.choice.equals("4")) {
            gameMenu.getInput();
            gameMenu.validate("1","2","3","4");
            
            if (gameMenu.choice.equals("1")) {
                game.grimoire.display();
                while (true) {
                    grimoireMenu.getInput();
                    grimoireMenu.validate("1","2","3","4");

                    if (grimoireMenu.choice.equals("1")) {
                        while (!sortMenu.choice.equals("4")) {
                            sortMenu.getInput();
                            sortMenu.validate("1","2","3","4");
                            
                            if (sortMenu.choice.equals("1")) {
                                game.grimoire.sort("Set");
                            } else if(sortMenu.choice.equals("2")) {
                                game.grimoire.sort("Cooldown");
                            } else if (sortMenu.choice.equals("3")) {
                                game.grimoire.sort("Duration");
                            } else if (sortMenu.choice.equals("4")) {
                                sortMenu.choice = "";
                                break;
                            }
                            
                            game.grimoire.display();
                        }
                    } else if (grimoireMenu.choice.equals("2")) {
                        String filters = "";
                        
                        while (!filterMenu.choice.equals("6")) {
                            filterMenu.getInput();
                            filterMenu.validate("1","2","3","4","5","6");
                            
                            String filter = "";
                            if (filterMenu.choice.equals("1")) {
                                filter = "Attack";
                            } else if(filterMenu.choice.equals("2")) {
                                filter = "Defence";
                            } else if (filterMenu.choice.equals("3")) {
                                filter = "Buff";
                            } else if (filterMenu.choice.equals("4")) {
                                filter = "Debuff";
                            } else if (filterMenu.choice.equals("5")) {
                                filter = "Passive";
                            } else if (filterMenu.choice.equals("6")) {
                                filterMenu.choice = "";
                                break;
                            }
                            
                            if (filters.contains(filter)) {
                                filters = filters.replace(filter+", ", "");
                            } else {
                                filters += filter+", ";
                            }
                            
                            game.grimoire.display(filters.split(", "));
                        }
                    } else if(grimoireMenu.choice.equals("3")) {
                        grimoireMenu.choice = "";
                        break;
                    }
                }
            } else if (gameMenu.choice.equals("2")) {
                game.fight_duel();
                game.initializeDisplay();
                game.nextTurn();
                
                while (!rematchMenu.choice.equals("2")) {
                    rematchMenu.getInput();
                    rematchMenu.validate("1","2");
                    
                    if (rematchMenu.choice.equals("1")) {
                        game.resetTurns();
                        game.resetPlayers();
                        game.initializeDisplay();
                        game.nextTurn();                        
                    } else if (rematchMenu.choice.equals("2")) {
                        game = new Game();
                        rematchMenu.choice = "";
                        break;
                    }
                }
            } else if (gameMenu.choice.equals("3")) {
                Enemy.display(game);
                
                game.fight_enemy();
                game.initializeDisplay();
                game.nextTurn();
                
                while (!rematchMenu.choice.equals("2")) {
                    rematchMenu.getInput();
                    rematchMenu.validate("1","2");
                    
                    if (rematchMenu.choice.equals("1")) {
                        game.resetTurns();
                        game.resetPlayers();
                        game.initializeDisplay();
                        game.nextTurn();
                    } else if (rematchMenu.choice.equals("2")) {
                        game = new Game();
                        rematchMenu.choice = "";
                        break;
                    }
                }
            } else if (gameMenu.choice.equals("4")) {
                gameMenu.choice = "";
                break;
            }
        }
    }
}