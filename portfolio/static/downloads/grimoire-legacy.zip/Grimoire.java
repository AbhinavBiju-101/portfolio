import java.util.Random;
import java.util.Scanner;

class Grimoire{
    Spell[] spells;
    Game game;
    
    Grimoire(Game game) {
        this.game = game;
        spells = new Spell[]{
            new Spell(EffectType.Attack, "-", 1, 1, "(do nothing)"){
                @Override
                void apply() {}
            },
            new Spell(EffectType.Attack, "Fireball", 1, 1, "100 dmg"){
                @Override
                void apply() {
                    game.currentTurn.addEffect(new AttackEffect(this, 100));
                }
            },
            new Spell(EffectType.Defence, "Shield", 3, 4, "50 def per turn") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new DefenceEffect(this, 50, 1));
                    game.currentTurn.next.addEffect(new DefenceEffect(this, 50, 1));
                    game.currentTurn.next.next.addEffect(new DefenceEffect(this, 50, 1));
                }
            },
            new Spell(EffectType.Attack, "Wind Bullet", 1, 1, "40x3 barrage damage") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new AttackEffect(this,40*3));
                }
            },
            new Spell(EffectType.Healing, "Prayer", 1, 1, "120 hp") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new HealEffect(this, 120));
                }
            },
            new Spell(EffectType.Debuff, "Taunt", 4, 3, "Reduce opponent Atk by 20%") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    for (int i = 0; i<3; i++) {                        
                        current.addEffect(new MultiplierEffect(this, EffectType.Attack, 0.8, false));
                        current = current.next;
                    }                    
                }
            },
            new Spell(EffectType.Attack, "Flame Cutter", 1, 2, "175 dmg") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new AttackEffect(this, 175));
                }
            },
            new Spell(EffectType.Defence, "Barrier", 2, 3, "200 def") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new DefenceEffect(this, 200, 2));
                }
            },
            new Spell(EffectType.Buff, "Focus", 4, 3, "Increase atk by 20%") {
                @Override
                void apply(){
                    Turn current = game.currentTurn;
                    for (int i = 0; i<3; i++) {                        
                        current.addEffect(new MultiplierEffect(this, EffectType.Attack, 1.20, true));
                        current = current.next;
                    }
                }
            },
            new Spell(EffectType.Attack, "Golem", 3, 4, "80 dmg/turn") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    for (int i = 0; i<3; i++) {
                        current.addEffect(new AttackEffect(this,80));
                        current = current.next;
                    }
                }
            },
            new Spell(EffectType.Attack, "Pressure beam", 1, 3, "220 dmg") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new AttackEffect(this,220));
                }
            },
            new Spell(EffectType.Healing, "Blessing", 4, 4, "80 hp/turn") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    for (int i = 0; i<4; i++) {
                        current.addEffect(new HealEffect(this,80));
                        current = current.next;
                    }
                }
            },
            new Spell(EffectType.Attack, "Emblaze", 5, 4, "100 dmg/turn") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    for (int i = 0; i<5; i++) {
                        current.addEffect(new AttackEffect(this,100));
                        current = current.next;
                    }
                }
            },
            new Spell(EffectType.Defence, "Hexasphere", 2, 1, "175 def") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new DefenceEffect(this, 175, 2));
                }
            },
            new Spell(EffectType.Attack, "Spikes", 2, 2, "160 dmg/turn") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new AttackEffect(this, 160));
                    game.currentTurn.next.addEffect(new AttackEffect(this, 160));
                }
            },
            new Spell(EffectType.Attack, "Light Shots", 2, 1, "30x4 dmg/turn") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new AttackEffect(this, 30*4));
                    game.currentTurn.next.addEffect(new AttackEffect(this, 30*4));
                }
            },
            new Spell(EffectType.Attack, "Skeleton Horde", 2, 3, "50x3 dmg/turn") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new AttackEffect(this, 50*3));
                    game.currentTurn.next.addEffect(new AttackEffect(this, 50*3));
                }
            },
            new Spell(EffectType.Defence, "Neuter", 1, 2, "300 def") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new DefenceEffect(this, 300, 1));
                }
            },
            new Spell(EffectType.Attack, "Sonic Crescent", 1, 1, "200 damage") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new AttackEffect(this,200));
                }
            },
            new Spell(EffectType.Attack, "Bladestorm", 4, 4, "25x8 dmg/turn") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    for (int i = 0; i<4; i++) {
                        current.addEffect(new AttackEffect(this, 25*8));
                        current = current.next;
                    }
                }
            },
            new Spell(EffectType.Buff, "Rage", 3, 3, "Increase Atk by 15%, gain 25% def pierce") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    for (int i = 0; i<3; i++) {
                        current.addEffect(new MultiplierEffect(this, EffectType.Pierce, 1.25, true));
                        current.addEffect(new MultiplierEffect(this, EffectType.Attack, 1.15, true));
                        current = current.next;                        
                    }
                }
            },
            new Spell(EffectType.Buff, "Blood Sucker", 1, 0, "Heal 40% of your dmg (piercing does not count)") {
                @Override
                void apply() {
                    Effect e = new Effect(this, 5, EffectType.Buff){
                        @Override
                        void apply() {
                            Effect current = game.currentTurn.pointer;
                            if (current == null) {
                                return;
                            }
                            while (current != null) {
                                if (current.effectType == EffectType.Attack && current.from.caster == caster) {
                                  AttackEffect A = (AttackEffect) current; //type casting
                                  game.currentTurn.addEffect(new HealEffect(from, (int)(A.value*0.4)));
                                  //caster.heal((int)(A.value*0.4));
                                }
                                current = current.next;
                            }
                          
                        }
                    };
                    game.currentTurn.addEffect(e);
                    if (game.A == caster) {
                        game.currentTurn.row.addLeft("+40% Leech",1);
                    } else {
                        game.currentTurn.row.addRight("+40% Leech",6);
                    }
                }
            },
            new Spell(EffectType.Attack, "Electrify", 3, 1, "100 dmg/turn") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    for (int i = 0; i<3; i++) {
                        current.addEffect(new AttackEffect(this, 100));
                        current = current.next;
                    }
                }
            },
            new Spell(EffectType.Attack, "Smite", 1, 3, "300 dmg") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new AttackEffect(this, 300));
                }
            },
            new Spell(EffectType.Healing, "Divine Call", 1, 1, "200 hp") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new HealEffect(this,200));
                }
            },
            new Spell(EffectType.Debuff, "Curse", 3, 3, "Reduce opponent healing by 40%") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    for (int i = 0; i<3; i++) {                        
                        current.addEffect(new MultiplierEffect(this, EffectType.Healing, 0.6, false));
                        current = current.next;
                    }
                }
            },
            new Spell(EffectType.Buff, "Health Siphon", 1, 0, "Heal 50% of what opponent heals") {
                @Override
                void apply() {
                    Effect e = new Effect(this, 6, EffectType.Buff){
                        @Override
                        void apply() {
                            Effect current = game.currentTurn.pointer;
                            if (current == null) {
                                return;
                            }
                            while (current != null) {
                                if (current.effectType == EffectType.Healing && current.from.caster == caster.opponent) {
                                    HealEffect A = (HealEffect) current; //type casting
                                    game.currentTurn.addEffect(new HealEffect(from, (int)(A.value*0.5) ));
                                    //caster.heal((int)(A.value*0.5));
                                }
                                current = current.next;
                            }
                        }
                    };
                    game.currentTurn.addEffect(e);
                    if (game.A == caster) {
                        game.currentTurn.row.addLeft("+50% Health Siphon",1);
                    } else {
                        game.currentTurn.row.addRight("+50% Health Siphon",6);
                    }
                }
            },
            new Spell(EffectType.Attack, "Sand Tempest", 2, 2, "200 dmg/turn") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    for (int i = 0; i<2; i++) {
                        current.addEffect(new AttackEffect(this, 200));
                        current = current.next;
                    }
                }
            },
            new Spell(EffectType.Attack, "Absolute Zero", 5, 3, "120 dmg/turn") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    for (int i = 0; i<5; i++) {
                        current.addEffect(new AttackEffect(this, 120));
                        current = current.next;
                    }
                }
            },
            new Spell(EffectType.Defence, "Iron Talisman", 3, 3, "500 def") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new DefenceEffect(this, 500, 3));
                }
            },
            new Spell(EffectType.Attack, "Undead Warrior Spawn", 4, 4, "60 dmg/turn, 100 def/turn") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    for (int i = 0; i<4; i++) {
                        current.addEffect(new AttackEffect(this, 60));
                        current.addEffect(new DefenceEffect(this, 100,1));
                        current = current.next;
                    }
                }
            },
            new Spell(EffectType.Attack, "Poison Bomb", 3, 2, "150 dmg(1D) + 80 dmg/turn(3D)") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    current.addEffect(new AttackEffect(this, 150));
                    for (int i = 0; i<3; i++) {
                        current.addEffect(new AttackEffect(this, 80));
                        current = current.next;
                    }
                }
            },
            new Spell(EffectType.Healing, "Holy Decree", 5, 2, "180 hp(1D) + 30 hp/turn(5D)") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    current.addEffect(new HealEffect(this, 180));
                    for (int i = 0; i<5; i++) {
                        current.addEffect(new HealEffect(this, 30));
                        current = current.next;
                    }
                }
            },
            new Spell(EffectType.Buff, "Critical", 1, 2, "Increase Atk by 50% for next attack (can stack)") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new CritEffect(this));
                }
            },
            new Spell(EffectType.Healing, "Vitality", 1, 0, "100 hp/turn") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new HealEffect(this,100));
                }
            },
            new Spell(EffectType.Attack, "Blood Hammer", 1, 3, "350 dmg, but -100 hp") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new AttackEffect(this,350));
                    game.currentTurn.addEffect(new HealEffect(this,-100));
                }
            },
            new Spell(EffectType.Debuff, "Thorns", 1, 0, "Opponent gets hit with 50% of what they deal") {
                @Override
                void apply() {
                    Effect e = new Effect(this, 6, EffectType.Debuff){
                        @Override
                        void apply() {
                            Effect current = game.currentTurn.pointer;
                            if (current == null) {
                                return;
                            }
                            while (current != null) {
                                if (current.effectType == EffectType.Attack && current.from.caster == caster.opponent) {
                                    AttackEffect A = (AttackEffect) current; //type casting
                                    //caster.opponent.dealDamage((int)(A.value*0.5));
                                    game.currentTurn.addEffect(new AttackEffect(from, (int)(A.value*0.5) ));
                                }
                                current = current.next;
                            }
                        }
                    };
                    game.currentTurn.addEffect(e);
                    if (game.A == caster) {
                        game.currentTurn.row.addLeft("+50% Thorns",1);
                    } else {
                        game.currentTurn.row.addRight("+50% Thorns",6);
                    }
                }
            },
            new Spell(EffectType.Attack, "Skeleton Battalion", 3, 3, "30x5 dmg/turn + 25x5 def/turn") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    for (int i = 0; i<5; i++) {
                        current.addEffect(new AttackEffect(this, 30*5));
                        current.addEffect(new DefenceEffect(this, 25*5, 1));
                        current = current.next;
                    }
                }
            },
            new Spell(EffectType.Attack, "Magic Minigun", 5, 1, "10x16 dmg/turn") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    for (int i = 0; i<5; i++) {
                        current.addEffect(new AttackEffect(this, 10*16));
                        current = current.next;
                    }
                }
            },
            new Spell(EffectType.Healing, "Revive", 1, 8, "+1000 hp") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new HealEffect(this, 1000));
                }
            },
            new Spell(EffectType.Buff, "Inductive Stone", 3, 3, "Get a barrier 80% as effective as opponent's") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    for (int i = 0; i<3; i++) {
                        Effect e = new Effect(this, 6, EffectType.Buff){
                            @Override
                            void apply() {
                                Effect current = game.currentTurn.pointer;
                                if (current == null) {
                                    return;
                                }
                                while (current != null) {
                                    if (current.effectType == EffectType.Defence && current.from.caster == caster.opponent) {
                                        DefenceEffect A = (DefenceEffect) current; //type casting
                                        //caster.applyDef((int)(A.value * 0.8), A.duration);
                                        game.currentTurn.addEffect(new DefenceEffect(from, (int)(A.value*0.8), A.duration));
                                    }
                                    current = current.next;
                                }
                            }
                        };
                        current.addEffect(e);
                        if (game.A == caster) {
                            current.row.addLeft("+Inductive",1);
                        } else {
                            current.row.addRight("+Inductive",6);
                        }
                        current = current.next;
                    }                    
                }
            },
            new Spell(EffectType.Buff, "Capacitor", 1, 4, "Store your attacks of next 4 turns, and release at once with 30% more power"){
                @Override
                void apply(){
                    game.currentTurn.addEffect(new CapacitorEffect(this));
                }
            },
            new Spell(EffectType.Defence, "Slime monster", 5, 4, "500 def(4D) + 100 def/turn(1D,4D) + reflect 50% taken damage on def") {
                @Override
                void apply() {                                       
                    Turn current = game.currentTurn;
                    current.addEffect(new DefenceEffect(this, 500, 4));     
                    for (int i=0; i<4; i++) {
                        Effect a = new DefenceEffect(this, 100, 1);
                        Effect b = new Effect(this, 2, EffectType.Debuff){
                            @Override
                            void apply() {
                                Effect current = game.currentTurn.pointer;
                                int defsum = caster.defSum();
                                if (current == null) {
                                    return;
                                }
                                while (current != null) {
                                    if (current.effectType == EffectType.Attack && current.from.caster == caster.opponent) {
                                        AttackEffect A = (AttackEffect) current; //type casting            
                                        if (defsum - A.value > 0) {
                                            caster.opponent.dealDamage((int)(A.value*0.5));
                                        } else {
                                            caster.opponent.dealDamage((int)(defsum*0.5));
                                            break;
                                        }
                                        defsum -= A.value;
                                    }
                                    current = current.next;
                                }
                            }
                        };
                        current.addEffect(a);
                        current.addEffect(b);
                        current = current.next;
                    }                                  
                    
                } // still have to make it so that other defences do not reflect the damage.
            },
            new Spell(EffectType.Defence, "Parry", 1, 0, "25% chance/turn for 1000 def(1D)") {
                @Override
                void apply() {
                    if (new Random().nextInt(3) == 0) {
                        game.currentTurn.addEffect(new DefenceEffect(this, 1000, 1));
                    }
                }
            },
            new Spell(EffectType.Healing, "Tenacity", 3, 0, "Avoid death, and set hp to 1 + 300 hp/turn(2D)") {
                boolean used = false;
                @Override
                void apply() {
                    if (used) {
                        return;
                    }
                    
                    Effect e = new Effect(this, 0, EffectType.Buff){
                        @Override
                        void apply() {
                            if (caster.hp > 0) {
                                return;
                            }
                            
                            used = true;
                            caster.hp = 0;
                            caster.heal(1);
                            
                            if (game.A == caster) {
                                game.currentTurn.row.addLeft("+Tenacity",1);
                            } else {
                                game.currentTurn.row.addRight("+Tenacity",6);
                            }
                            
                            Turn current = game.currentTurn.next;
                            for (int i = 0; i<2; i++) {
                                current.addEffect(new HealEffect(from, 300));
                                current = current.next;
                            }
                        }
                    };
                    game.currentTurn.addEffect(e);
                }
            },
            new Spell(EffectType.Buff, "Sanguine Aura", 1, 0, "Increase Atk by +30% under 500 Hp, and 20% chance to dodge below 200 hp") {
                @Override
                void apply() {
                    Effect e = new Effect(this, 6, EffectType.Buff) {
                        @Override
                        void apply() {
                            Effect current = game.currentTurn.pointer;
                            if (current == null) {
                                return;
                            }
                            if (from.caster.hp <= 200) {
                                if (new Random().nextInt(4) == 0) {
                                    while (current != null) {
                                        if (current.effectType == EffectType.Attack && current.from.caster == caster.opponent) {
                                            AttackEffect A = (AttackEffect) current; //type casting
                                            A.value = 0;
                                        }
                                        current = current.next;
                                    }
                                    if (from.caster.game.A == from.caster) {
                                        game.currentTurn.row.addLeft("+Dodge",1);
                                    } else {
                                        game.currentTurn.row.addRight("+Dodge",6);
                                    }
                                }
                            }
                            if (from.caster.hp <= 500) {
                                current = game.currentTurn.pointer;
                                while (current != null) {
                                    if (current.effectType == EffectType.Attack && current.from.caster == caster) {
                                        AttackEffect A = (AttackEffect) current; //type casting
                                        A.value = (int)(A.value * 1.3);
                                    }
                                    current = current.next;
                                }
                                if (from.caster.game.A == from.caster) {
                                    game.currentTurn.row.addLeft("+30% Atk",1);
                                } else {
                                    game.currentTurn.row.addRight("+30% Atk",6);
                                }
                            }
                        }
                    };
                    game.currentTurn.addEffect(e);
                }
            },
            new Spell(EffectType.Attack, "Soul Convergance", 3, 3, "280 dmg, 125 dmg/turn(3D), -50 hp/turn(3D)") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new AttackEffect(this, 280));
                    Turn current = game.currentTurn;
                    for (int i=0; i<3; i++) {
                        current.addEffect(new AttackEffect(this, 125));
                        current.addEffect(new HealEffect(this, -50));
                        current = current.next;
                    }
                }
            },
            new Spell(EffectType.Debuff, "Life Fragmentation", 4, 3, "Set yours and opponent's hp to their average, +80hp/turn(4D)") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    Effect e = new Effect(this, 6, EffectType.Debuff) {
                        @Override
                        void apply() {
                            int average = (int)((from.caster.hp + from.caster.opponent.hp)/2);
                            if (from.caster.game.A == from.caster) {
                                game.currentTurn.row.addLeft("+Life fragment ("+(average-from.caster.hp)+" hp)",1);
                                game.currentTurn.row.addRight("+Life fragment ("+(average-from.caster.opponent.hp)+" hp)",6);
                            } else {
                                game.currentTurn.row.addLeft("+Life fragment ("+(average-from.caster.hp)+" hp)",6);
                                game.currentTurn.row.addRight("+Life fragment ("+(average-from.caster.opponent.hp)+" hp)",1);
                            }
                            from.caster.hp = average;
                            from.caster.opponent.hp = average;
                        }
                    };
                    current.addEffect(e);                    
                    for (int i=0; i<4; i++) {
                        current.addEffect(new HealEffect(this, 80));
                        current = current.next;
                    }
                }              
            },
            new Spell(EffectType.Attack, "Meteor Strike", 1, 5, "520 dmg") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new AttackEffect(this, 520));
                }
            },
            new Spell(EffectType.Debuff, "Paralyze", 1, 5, "Opponent Skips their next 2 turns (Even passives get ignored)") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    for (int i=0; i<2; i++) {
                        Effect e = new Effect(this, 0, EffectType.Debuff) {
                            @Override
                            void apply() {
                                from.caster.opponent.skipTurn = true;
                            }
                        };
                        current.addEffect(e);
                        
                        current = current.next;
                    }
                }
            },
            new Spell(EffectType.Healing, "Ancient Scripture", 2, 2, "300hp, 150 def(1D)/turn(2D)") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new HealEffect(this, 300));
                    game.currentTurn.addEffect(new DefenceEffect(this, 150, 1));
                    game.currentTurn.next.addEffect(new DefenceEffect(this, 150, 1));
                }
            },
            new Spell(EffectType.Defence, "Hectasphere", 4, 1, "100 def(1D)/turn") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    for (int i=0; i<4; i++) {
                        current.addEffect(new DefenceEffect(this, 100, 1));
                        current = current.next;
                    }
                }
            },
            new Spell(EffectType.Debuff, "Devour", 2, 4, "Break opponent's shields") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    for (int i=0; i<2; i++) {
                        Effect e = new Effect(this, 2, EffectType.Debuff){
                            @Override
                            void apply() {
                                int defsum = from.caster.opponent.defSum();
                                game.currentTurn.addEffect(new AttackEffect(from, defsum));
                                if (from.caster.game.A == from.caster) {
                                    game.currentTurn.row.addLeft("-Devour (-"+defsum+" def)",6);
                                } else {
                                    game.currentTurn.row.addRight("-Devour (-"+defsum+" def)",1);
                                }
                            }
                        };
                        
                        current.addEffect(e);
                        //current.addEffect(new AttackEffect(this, caster.opponent.defSum()));
                        current = current.next;
                    }
                }
            },
            new Spell(EffectType.Attack, "Godly Wrath", 3, 4, "300 dmg/turn") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    for (int i=0; i<3; i++) {
                        current.addEffect(new AttackEffect(this, 300));
                        current = current.next;
                    }
                }
            },
            new Spell(EffectType.Buff, "Lightspeed", 1, 0, "Reduce cooldown of selected spell by 1. (CD cannot be 0)") {
                int slot;
                final int increment = 1;
                @Override
                void apply() {
                    if (slot == 0) {
                        if (caster instanceof Enemy) {
                            Enemy e = (Enemy) caster;
                            slot = e.lightspeedSlot;
                            System.out.print("Enemy ("+caster.name+"), enter target of lightspeed: "+slot+"\n");
                            Spell target = caster.loadout[slot-1];
                            target.initial_cooldown -= increment;
                            return;
                        }
                        
                        Scanner sc = new Scanner(System.in);
                        System.out.print("Player ("+caster.name+"), enter target of lightspeed: ");
                        slot = sc.nextInt();
                        while (true) {
                            if (slot < 1 || slot > 5) {
                                System.out.println("Out of range! Choose from (1,2,3,4,5)\n");
                                System.out.print("Player ("+caster.name+"), enter target of lightspeed: ");
                                slot = sc.nextInt();
                                continue;
                            }
                            Spell target = caster.loadout[slot-1];
                            if (target.initial_cooldown == 0) {
                                System.out.println("Cannot reduce cooldown of passive spells!\n");
                                System.out.print("Player ("+caster.name+"), enter target of lightspeed: ");
                                slot = sc.nextInt();
                                continue;
                            } else if (target.initial_cooldown - increment <= 0) {
                                System.out.println("Cooldown cannot be made zero!\n");
                                System.out.print("Player ("+caster.name+"), enter target of lightspeed: ");
                                slot = sc.nextInt();
                                continue;
                            } else {
                                target.initial_cooldown -= increment;
                                break;
                            }
                        }
                        sc.close();
                    }
                }
            },
            new Spell(EffectType.Attack, "Plasma Cannon", 5, 2, "250 dmg, 50 dmg/turn") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    current.addEffect(new AttackEffect(this, 250));
                    for (int i=0; i<5; i++) {
                        current.addEffect(new AttackEffect(this, 50));
                        current = current.next;
                    }
                }
            },
            new Spell(EffectType.Attack, "Last Struggle", 1, 5, "750 dmg, -300 hp, +50% def pierce") {
                @Override
                void apply() {
                    game.currentTurn.addEffect(new MultiplierEffect(this, EffectType.Pierce, 1.5, true));
                    game.currentTurn.addEffect(new HealEffect(this, -300));
                    game.currentTurn.addEffect(new AttackEffect(this,750));                    
                }
            },
            new Spell(EffectType.Buff, "Bloodlust Bullet", 3, 4, "Reduce Atk by 15%, +40% def pierce, opponent heals 30% less") {
                @Override
                void apply() {
                    Turn current = game.currentTurn;
                    for (int i = 0; i<3; i++) {
                        current.addEffect(new MultiplierEffect(this, EffectType.Attack, 0.85, true));
                        current.addEffect(new MultiplierEffect(this, EffectType.Pierce, 1.40, true));
                        current.addEffect(new MultiplierEffect(this, EffectType.Healing, 0.70, false));
                        current = current.next;
                    }
                }
            },
        };
    }
    
    Spell get(String spellName) {
        for (int i=0; i<spells.length; i++) {
            if (spells[i].name.equalsIgnoreCase(spellName)) {
                return spells[i];
            }
        }
        return null;
    }
    
    void sort(String by) {
        if (by.equalsIgnoreCase("Cooldown")) {
            
        } else if (by.equalsIgnoreCase("Duration")) {
            
        } else {
            
        }
    }
    
    void display() {
        System.out.println("------------------------------------------------------------------------------------------");
        System.out.println("GRIMOIRE LEGACY SPELLS:");
        System.out.println("------------------------------------------------------------------------------------------");
        System.out.println("SPELL SET 1\n");
        for (int i=0; i<spells.length; i++) {
            if (i>0 && i%5 == 0) {
                System.out.println("------------------------------------------------------------------------------------------");
                System.out.println("SPELL SET "+(1+i/5)+"\n");
            }
            Spell spell = spells[i];
            spell.display();
            System.out.println();
        }
        System.out.println("------------------------------------------------------------------------------------------");
    }
    
    void display(String[] spellTypes) {
        System.out.println("------------------------------------------------------------------------------------------");
        int c = 0;
        for (int i=0; i<spells.length; i++) {
            int pass = 0;
            for (String spellType : spellTypes) {
                if (spellType.equalsIgnoreCase("passive")) {
                    if (spells[i].initial_cooldown != 0) {
                        pass++;
                    }
                    continue;
                }
                if (!spellType.equalsIgnoreCase(spells[i].spellType+"")) {
                    pass++;
                }
            }
            if (pass == spellTypes.length) {
                continue;
            }
            if (c>0 && c%5 == 0) {
                System.out.println("------------------------------------------------------------------------------------------\n");
            }
            Spell spell = spells[i];
            spell.display();
            System.out.println();
            c++;
        }
        System.out.println("------------------------------------------------------------------------------------------");
    }
    
    static Grimoire test() {
        Game game = new Game();
        Grimoire grimoire = new Grimoire(game);
        return grimoire;
    }
}