import java.util.Scanner;

class Menu {
    String choice;
    Option pointer;
    
    class Option {
        String value;
        Option next;
        
        Option(String value) {
            this.value = value;
            next = null;
        }
        
        void display() {
            System.out.println(value);
        }
    }
    
    Menu() {
        pointer = null;
        choice = "";
    }
    
    void add(String option) {
        Option New = new Option(option);
        if (pointer == null) {
            pointer = New;
            return;
        }
        
        Option current = pointer;
        while (current.next != null) {
            current = current.next;
        }
        current.next = New;
    }
    
    void display() {
        if (pointer == null) {
            return;
        }
        
        System.out.println();
        
        Option current = pointer;
        while (current != null) {
            current.display();
            current = current.next;
        }
    }
    
    void getInput() {
        display();      
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter your choice: ");
        choice = sc.next();
    }
    
    void validate(String... choices) {
        if (pointer == null) {
            return;
        }
        
        boolean found = false;
        for (String choice : choices) {
            if (this.choice.equals(choice)) {
                found = true;
                break;
            }
        }
        
        if (!found) {
            getInput();
            validate(choices);
        }
    }
}