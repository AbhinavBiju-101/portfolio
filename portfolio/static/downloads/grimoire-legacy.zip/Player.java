import java.util.Scanner;

class Player {
    String name;
    Player opponent;
    int hp;
    Def def;
    Spell[] loadout;
    Grimoire grimoire;
    Game game;
    boolean skipTurn;
    
    Player(Game game, String name) {
        hp = 1000;
        def = null;
        grimoire = new Grimoire(game);
        this.game = game;
        this.name = name;
        skipTurn = false;
    }
    
    Player Clone() {
        Player clone = new Player(game, name);
        String[] currentLoadout = getLoadout();
        clone.loadout = new Spell[5];
        for (int i=0; i<5; i++) {
            clone.loadout[i] = clone.grimoire.get(currentLoadout[i]);
            clone.loadout[i].caster = clone;
        }
        return clone;
    }
    
    void setLoadout() {
        Scanner sc = new Scanner(System.in);
        loadout = new Spell[5];
        System.out.println("Enter Player ("+ name +")'s loadout: ");
        for (int i=0; i<5; i++) {
            System.out.print((i+1)+". ");
            String spellName = sc.nextLine();
            while (grimoire.get(spellName) == null) {
                System.out.println("Not found!");
                System.out.print((i+1)+". ");
                spellName = sc.nextLine();
            }
            loadout[i] = grimoire.get(spellName);
            loadout[i].caster = this;
        }
        sc.close();
    }
    
    String[] getLoadout() {
        String[] loadout = new String[5];
        for (int i=0; i<5; i++) {
            loadout[i] = this.loadout[i].name;
        }
        return loadout;
    }
    
    void dealDamage(int damage) {
        if (damage == 0) {
            return;
        }
        if (def == null) {
            heal(-damage);
            return;
        }
        
        Def current = def;
        while (current.next != null) {
            current = current.next; // To find last link
        }
        
        if (current.value > damage) {
            current.value -= damage;
            if (game.A == this) {
                game.currentTurn.row.addLeft("-"+damage,2);
            } else {
                game.currentTurn.row.addRight("-"+damage,5);
            }
        } else{
            if (current == def) {
                def = null;
                dealDamage(damage-current.value);
                if (game.A == this) {
                    game.currentTurn.row.addLeft("-"+current.value,2);
                } else {
                    game.currentTurn.row.addRight("-"+current.value,5);
                }
                return;
            }
            
            Def prev = def;
            while (prev.next != current) {
                prev = prev.next;
            }
            prev.next = null;
            if (game.A == this) {
                game.currentTurn.row.addLeft("-"+current.value,2);
            } else {
                game.currentTurn.row.addRight("-"+current.value,5);
            }
            dealDamage(damage-current.value);
        }
    }
    void heal(int hp) {
        this.hp += hp;
        if (game.A == this) {
            game.currentTurn.row.addLeft((hp>0? "+":"")+hp,3);
        } else {
            game.currentTurn.row.addRight((hp>0? "+":"")+hp,4);
        }
    }
    void applyDef(int value, int duration) {
        Def New = new Def(value, duration);
        if (def == null) {
            def = New;
            if (game.A == this) {
                game.currentTurn.row.addLeft("+"+value,2);
            } else {
                game.currentTurn.row.addRight("+"+value,5);
            }
            return;
        }
        
        Def current = def;
        while (current != null) {
            if (current.duration < New.duration) {
                if (current == def) {
                    New.next = current;
                    def = New;
                    if (game.A == this) {
                        game.currentTurn.row.addLeft("+"+value,2);
                    } else {
                        game.currentTurn.row.addRight("+"+value,5);
                    }
                    return;
                }
                
                Def prev = def;
                while (prev.next != current) {
                    prev = prev.next;
                }
                prev.next = New;
                New.next = current;
                if (game.A == this) {
                    game.currentTurn.row.addLeft("+"+value,2);
                } else {
                    game.currentTurn.row.addRight("+"+value,5);
                }
                return;
            }
            if (current.next == null) {
                current.next = New;
                if (game.A == this) {
                    game.currentTurn.row.addLeft("+"+value,2);
                } else {
                    game.currentTurn.row.addRight("+"+value,5);
                }
                return;
            }
            current = current.next;
        }
    }
    int defSum(){
        if (def == null) {
            return 0;
        }
        
        Def current = def;
        int sum = 0;
        while (current != null) {
            sum += current.value;
            current = current.next;
        }
        
        return sum;
    }
    
    void cast(int slot) {
        if (slot < 0) return;
        if (!canCast() && loadout[slot].initial_cooldown != 0) return;
        loadout[slot].cast();
    }
    
    boolean canCast() {
        if (skipTurn) return false;
        boolean check = false;
        for (int i=0; i<5; i++) {
            if (loadout[i].initial_cooldown == 0) continue;
            if (loadout[i].cooldown == 0) check = true;
        }
        return check;
    }
    
    void reduceCooldown() {
        for (int i=0; i<5; i++) {
            loadout[i].reduceCooldown();
        }
        
        if (def == null) {
            return;
        }
        
        Def current = def;
        while (current != null) {
            current.duration--;
            if (current.duration <= 0) {
                if (current == def) {
                    def = null;
                    if (game.A == this) {
                        game.currentTurn.row.addLeft("-"+current.value,2);
                    } else {
                        game.currentTurn.row.addRight("-"+current.value,5);
                    }
                    return;
                }
                
                Def prev = def;
                while (prev.next != current) {
                    prev = prev.next;
                }
                prev.next = null;
                if (game.A == this) {
                    game.currentTurn.row.addLeft("-"+current.value,2);
                } else {
                    game.currentTurn.row.addRight("-"+current.value,5);
                }
                return;
            }
            current = current.next;
        }
    }
    
    Player getOpponent() {
        return opponent;
    }
}

