# Grimoire: Legacy

A turn-based spell combat simulator with 150+ unique spells, complex effect
interactions, and strategic depth. Originally designed as a pen-and-paper
game, later built into a full Java simulator to handle the calculations,
effect tracking, and turn management automatically.

## How to run

```bash
javac *.java
java Game
```

You'll get a menu to view the full spell grimoire, duel another player
locally (PVP), or fight one of 30+ preset AI enemies.

## Files

- `Grimoire.java` — spell definitions
- `Game.java` — core game engine and turn management
- `Player.java` — player state and spell loadout
- `Enemy.java` — AI opponent definitions
- `Turn.java` — turn queue and effect resolution
- `Effect.java` — effect types and application logic
- `Spell.java` — base spell class
- `Menu.java`, `Row.java`, `Def.java` — supporting UI/utility classes

Built by Abhinav Biju — Grade 12 (2024–2025). From pen-and-paper concept to
a fully automated combat simulator.
