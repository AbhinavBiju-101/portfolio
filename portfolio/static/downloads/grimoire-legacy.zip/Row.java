
class Row {
    int size;
    int columns;
    char[] chars;
    Row sub;
    
    Row(int columns, int columnSize) {
        size = columns*columnSize;
        this.columns = columns;
        sub = null;
        
        chars = new char[size];
        for (int i=0; i<size; i++) {
            chars[i] = ' ';
        }
    }
    
    void display() {
        for (char ch : chars) {
            System.out.print(ch+"");
        }
        System.out.println();
        
        if (sub != null) {
            sub.display();  
        }
    }
    
    boolean isEmpty(int column) {
        int columnSize = size/columns;
        for (int i=(column*columnSize); i<(column+1)*columnSize; i++) {
            if (chars[i] != ' ') {
                return false;
            }
        }
        return true;
    }
    
    void addLeft(String word, int column) {
        word = word.trim();
        int columnSize = size/columns;
        if (!isEmpty(column)){
            if (sub != null) {
                sub.addLeft(word,column);
                return;
            }
            Row row = new Row(columns,columnSize);
            row.addLeft(word,column);
            sub = row;
            return;
        }
        for (int i=0; i<word.length(); i++) {
            if ((column*columnSize+i) == (column+1)*columnSize) {
                if (word.charAt(i-1) != ' ' && word.charAt(i) != ' '){
                    while (word.charAt(i-1) != ' ') {
                        i--;
                        chars[column*columnSize+i] = ' ';
                        if (i-1<0){
                            for (;i<columnSize;i++) {
                                chars[column*columnSize+i] = word.charAt(i);
                            }
                            break;
                        }
                    }
                }
                if (sub != null) {
                    sub.addLeft(word.substring(i), column);
                    return;
                }
                Row row = new Row(columns, columnSize);
                row.addLeft(word.substring(i), column);
                sub = row;
                return;
            }
            
            chars[column*columnSize+i] = word.charAt(i);
        }
    }
    
    void addRight(String word, int column) {
        word = word.trim();
        int columnSize = size/columns;
        int start = (column+1)*columnSize - word.length();
        start = word.length()>columnSize ? column*columnSize: start;
        if (!isEmpty(column)){
            if (sub != null) {
                sub.addRight(word,column);
                return;
            }
            Row row = new Row(columns,columnSize);
            row.addRight(word,column);
            sub = row;
            return;
        }
        for (int i=0; i<word.length(); i++) {
            if ((start+i) == start+columnSize) {
                if (word.charAt(i-1) != ' ' && word.charAt(i) != ' '){
                    while (word.charAt(i-1) != ' ') {
                        i--;
                        chars[column*columnSize+i] = ' ';
                        if (i-1<0){
                            for (;i<columnSize;i++) {
                                chars[column*columnSize+i] = word.charAt(i);
                            }
                            break;
                        }
                    }
                    String remaining = "";
                    for (int j=0; j<i; j++) {
                        remaining += word.charAt(j);
                        chars[column*columnSize+j] = ' ';
                    }
                    remaining = remaining.trim();
                    if (remaining.length()>0){
                        for (int j = columnSize-remaining.length();j<columnSize; j++) {
                            chars[column*columnSize+j] = remaining.charAt(j-(columnSize-remaining.length()));
                        }
                    }
                }
                if (sub != null) {
                    sub.addRight(word.substring(i), column);
                    return;
                }
                Row row = new Row(columns, columnSize);
                row.addRight(word.substring(i), column);
                sub = row;
                return;
            }
            
            char ch = word.charAt(i);
            chars[start+i] = ch;
        }
    }    
    
    public static void main() {
        Row test = new Row(4,10);
        test.addLeft("this is a simple sentance.",0);
        test.addLeft("this is a much longer sentance, to test how far it can actually go before reaching the limit.",1);
        test.addLeft("this is a long-word-abomination-linked-together to see if it breaks.",2);
        test.addLeft("this is half a sentance,",3);
        test.addLeft("while this is the other half.",3);
        test.display();
        
        test = new Row(4,10);
        test.addRight("this is a simple sentance.",0);
        test.addRight("this is a much longer sentance, to test how far it can actually go before reaching the limit.",1);
        test.addRight("this is a long-word-abomination-linked-together to see if it breaks.",2);
        test.addRight("this is half a sentance,",3);
        test.addRight("while this is the other half.",3);
        test.display();
    }
}