
abstract class Spell {
    String name;
    Player caster;
    int initial_cooldown;
    int cooldown;
    int duration;
    String description;
    EffectType spellType;
    
    Spell(EffectType spellType, String name, int duration, int initial_cooldown, String description) {
        this.spellType = spellType;
        this.name = name;
        this.initial_cooldown = initial_cooldown;
        this.duration = duration;
        this.description = description;
        cooldown = 0;
    }
    
    abstract void apply();
    
    void cast() {
        cooldown = initial_cooldown;
        apply();
    }
    
    void reduceCooldown(){
        if (cooldown > 0) {
            cooldown--;
        }
    }
    
    void display() {
        Row row = new Row(4,20);
        row.addLeft(spellType+"",0);
        row.addLeft(name,1);
        row.addLeft(description,2);
        row.addRight(duration+" D, "+initial_cooldown+" CD",3);
        row.display();
    }
}