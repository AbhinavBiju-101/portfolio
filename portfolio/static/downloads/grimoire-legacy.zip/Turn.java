
class Turn {
    Turn next;
    Effect pointer;
    int turnNumber;
    Row row;

    Turn(int turnNumber) {
        this.turnNumber = turnNumber;
        pointer = null;
        
        row = new Row(8,10);
        row.addLeft(turnNumber+". ",0);
        row.addRight(" ."+turnNumber,7);
    }

    void addEffect(Effect e){
        if (pointer == null) {
            pointer = e;
            return;
        }

        Effect current = pointer;
        while (current != null) {
            if (current.priority < e.priority) {
                if (current == pointer) {
                    e.next = current;
                    pointer = e;
                    return;
                } 
                Effect prev = getPrevious(current);
                prev.next = e;
                e.next = current;
                return;
            }
            if (current.next == null) {
                current.next = e;
                return;
            }
            current = current.next;
        }
    }
    
    Effect getPrevious(Effect e) {
        if (pointer == null) {
            return null;
        }
        if (pointer.next == null) {
            return null;
        }
        
        Effect current = pointer;
        while (current.next != e) {
            current = current.next;
        }
        return current;
    }

    void applyEffects(){
        if (pointer == null) {
            return;
        }

        Effect current = pointer;
        while (current != null) {
            current.apply();
            current = current.next;
        }
    }
    
    void display() {
        row.display();
    }
}