from search_suggestion import SearchSuggestion
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtWebEngineWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtNetwork import *
from PyQt5.QtMultimediaWidgets import *
from PyQt5.QtMultimedia import *

Domains = ['.com','.org','.to','.gov','.in','.net','.edu','.int','.io','.biz','.co','.me','.store','.app','.mit']

def stripURL(text, type):
    if 'http' not in text:
        if 'www.' not in text:
            if '://' in text:
                if not 'file:///' in text:
                    text = QUrl.fromLocalFile(text)
                else:
                    text = QUrl(text)
            else:
                if any([i in text for i in Domains]):
                    text = 'https://www.'+text
                else:
                    if text.strip() == '':
                        text = 'https://www.google.com'
                    else:
                        text = 'https://www.google.com/search?q=' + text
                text = QUrl(text)
        else:
            # If the text contains a dot but not 'http', treat it as a URL
            text = 'https://' + text
            text = QUrl(text)
    else:
        text = QUrl(text)
    
    if type == str:
        return text.toString()
    elif type == QUrl:
        return text
    
def stripURLdomain(url):
    text = stripURL(url,str)
    if 'file:///' in text:
        return 'File'
    else:
        text = text.split('://')[1]
        while any(i in text for i in Domains):
            text = text[:text.index([i for i in Domains if i in text][0])]
        if 'www.' in text:
            text = text[4:]
        
    text = f'{text[0].upper()}{text[1:]}' # Capitalize first letter
    
    return text

class AnimatedButton(QToolButton):
    def __init__(self, text, start_color, end_color, click_color, duration_ms, parent=None, menu_indicator = False):
        super().__init__(parent)
        self.setText(text)
        self._color = QColor(start_color)
        if menu_indicator:
            self.setPopupMode(QToolButton.MenuButtonPopup)

        self.start_color = start_color
        self.end_color = end_color
        self.click_color = click_color
        self.duration = duration_ms

        self.anim = QPropertyAnimation(self, b'color', self)
        self.anim.setDuration(duration_ms)
        self.anim.setStartValue(QColor(self.start_color))
        self.anim.setEndValue(QColor(self.end_color))
        
        self.clicked.connect(self.clickEvent)

    def enterEvent(self, event):
        self.anim.setStartValue(QColor(self.start_color))
        self.anim.setEndValue(QColor(self.end_color))
        self.anim.setDirection(QPropertyAnimation.Forward)
        self.anim.setDuration(self.duration)
        self.anim.start()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.anim.setStartValue(QColor(self.start_color))
        self.anim.setEndValue(QColor(self.end_color))
        self.anim.setDirection(QPropertyAnimation.Backward)
        self.anim.setDuration(self.duration)
        self.anim.start()
        super().leaveEvent(event)

    def clickEvent(self):
        self.anim.setStartValue(QColor(self.end_color))
        self.anim.setEndValue(QColor(self.click_color))
        self.anim.setDirection(QPropertyAnimation.Forward)
        self.anim.setDuration(self.duration//2)
        back = QPropertyAnimation(self, b'color', self)
        back.setStartValue(QColor(self.end_color))
        back.setEndValue(QColor(self.click_color))
        back.setDirection(QPropertyAnimation.Backward)
        back.setDuration(self.duration//2)
        self.anim.start()
        back.start()

    def recolor(self, start_color, end_color, click_color):
        self.start_color = start_color
        self.end_color = end_color
        self.click_color = click_color

    @pyqtProperty(QColor)
    def color(self):
        return self._color

    @color.setter
    def color(self, color):
        self._color = color
        self.setStyleSheet(f'QToolButton {{background-color: {self._color.name()};}} QToolButton::menu-indicator {{ image: none;}}')

class AnimatedMenuButton(AnimatedButton):
    def __init__(self, text, start_color, end_color, duration_ms, parent=None):
        super().__init__(text, start_color, end_color, duration_ms, parent)

    def mousePressEvent(self, event):
        super().mousePressEvent(event)
        if self.menu():
            self.showMenu()

class MyCompleter(QCompleter):
    def __init__(self, parent=None):
        super(MyCompleter, self).__init__(parent)

    def splitPath(self, path):
        return ['']

    def pathFromIndex(self, index):
        return index.data()

class MyLineEdit(QLineEdit):
    def __init__(self, main_window, parent=None):
        super(MyLineEdit, self).__init__(parent)
        self.main_window = main_window

        # Create a QToolBar inside the QLineEdit
        self.toolbar = QToolBar(self)
        #clr = self.palette().color(QPalette.Base).name()
        #self.toolbar.setStyleSheet("QToolBar { border: 0px; background-color: %s;} QAction {background-color: %s;}" % (clr,clr))  # Remove the toolbar border
        self.toolbar.setStyleSheet("QToolBar { border: 0px; background-color: transparent;} QAction {background-color: transparent;} QAction:hover {background-color: tomato}")

        # Create the Zoom In action
        self.zoom_in_action = QAction("+", self)
        self.zoom_in_action.triggered.connect(self.main_window.zoom_in)
        self.zoom_in_action.triggered.connect(self.main_window.show_zoom_widget)
        self.toolbar.addAction(self.zoom_in_action)

        # Create the Zoom Out action
        self.zoom_out_action = QAction("-", self)
        self.zoom_out_action.triggered.connect(self.main_window.zoom_out)
        self.zoom_out_action.triggered.connect(self.main_window.show_zoom_widget)
        self.toolbar.addAction(self.zoom_out_action)

        # Position the toolbar at the right end of the QLineEdit
        self.setStyleSheet(self.styleSheet()+"padding-right: %dpx;" % self.toolbar.sizeHint().width())
        self.toolbar.move(self.rect().right() - self.toolbar.sizeHint().width(), 0)

        # Access bookmarks and history from the parent (MainWindow)
        self.bookmarks = self.main_window.bookmarks
        self.history = [entry[0] for entry in self.main_window.history] if not self.main_window.history == [()] else []

        self.completer = MyCompleter(self)
        self.setCompleter(self.completer)
        self.completer.highlighted.connect(self.on_completer_highlighted)
        self.tempText = ''
        
        self.textChanged.connect(self.update_completer)
        self.textChanged.connect(self.update_tempText)

    def update_styles(self):
        self.setStyleSheet(self.styleSheet()[:len(self.styleSheet())-1]+"padding-right: %dpx;}" % self.toolbar.sizeHint().width())

    def resizeEvent(self, event):
        # Update the position of the toolbar when the QLineEdit is resized
        self.toolbar.move(self.rect().right() - 47, 0)
        
        # Move the widget when resizing browser
        widget = self.toolbar.widgetForAction(self.zoom_in_action)
        pos = widget.mapToGlobal(widget.rect().bottomLeft())
        pos.setX(int(pos.x() + widget.width() / 2 - self.main_window.zoom_widget.width() / 2))
        self.main_window.zoom_widget.move(pos)
        
        super(MyLineEdit, self).resizeEvent(event)
    
    def update_tempText(self, text):
        self.tempText = self.text()

    def focusInEvent(self, event):
        self.tempText = self.text()
        super(MyLineEdit, self).focusInEvent(event)

    def on_completer_highlighted(self, text):
        self.tempText = text

    def keyPressEvent(self, event):
        if self.tempText not in [f'{"—"*10}{i}{"—"*10}' for i in ['Bookmarks', 'Suggestions', 'History']]:
            if event.key() == Qt.Key_Return or event.key() == Qt.Key_Enter:
                if self.tempText == '':
                    self.setText(self.text())
                    self.clearFocus()
                    self.main_window.add_tab(self.text())
                else:
                    self.setText(self.tempText)
                    self.clearFocus()
                    self.main_window.add_tab(self.tempText,sametab = True)
            else:
                super(MyLineEdit, self).keyPressEvent(event)
        else:
            self.clear()
            self.tempText = ''

    def on_completer_activated(self, text):
        if text not in [f'{"—"*10}{i}{"—"*10}' for i in ['Bookmarks', 'Suggestions', 'History']]:
            self.setText(text)
            #self.clearFocus()
            self.main_window.add_tab(text,sametab = True)
        else:
            self.clear()

    def update_completer(self,text):
        general_suggestions = set(self.main_window.ss.search(text))
        bookmark_suggestions = []
        history_suggestions = []

        # Separate loop for bookmarks
        for url in self.bookmarks.values():
            without = stripURL(url,str)
            if text in without:
                bookmark_suggestions.append(without)

        # Separate loop for history
        for url in self.history:
            without = stripURL(url,str)
            if text in without:
                history_suggestions.append(without)

        history_suggestions = list(set(history_suggestions))
        general_suggestions = list(general_suggestions)

        bookmark_suggestions = [f'{"—"*10}Bookmarks{"—"*10}'] + bookmark_suggestions if not bookmark_suggestions == [] else []
        history_suggestions = [f'{"—"*10}History{"—"*10}'] + history_suggestions if not history_suggestions == [] else []

        if  list(general_suggestions) + bookmark_suggestions + history_suggestions == []:
            all_suggestions = []
        else:
            all_suggestions = general_suggestions + bookmark_suggestions + history_suggestions

        self.completer.setModel(QStringListModel(all_suggestions))

    def match_input(self, input):
        matched_urls = []
        for url in self.history + list(self.bookmarks.values()):
            #without = (url.split('https://www.')[1] if 'www.' in url else url.split('https://')[1]) if 'https://' in url else url.split('file:///')[1]
            without = stripURL(url,str)
            if input in without:
                matched_urls.append(without)
        return matched_urls

class HistoryLineEdit(QLineEdit):
    def __init__(self, table_widget, *args, **kwargs):
        super(HistoryLineEdit, self).__init__(*args, **kwargs)
        self.table_widget = table_widget
        self.textChanged.connect(self.filter)
    
    def filter(self):
        search_text = self.text().strip()
        for i in range(self.table_widget.rowCount()):
            domain_item = self.table_widget.item(i, 2)
            self.table_widget.setRowHidden(i, search_text not in domain_item.text().lower())

    def keyPressEvent(self, event):
        super(HistoryLineEdit, self).keyPressEvent(event)

        if event.key() == Qt.Key_Enter or event.key() == Qt.Key_Return:
            # If 'Enter' was pressed, clear the focus
            self.clearFocus()
            if self.text().strip() == '':
                self.setPlaceholderText("Search history...")

class CustomWebEngineView(QWebEngineView):
    def __init__(self, *args, **kwargs):
        super(CustomWebEngineView, self).__init__(*args, **kwargs)
        self.hovered_link = None
        self.network_manager = QNetworkAccessManager(self)
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.showContextMenu)
        self.page().linkHovered.connect(self.link_hovered)
        QWebEngineProfile.defaultProfile().downloadRequested.connect(self.on_download_requested)

    def link_hovered(self, url):
        self.hovered_link = url
        #print(url)
    
    def acceptNavigationRequest(self, url, _type, isMainFrame):
        if _type == QWebEnginePage.NavigationTypeLinkClicked:
            # Open the url in the same tab
            self.window().add_tab(url, sametab = True)
            return True
        return super().acceptNavigationRequest(url, _type, isMainFrame)

    def on_download_requested(self, download):
        old_path = download.path()
        suffix = QFileInfo(old_path).suffix()
        path, _ = QFileDialog.getSaveFileName(self, "Save File", old_path, "*."+suffix)
        if path:
            download.setPath(path)
            download.accept()

    def showContextMenu(self, pos):
        # Create a new QMenu
        context_menu = QMenu(self)

        # Add the default actions
        context_menu.addAction(self.pageAction(QWebEnginePage.Back))
        context_menu.addAction(self.pageAction(QWebEnginePage.Forward))
        context_menu.addAction(self.pageAction(QWebEnginePage.Reload))

        # Add a separator
        context_menu.addSeparator()

        # Add your custom actions
        self.addCustomActions(context_menu)

        # Show the context menu
        context_menu.exec_(self.mapToGlobal(pos))

    def addCustomActions(self, context_menu):
        # Check if the user right-clicked on a link
        if self.hovered_link:
            open_link_action = QAction('Open link in new tab', self)
            open_link_action.triggered.connect(self.open_link_in_new_tab)
            context_menu.addAction(open_link_action)

            open_link_in_new_window_action = QAction('Open link in new window', self)
            open_link_in_new_window_action.triggered.connect(self.open_link_in_new_window)
            context_menu.addAction(open_link_in_new_window_action)

            open_link_in_new_incognito_window_action = QAction('Open link in new incognito window', self)
            open_link_in_new_incognito_window_action.triggered.connect(self.open_link_in_new_incognito_window)
            context_menu.addAction(open_link_in_new_incognito_window_action)


            context_menu.addSeparator()

            save_link_action = QAction('Save link', self)
            save_link_action.triggered.connect(self.save_link)
            context_menu.addAction(save_link_action)

            copy_link_address_action = QAction('Copy link address', self)
            copy_link_address_action.triggered.connect(self.copy_link_address)
            context_menu.addAction(copy_link_address_action)

        # Check if the user right-clicked on an image
        if self.page().contextMenuData().mediaType() == QWebEngineContextMenuData.MediaTypeImage:
            # Add a separator
            context_menu.addSeparator()

            save_image_action = QAction('Save image', self)
            save_image_action.triggered.connect(self.save_image)
            context_menu.addAction(save_image_action)

            copy_image_address_action = QAction('Copy image address', self)
            copy_image_address_action.triggered.connect(self.copy_image_address)
            context_menu.addAction(copy_image_address_action)

            copy_image_action = QAction('Copy image', self)
            copy_image_action.triggered.connect(self.copy_image)
            context_menu.addAction(copy_image_action)

        if self.page().hasSelection():
            context_menu.addSeparator()

            copy_text_action = QAction('Copy Text', self)
            copy_text_action.triggered.connect(self.copy_text)
            context_menu.addAction(copy_text_action)

            translate_text_action = QAction('Translate Text', self)
            translate_text_action.triggered.connect(self.translate_text)
            context_menu.addAction(translate_text_action)

        '''if self.hovered_link.lower().endswith(('.mp4', '.avi', '.flv', '.wmv', '.mov')):
	        context_menu.addSeparator()
            # If the URL is a video file, add a custom action to the context menu
            play_video_action = QAction('Play video in external player', self)
            play_video_action.triggered.connect(lambda: QDesktopServices.openUrl(QUrl(self.hovered_link))) 
            context_menu.addAction(play_video_action)'''

        # Add a separator
        context_menu.addSeparator()

        # Add the 'View page source' action
        view_page_source_action = QAction('View page source', self)
        view_page_source_action.triggered.connect(self.view_page_source)
        context_menu.addAction(view_page_source_action)

    def copy_text(self):
        self.page().triggerAction(QWebEnginePage.Copy)

    def translate_text(self):
        selected_text = self.page().selectedText()
        url = f"https://translate.google.com/?sl=auto&tl=en&text={selected_text}&op=translate"
        self.window().add_tab(url)

    def open_link_in_new_tab(self):
        if self.hovered_link:
            self.window().add_tab(self.hovered_link)

    def open_link_in_new_incognito_window(self):
        if self.hovered_link:
            self.incognito_window = self.window().open_incognito_window()  # Use the method you defined earlier
            self.incognito_window.add_tab(self.hovered_link)

    def open_link_in_new_window(self):
        if self.hovered_link:
            self.new_window = MainWindow()
            self.new_window.add_tab(self.hovered_link)
            self.new_window.show()

    def save_link(self):
        fileName, _ = QFileDialog.getSaveFileName(self, "Save Link", "download", "All Files (*);;Text Files (*.txt)")
        if fileName:
            self.page().download(QUrl(self.hovered_link), fileName)

    def copy_link_address(self):
        QApplication.clipboard().setText(self.hovered_link)

    def save_image(self):
        fileName, _ = QFileDialog.getSaveFileName(self, "Save Image", "download", "Images (*.png *.xpm *.jpg);;All Files (*)")
        if fileName:
            self.page().download(QUrl(self.page().contextMenuData().mediaUrl().toString()), fileName)

    def copy_image_address(self):
        QApplication.clipboard().setText(self.page().contextMenuData().mediaUrl().toString())

    def copy_image(self):
        url = self.page().contextMenuData().mediaUrl()
        request = QNetworkRequest(url)
        reply = self.network_manager.get(request)
        reply.finished.connect(lambda: self.copy_image_to_clipboard(reply))

    def copy_image_to_clipboard(self, reply):
        img_data = reply.readAll()
        image = QImage.fromData(img_data)
        pixmap = QPixmap.fromImage(image)
        QApplication.clipboard().setPixmap(pixmap)

    def view_page_source(self):
        self.page().toHtml(self.display_source_in_dialog)

    def display_source_in_dialog(self, source):
        dialog = QDialog(self)
        dialog.setWindowTitle("Page Source")
        dialog.setWindowModality(Qt.ApplicationModal)
        dialog.resize(self.width() * 1, self.height() * 1)
        dialog.setWindowFlags(Qt.Dialog | Qt.WindowCloseButtonHint)

        layout = QVBoxLayout(dialog)
        text_edit = QTextEdit(dialog)
        text_edit.setPlainText(source)
        text_edit.setReadOnly(True)
        layout.addWidget(text_edit)

        dialog.setLayout(layout)
        dialog.exec_()

class MySlider(QSlider):
    def __init__(self, *args, **kwargs):
        super(MySlider, self).__init__(*args, **kwargs)
        self.setMouseTracking(True)
        self.installEventFilter(self)

    def eventFilter(self, source, event):
        if event.type() == QEvent.HoverMove:
            pos = event.pos()
            value = self.valueFromPosition(pos.x())
            QToolTip.showText(self.mapToGlobal(pos), str(value)+'%')
        return super(MySlider, self).eventFilter(source, event)

    def valueFromPosition(self, x):
        opt = QStyleOptionSlider()
        self.initStyleOption(opt)
        gr = self.style().subControlRect(QStyle.CC_Slider, opt, QStyle.SC_SliderGroove, self)
        sr = self.style().subControlRect(QStyle.CC_Slider, opt, QStyle.SC_SliderHandle, self)
        if self.orientation() == Qt.Horizontal:
            sliderLength = sr.width()
            sliderMin = gr.x()
            sliderMax = gr.right() - sliderLength + 1
        else:
            sliderLength = sr.height()
            sliderMin = gr.y()
            sliderMax = gr.bottom() - sliderLength + 1
        pr = int(x - sliderLength / 2 - sliderMin)
        value = QStyle.sliderValueFromPosition(self.minimum(), self.maximum(), pr, sliderMax - sliderMin,
                                               opt.upsideDown)
        return value
    
    def sliderChange(self, change):
        super(MySlider, self).sliderChange(change)
        if change == QSlider.SliderValueChange:
            QToolTip.showText(self.mapToGlobal(self.pos()), str(self.value())+'%')
    
class ZoomWidget(QWidget):
    def __init__(self, parent=None):
        super(ZoomWidget, self).__init__(parent)
        self.setWindowFlags(Qt.Tool | Qt.FramelessWindowHint)

        toolbar = QToolBar(self)  # Use QToolBar instead of QVBoxLayout

        # Replace 'Reset' with a Unicode symbol, for example U+21BA for anticlockwise open circle arrow
        reset_action = QAction(u"\u21BA", self)  
        reset_action.triggered.connect(self.reset_zoom)
        toolbar.addAction(reset_action)

        plus_action = QAction("+", self)
        plus_action.triggered.connect(self.zoom_in)
        toolbar.addAction(plus_action)

        # Assign zoom_slider to self
        self.zoom_slider = MySlider(Qt.Orientation.Horizontal, self)
        self.zoom_slider.setMinimum(50)
        self.zoom_slider.setMaximum(200)
        self.zoom_slider.setValue(100)
        self.zoom_slider.valueChanged.connect(self.set_zoom)
        toolbar.addWidget(self.zoom_slider)

        minus_action = QAction("-", self)
        minus_action.triggered.connect(self.zoom_out)
        toolbar.addAction(minus_action)

        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.timeout.connect(self.hide)

        self.show()
        self.hide()

    def showEvent(self, event):
        self.timer.start(3000)

    def enterEvent(self, event):
        self.timer.stop()

    def leaveEvent(self, event):
        self.timer.start(3000)

    def zoom_in(self):
        # Get the current zoom level from the slider
        current_zoom = self.zoom_slider.value()
        # Increase the zoom level by 10
        new_zoom = current_zoom + 10
        # Set the new zoom level
        self.zoom_slider.setValue(new_zoom)

    def zoom_out(self):
        # Get the current zoom level from the slider
        current_zoom = self.zoom_slider.value()
        # Decrease the zoom level by 10
        new_zoom = current_zoom - 10
        # Set the new zoom level
        self.zoom_slider.setValue(new_zoom)

    def reset_zoom(self):
        # Reset the zoom level to 100
        self.zoom_slider.setValue(100)

    def set_zoom(self, value):
        self.parent().setZoomLevel(value)

class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()  # Set window properties
        self.setWindowTitle('Navigo')
        self.setWindowIcon(QIcon('OIGA.png'))

        with open('search_queries.txt', 'r',encoding='utf-8') as file:
            queries = file.read().splitlines()

        #print('Queries'+'-'*30)
        #print(queries)

        self.ss = SearchSuggestion()
        self.ss.batch_insert(queries)

        # Create toolbar
        self.toolbar = QToolBar()
        toolbar = self.toolbar
        toolbar.setStyleSheet("QToolBar { background-color: #B0B0B0; } QToolButton:hover {background-color: #B0B0B0;}")  # Change the background color to grey

        # Create a bookmark toolbar
        self.bookmark_toolbar = QToolBar()
        self.bookmark_toolbar.setStyleSheet("QToolBar { background-color: Orange; padding-left:5px; } QToolButton:hover {background-color:#e69500;}") # Change the background color to Olive

        # Add a label to the bookmark toolbar
        bookmark_label = QLabel("Bookmarks:")
        bookmark_label.setStyleSheet("background-color:transparent")

        # Create a QWidgetAction and set the QLabel as its default widget
        bookmark_label_action = QWidgetAction(self)
        bookmark_label_action.setDefaultWidget(bookmark_label)

        # Add the QWidgetAction to the bookmark toolbar
        self.bookmark_toolbar.addAction(bookmark_label_action)

        # Create tab widget
        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.setElideMode(Qt.ElideNone)
        self.tabs.setDocumentMode(True)
        self.tabs.setStyleSheet("QTabWidget::tab-bar { border-radius: 4px; } QPushButton {background-color:#D0D0D0} QPushButton:hover {background-color:#E0E0E0}")  # Make tabs have rounded edges

        add_tab_btn = QPushButton('Add new tab', self)
        add_tab_btn.clicked.connect(lambda checked = False,url='https://google.com': self.add_tab(url))
        #add_tab_btn.setFixedSize(25, 25)  # Set fixed size for the add button
        self.tabs.setCornerWidget(add_tab_btn, Qt.TopLeftCorner)

        self.closed_tabs = []
        self.history = []
        self.bookmarks = {}
        self.read_files()   

        self.incognito = False
        
        if self.bookmarks != {}:
            for title in self.bookmarks.keys():
                self.add_bookmark(title=title)

        # Create a QVBoxLayout
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)  # Set layout margins to zero

        # Create a QWidget and set it as the central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        central_widget.setLayout(layout)

        layout.addWidget(toolbar)  # Toolbar added first
        layout.addWidget(self.bookmark_toolbar)  # Then bookmark toolbar
        layout.addWidget(self.tabs)  # Finally tabs
        layout.setSpacing(0)

        # Add shortcuts
        QShortcut(QKeySequence("Ctrl+W"), self, self.close_tab)
        QShortcut(QKeySequence("Ctrl+T"), self, self.add_tab)
        QShortcut(QKeySequence("Ctrl+Shift+T"), self, self.reopen_tabs)
        QShortcut(QKeySequence("Ctrl+H"), self, self.view_history)
        QShortcut(QKeySequence("Ctrl+R"), self, self.reloadtab)
        QShortcut(QKeySequence("Alt+Left"), self, self.backtab)
        QShortcut(QKeySequence("Alt+Right"), self, self.forwardtab)
        QShortcut(QKeySequence("Ctrl+Shift+I"), self, self.view_page_source_current_tab)
        QShortcut(QKeySequence("Ctrl+E"), self, self.QlineEditSelect)
        QShortcut(QKeySequence("Ctrl+Shift++"), self, self.zoom_in)
        QShortcut(QKeySequence("Ctrl+Shift+-"), self, self.zoom_out)
        
        # Add navigation buttons        
        back_action = QAction('⮜')
        back_action.triggered.connect(lambda: self.current_browser().back())
        self.back_btn = AnimatedButton(back_action.text(), '#B0B0B0', '#C0C0C0', '#A0A0A0', 200)
        self.back_btn.setDefaultAction(back_action)
        self.back_btn.setFixedSize(QSize(25,23))
        toolbar.addWidget(self.back_btn)

        forward_action = QAction('⮞', self)
        forward_action.triggered.connect(lambda: self.current_browser().forward())
        self.forward_btn = AnimatedButton(forward_action.text(), '#B0B0B0', '#C0C0C0', '#A0A0A0', 200)
        self.forward_btn.setDefaultAction(forward_action)
        self.forward_btn.setFixedSize(QSize(25,23))
        toolbar.addWidget(self.forward_btn)

        reload_action = QAction('⟳', self)
        reload_action.triggered.connect(lambda: self.current_browser().reload())
        self.reload_btn = AnimatedButton(reload_action.text(), '#B0B0B0', '#C0C0C0', '#A0A0A0', 200)
        self.reload_btn.setDefaultAction(reload_action)
        self.reload_btn.setFixedSize(QSize(25,23))
        toolbar.addWidget(self.reload_btn)

        self.line_edit = MyLineEdit(self)  # Pass the MainWindow instance (self) to MyLineEdit
        self.line_edit.returnPressed.connect(self.handle_return_pressed)
        self.line_edit.setStyleSheet("QLineEdit { height: 20px; border-radius: 10px; padding-left:5px; }")
        self.tabs.currentChanged.connect(self.update_line_edit)

        # Add MyLineEdit to the main toolbar
        self.toolbar.addWidget(self.line_edit)

        # Create a QWidget for the zoom control
        self.zoom_widget = ZoomWidget(self)

        # Add bookmark button
        self.bookmark_action = QAction('⭐', self)
        self.bookmark_action.triggered.connect(self.add_bookmark)
        self.bookmark_btn = AnimatedButton(self.bookmark_action.text(), '#B0B0B0', '#C0C0C0', '#A0A0A0', 200)
        self.bookmark_btn.setDefaultAction(self.bookmark_action)
        self.bookmark_btn.setFixedSize(QSize(25,23))
        self.toolbar.addWidget(self.bookmark_btn)

        self.menu_btn = AnimatedMenuButton('⋮', '#B0B0B0', '#C0C0C0', '#A0A0A0', 200)
        self.setStyleSheet('QToolButton::menu-indicator { image: none;}')
        self.menu_btn.setFixedSize(QSize(25,23))
        menu = QMenu()
        menu.addAction('Open new window', self.open_new_window)
        menu.addAction('Open incognito window', self.open_incognito_window)
        self.menu_btn.setMenu(menu)
        toolbar.addWidget(self.menu_btn)

        self.incognito_icon = QIcon('OIGE.png')

        self.add_tab()
        self.current_browser().urlChanged.connect(self.update_url)  # Add first tab

    def setZoomLevel(self, value):
        # Convert the value from the slider (50-200) to a zoom factor (0.5-2.0)
        zoom_factor = value / 100.0
        # Set the zoom factor of the current browser or web view
        self.current_browser().setZoomFactor(zoom_factor)

    def zoom_in(self):
        current_browser = self.current_browser()
        current_browser.setZoomFactor(current_browser.zoomFactor() + 0.1)
        self.show_zoom_widget()

    def zoom_out(self):
        current_browser = self.current_browser()
        current_browser.setZoomFactor(current_browser.zoomFactor() - 0.1)
        self.show_zoom_widget()

    def show_zoom_widget(self):
        # Get the current zoom level of the page
        current_zoom = int(self.current_browser().zoomFactor() * 100)
        # Set the slider to the current zoom level
        self.zoom_widget.zoom_slider.setValue(current_zoom)

        if not self.zoom_widget.isVisible():
            # Find the widget associated with the "+" action
            zoom_in_widget = self.line_edit.toolbar.widgetForAction(self.line_edit.zoom_in_action)
            # Get the position of the "+" button
            pos = zoom_in_widget.mapToGlobal(zoom_in_widget.rect().bottomLeft())
            pos.setX(int(pos.x() + zoom_in_widget.width() / 2 - self.zoom_widget.width() / 2))
            self.zoom_widget.move(pos)
            self.zoom_widget.show()
        else:
            self.zoom_widget.timer.start(3000)

    def open_new_window(self):
        self.new_window = MainWindow()
        self.new_window.show()

    def open_incognito_window(self):
        self.incognito_profile = QWebEngineProfile()  # Create a new profile
        self.incognito_page = QWebEnginePage(self.incognito_profile, self)  # Create a new page with the new profile
        self.incognito_window = MainWindow()
        self.incognito_window.current_browser().setPage(self.incognito_page)  # Set the new page as the current page
        self.incognito_window.setWindowTitle("Incognito Window")  # Change the window title
        self.incognito_window.setStyleSheet("background-color: #2f3640; color: #f5f6fa;") # Change the color scheme (applies to the buttons, tab bar buttons, and bookmark buttons)
        self.incognito_window.add_tab('https://google.com',sametab=True)
        self.incognito_window.bookmark_toolbar.setStyleSheet("QToolBar { background-color: maroon; } QToolButton {background-color:transparent} QToolButton::hover {background-color:#800000}")
        self.incognito_window.showMaximized()
        self.incognito_window.tabs.setStyleSheet("QPushButton::hover {background-color:#3a424f;color:white;} QTabBar::tab:selected {background-color:#3a424f; color: white; } QTabBar::tab:!selected {background-color:#242a31;color:white;}QTabBar::tab:hover { background-color: #3a426f; color: white; }")
        self.incognito_action = QAction(self.incognito_icon, '', self)
        self.incognito_window.toolbar.setIconSize(QSize(18,18))
        self.incognito_window.toolbar.insertAction(self.incognito_window.bookmark_action, self.incognito_action)
        self.incognito_window.toolbar.setStyleSheet('background-color:#202020;')
        self.incognito_window.line_edit.setStyleSheet('QToolBar { border: 0px; background-color: transparent; border-radius:0px;} QToolButton {background-color:transparent;} QToolButton::hover {background-color:#505050} QLineEdit { background-color:#303030;height:20px;border-radius:10px;padding-left:5px;}')
        self.incognito_window.line_edit.update_styles()
        self.incognito_window.line_edit.completer.popup().setStyleSheet('background-color:#202020;color:white;')
        self.incognito_window.incognito = True

        self.incognito_window.back_btn.recolor('#202020', '#404040', '#101010')
        self.incognito_window.forward_btn.recolor('#202020', '#404040', '#101010')
        self.incognito_window.reload_btn.recolor('#202020', '#404040', '#101010')
        self.incognito_window.bookmark_btn.recolor('#202020', '#404040', '#101010')
        self.incognito_window.menu_btn.setStyleSheet('QToolButton::menu-indicator { image: none;}')
        self.incognito_window.menu_btn.recolor('#202020', '#404040', '#101010')
        
        return self.incognito_window

    def QlineEditSelect(self):
        self.line_edit.selectAll()
        self.line_edit.setFocus()

    def handle_return_pressed(self):
        text = self.line_edit.text()
        self.add_tab(text,sametab=True)
        self.line_edit.clearFocus()

    def view_page_source_current_tab(self):
        current_widget = self.tabs.currentWidget()
        if isinstance(current_widget,CustomWebEngineView):
            current_widget.view_page_source()

    def add_bookmark(self,checked=False,title=None):
        if title is None:
            current_tab = self.tabs.currentWidget()
            url = current_tab.url().toString()
            title = self.tabs.tabText(self.tabs.indexOf(current_tab))
            if len(title) > 20:
                title = f'{title[:17]}...'
            self.bookmarks[title] = url
            
        if len(title) > 20:
            title = f'{title[:17]}...'

        # Create an action for the bookmark and add it to the bookmark toolbar
        bookmark_action = QAction(title+',,,' if len(title)==17 else title, self)
        bookmark_action.triggered.connect(lambda checked=False, title=title: self.navigate_to_bookmark(self.bookmarks[title]))
        bookmark_btn = AnimatedButton(bookmark_action.text(), 'orange', '#f68500', '#e57400', 200, menu_indicator = True)
        bookmark_btn.setDefaultAction(bookmark_action)
        bookmark_btn.setFixedHeight(20)

        # Create a context menu for the bookmark action
        bookmark_menu = QMenu()
        edit_action = QAction("Edit link", self)
        edit_action.triggered.connect(lambda checked=False, title=title: self.edit_bookmark_url(title))
        rename_action = QAction("Edit Name",self)
        rename_action.triggered.connect(lambda checked=False, title=title: self.edit_bookmark_title(title))
        delete_action = QAction("Delete", self)
        delete_action.triggered.connect(lambda checked=False, title=title: self.delete_bookmark(title))
        bookmark_menu.addAction(rename_action)
        bookmark_menu.addAction(edit_action)
        bookmark_menu.addAction(delete_action)

        #bookmark_action.setMenu(bookmark_menu)
        bookmark_btn.setMenu(bookmark_menu)

        #self.bookmark_toolbar.addAction(bookmark_action)
        self.bookmark_toolbar.addWidget(bookmark_btn)
    
    def edit_bookmark_title(self, title):
        nTitle, ok = QInputDialog.getText(self, 'Edit bookmark name', f'Current Name: {title}\nCurrent Url: {self.bookmarks[title]}\nEnter new name:',text=title)
        if ok:
            if len(nTitle) > 20:
                nTitle = f'{nTitle[:17]}...'
            if len(title) == 17:
                title = f'{title}...'
            #print(self.bookmarks)
            self.bookmarks[nTitle] = self.bookmarks.pop(title)
            #print(self.bookmarks)
            for action in self.bookmark_toolbar.actions():
                if action.text() == title:
                    action.setText(nTitle)
                    action.triggered.disconnect()
                    action.triggered.connect(lambda checked=False, nTitle=nTitle: self.navigate_to_bookmark(self.bookmarks[nTitle]))
                    for a in action.menu().actions():
                        a.triggered.disconnect()
                        if a.text() == "Edit link":
                            a.triggered.connect(lambda checked=False, nTitle=nTitle: self.edit_bookmark_url(nTitle))
                        elif a.text() == "Edit Name":
                            a.triggered.connect(lambda checked=False, nTitle=nTitle: self.edit_bookmark_title(nTitle))
                        elif a.text() == "Delete":
                            a.triggered.connect(lambda checked=False, nTitle=nTitle: self.delete_bookmark(nTitle))
                    break
        self.write_files()
        self.read_files()
    def edit_bookmark_url(self, title):
        url, ok = QInputDialog.getText(self, 'Edit bookmark url', f'Current Name: {title}\nCurrent Url: {self.bookmarks[title]}\nEnter new URL:',text=self.bookmarks[title])
        if ok:
            self.bookmarks[title] = url
            for action in self.bookmark_toolbar.actions():
                if action.text() == title:
                    action.triggered.disconnect()
                    action.triggered.connect(lambda checked=False, title=title: self.navigate_to_bookmark(self.bookmarks[title]))
                    for a in action.menu().actions():
                        a.triggered.disconnect()
                        if a.text() == "Edit link":
                            a.triggered.connect(lambda checked=False, title=title: self.edit_bookmark_url(title))
                        elif a.text() == "Edit Name":
                            a.triggered.connect(lambda checked=False, title=title: self.edit_bookmark_title(title))
                        elif a.text() == "Delete":
                            a.triggered.connect(lambda checked=False, title=title: self.delete_bookmark(title))
                    break
        self.write_files()
        self.read_files()
    def delete_bookmark(self, title):        
        if title in self.bookmarks.keys():
            del self.bookmarks[title]
        for action in self.bookmark_toolbar.actions():
            if action.defaultWidget().text() == title:
                self.bookmark_toolbar.removeAction(action)
                action.deleteLater()
                self.write_files()
                self.read_files()
                break

    def reloadtab(self):
        current_widget = self.tabs.currentWidget()
        if current_widget is not None:
            current_widget.reload()
    def backtab(self):
        current_widget = self.tabs.currentWidget()
        if current_widget is not None:
            current_widget.back()
    def forwardtab(self):
        current_widget = self.tabs.currentWidget()
        if current_widget is not None:
            current_widget.forward()

    def navigate_to_bookmark(self, url):
        self.add_tab(url)

    def reopen_tabs(self):
        if self.closed_tabs:
            url = self.closed_tabs.pop()  # Get the tab and its title
            #print(self.closed_tabs)
            self.add_tab(url = url)  # Use the original title

    def view_history(self):
        dialog = QDialog()
        dialog.setWindowFlags(Qt.WindowTitleHint | Qt.Popup)  # Make it a popup and remove the '?' button
        dialog.setWindowIcon(QIcon())  # Remove the icon
        layout = QVBoxLayout()
        table_widget = QTableWidget()

        # Add a label with the text 'History' centered at the top
        history_label = QLabel("History")
        history_label.setAlignment(Qt.AlignCenter)
        font = history_label.font()
        font.setPointSize(15)
        history_label.setFont(font)
        layout.addWidget(history_label)

        # Add a search bar right below 'History'
        search_bar = HistoryLineEdit(table_widget)
        search_bar.setPlaceholderText("Search history...")
        search_bar.setStyleSheet('border-radius:10px;padding-left:5px;'+('background-color:#202020;color:white;' if self.incognito else ''))
        layout.addWidget(search_bar)

        # Create a table
        table_widget.setRowCount(len(self.history))
        table_widget.setColumnCount(4)

        # Set the column headers
        table_widget.setHorizontalHeaderLabels(["Date", "Time", "Domain", "URL"])
        table_widget.setShowGrid(False)
        table_widget.setColumnWidth(3,500)

        # Disable column resizing
        header = table_widget.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Fixed)
        vheader = table_widget.verticalHeader()
        vheader.setSectionResizeMode(QHeaderView.Fixed)

        for i, (url, time, date) in enumerate(reversed(self.history)):
            # Add each item to the table
            date_item = QTableWidgetItem(date)
            time_item = QTableWidgetItem(time)
            domain_item = QTableWidgetItem(stripURLdomain(url))
            url_item = QTableWidgetItem(url)

            # Make the items non-editable
            date_item.setFlags(date_item.flags() & ~Qt.ItemIsEditable)
            time_item.setFlags(time_item.flags() & ~Qt.ItemIsEditable)
            domain_item.setFlags(domain_item.flags() & ~Qt.ItemIsEditable)
            url_item.setFlags(url_item.flags() & ~Qt.ItemIsEditable)

            table_widget.setItem(i, 0, date_item)
            table_widget.setItem(i, 1, time_item)
            table_widget.setItem(i, 2, domain_item)
            table_widget.setItem(i, 3, url_item)

        # Connect the signal to the slot
        table_widget.itemDoubleClicked.connect(self.reopen_tab_from_history)

        # Add the table widget to the layout
        layout.addWidget(table_widget)

        if self.incognito:
            palette = QPalette()
            palette.setColor(QPalette.Window, QColor(53, 53, 53))
            palette.setColor(QPalette.WindowText, Qt.white)
            dialog.setPalette(palette)
            #dialog.setStyleSheet("QToolTip { color: #ffffff; background-color: #2a82da; border: 1px solid white; }")
            history_label.setStyleSheet('color:white;')
            table_widget.setStyleSheet('background-color:#202020;color:white;')
            header.setStyleSheet('QHeaderView::section{background-color:#202020;color:white;}')
            vheader.setStyleSheet('QHeaderView::section{background-color:#202020;color:white;}')

        dialog.setLayout(layout)
        dialog.resize(800,600)
        dialog.exec_()

        return dialog
    
    def read_files(self):
        try:
            with open('history.txt', 'r',encoding='utf-8') as f:
                self.history = (f.read())
                f.close()
        except FileNotFoundError:
            self.history = '[()]'
            with open('history.txt', 'x',encoding='utf-8') as f:
                f.write('[()]')
                f.close()

        try:
            with open('bookmarks.txt', 'r',encoding='utf-8') as f:
                self.bookmarks = (f.read())
                f.close()
        except FileNotFoundError:
            self.bookmarks = '{}'
            with open('bookmarks.txt', 'x',encoding='utf-8') as f:
                f.write('{}')
                f.close()
        self.history = eval(self.history)
        self.bookmarks = eval(self.bookmarks)

    def write_files(self):
        history, bookmarks = '',''
        try:
            with open('history.txt', 'r',encoding='utf-8') as f:
                history = (f.read())
                f.close()
        except FileNotFoundError:
            self.history = '[()]'
            history = '[()]'
            with open('history.txt', 'x',encoding='utf-8') as f:
                f.write('[()]')
                f.close()

        try:
            with open('bookmarks.txt', 'r',encoding='utf-8') as f:
                bookmarks = (f.read())
                f.close()
        except FileNotFoundError:
            self.bookmarks = '{}'
            bookmarks = '{}'
            with open('bookmarks.txt', 'x',encoding='utf-8') as f:
                f.write('{}')
                f.close()
        history = eval(history)
        bookmarks = eval(bookmarks)

        history_edits = [value for value in self.history if (value not in history)]
        bookmark_edits = {key: self.bookmarks[key] for key in self.bookmarks if key not in bookmarks}
        removed = False
        if bookmark_edits == {}:
            bookmark_edits = {key: bookmarks[key] for key in bookmarks if key not in self.bookmarks}
            if not bookmark_edits == {}:
                removed = True

        #print("read: ", history)
        #print("current: ", self.history)
        #print("edits: ", history_edits)
        #print("read: ", bookmarks.keys())
        #print("current: ", self.bookmarks.keys())
        #print("edits: ", bookmark_edits.keys())

        with open('history.txt', 'w',encoding='utf-8') as f:
            if self.history == []:
                f.write('[]')
            else:
                if history == [()]:
                    f.write(str(self.history))
                else:
                    f.write(str(history + history_edits))
            f.close()
        with open('bookmarks.txt', 'w',encoding='utf-8') as f:
            if self.bookmarks == {}:
                f.write('{}')
            else:
                if bookmarks == {}:
                    f.write(str(self.bookmarks))
                else:
                    if removed == False:
                        f.write(str({**bookmarks, **bookmark_edits}))
                    else:
                        f.write(str({key: bookmarks[key] for key in bookmarks if key not in bookmark_edits or bookmarks[key] != bookmark_edits[key]}))
            f.close()

        self.read_files()
    
    def overwrite_files(self):
        with open('history.txt', 'w',encoding='utf-8') as f:
            if self.history == []:
                f.write('[]')
            else:
                f.write(str(self.history))
            f.close()
        with open('bookmarks.txt', 'w',encoding='utf-8') as f:
            if self.bookmarks == {}:
                f.write('{}')
            else:
                f.write(str(self.bookmarks))
            f.close()

    def reopen_tab_from_history(self, item):
        if not (len(item.text()) == 8 or len(item.text()) == 10): # prevent opening of date or time
            url = item.text()
            self.add_tab(url)

    def update_history(self):
        #print('updating files...')
        current_tab = self.tabs.currentWidget() 
        url = current_tab.url().toString()
        time = QTime.currentTime().toString()  # Get the current time
        date = QDate.currentDate().toString('dd-MM-yyyy')
        if self.history == [()]:
            self.history = [(url, time, date)]
        else:
            if not self.history[len(self.history)-1][0] == url: # Remove duplicate urls
                self.history.append((url, time, date))
        self.write_files()
        self.read_files()

    def current_browser(self):
        return self.tabs.currentWidget()
    
    def add_tab(self, url='https://google.com', sametab=False):
        url = stripURL(url, QUrl)

        if sametab and self.tabs.count() > 0:
            # If sametab is True and there is at least one tab, set the URL of the current tab to the new URL
            self.tabs.currentWidget().setUrl(url)
        else:
            # If sametab is False, create a new tab
            browser = CustomWebEngineView()
            browser.setUrl(url)

            browser.loadFinished.connect(self.load_finished)
            browser.settings().setAttribute(QWebEngineSettings.PluginsEnabled, True)

            self.tabs.addTab(browser, 'New Tab')
            self.tabs.setCurrentWidget(browser)
            self.tabs.setTabText(self.tabs.currentIndex(), 'Loading...')
            browser.titleChanged.connect(
                lambda title, browser=browser: self.update_title(title,browser))
            browser.urlChanged.connect(
                lambda url, browser=browser: self.update_url(url) if self.tabs.currentWidget() == browser else None)

    def update_title(self,title,browser):
        self.tabs.setTabText(self.tabs.indexOf(browser),title)
        CName = self.tabs.tabText(self.tabs.indexOf(browser))
        self.setWindowTitle(f'{CName} — Navigo')
        self.update_history()
        #if (not self.history == [()]) and (not self.tabs.currentWidget().url().toString() == self.history[len(self.history)-1][0]):
            #self.update_history()

    def load_finished(self, ok):
        if ok:
            print("Page loaded successfully.")
            browser = self.tabs.currentWidget()
            CName = self.tabs.tabText(self.tabs.indexOf(browser))
            print("current tab name: ",CName)
            #if (not self.history == [()]) and (not self.tabs.currentWidget().url().toString() == self.history[len(self.history)-1][0]):
                #self.update_history()
            #if self.history == [()]:
                #self.update_history()
        else:
            print("Error loading page.")
            #print("Error string:", self.current_browser().page().errorString())

    def javaScriptConsoleMessage(self, level, msg, line, sourceID):
        print('console mesage: ', msg)

    def close_tab(self, index=None):
        if index is None:
            index = self.tabs.currentIndex()
        browser_widget = self.tabs.widget(index)
        if browser_widget.url().host() == "www.youtube.com":
            browser_widget.page().runJavaScript("document.getElementsByTagName('video')[0].pause();")# Remove the tab
        if self.tabs.count() < 2: # If this is the last tab, close the whole window
            self.close()
        else: # Remove the tab and delete the associated browser widget
            self.closed_tabs.append((self.tabs.currentWidget().url().toString()))
            self.tabs.removeTab(index)
            browser_widget.deleteLater()

    def closeEvent(self,event):
        print('closing window... ')
        self.write_files()
        #if self.incognito_window.incognito_action in self.incognito_window.toolbar.actions():
            #self.incognito_window.toolbar.removeAction(self.incognito_action)
        super().closeEvent(event)

    def navigate_to_url(self):
        url = self.line_edit.text()
        if 'http' not in url:
            url = 'https://' + url
        self.current_browser().setUrl(QUrl(url))
        
    def update_url(self, q):
        if self.sender() == self.current_browser():
            self.line_edit.setText(q.toString())
            self.line_edit.setCursorPosition(0)
   
    def update_line_edit(self, index):
        browser = self.tabs.widget(index)
        url = browser.url().toString()
        self.line_edit.setText(url)
        CName = self.tabs.tabText(self.tabs.indexOf(browser))
        self.setWindowTitle(f'{CName} — Navigo')

app = QApplication(['', '--no-sandbox', '-platform', 'windows:darkmode=1']) 

app.setApplicationName("")
app.setApplicationDisplayName('')
app.setOrganizationName('Scientyfic World')
window = MainWindow()
window.showMaximized()
app.exec_()
