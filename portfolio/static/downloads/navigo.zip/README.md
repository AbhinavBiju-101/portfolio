# Navigo

A PyQt5-based desktop web browser built on QtWebEngine (Chromium).

## Run

```bash
pip install -r requirements.txt
python Navigo.py
```

Requires a desktop environment (this is a Qt GUI application, not a
console app) — there's no in-browser preview for it here for that reason.
