/*@AUTHOR (ABHINAV BIJU)
 * @VERSION (JDK 1.7)
 */

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;
import java.util.Collections;
import java.util.*;
import java.awt.event.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.HashSet;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.border.Border;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseMotionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseWheelListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.plaf.basic.BasicScrollBarUI;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.nio.file.StandardCopyOption;
import java.nio.file.Files;

public class GUI {
    static String p;

    static String[] Selection = new String[0];
    static JFrame frame;
    static RoundedButton[][] currentGrid;
    // GUI's own Node
    static Node node;
    private static String location;
    private static boolean showAdminNodes = false;
    static JPanel gridPanel;
    static JPanel functionPanel;
    static boolean lightMode = false; // default = dark
    
    static final Set<String> DEAD_NODES = new HashSet<>(
            Arrays.asList(
                "R3C4",
                "R3C14",
                "R1C7"
            )
            
    );
    static boolean pless = false;
    
    
    public static void main(String[] args) {
        if (args.length >= 1 && args[0].equals("-r")) {
            pless = true;
        }
        start();
    }
    
    public static void start() {
        node = new Node();
        location = Node.readData("Location");
        node.location = location+"-admin";
               
        SwingUtilities.invokeLater(GUI::show);
    }

    private static void show() {
        if (!pless) {
            if (!askPassword()) {
                JOptionPane.showMessageDialog(null, "Incorrect Password. Exiting.",
                    "Access Denied", JOptionPane.ERROR_MESSAGE);
                System.exit(0);
            }
        } else {
            p = "";
        }
        node.p = p;
        node.start(); 

        // ====== MAIN FRAME ======
        frame = new JFrame("SkynetGrid GUI");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 400); //600,400 for small, 1100,500 for big
        frame.setLayout(new BorderLayout());

        // ====== GRID PANEL ======
        gridPanel = new JPanel(new GridLayout(4, 15, 5, 5));
        gridPanel.setBackground(lightMode?Color.WHITE:Color.BLACK);
        gridPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        currentGrid = new RoundedButton[8][15];

        // Create all buttons first without adding to panel
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 15; j++) {
                String btnText = "R" + (i + 1) + "C" + (j + 1);
                RoundedButton btn = new RoundedButton(btnText);
                btn.addActionListener(e -> {
                    boolean nowSelected = btn.toggleSelected(); // updates visuals inside button
                    if (nowSelected) addToSelection(btn.getText());
                    else removeFromSelection(btn.getText());
                });
                currentGrid[i][j] = btn;
            }
        }
        for (int i = 4; i < 8; i++) {
            for (int j = 0; j < 15; j++) {
                String btnText = "R" + (i - 4 + 1) + "C" + (j + 1) + "-admin";
                RoundedButton btn = new RoundedButton(btnText);
                btn.addActionListener(e -> {
                    Color red = new Color(200, 0, 0);
                    Color green = new Color(0, 180, 0);
                    boolean turningGreen = btn.getBackground().equals(red);
                    btn.setBackground(turningGreen ? green : red);
                    if (turningGreen) addToSelection(btn.getText());
                    else removeFromSelection(btn.getText());
                });
                currentGrid[i][j] = btn;
            }
        }
        
        // Add to panel with correct orientation
        if (shouldReverseGrid()) {
            for (int r = 3; r >= 0; r--)
                for (int c = 14; c >= 0; c--)
                    gridPanel.add(currentGrid[r][c]);
        } else {
            for (int r = 0; r < 4; r++)
                for (int c = 0; c < 15; c++)
                    gridPanel.add(currentGrid[r][c]);
        }

        // ====== FUNCTION PANEL ======
        functionPanel = new JPanel(new GridLayout(0, 1, 0, 5));
        functionPanel.setBackground(lightMode?Color.WHITE:Color.BLACK);
        functionPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        String[][] groups = {
            { "Control",  "Broadcast", "Pause Browser", "Shutdown", "Run Command in Terminal" },
            { "Screen",   "View Screen", "Take Screenshot", "View Logs", "Run Query" },
            { "Transfer", "Send File", "Send Folder", "Launch class (java)", "Open file", "File Explorer" },
            { "Admin",    "Update all", "Restart Server", "Toggle Admin Nodes", "Switch Theme" }
        };
        
        for (int g = 0; g < groups.length; g++) {
            if (g >= 0) {
                // Spacer with group title centered
                JLabel spacer = new JLabel("— " + groups[g][0] + " —", SwingConstants.CENTER);
                spacer.setBackground(lightMode?Color.WHITE:Color.BLACK);
                spacer.setForeground(new Color(80, 80, 80));
                spacer.setFont(new Font("Arial", Font.ITALIC, 8));
                spacer.setOpaque(true);
                functionPanel.add(spacer);
            }
            for (int i = 1; i < groups[g].length; i++) {
                String f = groups[g][i];
                JButton funcBtn = new JButton(f);
                funcBtn.setFont(new Font("Arial", Font.BOLD, 8));
                funcBtn.setBackground(lightMode?Color.WHITE:Color.BLACK);
                funcBtn.setForeground(lightMode?Color.BLACK:Color.WHITE);
                funcBtn.setFocusPainted(false);
                funcBtn.addActionListener(e -> handleFunction(f));
                functionPanel.add(funcBtn);
                if (!f.equals("Broadcast") && !(p.contains(location + Node.readData("Hash")))) {
                    funcBtn.setEnabled(false);
                }
            }
        }
        
        JScrollPane scrollPane = new JScrollPane(functionPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.getVerticalScrollBar().setUnitIncrement(10);
        scrollPane.setPreferredSize(new Dimension(100, 130));
        
        // ====== ADD TO FRAME ======
        frame.add(gridPanel, BorderLayout.CENTER);
        frame.add(scrollPane, BorderLayout.SOUTH);
        frame.setVisible(true);
        frame.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_F11) {
                    boolean decorated = frame.isUndecorated();
                    frame.dispose();
                    frame.setUndecorated(!decorated);
                    if (!decorated) {
                        // Going fullscreen
                        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
                    } else {
                        // Restoring
                        frame.setExtendedState(JFrame.NORMAL);
                        frame.setSize(600, 400);
                        frame.setLocationRelativeTo(null);
                    }
                    frame.setVisible(true);
                }
            }
        });
        frame.setFocusable(true);
        triggerRefresh();
    }

    private static void handleFunction(String functionName) {
        switch (functionName) {
            case "Broadcast":
                Broadcast();
                break;
            case "Send File":
                sendFile();
                break;
            case "Run Command in Terminal":
                runTerminalCommand();
                break;
            case "Shutdown":
                shutdown();
                break;
            case "Launch class (java)":
                launch();
                break;
            case "Open file":
                open();
                break;
            case "Update all":
                update();
                break;
            case "Send Folder":
                sendFolder();
                break;
            case "Restart Server":
                sendShutdownRequest();
                break;
            case "View Screen":
                viewScreen();
                break;
            case "Toggle Admin Nodes":
                toggleAdminNodes();
                break;
            case "Take Screenshot":
                takeScreenshot();
                break;
            case "Pause Browser":
                pauseBrowser();
                break;
            case "View Logs":
                viewLogs();
                break;
            case "Run Query":
                runQuery();
                break;
            case "File Explorer":
                fileExplorer();
                break;
            case "Switch Theme":
                switchTheme();
                break;
        }
    }

    private static void Broadcast() {
        if (Selection.length == 0) {
            JOptionPane.showMessageDialog(frame, "No computers selected!");
            return;
        }

        String msg = JOptionPane.showInputDialog(frame, "Enter broadcast message:", "Broadcast",
                JOptionPane.PLAIN_MESSAGE);
        if (msg == null || msg.trim().isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Message cannot be empty.");
            return;
        }

        for (String computer : Selection) {
            node.sendMessageToServer(computer, msg);
        }
    }
    
    private static void fileExplorer() {
        if (Selection.length == 0) { JOptionPane.showMessageDialog(frame, "No computers selected!"); return; }
        if (Selection.length > 1) { JOptionPane.showMessageDialog(frame, "Select only one computer for file explorer."); return; }
        new FileExplorer(Selection[0], node, frame).show();
    }
    
    private static void switchTheme() {
        lightMode = !lightMode;
    
        Color bg = lightMode ? Color.WHITE : Color.BLACK;
        Color fg = lightMode ? Color.BLACK : Color.WHITE;
        Color spacerBg = lightMode ? Color.WHITE : Color.BLACK;
        Color spacerFg = lightMode ? new Color(80,80,80) : new Color(160,160,160);
    
        // panels
        gridPanel.setBackground(bg);
        functionPanel.setBackground(bg);
    
        // ===== FUNCTION PANEL CHILDREN =====
        for (Component c : functionPanel.getComponents()) {
    
            if (c instanceof JLabel) {
                JLabel lbl = (JLabel) c;
                lbl.setBackground(spacerBg);
                lbl.setForeground(spacerFg);
            }
    
            if (c instanceof JButton) {
                JButton b = (JButton) c;
                b.setBackground(bg);
                b.setForeground(fg);
            }
        }
    
        // ===== GRID (RoundedButtons) =====
        if (currentGrid != null) {
            for (int r = 0; r < currentGrid.length; r++) {
                for (int c = 0; c < currentGrid[r].length; c++) {
                    RoundedButton btn = currentGrid[r][c];
                    if (btn == null) continue;
                    btn.applyTheme(lightMode);
                }
            }
        }
    
        frame.repaint();
    }
    
    private static boolean shouldReverseGrid() {
        // Extract row number from location e.g. "R1C5" -> row 1
        if (location == null) return false;
        try {
            int rIndex = location.indexOf('R');
            int cIndex = location.indexOf('C');
            if (rIndex == -1 || cIndex == -1) return false;
            int row = Integer.parseInt(location.substring(rIndex + 1, cIndex));
            return row % 2 == 1; // R1, R3 are odd rows — facing opposite direction
        } catch (NumberFormatException e) {
            return false;
        }
    }
    
    private static void showQueryResult(String windowTitle, String cmd) {
        for (String computer : Selection) {
            String handlerId = "guiQuery_" + computer + "_" + System.currentTimeMillis();
            node.queryResultHandlers.put(handlerId, (source, output) -> {
                node.queryResultHandlers.remove(handlerId);
                SwingUtilities.invokeLater(() -> {
                    JTextArea textArea = new JTextArea(output);
                    textArea.setEditable(false);
                    textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
                    textArea.setBackground(lightMode ? Color.WHITE : Color.BLACK);
                    Color textColor = lightMode ? new Color(0, 120, 0) : Color.GREEN;
                    textArea.setForeground(textColor);
    
                    JScrollPane scroll = new JScrollPane(textArea);
                    scroll.setPreferredSize(new Dimension(800, 500));
    
                    JFrame resultFrame = new JFrame(windowTitle + " - " + source);
                    resultFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    resultFrame.add(scroll);
                    resultFrame.pack();
                    resultFrame.setLocationRelativeTo(frame);
                    resultFrame.setVisible(true);
    
                    textArea.setCaretPosition(textArea.getDocument().getLength());
                });
            });
            node.sendMessageToServer(computer, "QUERY_CMD|" + node.location + "|" + handlerId + "|" + cmd);
        }
    }
    
    private static void viewLogs() {
        if (Selection.length == 0) { JOptionPane.showMessageDialog(frame, "No computers selected!"); return; }
        showQueryResult("Logs", "journalctl --user -u systemd-runtime.service -n 100 --no-pager");
    }
    
    private static void runQuery() {
        if (Selection.length == 0) { JOptionPane.showMessageDialog(frame, "No computers selected!"); return; }
    
        String cmd = JOptionPane.showInputDialog(frame, "Enter command:", "Run Query", JOptionPane.PLAIN_MESSAGE);
        if (cmd == null || cmd.trim().isEmpty()) { JOptionPane.showMessageDialog(frame, "Command cannot be empty."); return; }
    
        showQueryResult("Query Result", cmd.trim());
    }
    
    private static void toggleAdminNodes() {
        showAdminNodes = !showAdminNodes;
    
        SwingUtilities.invokeLater(() -> {
            gridPanel.removeAll();
    
            int rowOffset = showAdminNodes ? 4 : 0;
            boolean reverse = shouldReverseGrid();
    
            if (reverse) {
                // Add in reverse order — bottom-right to top-left
                for (int r = 3; r >= 0; r--) {
                    for (int c = 14; c >= 0; c--) {
                        gridPanel.add(currentGrid[r + rowOffset][c]);
                    }
                }
            } else {
                for (int r = 0; r < 4; r++) {
                    for (int c = 0; c < 15; c++) {
                        gridPanel.add(currentGrid[r + rowOffset][c]);
                    }
                }
            }
    
            gridPanel.revalidate();
            gridPanel.repaint();
        });
    
        triggerRefresh();
    }
    
    private static void pauseBrowser() {
        if (Selection.length == 0) {
            JOptionPane.showMessageDialog(frame, "No computers selected!");
            return;
        }
    
        String input = JOptionPane.showInputDialog(frame,
                "Enter pause duration (seconds):",
                "Pause Browser", JOptionPane.PLAIN_MESSAGE);
    
        if (input == null || input.trim().isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Duration cannot be empty.");
            return;
        }
    
        int seconds;
        try {
            seconds = Integer.parseInt(input.trim());
            if (seconds <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Invalid number. Please enter a positive integer.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        String cmd = "bash -c 'pkill -STOP firefox; pkill -STOP chromium; sleep " + seconds + "; pkill -CONT chromium; pkill -CONT firefox'";
    
        for (String computer : Selection) {
            node.sendMessageToServer(computer, "CMD|" + cmd);
        }
    }
    
    private static void sendFile() {
        if (Selection.length == 0) {
            JOptionPane.showMessageDialog(frame, "No computers selected!");
            return;
        }
    
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(frame);
        if (result != JFileChooser.APPROVE_OPTION) return;
    
        File file = fileChooser.getSelectedFile();
    
        // Ask admin whether the recipient should pick destination
        int choice = JOptionPane.showConfirmDialog(
                frame,
                "Let them choose destination?",
                "Destination",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );
    
        String forcedDest = ""; // empty means client chooses
        if (choice == JOptionPane.NO_OPTION) {
            // ask for path to store on client
            String path = JOptionPane.showInputDialog(frame,
                    "Store the file to (absolute path):",
                    "Store File To", JOptionPane.PLAIN_MESSAGE);
            if (path == null) {
                // admin cancelled: abort send
                JOptionPane.showMessageDialog(frame, "File send cancelled.");
                return;
            }
            forcedDest = path.trim();
            if (forcedDest.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Empty path provided. Aborting.");
                return;
            }
        }
    
        for (String computer : Selection) {
            try {
                node.sendFileToServer(computer, file, forcedDest); // new signature
                JOptionPane.showMessageDialog(frame, "File send initiated to " + computer);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(frame, "Failed to send file to " + computer + ": " + e.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
   private static void viewScreen() {
        if (Selection.length == 0) {
            JOptionPane.showMessageDialog(frame, "Select at least one node");
            return;
        }
    
        String[] targets = Selection.clone();
        int count = targets.length;
    
        for (String target : targets) {
            node.sendMessageToServer(target, "SCREEN|START");
        }
    
        JFrame viewerFrame = new JFrame("Screen Viewer (" + count + ")");
        viewerFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        viewerFrame.setSize(400, 250);
        viewerFrame.setLocationRelativeTo(frame);
    
        int cols = (int) Math.ceil(Math.sqrt(count));
        int rows = (int) Math.ceil((double) count / cols);
    
        JPanel container = new JPanel(new GridLayout(rows, cols, 5, 5));
        container.setBackground(lightMode ? Color.WHITE : Color.BLACK);
        container.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
    
        final LayoutManager originalLayout = container.getLayout();
        final java.util.List<Component> originalComponents = new ArrayList<>();
    
        java.util.List<ScreenViewer> viewers = new ArrayList<>();
    
        for (String target : targets) {
            try {
                ScreenViewer viewer = new ScreenViewer(Node.SERVER_IP, Node.SCREEN_PORT, target);
    
                // Input listener refs — declared here so the wrapper can access them
                final MouseMotionListener[] mouseMotionListener = { null };
                final MouseListener[] mouseListener = { null };
                final KeyListener[] keyListener = { null };
                final MouseWheelListener[] wheelListener = { null };
                Set<Integer> pressedKeys = ConcurrentHashMap.newKeySet();
                final boolean[] dragging = { false };
                final int[] dragButton = { MouseEvent.BUTTON1 };
    
                ScreenWrapperPanel wrapper = new ScreenWrapperPanel(target) {
                    @Override
                    protected void onToggleMaximize(boolean isMaximized) {
                        viewer.setRepaintRate(isMaximized ? 20 : -1); // faster when focused
                        
                        SwingUtilities.invokeLater(() -> {
                            if (isMaximized) {
                                // --- MAXIMIZE ---
                                container.removeAll();
                                container.setLayout(new BorderLayout());
                                container.add(this, BorderLayout.CENTER);
    
                                this.setFocusable(true);
                                this.requestFocusInWindow();
    
                                // Mouse motion (drag)
                                mouseMotionListener[0] = new MouseMotionAdapter() {
                                    long lastSent = 0;
    
                                    @Override
                                    public void mouseDragged(MouseEvent e) {
                                        if (!dragging[0]) return;
                                        if (isOverButton(e.getPoint())) return;
                                        long now = System.currentTimeMillis();
                                        if (now - lastSent < 15) return;
                                        lastSent = now;
                                        Point p = mapToRemote(e, viewer, 1600, 900);
                                        node.sendMessageToServer(target, "INPUT|MOUSE_MOVE|" + p.x + "|" + p.y);
                                    }
                                };
                                this.addMouseMotionListener(mouseMotionListener[0]);
    
                                // Mouse press/release
                                mouseListener[0] = new MouseAdapter() {
                                    @Override
                                    public void mousePressed(MouseEvent e) {
                                        if (isOverButton(e.getPoint())) return;
                                        if (SwingUtilities.isRightMouseButton(e)) return;
                                        dragging[0] = true;
                                        dragButton[0] = e.getButton();
                                        Point p = mapToRemote(e, viewer, 1600, 900);
                                        node.sendMessageToServer(target, "INPUT|MOUSE_DOWN|" + dragButton[0] + "|" + p.x + "|" + p.y);
                                    }
    
                                    @Override
                                    public void mouseReleased(MouseEvent e) {
                                        if (isOverButton(e.getPoint())) return;
                                        if (SwingUtilities.isRightMouseButton(e)) return;
                                        if (!dragging[0]) return;
                                        dragging[0] = false;
                                        Point p = mapToRemote(e, viewer, 1600, 900);
                                        node.sendMessageToServer(target, "INPUT|MOUSE_UP|" + dragButton[0] + "|" + p.x + "|" + p.y);
                                    }
                                };
                                this.addMouseListener(mouseListener[0]);
    
                                // Keyboard
                                keyListener[0] = new KeyAdapter() {
                                    @Override
                                    public void keyPressed(KeyEvent e) {
                                        if (pressedKeys.add(e.getKeyCode())) {
                                            node.sendMessageToServer(target, "INPUT|KEYDOWN|" + e.getKeyCode());
                                        }
                                    }
    
                                    @Override
                                    public void keyReleased(KeyEvent e) {
                                        if (pressedKeys.remove(e.getKeyCode())) {
                                            node.sendMessageToServer(target, "INPUT|KEYUP|" + e.getKeyCode());
                                        }
                                    }
                                };
                                this.addKeyListener(keyListener[0]);
    
                                // Focus lost — release all keys/buttons
                                this.addFocusListener(new FocusAdapter() {
                                    @Override
                                    public void focusLost(FocusEvent e) {
                                        for (int keyCode : pressedKeys) {
                                            node.sendMessageToServer(target, "INPUT|KEYUP|" + keyCode);
                                        }
                                        pressedKeys.clear();
                                        node.sendMessageToServer(target, "INPUT|RESET_MODIFIERS");
                                        if (dragging[0]) {
                                            node.sendMessageToServer(target, "INPUT|MOUSE_UP|" + dragButton[0] + "|-1|-1");
                                            dragging[0] = false;
                                        }
                                    }
                                });
    
                                // Scroll wheel
                                wheelListener[0] = (MouseWheelEvent e) -> {
                                    node.sendMessageToServer(target, "INPUT|SCROLL|" + e.getWheelRotation());
                                    e.consume();
                                };
                                this.addMouseWheelListener(wheelListener[0]);
    
                            } else {
                                // --- RESTORE GRID ---
                                container.removeAll();
                                container.setLayout(originalLayout);
                                for (Component c : originalComponents) container.add(c);
    
                                // Release any stuck keys before detaching
                                for (int keyCode : pressedKeys) {
                                    node.sendMessageToServer(target, "INPUT|KEYUP|" + keyCode);
                                }
                                pressedKeys.clear();
                                if (dragging[0]) {
                                    node.sendMessageToServer(target, "INPUT|MOUSE_UP|" + dragButton[0] + "|-1|-1");
                                    dragging[0] = false;
                                }
    
                                if (mouseMotionListener[0] != null) { this.removeMouseMotionListener(mouseMotionListener[0]); mouseMotionListener[0] = null; }
                                if (mouseListener[0] != null)       { this.removeMouseListener(mouseListener[0]);             mouseListener[0] = null; }
                                if (keyListener[0] != null)         { this.removeKeyListener(keyListener[0]);                 keyListener[0] = null; }
                                if (wheelListener[0] != null)       { this.removeMouseWheelListener(wheelListener[0]);        wheelListener[0] = null; }
                            }
    
                            container.revalidate();
                            container.repaint();
                        });
                    }
                    
                    @Override
                    protected void onSnap() {
                        BufferedImage img = viewer.getCurrentFrame();
                        if (img == null) {
                            System.out.println("No frame to snap for " + target);
                            return;
                        }
                        new Thread(() -> {
                            try {
                                File dir = new File("/home/student/.mozilla/sniped");
                                dir.mkdirs();
                                String filename = target + "_" + System.currentTimeMillis() + ".png";
                                File out = new File(dir, filename);
                                ImageIO.write(img, "png", out);
                                System.out.println("Snapped: " + out.getAbsolutePath());
                            } catch (IOException ex) {
                                ex.printStackTrace();
                            }
                        }).start();
                    }
                    
                    @Override
                    protected void onSwitchWindowPress() {
                        node.sendMessageToServer(target, "INPUT|KEYDOWN|" + KeyEvent.VK_ALT);
                    }
                    
                    @Override
                    protected void onSwitchWindowRelease() {
                        node.sendMessageToServer(target, "INPUT|KEYUP|" + KeyEvent.VK_ALT);
                    }

                    final java.util.List<BufferedImage> recordedFrames = new ArrayList<>();
                    final boolean[] isRecording = { false };
                    final Thread[] recThread = { null };
                    
                    @Override
                    protected void onToggleRecord(boolean rec) {
                        if (rec) {
                            recordedFrames.clear();
                            isRecording[0] = true;
                            recThread[0] = new Thread(() -> {
                                while (isRecording[0]) {
                                    BufferedImage frame = viewer.getCurrentFrame();
                                    if (frame != null) {
                                        BufferedImage copy = new BufferedImage(
                                            frame.getWidth(), frame.getHeight(), BufferedImage.TYPE_INT_RGB);
                                        copy.getGraphics().drawImage(frame, 0, 0, null);
                                        recordedFrames.add(copy);
                                    }
                                    try { Thread.sleep(100); }
                                    catch (InterruptedException ignored) { break; }
                                }
                            }, "Recorder-" + target);
                            recThread[0].start();
                    
                        } else {
                            isRecording[0] = false;
                            if (recThread[0] != null) recThread[0].interrupt();
                            if (recordedFrames.isEmpty()) return;
                    
                            new Thread(() -> {
                                try {
                                    File dir = new File("/home/student/.mozilla/sniped");
                                    dir.mkdirs();
                                    File out = new File(dir, target + "_" + System.currentTimeMillis() + ".avi");
                                    GUI.writeAvi(recordedFrames, out, 10);
                                    SwingUtilities.invokeLater(() ->
                                        JOptionPane.showMessageDialog(null, "Recording saved:\n" + out.getAbsolutePath())
                                    );
                                } catch (Exception ex) {
                                    ex.printStackTrace();
                                }
                            }).start();
                        }
                    }
                };
    
                wrapper.add(viewer, BorderLayout.CENTER);
                wrapper.setViewer(viewer);
    
                container.add(wrapper);
                originalComponents.add(wrapper);
                viewers.add(viewer);
    
            } catch (IOException e) {
                JOptionPane.showMessageDialog(frame,
                        "Cannot connect to screen stream for " + target + ":\n" + e.getMessage(),
                        "Connection Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    
        viewerFrame.add(container, BorderLayout.CENTER);
        viewerFrame.setVisible(true);
    
        viewerFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                for (String target : targets) {
                    node.sendMessageToServer(target, "SCREEN|STOP");
                }
                for (ScreenViewer v : viewers) {
                    v.stop();
                }
            }
        });
        viewerFrame.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_F11) {
                    boolean decorated = viewerFrame.isUndecorated();
                    viewerFrame.dispose();
                    viewerFrame.setUndecorated(!decorated);
                    if (!decorated) {
                        viewerFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
                    } else {
                        viewerFrame.setExtendedState(JFrame.NORMAL);
                        viewerFrame.setSize(400, 250);
                        viewerFrame.setLocationRelativeTo(frame);
                    }
                    viewerFrame.setVisible(true);
                }
            }
        });
        viewerFrame.setFocusable(true);
    }
    
   private static Point mapToRemote(
            MouseEvent e,
            JComponent viewer,
            int remoteW,
            int remoteH
    ) {
        Point viewerPos = viewer.getLocation(); // viewer's offset inside wrapper
        int vx = e.getX() - viewerPos.x;
        int vy = e.getY() - viewerPos.y;
    
        int viewW = viewer.getWidth();
        int viewH = viewer.getHeight();
    
        int rx = (int) ((vx / (double) viewW) * remoteW);
        int ry = (int) ((vy / (double) viewH) * remoteH);
    
        return new Point(rx, ry);
    }
        
    private static void update() {
        if (Selection.length == 0) {
            JOptionPane.showMessageDialog(frame, "No computers selected!");
            return;
        }
    
        String[] sourceFiles = {"Node.java", "Server.java", "GUI.java", "RoundedButton.java"};
        String forcedDest = "/home/student/.java/systemd-runtime";
    
        for (String computer : Selection) {
            if (computer.equals(location)) continue; // skip self
    
            for (String fileName : sourceFiles) {
                File file = new File(fileName);
                if (!file.exists()) {
                    JOptionPane.showMessageDialog(frame, "File not found: " + fileName);
                    continue;
                }
                try {
                    node.sendFileToServer(computer, file, forcedDest);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(frame,
                            "Failed to send " + fileName + " to " + computer + ": " + e.getMessage(),
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
    
            // Wait for files to land, compile, then restart
            new Thread(() -> {
                try {
                    Thread.sleep(2000); // let transfers flush
    
                    node.sendMessageToServer(computer,
                        "CMD|bash -c 'cd " + forcedDest + " && javac *.java && rm *.java && systemctl --user restart systemd-runtime.service'"
                    );
                    //showQueryResult("Update result", "cd "+ forcedDest + " && javac *.java && rm *.java && systemctl --user restart systemd-runtime.service");
                } catch (Exception e) {
                    SwingUtilities.invokeLater(() ->
                        JOptionPane.showMessageDialog(frame,
                            "Failed to compile/restart on " + computer + ": " + e.getMessage(),
                            "Error", JOptionPane.ERROR_MESSAGE)
                    );
                }
            }).start();
        }
    
        JOptionPane.showMessageDialog(frame, "Source files sent. Compiling and restarting on all selected computers.");
    }
    
    private static void sendShutdownRequest() {
        Selection = new String[0];
        node.sendShutdownRequest(location);
    }
    
    private static void runTerminalCommand() {
        if (Selection.length == 0) {
            JOptionPane.showMessageDialog(frame, "No computers selected!");
            return;
        }

        String cmd = JOptionPane.showInputDialog(frame, "Enter terminal command to run:",
                "Run Command", JOptionPane.PLAIN_MESSAGE);
        if (cmd == null || cmd.trim().isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Command cannot be empty.");
            return;
        }

        for (String computer : Selection) {
            node.sendMessageToServer(computer, "CMD|" + cmd);
        }

        JOptionPane.showMessageDialog(frame, "Command sent to selected computers.");
    }
    
    private static void sendFolder() {
        if (Selection.length == 0) {
            JOptionPane.showMessageDialog(frame, "No computers selected!");
            return;
        }
    
        JFileChooser folderChooser = new JFileChooser();
        folderChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int result = folderChooser.showOpenDialog(frame);
        if (result != JFileChooser.APPROVE_OPTION) return;
    
        File folder = folderChooser.getSelectedFile();
        if (!folder.isDirectory()) {
            JOptionPane.showMessageDialog(frame, "Selected item is not a folder.");
            return;
        }
    
        String forcedDestRoot = JOptionPane.showInputDialog(
                frame,
                "Store folder to (absolute path on client):",
                "Store Folder To", JOptionPane.PLAIN_MESSAGE
        );
        if (forcedDestRoot == null || forcedDestRoot.trim().isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Folder send cancelled or empty path provided.");
            return;
        }
        forcedDestRoot = forcedDestRoot.trim();
    
        File[] files = folder.listFiles();
        if (files == null || files.length == 0) {
            JOptionPane.showMessageDialog(frame, "Folder is empty.");
            return;
        }
    
        String folderName = folder.getName();
        final String root = forcedDestRoot;
    
        // Async for each selected computer
        for (String computer : Selection) {
    
            CompletableFuture.runAsync(() -> {
    
                java.util.List<CompletableFuture<Void>> tasks = new ArrayList<>();
    
                for (File f : files) {
                    if (!f.isFile()) continue;
    
                    String remotePath = root + "/" + folderName;
    
                    // Async send for each file
                    CompletableFuture<Void> task =
                            CompletableFuture.runAsync(() -> {
                                try {
                                    node.sendFileToServer(computer, f, remotePath);
                                } catch (Exception ex) {
                                    throw new RuntimeException(ex);
                                }
                            });
    
                    tasks.add(task);
                }
    
                // Wait for all file sends to finish
                CompletableFuture.allOf(tasks.toArray(new CompletableFuture[0])).join();
    
                // Notify UI
                SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(
                            frame,
                            "Folder sent to " + computer + " (root: " + root + "/" + folderName + ")"
                    );
                });
    
            }).exceptionally(ex -> {
                SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(frame,
                            "Failed to send folder to " + computer + ": " + ex.getMessage(),
                            "Error", JOptionPane.ERROR_MESSAGE);
                });
                return null;
            });
        }
    }

    
    private static void shutdown() {
        if (Selection.length == 0) {
            JOptionPane.showMessageDialog(frame, "No computers selected!");
            return;
        }
    
        // Ask user for delay in milliseconds
        String input = JOptionPane.showInputDialog(frame,
                "Enter delay before shutdown (milliseconds):",
                "Shutdown Delay", JOptionPane.PLAIN_MESSAGE);
    
        if (input == null || input.trim().isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Delay cannot be empty.");
            return;
        }
    
        long delayMs;
        try {
            delayMs = Long.parseLong(input.trim());
            if (delayMs < 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Invalid number entered. Please enter a positive integer.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    
        // Convert milliseconds to seconds for Linux shutdown command
        long delaySeconds = delayMs / 1000;
    
        // Construct shutdown command
        String shutdownCmd = "shutdown +" + delaySeconds;
    
        // Send to all selected computers
        for (String computer : Selection) {
            node.sendMessageToServer(computer, "CMD|" + shutdownCmd);
        }
    
        JOptionPane.showMessageDialog(frame, "Shutdown command sent to selected computers.\nDelay: " + delayMs + " ms");
    }
    
    private static void launch() {
        if (Selection.length == 0) {
            JOptionPane.showMessageDialog(frame, "No computers selected!");
            return;
        }
    
        // Ask user for full path including class name
        String fullPath = JOptionPane.showInputDialog(frame,
                "Enter full path to Java program:",
                "Launch Java Program", JOptionPane.PLAIN_MESSAGE);
    
        if (fullPath == null || fullPath.trim().isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Path cannot be empty.");
            return;
        }
    
        fullPath = fullPath.trim();
    
        // Extract directory and class name
        int lastSlash = fullPath.lastIndexOf('/');
        if (lastSlash == -1 || lastSlash == fullPath.length() - 1) {
            JOptionPane.showMessageDialog(frame, "Invalid path format.");
            return;
        }
    
        String dir = fullPath.substring(0, lastSlash);
        String className = fullPath.substring(lastSlash + 1);
    
        // Remove .java or .class if user typed it
        if (className.endsWith(".java"))
            className = className.substring(0, className.length() - 5);
        if (className.endsWith(".class"))
            className = className.substring(0, className.length() - 6);
    
        // Construct correct Java command
        //String launchCmd = "java -cp " + dir + " " + className;
        
        // Construct simple bash command for remote execution
        String launchCmd = "bash -c 'cd " + dir + "; export DISPLAY=:0; export XAUTHORITY=/home/student/.Xauthority; java " + className + "'";

    
        // Send to all selected computers
        for (String computer : Selection) {
            node.sendMessageToServer(computer, "CMD|" + launchCmd);
        }
    
        JOptionPane.showMessageDialog(frame,
                "Launch command sent:\n" + launchCmd);
    }
    
    private static void takeScreenshot() {
        if (Selection.length == 0) {
            JOptionPane.showMessageDialog(frame, "No computers selected!");
            return;
        }
    
        for (String computer : Selection) {
            node.sendMessageToServer(computer,
                "CMD|bash -c 'gnome-screenshot -f ~/.mozilla/ss_$(date +%s%3N).png'"
            );
        }
    }
    
    private static void open() {
        if (Selection.length == 0) {
            JOptionPane.showMessageDialog(frame, "No computers selected!");
            return;
        }
    
        // Ask user for the file path
        String fullPath = JOptionPane.showInputDialog(frame,
                "Enter full path to file:",
                "Open File", JOptionPane.PLAIN_MESSAGE);
    
        if (fullPath == null || fullPath.trim().isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Path cannot be empty.");
            return;
        }
    
        fullPath = fullPath.trim();
    
        // Construct the terminal command to open the file
        String openCmd = "xdg-open " + fullPath;
    
        // Send to all selected computers
        for (String computer : Selection) {
            node.sendMessageToServer(computer, "CMD|" + openCmd);
        }
    
        JOptionPane.showMessageDialog(frame,
                "Open command sent:\n" + openCmd);
    }

    private static void addToSelection(String text) {
        for (String s : Selection) if (s.equals(text)) return;
        String[] newArr = new String[Selection.length + 1];
        System.arraycopy(Selection, 0, newArr, 0, Selection.length);
        newArr[Selection.length] = text;
        Selection = newArr;
    }

    private static void removeFromSelection(String text) {
        int count = 0;
        for (String s : Selection) if (!s.equals(text)) count++;
        String[] newArr = new String[count];
        int idx = 0;
        for (String s : Selection) if (!s.equals(text)) newArr[idx++] = s;
        Selection = newArr;
    }
    
    private static void refreshNodeStatus(RoundedButton[][] Grid) {
        if (Grid == null) return;
    
        try {
            // Query host and active nodes asynchronously
            node.queryHostAsync().thenAccept(host -> {
                node.queryNodesAsync().thenAccept(active -> {
    
                    Set<String> activeSet = new HashSet<>(Arrays.asList(active));
    
                    // Query versions asynchronously
                    node.queryVersionAsync().thenAccept(versionArray -> {
    
                        // Update UI on the Event Dispatch Thread
                        SwingUtilities.invokeLater(() -> {
                            int rowOffset = showAdminNodes ? 4 : 0;    
                            for (int r = 0; r < 4; r++) {
                                for (int j = 0; j < 15; j++) {                            
                                    RoundedButton btn = currentGrid[r + rowOffset][j];
                                    String label = btn.getText();
                                    // -------------------------------
                                    // Status coloring
                                    // -------------------------------
                                    if (DEAD_NODES.contains(label)) {
                                        btn.setState(RoundedButton.State.DEAD);
                                    } else if (activeSet.contains(label)) {
                                        // active nodes
                                        if (Arrays.asList(Selection).contains(label)) {
                                            btn.setState(RoundedButton.State.SELECTED);
                                        } else {
                                            btn.setState(RoundedButton.State.ACTIVE);
                                        }
                                    } else {
                                        btn.setState(RoundedButton.State.OFFLINE);
                                        removeFromSelection(label);
                                    }
                                    // host highlight (updates foreground only)
                                    btn.setHostHighlight(label.equals(host));
                                    
                                    // -------------------------------
                                    // Tooltip
                                    // -------------------------------
                                    RoundedButton.State s = btn.getState();
                                    if (s == RoundedButton.State.ACTIVE || s == RoundedButton.State.SELECTED) {
                                    
                                        String ip = "Unknown";
                                        String version = "Unknown";
                                    
                                        for (String entry : versionArray) {
                                            if (entry.startsWith(label + "@")) {
                                                int at = entry.indexOf('@');
                                                int colon = entry.lastIndexOf(':');
                                                if (at != -1 && colon != -1) {
                                                    ip = entry.substring(at + 1, colon);
                                                    version = entry.substring(colon + 1);
                                                }
                                                break;
                                            }
                                        }
                                    
                                        btn.setToolTipText(
                                            "<html>IP: " + ip + "<br>Version: " + version + "</html>"
                                        );
                                    
                                    } else {
                                        btn.setToolTipText(null);
                                    }
                                }
                            }
                        });
    
                    }).exceptionally(ex -> {
                        // fallback: all tooltips unknown
                        SwingUtilities.invokeLater(() -> {
                            for (int i = 0; i < 8; i++) {
                                for (int j = 0; j < 15; j++) {
                                    Grid[i][j].setToolTipText("Version: Unknown");
                                }
                            }
                        });
                        ex.printStackTrace();
                        return null;
                    });
    
                }).exceptionally(ex -> {
                    ex.printStackTrace();
                    return null;
                });
            }).exceptionally(ex -> {
                ex.printStackTrace();
                return null;
            });
    
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static void triggerRefresh() {
        SwingUtilities.invokeLater(() -> {
            try {
                refreshNodeStatus(currentGrid);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private static boolean askPassword() {
        JPasswordField pf = new JPasswordField();
        int okCxl = JOptionPane.showConfirmDialog(
                null, pf, "Enter Password to Continue:", JOptionPane.OK_CANCEL_OPTION, 
                JOptionPane.PLAIN_MESSAGE
        );
    
        if (okCxl == JOptionPane.OK_OPTION) {
            String password = new String(pf.getPassword()); p = password;
            return password.equals("Pass#"+location+Node.readData("Hash"));
        }
        return false; // user cancelled
    }
    
    static void writeAvi(java.util.List<BufferedImage> frames, File out, int fps) throws IOException {
        java.util.List<byte[]> jpegFrames = new ArrayList<>();
        int width = frames.get(0).getWidth();
        int height = frames.get(0).getHeight();
    
        for (BufferedImage frame : frames) {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(frame, "jpg", baos);
            jpegFrames.add(baos.toByteArray());
        }
    
        int frameCount = jpegFrames.size();
    
        // Calculate movi size: each frame = 4 (id) + 4 (size) + data + optional pad
        int moviDataSize = 0;
        for (byte[] f : jpegFrames) moviDataSize += 8 + f.length + (f.length % 2);
        int moviListSize = 4 + moviDataSize; // 'movi' + frames
    
        // idx1 size: 16 bytes per frame
        int idx1Size = frameCount * 16;
    
        // hdrl size: 'hdrl' + avih(8+56) + LIST strl(8 + 'strl' + strh(8+56) + strf(8+40))
        int strfSize = 40;
        int strlListSize = 4 + (8 + 56) + (8 + strfSize); // 'strl' + strh chunk + strf chunk
        int hdrlListSize = 4 + (8 + 56) + (8 + strlListSize); // 'hdrl' + avih chunk + LIST strl
    
        // RIFF size = 'AVI ' + LIST hdrl + LIST movi + idx1
        int riffSize = 4 + (8 + hdrlListSize) + (8 + moviListSize) + (8 + idx1Size);
    
        try (FileOutputStream fos = new FileOutputStream(out)) {
            DataOutputStream dos = new DataOutputStream(fos);
    
            // RIFF
            dos.write("RIFF".getBytes()); writeLe32(dos, riffSize);
            dos.write("AVI ".getBytes());
    
            // LIST hdrl
            dos.write("LIST".getBytes()); writeLe32(dos, hdrlListSize);
            dos.write("hdrl".getBytes());
    
            // avih
            dos.write("avih".getBytes()); writeLe32(dos, 56);
            writeLe32(dos, 1000000 / fps);  // us per frame
            writeLe32(dos, 0);              // max bytes/sec
            writeLe32(dos, 0);              // padding
            writeLe32(dos, 0x10);           // flags AVIF_HASINDEX
            writeLe32(dos, frameCount);
            writeLe32(dos, 0);              // initial frames
            writeLe32(dos, 1);              // streams
            writeLe32(dos, 0);              // buffer size
            writeLe32(dos, width);
            writeLe32(dos, height);
            writeLe32(dos, 0); writeLe32(dos, 0); writeLe32(dos, 0); writeLe32(dos, 0);
    
            // LIST strl
            dos.write("LIST".getBytes()); writeLe32(dos, strlListSize);
            dos.write("strl".getBytes());
    
            // strh
            dos.write("strh".getBytes()); writeLe32(dos, 56);
            dos.write("vids".getBytes());
            dos.write("MJPG".getBytes());
            writeLe32(dos, 0);   // flags
            writeLe16(dos, (short)0); writeLe16(dos, (short)0); // priority, language
            writeLe32(dos, 0);   // initial frames
            writeLe32(dos, 1);   // scale
            writeLe32(dos, fps); // rate
            writeLe32(dos, 0);   // start
            writeLe32(dos, frameCount);
            writeLe32(dos, 0);   // buffer size
            writeLe32(dos, -1);  // quality
            writeLe32(dos, 0);   // sample size
            writeLe16(dos, (short)0); writeLe16(dos, (short)0);
            writeLe16(dos, (short)width); writeLe16(dos, (short)height);
    
            // strf (BITMAPINFOHEADER)
            dos.write("strf".getBytes()); writeLe32(dos, strfSize);
            writeLe32(dos, 40);           // header size
            writeLe32(dos, width);
            writeLe32(dos, height);
            writeLe16(dos, (short)1);     // planes
            writeLe16(dos, (short)24);    // bit count
            dos.write("MJPG".getBytes()); // compression
            writeLe32(dos, width * height * 3); // image size
            writeLe32(dos, 0); writeLe32(dos, 0); writeLe32(dos, 0); writeLe32(dos, 0);
    
            // LIST movi
            dos.write("LIST".getBytes()); writeLe32(dos, moviListSize);
            dos.write("movi".getBytes());
    
            // frames + build index simultaneously
            int[] offsets = new int[frameCount];
            int offset = 4; // start after 'movi'
            for (int i = 0; i < frameCount; i++) {
                byte[] frame = jpegFrames.get(i);
                offsets[i] = offset;
                dos.write("00dc".getBytes());
                writeLe32(dos, frame.length);
                dos.write(frame);
                if (frame.length % 2 != 0) dos.write(0);
                offset += 8 + frame.length + (frame.length % 2);
            }
    
            // idx1
            dos.write("idx1".getBytes()); writeLe32(dos, idx1Size);
            for (int i = 0; i < frameCount; i++) {
                dos.write("00dc".getBytes());
                writeLe32(dos, 0x10);          // AVIIF_KEYFRAME
                writeLe32(dos, offsets[i]);
                writeLe32(dos, jpegFrames.get(i).length);
            }
    
            dos.flush();
        }
    }
    
    private static void writeLe32(DataOutputStream dos, int v) throws IOException {
        dos.write(v & 0xFF);
        dos.write((v >> 8) & 0xFF);
        dos.write((v >> 16) & 0xFF);
        dos.write((v >> 24) & 0xFF);
    }
    
    private static void writeLe16(DataOutputStream dos, short v) throws IOException {
        dos.write(v & 0xFF);
        dos.write((v >> 8) & 0xFF);
    }
}

class ScreenWrapperPanel extends JPanel {
    private boolean hovered = false;
    private boolean maximized = false;
    private boolean recording = false;
    private final String target;
    private Point mousePos = null;
    private ScreenViewer viewer = null;

    private static final int BTN_SIZE = 22;
    private static final int BTN_MARGIN = 6;
    Rectangle btnBounds;
    Rectangle snapBounds;
    Rectangle switchBounds;
    Rectangle recordBounds;

    public ScreenWrapperPanel(String target) {
        this.target = target;
        setLayout(new BorderLayout());

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                hovered = true;
                repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                hovered = false;
                mousePos = null;
                repaint();
            }
            
            @Override
            public void mousePressed(MouseEvent e) {
                if (btnBounds != null && btnBounds.contains(e.getPoint())) e.consume();
                if (snapBounds != null && snapBounds.contains(e.getPoint())) e.consume();
                if (switchBounds != null && switchBounds.contains(e.getPoint())) {
                    e.consume();
                    onSwitchWindowPress();
                }
                if (recordBounds != null && recordBounds.contains(e.getPoint())) e.consume();
            }
            
            @Override
            public void mouseReleased(MouseEvent e) {
                if (btnBounds != null && btnBounds.contains(e.getPoint())) e.consume();
                if (snapBounds != null && snapBounds.contains(e.getPoint())) e.consume();
                if (switchBounds != null && switchBounds.contains(e.getPoint())) {
                    e.consume();
                    onSwitchWindowRelease();
                }
                if (recordBounds != null && recordBounds.contains(e.getPoint())) e.consume();
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                if (btnBounds != null && btnBounds.contains(e.getPoint())) {
                    e.consume();
                    maximized = !maximized;
                    onToggleMaximize(maximized);
                    repaint();
                    return;
                }
                if (snapBounds != null && snapBounds.contains(e.getPoint())) {
                    e.consume();
                    onSnap();
                    return;
                }
                if (recordBounds != null && recordBounds.contains(e.getPoint())) {
                    e.consume();
                    recording = !recording;
                    onToggleRecord(recording);
                    repaint();
                }
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                mousePos = e.getPoint();
                if ((btnBounds != null && btnBounds.contains(e.getPoint())) ||
                    (snapBounds != null && snapBounds.contains(e.getPoint())) ||
                    (switchBounds != null && switchBounds.contains(e.getPoint())) ||
                    (recordBounds != null && recordBounds.contains(e.getPoint()))) {
                    setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                } else {
                    setCursor(Cursor.getDefaultCursor());
                }
                repaint();
            }

            @Override
            public void mouseDragged(MouseEvent e) {
                mousePos = e.getPoint();
            }
        });
    }

    public void setViewer(ScreenViewer viewer) { this.viewer = viewer; }

    public boolean isOverButton(Point p) {
        return (btnBounds != null && btnBounds.contains(p)) ||
               (snapBounds != null && snapBounds.contains(p)) ||
               (switchBounds != null && switchBounds.contains(p)) ||
               (recordBounds != null && recordBounds.contains(p));
    }

    protected void onToggleMaximize(boolean isMaximized) {}
    protected void onSnap() {}
    protected void onSwitchWindowPress() {}
    protected void onSwitchWindowRelease() {} 
    protected void onToggleRecord(boolean isRecording) {}

    @Override
    protected void paintChildren(Graphics g) {
        super.paintChildren(g);

        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setClip(0, 0, getWidth(), getHeight());

        // ---- FPS label (top-right) — always visible ----
        if (viewer != null) {
            float fps = viewer.getFps();
            String fpsText = String.format("%.0f fps", fps);

            g2.setFont(new Font("Arial", Font.BOLD, 13));
            FontMetrics fm2 = g2.getFontMetrics();
            int fw = fm2.stringWidth(fpsText) + 16;
            int fh = fm2.getHeight() + 8;
            int fx = getWidth() - fw - BTN_MARGIN;
            int fy = 0;

            Color fpsBg = GUI.lightMode ? new Color(255,255,255,180) : new Color(0,0,0,180);
            Color fpsBorder = GUI.lightMode ? new Color(0,0,0,120) : new Color(255,255,255,120);
            Color fpsTextColor = GUI.lightMode ? Color.BLACK : Color.WHITE;
            
            g2.setColor(fpsBg);
            g2.fillRoundRect(fx, fy, fw, fh, 10, 10);
            
            g2.setColor(fpsBorder);
            g2.setStroke(new BasicStroke(1f));
            g2.drawRoundRect(fx, fy, fw, fh, 10, 10);

            Color fpsColor;

            if (fps >= 14) {
                fpsColor = GUI.lightMode ? new Color(0, 120, 0) : Color.GREEN;
            } else if (fps >= 8) {
                fpsColor = GUI.lightMode ? new Color(180, 140, 0) : Color.YELLOW;
            } else {
                fpsColor = GUI.lightMode ? new Color(160, 0, 0) : Color.RED;
            }
            
            g2.setColor(fpsColor);

            g2.drawString(fpsText, fx + 8, fy + fm2.getAscent() + 4);
        }

        // ---- Recording indicator — always visible when recording ----
        if (recording) {
            g2.setColor(new Color(200, 0, 0, 200));
            g2.fillOval(BTN_MARGIN, BTN_MARGIN, 10, 10);
        }

        if (!hovered && !maximized) {
            g2.dispose();
            return;
        }

        // ---- Maximize / Restore button (bottom-right) ----
        int bx = getWidth() - BTN_SIZE - BTN_MARGIN;
        int by = getHeight() - BTN_SIZE - BTN_MARGIN;
        btnBounds = new Rectangle(bx, by, BTN_SIZE, BTN_SIZE);
        drawButton(g2, bx, by);

        g2.setColor(GUI.lightMode?Color.BLACK:Color.WHITE);
        int pad = 5;
        int ix = bx + pad, iy = by + pad, is = BTN_SIZE - pad * 2;
        if (!maximized) {
            g2.drawRect(ix, iy, is, is);
            g2.drawRect(ix + 3, iy + 3, is - 6, is - 6);
        } else {
            int offset = 3;
            g2.drawRect(ix + offset, iy, is - offset, is - offset);
            g2.drawRect(ix, iy + offset, is - offset, is - offset);
        }

        // ---- Snap button (left of maximize) ----
        int sx = bx - BTN_SIZE - BTN_MARGIN;
        int sy = by;
        snapBounds = new Rectangle(sx, sy, BTN_SIZE, BTN_SIZE);
        drawButton(g2, sx, sy);

        g2.setColor(GUI.lightMode?Color.BLACK:Color.WHITE);
        g2.setStroke(new BasicStroke(1.2f));
        int cp = 5;
        g2.drawRoundRect(sx + cp, sy + cp + 2, BTN_SIZE - cp * 2, BTN_SIZE - cp * 2 - 3, 3, 3);
        int lensR = 3;
        int lcx = sx + BTN_SIZE / 2;
        int lcy = sy + BTN_SIZE / 2 + 2;
        g2.drawOval(lcx - lensR, lcy - lensR, lensR * 2, lensR * 2);
        g2.drawRect(sx + BTN_SIZE / 2 - 2, sy + cp, 4, 2);

        // ---- Switch window button (left of snap) ----
        int wx = sx - BTN_SIZE - BTN_MARGIN;
        int wy = by;
        switchBounds = new Rectangle(wx, wy, BTN_SIZE, BTN_SIZE);
        drawButton(g2, wx, wy);

        g2.setColor(GUI.lightMode?Color.BLACK:Color.WHITE);
        g2.setStroke(new BasicStroke(1.2f));
        int wp = 5;
        g2.drawRect(wx + wp, wy + wp + 2, BTN_SIZE - wp * 2 - 2, BTN_SIZE - wp * 2 - 2);
        g2.drawRect(wx + wp + 3, wy + wp, BTN_SIZE - wp * 2 - 2, BTN_SIZE - wp * 2 - 2);

        // ---- Record button (left of switch) ----
        int rx = wx - BTN_SIZE - BTN_MARGIN;
        int ry = by;
        recordBounds = new Rectangle(rx, ry, BTN_SIZE, BTN_SIZE);
        drawButton(g2, rx, ry);

        int rc = 5;
        if (recording) {
            g2.setColor(Color.RED);
            g2.fillOval(rx + rc, ry + rc, BTN_SIZE - rc * 2, BTN_SIZE - rc * 2);
        } else {
            g2.setColor(GUI.lightMode?Color.BLACK:Color.WHITE);
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawOval(rx + rc, ry + rc, BTN_SIZE - rc * 2, BTN_SIZE - rc * 2);
        }

        // ---- Hover label (top-center) ----
        if (hovered && mousePos != null) {
            g2.setFont(new Font("Arial", Font.BOLD, 13));
            FontMetrics fm = g2.getFontMetrics();
            int labelW = fm.stringWidth(target) + 16;
            int labelH = fm.getHeight() + 8;
            int lx = (getWidth() - labelW) / 2;
            int ly = 0;
        
            Color bg     = GUI.lightMode ? new Color(255, 255, 255, 200) : new Color(0, 0, 0, 180);
            Color border = GUI.lightMode ? new Color(0, 0, 0, 140)       : new Color(255, 255, 255, 120);
            Color text   = GUI.lightMode ? Color.BLACK                  : Color.WHITE;
        
            g2.setColor(bg);
            g2.fillRoundRect(lx, ly, labelW, labelH, 10, 10);
        
            g2.setColor(border);
            g2.setStroke(new BasicStroke(1f));
            g2.drawRoundRect(lx, ly, labelW, labelH, 10, 10);
        
            g2.setColor(text);
            g2.drawString(target, lx + 8, ly + fm.getAscent() + 4);
        }

        g2.dispose();
    }

    private void drawButton(Graphics2D g2, int x, int y) {
    
        Color fillColor;
        Color borderColor;
    
        if (GUI.lightMode) {
            // Light mode: light button, dark border
            fillColor   = new Color(255, 255, 255, 160);
            borderColor = new Color(0, 0, 0, 120);
        } else {
            // Dark mode: dark button, light border
            fillColor   = new Color(0, 0, 0, 160);
            borderColor = new Color(255, 255, 255, 200);
        }
    
        g2.setColor(fillColor);
        g2.fillRoundRect(x, y, BTN_SIZE, BTN_SIZE, 6, 6);
    
        g2.setColor(borderColor);
        g2.setStroke(new BasicStroke(1.5f));
        g2.drawRoundRect(x, y, BTN_SIZE, BTN_SIZE, 6, 6);
    }
}

class FileExplorer {

    private final String target;
    private final Node node;
    private final JFrame parentFrame;

    private JFrame explorerFrame;
    private JTextField pathField;
    private JList<FileEntry> fileList;
    private DefaultListModel<FileEntry> listModel;
    private JLabel statusLabel;
    private JLabel selectedLabel;

    private final String[] currentPath = { "/home/student" };
    private final java.util.List<FileEntry> currentEntries = new ArrayList<>();

    // Temp files to clean up on close
    private final java.util.List<File> tempFiles = new ArrayList<>();

    // Colors
    private static final Color BG       = new Color(18, 18, 18);
    private static final Color BG2      = new Color(26, 26, 26);
    private static final Color BG3      = new Color(36, 36, 36);
    private static final Color ACCENT   = new Color(0, 160, 100);
    private static final Color ACCENT2  = new Color(0, 120, 75);
    private static final Color FG       = new Color(220, 220, 220);
    private static final Color FG2      = new Color(140, 140, 140);
    private static final Color RED      = new Color(200, 60, 60);
    private static final Color SEL      = new Color(0, 80, 50);

    // Icons drawn programmatically
    private static final int ICON_SIZE = 16;

    // -------------------------------------------------------
    // FileEntry model
    // -------------------------------------------------------
    static class FileEntry {
        String name;
        String type; // "d", "f", "l"
        String size;
        String perms;
        String date;

        FileEntry(String name, String type, String size, String perms, String date) {
            this.name = name; this.type = type;
            this.size = size; this.perms = perms; this.date = date;
        }

        String ext() {
            int dot = name.lastIndexOf('.');
            return dot >= 0 ? name.substring(dot + 1).toLowerCase() : "";
        }

        boolean isImage() {
            String e = ext();
            return e.equals("png") || e.equals("jpg") || e.equals("jpeg")
                || e.equals("gif") || e.equals("bmp") || e.equals("webp");
        }

        boolean isText() {
            String e = ext();
            return e.equals("txt") || e.equals("java") || e.equals("py")
                || e.equals("sh") || e.equals("md") || e.equals("json")
                || e.equals("xml") || e.equals("html") || e.equals("css")
                || e.equals("js") || e.equals("log") || e.equals("conf")
                || e.equals("cfg") || e.equals("yaml") || e.equals("yml")
                || e.equals("class");
        }

        boolean isVideo() {
            String e = ext();
            return e.equals("mp4") || e.equals("avi") || e.equals("mkv")
                || e.equals("mov") || e.equals("webm");
        }

        boolean isAudio() {
            String e = ext();
            return e.equals("mp3") || e.equals("wav") || e.equals("ogg") || e.equals("flac");
        }

        boolean isArchive() {
            String e = ext();
            return e.equals("zip") || e.equals("tar") || e.equals("gz")
                || e.equals("bz2") || e.equals("7z") || e.equals("rar");
        }
    }

    // -------------------------------------------------------
    // Constructor
    // -------------------------------------------------------
    public FileExplorer(String target, Node node, JFrame parentFrame) {
        this.target = target;
        this.node = node;
        this.parentFrame = parentFrame;
    }

    public void show() {
        explorerFrame = new JFrame("File Explorer — " + target);
        explorerFrame.setSize(720, 550);
        explorerFrame.setMinimumSize(new Dimension(500, 350));
        explorerFrame.setLocationRelativeTo(parentFrame);
        explorerFrame.setLayout(new BorderLayout(0, 0));
        explorerFrame.getContentPane().setBackground(BG);

        explorerFrame.add(buildToolbar(), BorderLayout.NORTH);
        explorerFrame.add(buildFileList(), BorderLayout.CENTER);
        explorerFrame.add(buildStatusBar(), BorderLayout.SOUTH);

        explorerFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                cleanupTempFiles();
            }
        });

        explorerFrame.setVisible(true);
        loadDir();
    }

    // -------------------------------------------------------
    // Toolbar
    // -------------------------------------------------------
    private JPanel buildToolbar() {
        JPanel toolbar = new JPanel(new BorderLayout(0, 0));
        toolbar.setBackground(BG2);
        toolbar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BG3));

        // Nav buttons row
        JPanel navRow = new JPanel(new BorderLayout(4, 0));
        navRow.setBackground(BG2);
        navRow.setBorder(BorderFactory.createEmptyBorder(6, 8, 4, 8));

        JPanel navBtns = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        navBtns.setBackground(BG2);

        JButton upBtn     = mkBtn("↑", "Go up");
        JButton homeBtn   = mkBtn("⌂", "Home");
        JButton refreshBtn = mkBtn("↺", "Refresh");

        navBtns.add(upBtn);
        navBtns.add(homeBtn);
        navBtns.add(refreshBtn);

        pathField = new JTextField("/home/student");
        pathField.setBackground(BG3);
        pathField.setForeground(FG);
        pathField.setCaretColor(ACCENT);
        pathField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(60, 60, 60), 1),
            BorderFactory.createEmptyBorder(3, 8, 3, 8)
        ));
        pathField.setFont(new Font("Monospaced", Font.PLAIN, 12));

        navRow.add(navBtns, BorderLayout.WEST);
        navRow.add(pathField, BorderLayout.CENTER);

        // Action buttons row
        JPanel actionRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
        actionRow.setBackground(BG2);

        JButton downloadBtn  = mkAccentBtn("⬇ Download");
        JButton downloadDir  = mkAccentBtn("⬇ Download Folder");
        JButton renameBtn    = mkBtn("✎ Rename", null);
        JButton deleteBtn    = mkDangerBtn("✕ Delete");
        JButton newFolderBtn = mkBtn("+ Folder", null);

        actionRow.add(downloadBtn);
        actionRow.add(downloadDir);
        actionRow.add(renameBtn);
        actionRow.add(deleteBtn);
        actionRow.add(newFolderBtn);

        toolbar.add(navRow, BorderLayout.NORTH);
        toolbar.add(buildPinnedBar(), BorderLayout.CENTER);
        toolbar.add(actionRow, BorderLayout.SOUTH);

        // Listeners
        upBtn.addActionListener(e -> navigateUp());
        homeBtn.addActionListener(e -> { currentPath[0] = "/home/student"; loadDir(); });
        refreshBtn.addActionListener(e -> loadDir());
        pathField.addActionListener(e -> { currentPath[0] = pathField.getText().trim(); loadDir(); });

        downloadBtn.addActionListener(e -> downloadSelected(false));
        downloadDir.addActionListener(e -> downloadSelectedFolder());
        renameBtn.addActionListener(e -> renameSelected());
        deleteBtn.addActionListener(e -> deleteSelected());
        newFolderBtn.addActionListener(e -> createFolder());

        return toolbar;
    }
    
    private JPanel buildPinnedBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
        bar.setBackground(BG2);
        bar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BG3));
    
        String[][] pins = {
            { "🏠", "Home",      "/home/student" },
            { "🖥", "Desktop",   "/home/student/Desktop" },
            { "⬇", "Downloads", "/home/student/Downloads" },
            { "📄", "Documents", "/home/student/Documents" },
            { "🖼", "Pictures",  "/home/student/Pictures" },
            { "🎬", "Videos",    "/home/student/Videos" },
            { "🎵", "Music",     "/home/student/Music" },
        };
    
        for (String[] pin : pins) {
            JButton btn = new JButton(pin[0] + " " + pin[1]);
            btn.setBackground(BG3);
            btn.setForeground(FG2);
            btn.setFocusPainted(false);
            btn.setFont(new Font("Arial", Font.PLAIN, 10));
            btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(50, 50, 50), 1),
                BorderFactory.createEmptyBorder(2, 6, 2, 6)
            ));
            btn.setToolTipText(pin[2]);
            final String path = pin[2];
            btn.addActionListener(e -> {
                currentPath[0] = path;
                loadDir();
            });
    
            // Highlight if current path
            btn.addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) {
                    btn.setForeground(ACCENT);
                    btn.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(ACCENT, 1),
                        BorderFactory.createEmptyBorder(2, 6, 2, 6)
                    ));
                }
                @Override public void mouseExited(MouseEvent e) {
                    btn.setForeground(FG2);
                    btn.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(50, 50, 50), 1),
                        BorderFactory.createEmptyBorder(2, 6, 2, 6)
                    ));
                }
            });
    
            bar.add(btn);
        }
    
        return bar;
    }

    // -------------------------------------------------------
    // File list
    // -------------------------------------------------------
    private JScrollPane buildFileList() {
        listModel = new DefaultListModel<>();
        fileList = new JList<>(listModel);
        fileList.setBackground(BG);
        fileList.setForeground(FG);
        fileList.setFont(new Font("Monospaced", Font.PLAIN, 12));
        fileList.setFixedCellHeight(24);
        fileList.setSelectionBackground(SEL);
        fileList.setSelectionForeground(FG);
        fileList.setBorder(BorderFactory.createEmptyBorder(4, 0, 4, 0));
        fileList.setCellRenderer(new FileListRenderer());

        fileList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int idx = fileList.locationToIndex(e.getPoint());
                if (idx < 0 || idx >= currentEntries.size()) return;
                FileEntry entry = currentEntries.get(idx);

                if (e.getClickCount() == 2) {
                    if (entry.type.equals("d")) {
                        currentPath[0] = currentPath[0] + "/" + entry.name;
                        loadDir();
                    } else {
                        previewFile(entry);
                    }
                }
            }
        });

        fileList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int idx = fileList.getSelectedIndex();
                if (idx >= 0 && idx < currentEntries.size()) {
                    FileEntry entry = currentEntries.get(idx);
                    selectedLabel.setText(" " + entry.name + "  |  " + entry.size + "  |  " + entry.perms + "  |  " + entry.date);
                } else {
                    selectedLabel.setText(" ");
                }
            }
        });

        JScrollPane scroll = new JScrollPane(fileList);
        scroll.setBackground(BG);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setBackground(BG2);
        scroll.getVerticalScrollBar().setUnitIncrement(20);
        return scroll;
    }

    // -------------------------------------------------------
    // Status bar
    // -------------------------------------------------------
    private JPanel buildStatusBar() {
        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.setBackground(BG2);
        statusBar.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, BG3));

        statusLabel = new JLabel(" Loading...");
        statusLabel.setForeground(FG2);
        statusLabel.setFont(new Font("Arial", Font.PLAIN, 10));
        statusLabel.setBorder(BorderFactory.createEmptyBorder(3, 8, 3, 8));

        selectedLabel = new JLabel(" ");
        selectedLabel.setForeground(ACCENT);
        selectedLabel.setFont(new Font("Monospaced", Font.PLAIN, 10));
        selectedLabel.setBorder(BorderFactory.createEmptyBorder(3, 8, 3, 8));

        statusBar.add(statusLabel, BorderLayout.WEST);
        statusBar.add(selectedLabel, BorderLayout.CENTER);
        return statusBar;
    }

    // -------------------------------------------------------
    // Load directory
    // -------------------------------------------------------
    private void loadDir() {
        String path = currentPath[0];
        statusLabel.setText(" Loading " + path + "...");
        listModel.clear();
        currentEntries.clear();
        pathField.setText(path);

        String handlerId = "loadDir_" + System.currentTimeMillis();
        node.queryResultHandlers.put(handlerId, (source, output) -> {
            node.queryResultHandlers.remove(handlerId);
            SwingUtilities.invokeLater(() -> {
                listModel.clear();
                currentEntries.clear();

                // Sort: dirs first, then files
                java.util.List<FileEntry> dirs = new ArrayList<>();
                java.util.List<FileEntry> files = new ArrayList<>();

                for (String line : output.split("\n")) {
                    if (line.startsWith("total") || line.trim().isEmpty()) continue;
                    String[] parts = line.trim().split("\\s+", 9);
                    if (parts.length < 9) continue;
                    String name = parts[8];
                    if (name.equals(".") || name.equals("..")) continue;
                    boolean isDir = line.startsWith("d");
                    boolean isLink = line.startsWith("l");
                    String size = parts[4];
                    String perms = parts[0];
                    String date = parts[5] + " " + parts[6] + " " + parts[7];
                    String type = isDir ? "d" : isLink ? "l" : "f";
                    FileEntry entry = new FileEntry(name, type, formatSize(size), perms, date);
                    if (isDir) dirs.add(entry); else files.add(entry);
                }

                dirs.sort(Comparator.comparing(e -> e.name));
                files.sort(Comparator.comparing(e -> e.name));

                for (FileEntry e : dirs) { listModel.addElement(e); currentEntries.add(e); }
                for (FileEntry e : files) { listModel.addElement(e); currentEntries.add(e); }

                int total = currentEntries.size();
                long dirCount = currentEntries.stream().filter(e -> e.type.equals("d")).count();
                statusLabel.setText(" " + total + " items  (" + dirCount + " folders, " + (total - dirCount) + " files)  —  " + path);
            });
        });

        node.sendMessageToServer(target, "QUERY_CMD|" + node.location + "|" + handlerId + "|ls -la \"" + path + "\"");
    }

    // -------------------------------------------------------
    // Navigation
    // -------------------------------------------------------
    private void navigateUp() {
        String path = currentPath[0];
        int last = path.lastIndexOf('/');
        currentPath[0] = last > 0 ? path.substring(0, last) : "/";
        loadDir();
    }

    // -------------------------------------------------------
    // Preview file (double click)
    // -------------------------------------------------------
    private void previewFile(FileEntry entry) {
        String remotePath = currentPath[0] + "/" + entry.name;
    
        File tmpDir = new File(System.getProperty("user.dir"), "tmp");
        if (!tmpDir.exists()) tmpDir.mkdirs();
    
        if (entry.isText()) {
    
            String handlerId = "preview_" + System.currentTimeMillis();
            node.queryResultHandlers.put(handlerId, (source, output) -> {
                node.queryResultHandlers.remove(handlerId);
                SwingUtilities.invokeLater(() -> {
                    JFrame previewFrame = new JFrame("Preview — " + entry.name);
                    previewFrame.setSize(700, 500);
                    previewFrame.setLocationRelativeTo(explorerFrame);
    
                    JTextArea textArea = new JTextArea(output);
                    textArea.setEditable(false);
                    textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
                    textArea.setBackground(BG);
                    textArea.setForeground(new Color(180, 220, 180));
                    textArea.setCaretColor(ACCENT);
    
                    JScrollPane scroll = new JScrollPane(textArea);
                    scroll.setBorder(null);
    
                    JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
                    bottomBar.setBackground(BG2);
                    JButton dlBtn = mkAccentBtn("⬇ Download");
                    dlBtn.addActionListener(e2 -> downloadSelected(true));
                    bottomBar.add(dlBtn);
    
                    previewFrame.setLayout(new BorderLayout());
                    previewFrame.add(scroll, BorderLayout.CENTER);
                    previewFrame.add(bottomBar, BorderLayout.SOUTH);
                    previewFrame.getContentPane().setBackground(BG);
                    previewFrame.setVisible(true);
                });
            });
    
            node.sendMessageToServer(target, "QUERY_CMD|" + node.location + "|" + handlerId + "|cat \"" + remotePath + "\"");
    
        } else if (entry.isImage() || entry.isVideo() || entry.isAudio()) {
    
            statusLabel.setText(" Downloading for preview: " + entry.name + "...");
            File tempFile = new File(tmpDir, entry.name);
            tempFiles.add(tempFile);
    
            node.sendMessageToServer(target,
                "SEND_FILE_TO|" + node.location + "|" + remotePath + "|" + tmpDir.getAbsolutePath());
    
            new Thread(() -> {
                for (int i = 0; i < 30; i++) {
                    try { Thread.sleep(500); } catch (InterruptedException ignored) { break; }
                    if (tempFile.exists() && tempFile.length() > 0) {
    
                        if (entry.isImage()) {
                            try {
                                BufferedImage img = ImageIO.read(tempFile);
                                if (img == null) {
                                    Runtime.getRuntime().exec(new String[]{"xdg-open", tempFile.getAbsolutePath()});
                                    SwingUtilities.invokeLater(() -> statusLabel.setText(" Opened with system viewer: " + entry.name));
                                } else {
                                    SwingUtilities.invokeLater(() -> {
                                        try {
                                            JFrame imgFrame = new JFrame("Preview — " + entry.name);
                                            imgFrame.setSize(
                                                Math.min(img.getWidth() + 40, 1200),
                                                Math.min(img.getHeight() + 80, 800)
                                            );
                                            imgFrame.setLocationRelativeTo(explorerFrame);
    
                                            JLabel imgLabel = new JLabel(new ImageIcon(
                                                img.getScaledInstance(
                                                    Math.min(img.getWidth(), 1160),
                                                    Math.min(img.getHeight(), 720),
                                                    Image.SCALE_SMOOTH
                                                )
                                            ));
                                            imgLabel.setHorizontalAlignment(SwingConstants.CENTER);
                                            imgLabel.setBackground(Color.BLACK);
                                            imgLabel.setOpaque(true);
    
                                            JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
                                            bottomBar.setBackground(BG2);
                                            JButton dlBtn = mkAccentBtn("⬇ Download");
                                            dlBtn.addActionListener(e2 -> downloadSelected(true));
                                            bottomBar.add(dlBtn);
    
                                            imgFrame.setLayout(new BorderLayout());
                                            imgFrame.add(new JScrollPane(imgLabel), BorderLayout.CENTER);
                                            imgFrame.add(bottomBar, BorderLayout.SOUTH);
                                            imgFrame.getContentPane().setBackground(Color.BLACK);
                                            imgFrame.setVisible(true);
                                        } catch (Exception ex) { ex.printStackTrace(); }
                                    });
                                }
                            } catch (Exception ex) {
                                ex.printStackTrace();
                                showError("Preview failed: " + ex.getMessage());
                            }
    
                        } else {
                            try {
                                Runtime.getRuntime().exec(new String[]{"xdg-open", tempFile.getAbsolutePath()});
                                SwingUtilities.invokeLater(() -> statusLabel.setText(" Opened: " + entry.name));
                            } catch (Exception ex) { ex.printStackTrace(); }
                        }
                        return;
                    }
                }
                SwingUtilities.invokeLater(() -> statusLabel.setText(" Timed out waiting for: " + entry.name));
            }).start();
    
        } else {
    
            int choice = JOptionPane.showConfirmDialog(
                explorerFrame,
                "No preview available for ." + entry.ext() + " files.\nDownload it?",
                "Preview",
                JOptionPane.YES_NO_OPTION
            );
            if (choice == JOptionPane.YES_OPTION) downloadSelected(true);
        }
    }

    // -------------------------------------------------------
    // Download selected file
    // -------------------------------------------------------
    private void downloadSelected(boolean fromPreview) {
        int idx = fileList.getSelectedIndex();
        if (idx < 0 || idx >= currentEntries.size()) {
            JOptionPane.showMessageDialog(explorerFrame, "Select a file first.");
            return;
        }
    
        FileEntry entry = currentEntries.get(idx);
    
        if (entry.type.equals("d")) {
            JOptionPane.showMessageDialog(explorerFrame, "Use 'Download Folder' for directories.");
            return;
        }
    
        String remotePath = currentPath[0] + "/" + entry.name;
    
        // tmp cache location
        File tmpDir = new File(System.getProperty("user.dir"), "tmp");
        File cachedFile = new File(tmpDir, entry.name);
    
        if (fromPreview && cachedFile.exists()) {
    
            JFileChooser chooser = new JFileChooser();
            chooser.setSelectedFile(new File(entry.name));
    
            int res = chooser.showSaveDialog(explorerFrame);
            if (res != JFileChooser.APPROVE_OPTION) return;
    
            File dest = chooser.getSelectedFile();
    
            try {
                Files.copy(cachedFile.toPath(), dest.toPath(),
                           StandardCopyOption.REPLACE_EXISTING);
    
                statusLabel.setText(" Saved from preview cache: " + entry.name);
            } catch (IOException ex) {
                showError("Save failed: " + ex.getMessage());
            }
    
        } else {
            // fallback: request from remote
            node.sendMessageToServer(target,
                "SEND_FILE_TO|" + node.location + "|" + remotePath);
    
            statusLabel.setText(" Download requested: " + entry.name);
        }
    }

    // -------------------------------------------------------
    // Download folder (zip it first, then send)
    // -------------------------------------------------------
    private void downloadSelectedFolder() {
        int idx = fileList.getSelectedIndex();
        if (idx < 0 || idx >= currentEntries.size()) {
            JOptionPane.showMessageDialog(explorerFrame, "Select a folder first.");
            return;
        }
        FileEntry entry = currentEntries.get(idx);
        if (!entry.type.equals("d")) {
            JOptionPane.showMessageDialog(explorerFrame, "Select a folder to download.");
            return;
        }
        String remotePath = currentPath[0] + "/" + entry.name;
        String zipPath = "/tmp/" + entry.name + "_" + System.currentTimeMillis() + ".zip";

        // Zip on remote, then send zip back
        node.sendMessageToServer(target,
            "CMD|bash -c 'cd \"" + currentPath[0] + "\" && zip -r \"" + zipPath + "\" \"" + entry.name + "\"'");

        // Wait a moment then request the zip
        new Thread(() -> {
            try {
                Thread.sleep(3000); // let zip finish
                node.sendMessageToServer(target, "SEND_FILE_TO|" + node.location + "|" + zipPath);
                // Cleanup zip after sending
                Thread.sleep(5000);
                node.sendMessageToServer(target, "CMD|rm -f \"" + zipPath + "\"");
            } catch (InterruptedException ignored) {}
        }).start();

        statusLabel.setText(" Zipping and downloading: " + entry.name + "...");
    }

    // -------------------------------------------------------
    // Rename
    // -------------------------------------------------------
    private void renameSelected() {
        int idx = fileList.getSelectedIndex();
        if (idx < 0 || idx >= currentEntries.size()) {
            JOptionPane.showMessageDialog(explorerFrame, "Select a file or folder first.");
            return;
        }
        FileEntry entry = currentEntries.get(idx);
        String newName = JOptionPane.showInputDialog(explorerFrame,
            "Rename \"" + entry.name + "\" to:", "Rename", JOptionPane.PLAIN_MESSAGE);
        if (newName == null || newName.trim().isEmpty()) return;
        newName = newName.trim();

        String oldPath = currentPath[0] + "/" + entry.name;
        String newPath = currentPath[0] + "/" + newName;
        node.sendMessageToServer(target, "CMD|mv \"" + oldPath + "\" \"" + newPath + "\"");

        // Refresh after a short delay
        final String finalNewName = newName;
        new Thread(() -> {
            try { Thread.sleep(500); } catch (InterruptedException ignored) {}
            SwingUtilities.invokeLater(this::loadDir);
        }).start();
    }

    // -------------------------------------------------------
    // Delete
    // -------------------------------------------------------
    private void deleteSelected() {
        int idx = fileList.getSelectedIndex();
        if (idx < 0 || idx >= currentEntries.size()) {
            JOptionPane.showMessageDialog(explorerFrame, "Select a file or folder first.");
            return;
        }
        FileEntry entry = currentEntries.get(idx);
        String remotePath = currentPath[0] + "/" + entry.name;

        int confirm = JOptionPane.showConfirmDialog(explorerFrame,
            "Permanently delete \"" + entry.name + "\"?",
            "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            String cmd = entry.type.equals("d") ? "rm -rf" : "rm -f";
            node.sendMessageToServer(target, "CMD|" + cmd + " \"" + remotePath + "\"");
            new Thread(() -> {
                try { Thread.sleep(500); } catch (InterruptedException ignored) {}
                SwingUtilities.invokeLater(this::loadDir);
            }).start();
        }
    }

    // -------------------------------------------------------
    // Create folder
    // -------------------------------------------------------
    private void createFolder() {
        String name = JOptionPane.showInputDialog(explorerFrame,
            "New folder name:", "New Folder", JOptionPane.PLAIN_MESSAGE);
        if (name == null || name.trim().isEmpty()) return;
        String path = currentPath[0] + "/" + name.trim();
        node.sendMessageToServer(target, "CMD|mkdir -p \"" + path + "\"");
        new Thread(() -> {
            try { Thread.sleep(500); } catch (InterruptedException ignored) {}
            SwingUtilities.invokeLater(this::loadDir);
        }).start();
    }

    // -------------------------------------------------------
    // Cleanup temp files
    // -------------------------------------------------------
    private void cleanupTempFiles() {
        for (File f : tempFiles) {
            if (f.exists()) f.delete();
        }
    }

    // -------------------------------------------------------
    // Utility
    // -------------------------------------------------------
    private String formatSize(String rawSize) {
        try {
            long bytes = Long.parseLong(rawSize);
            if (bytes < 1024) return bytes + " B";
            if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
            if (bytes < 1024 * 1024 * 1024) return String.format("%.1f MB", bytes / (1024.0 * 1024));
            return String.format("%.1f GB", bytes / (1024.0 * 1024 * 1024));
        } catch (NumberFormatException e) { return rawSize; }
    }

    private void showError(String msg) {
        SwingUtilities.invokeLater(() ->
            JOptionPane.showMessageDialog(explorerFrame, msg, "Error", JOptionPane.ERROR_MESSAGE));
    }

    // -------------------------------------------------------
    // Button factories
    // -------------------------------------------------------
    private JButton mkBtn(String text, String tooltip) {
        JButton btn = new JButton(text);
        btn.setBackground(BG3);
        btn.setForeground(FG);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(60, 60, 60), 1),
            BorderFactory.createEmptyBorder(3, 8, 3, 8)
        ));
        btn.setFont(new Font("Arial", Font.PLAIN, 11));
        if (tooltip != null) btn.setToolTipText(tooltip);
        return btn;
    }

    private JButton mkAccentBtn(String text) {
        JButton btn = mkBtn(text, null);
        btn.setBackground(ACCENT2);
        btn.setForeground(Color.WHITE);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(ACCENT, 1),
            BorderFactory.createEmptyBorder(3, 8, 3, 8)
        ));
        return btn;
    }

    private JButton mkDangerBtn(String text) {
        JButton btn = mkBtn(text, null);
        btn.setBackground(new Color(80, 30, 30));
        btn.setForeground(new Color(255, 120, 120));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(RED, 1),
            BorderFactory.createEmptyBorder(3, 8, 3, 8)
        ));
        return btn;
    }

    // -------------------------------------------------------
    // Cell Renderer
    // -------------------------------------------------------
    class FileListRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value,
                int index, boolean isSelected, boolean cellHasFocus) {

            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (!(value instanceof FileEntry)) return this;

            FileEntry entry = (FileEntry) value;
            setBackground(isSelected ? SEL : (index % 2 == 0 ? BG : new Color(22, 22, 22)));
            setForeground(isSelected ? FG : getEntryColor(entry));
            setFont(new Font("Monospaced", Font.PLAIN, 12));
            setBorder(BorderFactory.createEmptyBorder(2, 8, 2, 8));
            setIcon(getEntryIcon(entry));

            // Format: name + padding + size + date
            String name = entry.name + (entry.type.equals("d") ? "/" : "");
            String info = String.format("%-8s  %s", entry.size, entry.date);
            setText(String.format("%-40s %s", name, info));

            return this;
        }

        private Color getEntryColor(FileEntry entry) {
            if (entry.type.equals("d")) return new Color(100, 180, 255);
            if (entry.type.equals("l")) return new Color(180, 230, 180);
            if (entry.isImage())  return new Color(255, 180, 100);
            if (entry.isText())   return new Color(200, 200, 200);
            if (entry.isVideo())  return new Color(200, 120, 255);
            if (entry.isAudio())  return new Color(255, 200, 100);
            if (entry.isArchive()) return new Color(255, 150, 100);
            return FG2;
        }

        private Icon getEntryIcon(FileEntry entry) {
            return new Icon() {
                public int getIconWidth()  { return ICON_SIZE + 4; }
                public int getIconHeight() { return ICON_SIZE; }

                public void paintIcon(Component c, Graphics g, int x, int y) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                    if (entry.type.equals("d")) {
                        // Folder icon
                        g2.setColor(new Color(80, 140, 200));
                        g2.fillRoundRect(x, y + 3, ICON_SIZE, ICON_SIZE - 3, 2, 2);
                        g2.fillRoundRect(x, y + 1, ICON_SIZE / 2, 4, 2, 2);
                        g2.setColor(new Color(100, 160, 220));
                        g2.fillRoundRect(x + 1, y + 4, ICON_SIZE - 2, ICON_SIZE - 5, 2, 2);

                    } else if (entry.type.equals("l")) {
                        // Symlink icon
                        g2.setColor(new Color(100, 200, 120));
                        g2.drawRoundRect(x, y + 1, ICON_SIZE - 1, ICON_SIZE - 2, 2, 2);
                        g2.drawString("→", x + 2, y + ICON_SIZE - 3);

                    } else if (entry.isImage()) {
                        // Image icon — small landscape
                        g2.setColor(new Color(60, 60, 60));
                        g2.fillRoundRect(x, y + 1, ICON_SIZE, ICON_SIZE - 2, 2, 2);
                        g2.setColor(new Color(255, 180, 80));
                        g2.fillOval(x + 2, y + 2, 4, 4); // sun
                        g2.setColor(new Color(80, 160, 80));
                        int[] mx = {x+1, x+6, x+ICON_SIZE-1};
                        int[] my = {y+ICON_SIZE-2, y+7, y+ICON_SIZE-2};
                        g2.fillPolygon(mx, my, 3);

                    } else if (entry.isText() || entry.isText()) {
                        // Document icon
                        g2.setColor(new Color(200, 200, 200));
                        g2.fillRoundRect(x + 1, y + 1, ICON_SIZE - 2, ICON_SIZE - 2, 2, 2);
                        g2.setColor(new Color(120, 120, 120));
                        for (int i = 0; i < 3; i++) {
                            g2.drawLine(x + 3, y + 4 + i * 3, x + ICON_SIZE - 3, y + 4 + i * 3);
                        }

                    } else if (entry.isVideo()) {
                        // Video icon
                        g2.setColor(new Color(80, 40, 100));
                        g2.fillRoundRect(x, y + 1, ICON_SIZE, ICON_SIZE - 2, 2, 2);
                        g2.setColor(new Color(180, 100, 255));
                        int[] px = {x + 4, x + 4, x + ICON_SIZE - 3};
                        int[] py = {y + 3, y + ICON_SIZE - 3, y + ICON_SIZE / 2};
                        g2.fillPolygon(px, py, 3);

                    } else if (entry.isAudio()) {
                        // Audio icon — musical note
                        g2.setColor(new Color(255, 180, 50));
                        g2.fillOval(x + 1, y + ICON_SIZE - 6, 5, 4);
                        g2.fillOval(x + 7, y + ICON_SIZE - 8, 5, 4);
                        g2.setStroke(new BasicStroke(1.5f));
                        g2.drawLine(x + 6, y + ICON_SIZE - 4, x + 6, y + 2);
                        g2.drawLine(x + 12, y + ICON_SIZE - 6, x + 12, y + 2);
                        g2.drawLine(x + 6, y + 2, x + 12, y + 2);

                    } else if (entry.isArchive()) {
                        // Archive icon — box with stripes
                        g2.setColor(new Color(200, 100, 50));
                        g2.fillRoundRect(x, y + 1, ICON_SIZE, ICON_SIZE - 2, 2, 2);
                        g2.setColor(new Color(240, 140, 80));
                        g2.fillRect(x, y + 5, ICON_SIZE, 3);
                        g2.setColor(new Color(200, 100, 50));
                        g2.fillRect(x + ICON_SIZE/2 - 1, y + 4, 3, 5);

                    } else {
                        // Generic file icon
                        g2.setColor(new Color(80, 80, 80));
                        g2.fillRoundRect(x + 1, y + 1, ICON_SIZE - 4, ICON_SIZE - 2, 2, 2);
                        g2.setColor(new Color(60, 60, 60));
                        g2.fillPolygon(
                            new int[]{x + ICON_SIZE - 4, x + ICON_SIZE - 4, x + ICON_SIZE - 1},
                            new int[]{y + 1, y + 4, y + 4}, 3);
                    }

                    g2.dispose();
                }
            };
        }
    }
}