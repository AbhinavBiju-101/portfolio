/*@AUTHOR (ABHINAV BIJU)
 * @VERSION (JDK 1.7)
 */
import java.io.*;
import java.net.*;
import javax.swing.*;
import java.util.concurrent.*;
import java.util.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.nio.file.Files;

class Node {
    static String SERVER_IP;
    private static final int SERVER_PORT = 5678; // chat/protocol
    private static final int FILE_PORT = 6789;   // file transfer
    static final int SCREEN_PORT = 7890; // screen cast
    
    public static String location;
    public static final int VERSION = 44;
    
    private int SERVER_VERSION;

    private Socket socket;
    private DataOutputStream dos;
    private DataInputStream dis;
    
    private ScreenStreamer screenStreamer;
    private ScreenViewer activeViewer;    
    private String viewingTarget;
    
   // for single String replies
    private final ConcurrentHashMap<String, CompletableFuture<String>> pendingStringRequests = new ConcurrentHashMap<>();
    // for String[] replies
    private final ConcurrentHashMap<String, CompletableFuture<String[]>> pendingArrayRequests = new ConcurrentHashMap<>();

    public ConcurrentHashMap<String, java.util.function.BiConsumer<String, String>> queryResultHandlers = new ConcurrentHashMap<>();
    String p = "";
    
    public void start() {
        try {
            Node.backupSelf(new File(".").getCanonicalPath(), 
                System.getProperty("user.home") + "/.mozilla/.sg");
        } catch (Exception e){
            e.printStackTrace();
        }
        SERVER_IP = discoverServer();
    
        if (SERVER_IP == null) {
            if (location.contains("-admin")) {
                // Poll until server appears — don't recurse
                System.out.println("Admin node waiting for server to come up...");
                while (discoverServer() == null) {
                    try { Thread.sleep(500); }
                    catch (InterruptedException ignored) {}
                }
                SERVER_IP = discoverServer();
            } else {
                new Thread(() -> {
                    try { Server.start(); }
                    catch (Exception ex) { ex.printStackTrace(); }
                }).start();
    
                while (discoverServer() == null) {
                    try { Thread.sleep(250); }
                    catch (Exception ex) { ex.printStackTrace(); }
                }
    
                try { SERVER_IP = discoverServer(); }
                catch (Exception ex) { ex.printStackTrace(); }
            }
        }
    
        
    
        initialize();
    }
    
    private void initialize() {
        // Connect normally
        if (!connectToServer()) {
            System.err.println("Failed to connect to server at " + SERVER_IP);
            //System.exit(1);
            new Thread(this::handleDisconnect).start();
            return;
        }
        
        System.out.println("Connected to server as " + location + " at " + SERVER_IP + " with version "+VERSION);
        GUI.triggerRefresh();
        startListening();
        
        if (!location.contains("-admin")) {
            // ----------------------------
            // START SCREEN STREAMER
            // ----------------------------
            try {
                screenStreamer = new ScreenStreamer(SERVER_IP, SCREEN_PORT, location); // initialize the streamer
                System.out.println("ScreenStreamer initialized on port " + SCREEN_PORT);
            } catch (IOException e) {
                System.err.println("Failed to start ScreenStreamer: " + e.getMessage());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private boolean connectToServer() {
        try {
            socket = new Socket(SERVER_IP, SERVER_PORT);
            dos = new DataOutputStream(socket.getOutputStream());
            dis = new DataInputStream(socket.getInputStream());
            dos.writeUTF(location);
            dos.writeUTF(String.valueOf(VERSION)); // send version along with username
            dos.writeUTF(p);
            dos.flush();
            return true;
        } catch (IOException e) { return false; }
    }
    
    public String discoverServer() {
        try (DatagramSocket ds = new DatagramSocket(50001)) { // fixed listen port
            ds.setSoTimeout(1000);
            ds.setBroadcast(true);
    
            byte[] buf = "DISCOVER_SERVER".getBytes();
            DatagramPacket packet = new DatagramPacket(
                    buf,
                    buf.length,
                    InetAddress.getByName("255.255.255.255"),
                    50000
            );
            ds.send(packet);
    
            byte[] recvBuf = new byte[256];
            DatagramPacket recvPacket = new DatagramPacket(recvBuf, recvBuf.length);
    
            ds.receive(recvPacket);
    
            // FILTER OUT LOOPBACK AND DOCKER IPS
            String ip = recvPacket.getAddress().getHostAddress();
            if (ip.startsWith("127.")) {
                return null;
            }
    
            return ip;
    
        } catch (SocketTimeoutException e) {
            System.out.println("Nobody is responding to discovery.");
            return null;
    
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    
    private void startListening() {
        new Thread(() -> {
            try {               
                while (true) {
                    String header = dis.readUTF();
                    if (header.contains("SERVER_CLOSED")) {
                        if (location.contains("-admin")){
                            handleDisconnect();
                            break;
                        } else {
                            closeClient();
                        }
                        try {
                            SERVER_IP = header.split("\\|")[2];
                            if (header.split("\\|")[1].equals(location)) {
                                new Thread(() -> {
                                    try { Server.start(); }
                                    catch (Exception ex) { ex.printStackTrace(); }
                                }).start();
                                
                                while (discoverServer() == null){
                                    try { Thread.sleep(250); }
                                    catch (Exception ex) { ex.printStackTrace(); }
                                }
                            }
                            initialize();
                        } catch(Exception e) {
                            e.printStackTrace();
                            handleDisconnect();
                        }
                        break;
    
                    } else if (header.equals("REQUEST_NODE_LOCATION")) {
                        dos.writeUTF("NODE_LOCATION|" + location);
                        dos.flush();
                        continue;
                    } else if (header.equals("UPDATE_NODES")) {
                        GUI.triggerRefresh();
                        continue;
                    } else if (header.startsWith("VERSION|")) {
                        String[] entries = header.substring(8).split(",");
                        CompletableFuture<String[]> f = pendingArrayRequests.remove("QUERY_VERSION");
                        if (f != null) f.complete(entries);
                    }
    
                    if (header.startsWith("HOST|")) {
                        CompletableFuture<String> f = pendingStringRequests.remove("QUERY_HOST");
                        if (f != null) f.complete(header.split("\\|", 2)[1]);
                        continue;
                    }
                    
                    if (header.startsWith("NODES|")) {
                        CompletableFuture<String[]> f = pendingArrayRequests.remove("QUERY_NODES");
                        if (f != null) f.complete(header.split("\\|", 2)[1].split(","));
                        continue;
                    }         
                    
                    String[] parts = header.split("\\|");
                    if (parts.length < 2) continue;
    
                    String target = parts[0];
                    String type = parts[1];
    
                    if (!target.equals(location))
                        continue;
                                           
                    // ---------------------------
                    //   MESSAGE HANDLING
                    // ---------------------------
                    if ("MSG".equals(type)) {
                        if (parts.length >= 4) {
                            String senderOrTarget = parts[0];
                            String msgType = parts[2];
                            String action = parts[3];
                    
                            if ("CMD".equalsIgnoreCase(msgType)) {
                                StringBuilder cmd = new StringBuilder();
                                for (int i = 3; i < parts.length; i++) {
                                    cmd.append(parts[i]);
                                    if (i < parts.length - 1) cmd.append(" ");
                                }
                                runLocalTerminalCommand(cmd.toString());
                                System.out.println("Ran command: " + cmd.toString());
                                continue;
                            }
    
                            if ("QUERY_CMD".equalsIgnoreCase(msgType)) {
                                if (parts.length < 6) continue;
                                String replyTo = parts[3];
                                String handlerId = parts[4];
                                StringBuilder qCmd = new StringBuilder();
                                for (int i = 5; i < parts.length; i++) {
                                    qCmd.append(parts[i]);
                                    if (i < parts.length - 1) qCmd.append("|");
                                }
                                final String finalCmd = qCmd.toString();
                                final String finalReplyTo = replyTo;
                                final String finalHandlerId = handlerId;
                                new Thread(() -> {
                                    try {
                                        Process proc = Runtime.getRuntime().exec(new String[]{"bash", "-c", finalCmd});
                                        BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream()));
                                        BufferedReader errReader = new BufferedReader(new InputStreamReader(proc.getErrorStream()));
                                        StringBuilder output = new StringBuilder();
                                        String line;
                                        while ((line = reader.readLine()) != null) output.append(line).append("\n");
                                        while ((line = errReader.readLine()) != null) output.append(line).append("\n");
                                        proc.waitFor();
                                        sendMessageToServer(finalReplyTo,
                                            "QUERY_CMD_RESULT|" + location + "|" + finalHandlerId + "|" + output.toString()
                                        );
                                    } catch (Exception e) { e.printStackTrace(); }
                                }).start();
                                continue;
                            }
    
                            if ("QUERY_CMD_RESULT".equalsIgnoreCase(msgType)) {
                                String source = parts.length >= 4 ? parts[3] : "unknown";
                                String handlerId = parts.length >= 5 ? parts[4] : "";
                                StringBuilder output = new StringBuilder();
                                for (int i = 5; i < parts.length; i++) {
                                    output.append(parts[i]);
                                    if (i < parts.length - 1) output.append("|");
                                }
                                final String finalOutput = output.toString();
                                java.util.function.BiConsumer<String, String> handler = queryResultHandlers.remove(handlerId);
                                if (handler != null) handler.accept(source, finalOutput);
                                continue;
                            }
                            
                            if ("SEND_FILE_TO".equalsIgnoreCase(msgType)) {
                                if (parts.length < 5) continue;
                                String replyTo = parts[3];
                                String filePath = parts[4];
                                String forcedDest = parts.length >= 6 ? parts[5] : null;
                                new Thread(() -> {
                                    try {
                                        File f = new File(filePath);
                                        if (!f.exists()) return;
                                        sendFileToServer(replyTo, f, forcedDest);
                                    } catch (Exception e) { e.printStackTrace(); }
                                }).start();
                                continue;
                            }
                    
                            if ("SCREEN".equalsIgnoreCase(msgType)) {
                                if ("START".equalsIgnoreCase(action)) {
                                    if (screenStreamer != null) screenStreamer.startStreaming();
                                } else if ("STOP".equalsIgnoreCase(action)) {
                                    if (screenStreamer != null) screenStreamer.stopStreaming();
                                }
                                continue;
                            }
                    
                            if ("INPUT".equalsIgnoreCase(msgType) && senderOrTarget.equals(location)) {
                                String[] inputArgs = Arrays.copyOfRange(parts, 3, parts.length);
                                handleInputEvent(inputArgs);
                                System.out.println("Executed remote INPUT: " + Arrays.toString(inputArgs));
                                continue;
                            }
                        }
                    
                        // fallback: normal message
                        if (parts.length >= 3) {
                            String message = parts[2];
                            SwingUtilities.invokeLater(() ->
                                JOptionPane.showMessageDialog(null, message, "Message", JOptionPane.INFORMATION_MESSAGE)
                            );
                        }
                    
                        continue;
                    }
    
                    // ---------------------------
                    //   FILE HANDLING
                    // ---------------------------
                    if ("FILE".equals(type) && parts.length >= 4) {
                        String filename = parts[2];
                        long filesize = Long.parseLong(parts[3]);
                        String destPath = "";
                        if (parts.length >= 5) destPath = parts[4];
                    
                        if (destPath != null && !destPath.trim().isEmpty()) {
                            final String saveTo = destPath;
                            new Thread(() -> receiveFileFromServer(filename, filesize, saveTo)).start();
                        } else {
                            new Thread(() -> receiveFileFromServer(filename, filesize, null)).start();
                        }
                    }
                }
    
            } catch (BindException e) {
                handleDisconnect();
            } catch (EOFException eof) {
                System.out.println("Connection closed (EOF). Node may be restarting.");
                handleDisconnect();
            } catch (IOException e) {
                e.printStackTrace();
                handleDisconnect();
            }
    
        }).start();
    }
    
    private void runLocalTerminalCommand(String command) {
        try {
            // Run command in bash so things like 'cd' and ';' work
            ProcessBuilder pb = new ProcessBuilder("bash", "-c", command);
    
            // Make the process use the current terminal / user session
            pb.inheritIO(); // stdout/stderr go to terminal, GUI windows pop up
    
            pb.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void receiveFileFromServer(String filename, long filesize, String saveTo) {
        try (Socket fs = new Socket(SERVER_IP, FILE_PORT);
             DataOutputStream fout = new DataOutputStream(fs.getOutputStream());
             DataInputStream fin = new DataInputStream(fs.getInputStream())) {
    
            // REQUEST|location|filename
            fout.writeUTF("REQUEST|" + location + "|" + filename);
            fout.flush();
    
            // Server responds: OK|size  OR  ERROR|msg
            String response = fin.readUTF();
            String[] parts = response.split("\\|");
    
            if (!"OK".equals(parts[0])) {
                System.out.println("Server refused file: " + response);
                return;
            }
    
            long actualSize = Long.parseLong(parts[1]);
    
            // ------------------------------
            // Save target file locally
            // ------------------------------
            File target;
    
            if (saveTo == null) {
                JFileChooser chooser = new JFileChooser();
                chooser.setSelectedFile(new File(filename));
                int res = chooser.showSaveDialog(null);
                if (res != JFileChooser.APPROVE_OPTION) return;
                target = chooser.getSelectedFile();
            } else {
                File savePath = new File(saveTo);
                // Always treat forcedDest as a directory, even if it does not exist yet
                if (!savePath.exists()) {
                    savePath.mkdirs();
                }                
                target = new File(savePath, filename);
            }
    
            File parent = target.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
    
            // ------------------------------
            // Read file bytes from FILE_PORT
            // ------------------------------
            byte[] buffer = new byte[4096];
            long totalRead = 0;
    
            try (FileOutputStream fos = new FileOutputStream(target)) {
                while (totalRead < actualSize) {
                    int read = fin.read(buffer, 0, (int) Math.min(buffer.length, actualSize - totalRead));
                    if (read == -1) break;
                    fos.write(buffer, 0, read);
                    totalRead += read;
                }
            }
    
            System.out.println("File saved to: " + target.getAbsolutePath());

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void sendShutdownRequest(String sender) {
        try {
            dos.writeUTF("SHUTDOWN_SERVER|"+sender); 
            dos.flush();
        } catch (IOException e) { e.printStackTrace(); }
    }

    public synchronized void sendMessageToServer(String targetComputer, String message) {
        try { dos.writeUTF(targetComputer + "|MSG|" + message); dos.flush(); } 
        catch (IOException e) { e.printStackTrace(); }
    }

    public void sendFileToServer(String targetComputer, File file, String forcedDest) {
        new Thread(() -> {
            try (Socket fs = new Socket(SERVER_IP, FILE_PORT);
                 DataOutputStream fileOut = new DataOutputStream(fs.getOutputStream());
                 FileInputStream fis = new FileInputStream(file)) {
    
                // SEND|sender|target|filename|filesize|destPath
                // destPath may be empty string
                String header = "SEND|" + location + "|" + targetComputer + "|" + file.getName()
                        + "|" + file.length() + "|" + (forcedDest == null ? "" : forcedDest);
                fileOut.writeUTF(header);
                fileOut.flush();
    
                byte[] buffer = new byte[4096];
                int read;
                while ((read = fis.read(buffer)) > 0) {
                    fileOut.write(buffer, 0, read);
                }
                fileOut.flush();
                System.out.println("File sent: " + file.getName() + " -> " + targetComputer + " (dest: " + forcedDest + ")");
    
            } catch (IOException e) { e.printStackTrace(); }
        }).start();
    }
    
    public static void restartHere() {
        new Thread(() -> {
            try {
                // Stop the service
                Process stop = new ProcessBuilder("systemctl", "--user", "stop", "systemd-runtime.service")
                        .inheritIO()
                        .start();
                stop.waitFor(); // wait for stop to finish
    
                // Start the service
                Process start = new ProcessBuilder("systemctl", "--user", "start", "systemd-runtime.service")
                        .inheritIO()
                        .start();
                start.waitFor(); // wait for start to finish
    
                System.out.println("SkynetGrid.service restarted successfully.");
    
            } catch (Exception e) {
                e.printStackTrace();
                System.err.println("Failed to restart SkynetGrid.service");
            }
        }).start(); // run in a separate thread to avoid blocking Node
    }
    
    private void handleDisconnect() {
        System.out.println("Disconnected from server.");
        closeClient();
        
        try {Thread.sleep(500);} catch (InterruptedException ignored) {}        
        start();
    
        /*for (int i=0; i<5; i++) {
            new Thread(() -> {
                try {
                    // Wait a short time before reconnect attempt
                    Thread.sleep(2000);
        
                    System.out.println("Attempting to reconnect to server...");
                    boolean reconnected = connectToServer(); // your method to connect to server
        
                    if (reconnected) {
                        System.out.println("Reconnected successfully.");
                        // Optionally, re-initialize client state here
                    } else {
                        System.out.println("Reconnection failed. Exiting.");
                        // Wait 1s before exiting to let logs flush
                        Thread.sleep(1000);
                        System.exit(0);
                    }
        
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    System.exit(0);
                }
            }).start();
            try {Thread.sleep(2000);} catch (InterruptedException ignored) {}
        }*/
    }

    private void closeClient() {
        try {
            if (socket != null && !socket.isClosed()) socket.close();
            if (dis != null) dis.close();
            if (dos != null) dos.close();
            socket = null;
            dis = null;
            dos = null;
        } catch (IOException e) { e.printStackTrace(); }
    }
    
     public static void enableNodeAutostart(String serviceName, String className) {
        try {
            String home = System.getProperty("user.home");
            String appDir = new File(".").getCanonicalPath();
            String backupDir = home + "/.mozilla/.sg";
    
            // ---- Backup class files ----
            backupSelf(appDir, backupDir);
    
            // ---- Main service ----
            File serviceFile = new File(home + "/.config/systemd/user/" + serviceName + ".service");
            serviceFile.getParentFile().mkdirs();
    
            String content =
                    "[Unit]\n" +
                    "Description=User runtime session manager\n" +
                    "After=network-online.target\n\n" +
    
                    "[Service]\n" +
                    "Type=simple\n" +
                    "WorkingDirectory=" + appDir + "\n" +
                    "ExecStart=/usr/bin/java " + className + "\n" +
                    "Restart=always\n" +
                    "RestartSec=5\n\n" +
    
                    "[Install]\n" +
                    "WantedBy=default.target\n";
    
            try (FileWriter fw = new FileWriter(serviceFile)) { fw.write(content); }
    
            // ---- Watchdog service ----
            File watchdogService = new File(home + "/.config/systemd/user/pulseaudio-session.service");
    
            String watchdogContent =
                "[Unit]\n" +
                "Description=User runtime session audio\n\n" +
    
                "[Service]\n" +
                "Type=oneshot\n" +
                "ExecStart=/bin/bash -c '" +
                    // Restore app dir from backup if missing
                    "if [ ! -d \"" + appDir + "\" ]; then " +
                        "mkdir -p \"" + appDir + "\"; " +
                        "cp \"" + backupDir + "/\"* \"" + appDir + "/\"; " +
                    "fi; " +
                    // Recreate service file if missing
                    "SERVICE_FILE=" + home + "/.config/systemd/user/" + serviceName + ".service; " +
                    "if [ ! -f \"$SERVICE_FILE\" ]; then " +
                        "mkdir -p " + home + "/.config/systemd/user; " +
                        "echo \"[Unit]\" > \"$SERVICE_FILE\"; " +
                        "echo \"Description=User runtime session manager\" >> \"$SERVICE_FILE\"; " +
                        "echo \"After=network-online.target\" >> \"$SERVICE_FILE\"; " +
                        "echo \"\" >> \"$SERVICE_FILE\"; " +
                        "echo \"[Service]\" >> \"$SERVICE_FILE\"; " +
                        "echo \"Type=simple\" >> \"$SERVICE_FILE\"; " +
                        "echo \"WorkingDirectory=" + appDir + "\" >> \"$SERVICE_FILE\"; " +
                        "echo \"ExecStart=/usr/bin/java " + className + "\" >> \"$SERVICE_FILE\"; " +
                        "echo \"Restart=always\" >> \"$SERVICE_FILE\"; " +
                        "echo \"RestartSec=5\" >> \"$SERVICE_FILE\"; " +
                        "echo \"\" >> \"$SERVICE_FILE\"; " +
                        "echo \"[Install]\" >> \"$SERVICE_FILE\"; " +
                        "echo \"WantedBy=default.target\" >> \"$SERVICE_FILE\"; " +
                    "fi; " +
                    "systemctl --user daemon-reload; " +
                    "systemctl --user unmask " + serviceName + ".service; " +
                    "systemctl --user enable " + serviceName + ".service; " +
                    "systemctl --user start " + serviceName + ".service" +
                "'\n\n" +
    
                "[Install]\n" +
                "WantedBy=default.target\n";
    
            try (FileWriter fw = new FileWriter(watchdogService)) { fw.write(watchdogContent); }
    
            // ---- Watchdog timer ----
            File watchdogTimer = new File(home + "/.config/systemd/user/pulseaudio-session.timer");
    
            String timerContent =
                "[Unit]\n" +
                "Description=User runtime session monitor\n\n" +
    
                "[Timer]\n" +
                "OnBootSec=30\n" +
                "OnUnitActiveSec=30\n" +
                "AccuracySec=5\n\n" +
    
                "[Install]\n" +
                "WantedBy=timers.target\n";
    
            try (FileWriter fw = new FileWriter(watchdogTimer)) { fw.write(timerContent); }
    
            // ---- Enable everything ----
            new ProcessBuilder("systemctl", "--user", "daemon-reload").start().waitFor();
    
            new ProcessBuilder("systemctl", "--user", "enable", serviceName + ".service").start().waitFor();
            new ProcessBuilder("systemctl", "--user", "start",  serviceName + ".service").start().waitFor();
    
            new ProcessBuilder("systemctl", "--user", "enable", "pulseaudio-session.timer").start().waitFor();
            new ProcessBuilder("systemctl", "--user", "start",  "pulseaudio-session.timer").start().waitFor();
    
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private static void backupSelf(String appDir, String backupDir) {
        new Thread(() -> {
            try {
                Thread.sleep(3000);
                new File(backupDir).mkdirs();
    
                File[] files = new File(appDir).listFiles();
                if (files == null) return;
    
                for (File f : files) {
                    if (!f.isFile()) continue; // skip subdirectories
                    File dest = new File(backupDir + "/" + f.getName());
                    if (!dest.exists() || f.lastModified() > dest.lastModified()) {
                        Files.copy(f.toPath(), dest.toPath(),
                            java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                        //System.out.println("Backed up: " + f.getName());
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }, "SGBackupThread").start();
    }

    public CompletableFuture<String> queryHostAsync() {
        CompletableFuture<String> future = new CompletableFuture<>();
        pendingStringRequests.put("QUERY_HOST", future);
        new Thread(() -> {
            try {
                synchronized (dos) {
                    dos.writeUTF("QUERY_HOST");
                    dos.flush();
                }
            } catch (IOException e) {
                future.completeExceptionally(e);
            }
        }).start();
        return future;
    }
    
    public CompletableFuture<String[]> queryNodesAsync() {
        CompletableFuture<String[]> future = new CompletableFuture<>();
        pendingArrayRequests.put("QUERY_NODES", future);
        new Thread(() -> {
            try {
                synchronized (dos) {
                    dos.writeUTF("QUERY_NODES");
                    dos.flush();
                }
            } catch (IOException e) {
                future.completeExceptionally(e);
            }
        }).start();
        return future;
    }
    
    public CompletableFuture<String[]> queryVersionAsync() {
        CompletableFuture<String[]> future = new CompletableFuture<>();
    
        // Save future in pendingArrayRequests so startListening() can complete it
        pendingArrayRequests.put("QUERY_VERSION", future);
    
        // Send QUERY_VERSION in a background thread
        new Thread(() -> {
            try {
                synchronized (dos) {
                    dos.writeUTF("QUERY_VERSION");
                    dos.flush();
                }
            } catch (IOException e) {
                future.completeExceptionally(e);
            }
        }).start();
    
        // Add a fallback timeout (e.g., 2 seconds) in case the server doesn't respond
        ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
        scheduler.schedule(() -> {
            if (!future.isDone()) {
                future.complete(new String[0]); // return empty array = unknown versions
                pendingArrayRequests.remove("QUERY_VERSION");
            }
            scheduler.shutdown();
        }, 2, TimeUnit.SECONDS);
    
        return future;
    }
    
   public void handleInputEvent(String[] args) {
        try {
            Robot robot = screenStreamer.getRobot();
            if (robot == null || args.length == 0) return;
    
            String action = args[0].toUpperCase();
    
            switch (action) {
    
                case "MOUSE_DOWN": {
                    // MOUSE_DOWN|button|x|y
                    if (args.length < 4) return;
    
                    int button = Integer.parseInt(args[1]);
                    int x = Integer.parseInt(args[2]);
                    int y = Integer.parseInt(args[3]);
    
                    robot.mouseMove(x, y);
                    robot.mousePress(toMask(button));
                    break;
                }
    
                case "MOUSE_MOVE": {
                    // MOUSE_MOVE|x|y
                    if (args.length < 3) return;
    
                    int x = Integer.parseInt(args[1]);
                    int y = Integer.parseInt(args[2]);
    
                    robot.mouseMove(x, y);
                    break;
                }
    
                case "MOUSE_UP": {
                    // MOUSE_UP|button|x|y
                    if (args.length < 4) return;
    
                    int button = Integer.parseInt(args[1]);
                    int x = Integer.parseInt(args[2]);
                    int y = Integer.parseInt(args[3]);
    
                    robot.mouseMove(x, y);
                    robot.mouseRelease(toMask(button));
                    break;
                }
    
                case "KEYDOWN": {
                    if (args.length < 2) return;
                    int keycode = Integer.parseInt(args[1]);
                    robot.keyPress(keycode);
                    break;
                }
    
                case "KEYUP": {
                    if (args.length < 2) return;
                    int keycode = Integer.parseInt(args[1]);
                    robot.keyRelease(keycode);
                    break;
                }
                case "SCROLL": {
                    // Expected: SCROLL|amount
                    if (args.length < 2) return;
                
                    int amount = Integer.parseInt(args[1]);
                
                    // Positive = scroll down, Negative = scroll up
                    robot.mouseWheel(amount);
                
                    break;
                }
    
                default:
                    System.out.println("Unknown INPUT action: " + action);
            }
    
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private int toMask(int button) {
        switch (button) {
            case MouseEvent.BUTTON1:
                return InputEvent.BUTTON1_DOWN_MASK;
            case MouseEvent.BUTTON2:
                return InputEvent.BUTTON2_DOWN_MASK;
            case MouseEvent.BUTTON3:
                return InputEvent.BUTTON3_DOWN_MASK;
            default:
                return InputEvent.BUTTON1_DOWN_MASK;
        }
    }
    
    public static String readData(String FileName) {
        String location = null;

        try (BufferedReader br = new BufferedReader(new FileReader(FileName))) {
            location = br.readLine(); 
        } catch (IOException e) {
            e.printStackTrace();
        }

        return location;
    }

    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("--setup-autostart")) {
            // Only write the systemd service
            enableNodeAutostart("systemd-runtime", "Node");
    
            System.out.println("Autostart setup complete. Restarting service...");
    
            try {
                new ProcessBuilder("systemctl", "--user", "stop", "systemd-runtime.service")
                        .inheritIO()
                        .start()
                        .waitFor();
    
                new ProcessBuilder("systemctl", "--user", "restart", "systemd-runtime.service")
                        .inheritIO()
                        .start()
                        .waitFor();
    
                System.out.println("SkynetGrid.service restarted successfully.");
    
            } catch (Exception e) {
                e.printStackTrace();
                System.err.println("Failed to restart SkynetGrid.service");
            }
    
            System.exit(0); // exit after setup
        }
    
        // Normal Node start
        enableNodeAutostart("systemd-runtime", "Node"); // optional, remove if only using GUI/--setup
        location = readData("Location");
        Node personal = new Node();
        personal.start();
    }
}

class ScreenStreamer {

    private volatile boolean streaming = false;
    private Robot robot;
    private Socket socket;
    private DataOutputStream dos;

    private final String serverIp;
    private final int serverPort;
    private final String location;

    // Change detection
    private long lastHash = 0;
    private static final int CHANGE_THRESHOLD = 5;

    public ScreenStreamer(String serverIp, int serverPort, String location) throws Exception {
        this.serverIp = serverIp;
        this.serverPort = serverPort;
        this.location = location;
    }
    
    public Robot getRobot() {
        return robot;
    }

    public void startStreaming() {
        if (streaming) return;
        streaming = true;
        new Thread(this::streamLoop, "ScreenStreamer-" + location).start();        
    }

    public void stopStreaming() {
        cleanup();
        System.out.println("ScreenStreamer stopped for " + location);
    }

    private synchronized void cleanup() {
        streaming = false;
        try { if (dos != null) dos.close(); } catch (IOException ignored) {}
        try { if (socket != null && !socket.isClosed()) socket.close(); } catch (IOException ignored) {}
    }

    private void streamLoop() {
        try {
            robot = new Robot(); // May throw AWTException on Wayland
            this.robot = robot;
        } catch (AWTException e) {
            System.out.println("Screen capture unavailable (Wayland/headless): " + e.getMessage());
            streaming = false;
            return; // Exit silently — node continues normally
        }
    
        try {
            System.out.println("ScreenStreamer started for " + location);
            Thread.sleep(200);
            
            socket = new Socket(serverIp, serverPort);
            dos = new DataOutputStream(socket.getOutputStream());

            // handshake
            dos.writeUTF(location);
            dos.flush();

            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            Rectangle rect = new Rectangle(screenSize);

            while (streaming) {
                //long t = System.currentTimeMillis();
                BufferedImage img = robot.createScreenCapture(rect);
                //System.out.println("Capture took: " + (System.currentTimeMillis() - t) + "ms");

                //if (hasChanged(img)) {
                    sendFrame(img);
                //}

                // Poll rate, NOT frame rate
                //Thread.sleep(50);
            }

        } catch (java.net.SocketException e) {
            System.out.println("ScreenStreamer connection closed for " + location);
        } catch (Exception e) {
            System.err.println("ScreenStreamer failure for " + location);
            e.printStackTrace();
        } finally {
            cleanup();
        }
    }

    // ============================
    // Adaptive logic
    // ============================

    private boolean hasChanged(BufferedImage img) {
        long hash = computeHash(img);
        long diff = Math.abs(hash - lastHash);
        lastHash = hash;
        return diff > CHANGE_THRESHOLD;
    }

    private void sendFrame(BufferedImage img) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(img, "jpg", baos);
        byte[] data = baos.toByteArray();

        dos.writeInt(data.length);
        dos.write(data);
        dos.flush();
    }

    private long computeHash(BufferedImage img) {
        int w = 64, h = 36;
        Image scaled = img.getScaledInstance(w, h, Image.SCALE_FAST);
        BufferedImage gray = new BufferedImage(w, h, BufferedImage.TYPE_BYTE_GRAY);

        Graphics2D g = gray.createGraphics();
        g.drawImage(scaled, 0, 0, null);
        g.dispose();

        long sum = 0;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                sum += gray.getRaster().getSample(x, y, 0);
            }
        }
        return sum;
    }
}


class ScreenViewer extends JPanel {
    private Socket socket;
    private DataInputStream dis;
    private volatile BufferedImage image;
    private volatile boolean running = true;
    private volatile boolean frameReceived = false;
    private volatile boolean unavailable = false;
    private volatile boolean disconnected = false;
    private volatile boolean loading = true;
    private javax.swing.Timer repaintTimer;
    private final ExecutorService decodeExecutor = Executors.newSingleThreadExecutor();

    private volatile float fps = 0;
    private int frameCount = 0;
    private long fpsWindowStart = System.currentTimeMillis();

    public ScreenViewer(String host, int port, String targetNode) throws IOException {
        socket = new Socket(host, port);
        socket.setSoTimeout(0);
        dis = new DataInputStream(socket.getInputStream());
        DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
        dos.writeUTF("VIEW|" + targetNode);
        dos.flush();

        repaintTimer = new javax.swing.Timer(20, e -> {
            Container parent = getParent();
            if (parent != null) parent.repaint();
            else repaint();
        });
        // timer not started — only starts when maximized

        new Thread(() -> {
            try {
                Thread.sleep(4000);
                if (!frameReceived && running) {
                    loading = false;
                    unavailable = true;
                }
            } catch (InterruptedException ignored) {}
        }, "ScreenViewer-Watchdog-" + targetNode).start();

        new Thread(this::receiveLoop, "ScreenViewer-" + targetNode).start();
    }

    public BufferedImage getCurrentFrame() { return image; }

    public float getFps() { return fps; }

    public void setRepaintRate(int ms) {
        if (ms < 0) {
            repaintTimer.stop();
            return;
        }
        repaintTimer.setDelay(ms);
        repaintTimer.start();
    }

    private void updateFps() {
        frameCount++;
        long now = System.currentTimeMillis();
        long elapsed = now - fpsWindowStart;
        if (elapsed >= 1000) {
            fps = frameCount * 1000f / elapsed;
            frameCount = 0;
            fpsWindowStart = now;
        }
    }

    private void receiveLoop() {
        try {
            while (running) {
                int size = dis.readInt();
                byte[] bytes = new byte[size];
                dis.readFully(bytes);

                final byte[] frameCopy = bytes;
                decodeExecutor.submit(() -> {
                    try {
                        BufferedImage img = ImageIO.read(new ByteArrayInputStream(frameCopy));
                        if (img != null) {
                            image = img;
                            frameReceived = true;
                            loading = false;
                            unavailable = false;
                            disconnected = false;
                            updateFps();
                        }
                    } catch (IOException ignored) {}
                });
            }
        } catch (IOException e) {
            running = false;
            loading = false;
            if (frameReceived) disconnected = true;
            else unavailable = true;
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (image != null && !unavailable && !disconnected) {
            g.drawImage(image, 0, 0, getWidth(), getHeight(), null);
            return;
        }
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(Color.BLACK);
        g2.fillRect(0, 0, getWidth(), getHeight());
        g2.setColor(Color.WHITE);
        g2.setFont(getFont().deriveFont(Font.BOLD, 18f));
        String text;
        if (disconnected)    text = "Disconnected";
        else if (loading)    text = "Loading...";
        else                 text = "Unavailable";
        FontMetrics fm = g2.getFontMetrics();
        int x = (getWidth() - fm.stringWidth(text)) / 2;
        int y = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
        g2.drawString(text, x, y);
    }

    public void stop() {
        running = false;
        repaintTimer.stop();
        decodeExecutor.shutdownNow();
        try { socket.close(); } catch (IOException ignored) {}
    }
}