/*@AUTHOR (ABHINAV BIJU)
 * @VERSION (JDK 1.7)
 */
import javax.swing.*;
import java.awt.*;

public class RoundedButton extends JButton {
    private static final int DEFAULT_RADIUS = 20;
    private int radius = DEFAULT_RADIUS;

    public enum State {
        DEAD,        // node known-dead / disabled
        OFFLINE,     // not active (black / neutral)
        ACTIVE,      // active but not selected (red in your original)
        SELECTED     // active + selected (green in your original)
    }

    // Simple theme holder; swap instances to switch palettes
    public static final class Theme {
        public final Color bgDead;
        public final Color bgOffline;
        public final Color bgActive;
        public final Color bgSelected;
        public final Color textDefault;
        public final Color textHostHighlight;

        public Theme(Color bgDead, Color bgOffline, Color bgActive, Color bgSelected,
                     Color textDefault, Color textHostHighlight) {
            this.bgDead = bgDead;
            this.bgOffline = bgOffline;
            this.bgActive = bgActive;
            this.bgSelected = bgSelected;
            this.textDefault = textDefault;
            this.textHostHighlight = textHostHighlight;
        }

        // Two example themes:
        public static final Theme DARK = new Theme(
            new Color(50,50,50),     // DEAD
            new Color(0,0,0),        // OFFLINE
            new Color(200,0,0),      // ACTIVE
            new Color(0,180,0),      // SELECTED
            Color.WHITE,             // text default
            Color.YELLOW             // host highlight text
        );

        public static final Theme LIGHT = new Theme(
            new Color(200,200,200),  // DEAD (light grey)
            new Color(240,240,240),  // OFFLINE (near white)
            new Color(220,80,80),    // ACTIVE (muted red)
            new Color(80,180,100),   // SELECTED (muted green)
            Color.BLACK,             // text default in light theme
            new Color(120,80,0)      // host highlight (brownish)
        );

        // Current theme (mutable)
        private static Theme CURRENT = DARK;
        public static Theme getCurrent() { return CURRENT; }
        public static void setCurrent(Theme t) { CURRENT = t; }
    }

    private State state = State.OFFLINE;
    private Theme theme = Theme.getCurrent();
    private boolean isHost = false; // for foreground highlight

    public RoundedButton(String text) {
        super(text);
        setFocusPainted(false);
        setBorderPainted(false);
        setContentAreaFilled(false); // we paint background ourselves
        setOpaque(false);
        setForeground(theme.textDefault);
        setFont(new Font("Arial", Font.BOLD, 7));
        setEnabled(false);

        // initial visual state
        applyTheme(theme);
    }

    public void applyTheme(Theme t) {
        this.theme = t;
        // update foreground depending on host flag
        setForeground(isHost ? theme.textHostHighlight : theme.textDefault);
        repaint();
    }
    
    public void applyTheme(boolean lightMode) {
        if (lightMode) {
            applyTheme(Theme.LIGHT);
        } else {
            applyTheme(Theme.DARK);
        }
    }

    public void setHostHighlight(boolean host) {
        this.isHost = host;
        setForeground(isHost ? theme.textHostHighlight : theme.textDefault);
        repaint();
    }

    public void setRadius(int r) {
        this.radius = r;
        repaint();
    }

    public synchronized void setState(State s) {
        if (s == null) return;
        this.state = s;
        // mapped enabled state: DEAD/OFFLINE -> disabled; ACTIVE/SELECTED -> enabled
        super.setEnabled(s == State.ACTIVE || s == State.SELECTED);
        repaint();
    }

    public synchronized State getState() {
        return state;
    }

    /**
     * Toggle selection: if state==SELECTED -> ACTIVE; else SELECTED.
     * Returns true if now selected.
     */
    public synchronized boolean toggleSelected() {
        if (state == State.SELECTED) {
            setState(State.ACTIVE);
            return false;
        } else {
            setState(State.SELECTED);
            return true;
        }
    }

    // Convenience helpers
    public void markDead()    { setState(State.DEAD); }
    public void markOffline() { setState(State.OFFLINE); }
    public void markActive()  { setState(State.ACTIVE); }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();

        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);

        // pick background from state + theme
        Color bg;
        switch (state) {
            case DEAD:    bg = theme.bgDead; break;
            case OFFLINE: bg = theme.bgOffline; break;
            case ACTIVE:  bg = theme.bgActive; break;
            case SELECTED: bg = theme.bgSelected; break;
            default:      bg = theme.bgOffline; break;
        }

        // fill rounded rect
        g2.setColor(bg);
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);

        // Let super paint text and focus (contentAreaFilled=false so it won't overdraw)
        super.paintComponent(g2);
        g2.dispose();
    }

    @Override
    protected void paintBorder(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setColor(new Color(80, 80, 80));
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);
        g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, radius, radius);
        g2.dispose();
    }

    // Prevent external code from accidentally changing background color as the canonical state.
    @Override
    public void setBackground(Color bg) {
        // Keep behaviour but also map to a state if needed:
        super.setBackground(bg);
        // It's better to call setState from GUI rather than setBackground; do nothing else here.
        repaint();
    }
}