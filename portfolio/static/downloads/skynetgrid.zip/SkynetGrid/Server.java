/*@AUTHOR (ABHINAV BIJU)
 * @VERSION (JDK 1.7)
 */

import java.net.*;
import java.io.*;
import java.util.*;
import java.nio.file.Files;

class Server {
    private static final int PORT = 5678;       // chat/protocol
    private static final int FILE_PORT = 6789;  // file transfer
    private static final Set<ClientHandler> clients = Collections.synchronizedSet(new HashSet<>());
    private static ServerSocket serverSocket;
    private static final Map<String, ClientHandler> nodeMap = Collections.synchronizedMap(new HashMap<>());
    private static String hostLocation = null;
    
    private static final Map<String, List<DataOutputStream>> screenViewers = new HashMap<>();
    private static final Map<String, byte[]> latestFrames = new HashMap<>();
    private static final Map<String, Socket> nodeScreens = new HashMap<>();
    
    private static final int ELECTION_PORT = 49999;

    public static void start() {    
        System.out.println("Server started on port " + PORT);        
        
        Thread discoveryThread = new Thread(() -> {
            try (DatagramSocket ds = new DatagramSocket(50000)) {
                byte[] buf = new byte[256];
        
                while (true) {
                    DatagramPacket packet = new DatagramPacket(buf, buf.length);
                    ds.receive(packet);
        
                    String msg = new String(packet.getData(), 0, packet.getLength());
                    if (msg.equals("DISCOVER_SERVER")) {
        
                        byte[] reply = "SERVER_HERE".getBytes();
        
                        DatagramPacket response = new DatagramPacket(
                                reply,
                                reply.length,
                                packet.getAddress(), // unicasting back to requester
                                50001 // client's listening port
                        );
        
                        ds.send(response);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        discoveryThread.start();
        
        // Chat server
        new Thread(Server::startChatServer).start();

        // File server
        new Thread(Server::startFileServer).start();
        
        new Thread(Server::startScreenServer).start();
    }

    private static void startScreenServer() {
        try (ServerSocket ss = new ServerSocket(Node.SCREEN_PORT)) {
            System.out.println("Screen server started on port " + Node.SCREEN_PORT);

            while (true) {
                Socket socket = ss.accept();
                new Thread(() -> handleScreenConnection(socket)).start();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Handle a new connection on the screen port. Could be a streaming node or a viewer.
     */
    private static void handleScreenConnection(Socket socket) {
        try {
            DataInputStream dis = new DataInputStream(socket.getInputStream());
    
            String firstMsg = dis.readUTF();
    
            if (firstMsg.startsWith("VIEW|")) {
                String targetNode = firstMsg.split("\\|")[1];
                addScreenViewer(targetNode, socket);
                System.out.println("Viewer added for node: " + targetNode);
                // IMPORTANT: do NOT close stream or socket
                return;
            }
    
            // Streaming node
            String nodeName = firstMsg;
            nodeScreens.put(nodeName, socket);
            System.out.println("Screen streaming started from node: " + nodeName);
    
            while (true) {
                int len = dis.readInt();
                byte[] frameData = new byte[len];
                dis.readFully(frameData);
            
                // Store the latest frame
                synchronized (latestFrames) {
                    latestFrames.put(nodeName, frameData);
                }
            
                // Send to all viewers
                synchronized (screenViewers) {
                    List<DataOutputStream> viewers = screenViewers.get(nodeName);
                    if (viewers != null) {
                        Iterator<DataOutputStream> it = viewers.iterator();
                        while (it.hasNext()) {
                            try {
                                DataOutputStream dos = it.next();
                                dos.writeInt(len);
                                dos.write(frameData);
                                dos.flush();
                            } catch (IOException e) {
                                it.remove();
                            }
                        }
                    }
                }
            }

    
        } catch (IOException e) {
            System.out.println("Screen connection closed: " + socket);
            nodeScreens.entrySet().removeIf(entry -> entry.getValue() == socket);
            try { socket.close(); } catch (IOException ignored) {}
        }
    }
    
    public static void addScreenViewer(String nodeName, Socket viewerSocket) throws IOException {
        DataOutputStream dos = new DataOutputStream(viewerSocket.getOutputStream());
    
        synchronized (screenViewers) {
            screenViewers.computeIfAbsent(nodeName, k -> new ArrayList<>()).add(dos);
        }
    
        // Immediately send the last frame if it exists
        byte[] lastFrame;
        synchronized (latestFrames) {
            lastFrame = latestFrames.get(nodeName);
        }
        if (lastFrame != null) {
            try {
                dos.writeInt(lastFrame.length);
                dos.write(lastFrame);
                dos.flush();
            } catch (IOException e) {
                // If sending fails, remove the viewer
                synchronized (screenViewers) {
                    screenViewers.get(nodeName).remove(dos);
                }
            }
        }
    }
    
    private static String getLocalLanAddress() throws SocketException {
        Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
        while (interfaces.hasMoreElements()) {
            NetworkInterface ni = interfaces.nextElement();
            if (!ni.isUp() || ni.isLoopback() || ni.isVirtual()) continue;
            Enumeration<InetAddress> addresses = ni.getInetAddresses();
            while (addresses.hasMoreElements()) {
                InetAddress addr = addresses.nextElement();
                if (addr instanceof Inet4Address && !addr.isLoopbackAddress()) {
                    return addr.getHostAddress();
                }
            }
        }
        return "127.0.0.1"; // fallback
    }

    private static void startChatServer() {
        try (ServerSocket ss = new ServerSocket(PORT)) {
            serverSocket = ss;
            System.out.println("File server started on port " + PORT);
            while (true) {
                Socket socket = serverSocket.accept();
                ClientHandler handler = new ClientHandler(socket);
                handler.start();
            }
        } catch (IOException e) {
            System.out.println("Chat server stopped.");
        }
    }

    private static void startFileServer() {
        try (ServerSocket fileServer = new ServerSocket(FILE_PORT)) {
            System.out.println("File server started on port " + FILE_PORT);
            while (true) {
                Socket fs = fileServer.accept();
                new Thread(() -> handleFileSocket(fs)).start();
            }
        } catch (IOException e) { System.out.println("File server stopped."); }
    }

    private static void handleFileSocket(Socket fs) {
        try (DataInputStream dis = new DataInputStream(fs.getInputStream());
             DataOutputStream dos = new DataOutputStream(fs.getOutputStream())) {

            String header = dis.readUTF();
            String[] parts = header.split("\\|");
            if (parts.length < 2) return;

            if ("REQUEST".equals(parts[0])) {
                // Node requests a file
                String filename = parts[2];
                File tempFile = new File("tmp", "tmp_" + filename);
                if (!tempFile.exists()) {
                    dos.writeUTF("ERROR|File not found");
                    return;
                }
                dos.writeUTF("OK|" + tempFile.length());
                try (FileInputStream fis = new FileInputStream(tempFile)) {
                    byte[] buffer = new byte[4096];
                    int read;
                    while ((read = fis.read(buffer)) > 0) {
                        dos.write(buffer, 0, read);
                    }
                }
                System.out.println("File served: " + filename + " -> " + parts[1]);

            } else if ("SEND".equals(parts[0])) {
                // Node sends a file to server
                // header: SEND|sender|target|filename|filesize|destPath
                String sender = parts[1];
                String target = parts[2];
                String filename = parts[3];
                long filesize = Long.parseLong(parts[4]);
                String destPath = "";
                if (parts.length >= 6) destPath = parts[5]; // may be empty
            
                // Prepare tmp folder: delete existing one if it exists
                File tmpDir = new File("tmp");
                tmpDir.mkdirs();
            
                File tempFile = new File(tmpDir, "tmp_" + filename);
                if (tempFile.exists()) tempFile.delete();
            
                try (FileOutputStream fos = new FileOutputStream(tempFile)) {
                    byte[] buffer = new byte[4096];
                    long remaining = filesize;
                    int read;
                    while (remaining > 0 && (read = dis.read(buffer, 0, (int)Math.min(buffer.length, remaining))) > 0) {
                        fos.write(buffer, 0, read);
                        remaining -= read;
                    }
                }
            
                System.out.println("Received file: " + filename + " from " + sender + " for " + target + " (dest: " + destPath + ")");
            
                // Broadcast file protocol to target nodes, include destPath (may be empty)
                // Broadcast format: target|FILE|filename|filesize|destPath
                String fileMsg = target + "|FILE|" + filename + "|" + filesize + "|" + destPath;
                broadcast(fileMsg);
            }
        } catch (IOException e) { e.printStackTrace(); }
        finally { try { fs.close(); } catch (IOException ignored) {} }
    }
    
    private static void deleteFolderRecursively(File folder) {
        if (folder.isDirectory()) {
            File[] files = folder.listFiles();
            if (files != null) {
                for (File f : files) {
                    deleteFolderRecursively(f);
                }
            }
        }
        folder.delete();
    }

    private static void broadcast(String message) {
        synchronized (clients) {
            for (ClientHandler c : clients) {
                try {
                    c.dos.writeUTF(message);
                    c.dos.flush();
                } catch (IOException e) { e.printStackTrace(); }
            }
        }
    }

    private static void shutdownServer(String filter) {
        synchronized (clients) {
            for (ClientHandler client : clients) {
                try {
                    client.dos.writeUTF("SERVER_CLOSED|"+filter+"|"+getLocalLanAddress());
                    client.socket.close();
                } catch (IOException ignored) {}
            }
        }
        try { serverSocket.close(); } catch (IOException ignored) {}
        System.exit(0);
    }
  
    private static class ClientHandler extends Thread {
        private final Socket socket;
        private DataOutputStream dos;
        private DataInputStream dis;
        private String username;
        private String version = "none";
        private String pass = "";

        public ClientHandler(Socket socket) {
            super("client-" + socket.getPort());
            this.socket = socket;
        }

        public void run() {
            try {
                dis = new DataInputStream(socket.getInputStream());
                dos = new DataOutputStream(socket.getOutputStream());
        
                username = dis.readUTF();
                if (username == null) return;
                version = dis.readUTF();
                pass = dis.readUTF();
                if (username.contains("-admin") && !pass.equals("Pass#"+username.split("-")[0]+"Hashed")) return;
        
                synchronized (clients) { clients.add(this); }
                nodeMap.put(username, this);
                System.out.println(username + " connected.");
                
                // First connected node becomes host
                if (hostLocation == null) {
                    hostLocation = username;
                    System.out.println("Host location set to: " + hostLocation);
                }
                
                if (!(username.contains("-admin"))) {
                    broadcast("UPDATE_NODES");
                }
        
                while (true) {
                    String msg = dis.readUTF();
                    if (msg == null) break;
        
                    System.out.println("Received from " + username + ": " + msg);
                    
                    if (msg.contains("SHUTDOWN_SERVER")) {
                        shutdownServer(msg.split("\\|")[1]); //need to recheck
                    }
        
                    // ---------------------------
                    // GUI REQUEST: GET HOST LOCATION
                    // ---------------------------
                    if (msg.equals("QUERY_HOST")) {
                        dos.writeUTF("HOST|" + hostLocation);
                        System.out.println("HOST|" + hostLocation);
                        dos.flush();
                        continue;
                    }
        
                    // ---------------------------
                    // GUI REQUEST: GET ACTIVE NODES
                    // ---------------------------
                    if (msg.equals("QUERY_NODES")) {
                        StringBuilder sb = new StringBuilder("NODES|");
        
                        synchronized (nodeMap) {
                            for (String loc : nodeMap.keySet()) {
                                sb.append(loc).append(",");
                            }
                        }
        
                        if (sb.charAt(sb.length() - 1) == ',')
                            sb.deleteCharAt(sb.length() - 1);
        
                        dos.writeUTF(sb.toString());
                        System.out.println(sb.toString());
                        dos.flush();
                        continue;
                    }
                    
                    if (msg.equals("QUERY_VERSION")) {
                        StringBuilder sb = new StringBuilder("VERSION|");
                        synchronized (nodeMap) {
                            for (String location : nodeMap.keySet()) {
                                ClientHandler node = nodeMap.get(location);
                                String ip = node.socket.getInetAddress().getHostAddress();
                                sb.append(location).append("@").append(ip).append(":").append(node.version).append(",");
                            }
                        }
                        if (sb.charAt(sb.length() - 1) == ',') sb.deleteCharAt(sb.length() - 1);
                        dos.writeUTF(sb.toString());
                        dos.flush();
                        System.out.println(sb.toString());
                        continue;
                    }

                    
                    // ---------------------------
                    // SCREEN VIEW REQUESTS
                    // ---------------------------
                    if (msg.startsWith("SCREEN|START|")) {
                        String[] parts = msg.split("\\|");
                        if (parts.length == 3) {
                            String targetNode = parts[2];
                            Socket viewerSocket = this.socket; // the GUI node that wants to view
                    
                            // Add this GUI node as a viewer of the target node
                            try {
                                Server.addScreenViewer(targetNode, viewerSocket);
                                dos.writeUTF("SCREEN|STARTED|" + targetNode);
                                dos.flush();
                                System.out.println(username + " started viewing screen of " + targetNode);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                        continue;
                    }
                    
                    if (msg.startsWith("SCREEN|STOP|")) {
                        String[] parts = msg.split("\\|");
                        if (parts.length == 3) {
                            String targetNode = parts[2];
                            synchronized (screenViewers) {
                                List<DataOutputStream> viewers = screenViewers.get(targetNode);
                                if (viewers != null) {
                                    viewers.remove(dos); // remove the exact stream you stored
                                }
                            }
                            try {
                                dos.writeUTF("SCREEN|STOPPED|" + targetNode);
                                dos.flush();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            System.out.println(username + " stopped viewing screen of " + targetNode);
                        }
                    }
        
                    // Default: broadcast message to all nodes
                    broadcast(msg);
                }
        
            } catch (IOException e) {
                System.out.println(username + " disconnected.");
                nodeMap.remove(username);
                if (!(username.contains("-admin"))) {
                    broadcast("UPDATE_NODES");
                }
        
            } finally {
                try { socket.close(); } catch (IOException ignored) {}
                clients.remove(this);
            }
        }
    }
}
