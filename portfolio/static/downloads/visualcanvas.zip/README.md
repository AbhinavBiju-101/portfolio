# Visual Canvas

A Linux desktop app (Java Swing) with interactive editors for learning
data structures, chemistry, and physics — plus a small math/probability
toolkit.

## Compile & run

```bash
javac VisualCanvas.java
java VisualCanvas
```

Requires JDK 8+. Optional: drop [Apache Batik](https://xmlgraphics.apache.org/batik/)
jars on the classpath for true vector SVG export — without it, SVG export
falls back to a PNG embedded in an SVG wrapper.

Sessions save/load as `.vcanvas` files (plain text, one section per
folder/structure) via File → Save/Load in the app, or by double-clicking
a `.vcanvas` file once the app registers itself as the default handler
(Linux only, via `xdg-mime`).
