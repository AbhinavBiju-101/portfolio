// ═══════════════════════════════════════════════════════════════════════════
//  VisualCanvas.java  v5
//
//  Compile:  javac VisualCanvas.java          (JDK 8+)
//  Run:      java  VisualCanvas
//
//  FOLDERS
//    💻 Computer Science — 11 structures + BFS/DFS animation
//    ⚗️  Chemistry        — molecule canvas, right-click-drag bonds, tool palette
//    📐 Mathematics      — Venn, Probability Distribution, Binomial Expansion
//    ⚙️  Physics          — springs/ropes/rods/pulleys, Verlet simulation
//
//  KEY UX
//    • Sidebar: collapsed by default, auto-expands when mouse hovers left edge
//    • Named session tabs — each tab has its own isolated renderer state
//    • Tab right-click → rename / save / close
//    • Ctrl+Z / Ctrl+Y  undo/redo + toolbar buttons
//    • Animation toolbar only visible in CS folder
//    • SVG export (Batik if available, PNG-in-SVG fallback)
//    • Save/Load sessions to  ./saves/*.vcs
// ═══════════════════════════════════════════════════════════════════════════

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.List;

public class VisualCanvas {

    public static void main(String[] args) {
        if (args.length == 0) createShortcut("VisualCanvas", "VisualCanvas", "icon.png");
    
        SwingUtilities.invokeLater(() -> {
            AppFrame app = new AppFrame();
    
            // If launched via double-click / "Open With"
            if (args.length > 0) {
                String filePath = args[0];
                app.loadCanvas(filePath);
            }
    
            app.setVisible(true);
        });
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  THEME
    // ═══════════════════════════════════════════════════════════════════════
    static final Color C_BG      = Color.WHITE;
    static final Color C_BORDER  = new Color(200,200,200);
    static final Color C_MUTED   = new Color(150,150,150);
    static final Color C_DIM     = new Color(70,70,70);
    static final Color C_SIDEBAR = new Color(248,248,248);
    static final Color C_ACCENT  = new Color(55,90,190);
    static final Color C_ANIM_CUR= new Color(255,130,0);
    static final Color C_ANIM_VIS= new Color(180,230,180);
    static final Color C_ANIM_HL = new Color(255,220,80);

    static final Font F_MONO  = new Font("Monospaced", Font.BOLD,  13);
    static final Font F_UI    = new Font("SansSerif",  Font.PLAIN, 12);
    static final Font F_HINT  = new Font("SansSerif",  Font.PLAIN, 11);
    static final Font F_IDX   = new Font("Monospaced", Font.PLAIN, 10);
    static final Font F_TITLE = new Font("SansSerif",  Font.BOLD,  15);
    static final Font F_SMALL = new Font("SansSerif",  Font.PLAIN, 10);

    static final Stroke S_LINE = new BasicStroke(1.8f);
    static final Stroke S_THICK= new BasicStroke(2.5f);
    static final Stroke S_THIN = new BasicStroke(1.2f);
    static final Stroke S_BOND = new BasicStroke(2.2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
    static final Stroke S_DASH = new BasicStroke(1.2f, BasicStroke.CAP_BUTT,  BasicStroke.JOIN_MITER, 10f, new float[]{5,3}, 0);
    static final Stroke S_GDASH= new BasicStroke(0.5f, BasicStroke.CAP_BUTT,  BasicStroke.JOIN_MITER, 10f, new float[]{3,3}, 0);

    // ═══════════════════════════════════════════════════════════════════════
    //  INTERFACES
    // ═══════════════════════════════════════════════════════════════════════
    interface Draggable { double gx(); double gy(); void mv(double dx, double dy); }

    /** Renderer can consume mouse events to prevent canvas pan/drag. */
    interface MouseConsumer {
        boolean onPress  (double wx, double wy, MouseEvent e, CanvasPanel cv);
        boolean onDrag   (double wx, double wy, double px, double py, MouseEvent e, CanvasPanel cv);
        void    onRelease(double wx, double wy, MouseEvent e, CanvasPanel cv);
        void    onRightClick(double wx, double wy, int sx, int sy, CanvasPanel cv);
        void    onRightDragEnd(double sx, double sy, double ex, double ey, CanvasPanel cv);
    }

    interface DSRenderer {
        void draw(Graphics2D g);
        void add(int v);
        void removeLast();
        void clear();
        boolean hasAnimation();
        void animStep();
        void animReset();
        boolean animDone();
        default void saveTo(StringBuilder sb){}
        default void loadLine(String line){}
    }

    interface HittableRenderer extends DSRenderer {
        Draggable nodeAt(double wx, double wy);
    }

    interface FolderPanel {
        JPanel getToolbar();
        void activate(Session s);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  UNDO MANAGER
    // ═══════════════════════════════════════════════════════════════════════
    interface UndoableAction { void undo(); void redo(); String desc(); }

    static class UndoManager {
        private final Deque<UndoableAction> undos = new ArrayDeque<>();
        private final Deque<UndoableAction> redos = new ArrayDeque<>();
        private static final int MAX = 80;

        void push(UndoableAction a) {
            undos.push(a); redos.clear();
            while (undos.size() > MAX) { List<UndoableAction> tmp = new ArrayList<>(undos); tmp.remove(tmp.size()-1); undos.clear(); for (int i=tmp.size()-1;i>=0;i--) undos.push(tmp.get(i)); }
        }
        boolean canUndo() { return !undos.isEmpty(); }
        boolean canRedo() { return !redos.isEmpty(); }
        void undo() { if (!undos.isEmpty()) { UndoableAction a=undos.pop(); a.undo(); redos.push(a); } }
        void redo() { if (!redos.isEmpty()) { UndoableAction a=redos.pop(); a.redo(); undos.push(a); } }
        void clear() { undos.clear(); redos.clear(); }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  SESSION  — each tab owns its own renderer instances
    // ═══════════════════════════════════════════════════════════════════════
    static class Session {
        String name;
        String activeFolder = "Computer Science";
        UndoManager undo = new UndoManager();

        // CS: each named structure has its own renderer
        LinkedHashMap<String, DSRenderer> csRends = new LinkedHashMap<>();
        String csActive = "Linked List";

        // Other folders
        ChemRenderer  chemRend;
        VennRend      vennRend   = new VennRend();
        ProbDistRend  probRend   = new ProbDistRend();
        BinomRend     binomRend  = new BinomRend();
        String        mathActive = "Venn Diagram";
        PhysicsRenderer physRend;

        Session(String name) {
            this.name = name;
            csRends.put("Linked List",       new LLRend(false));
            csRends.put("Doubly Linked List",new LLRend(true));
            csRends.put("Stack",             new StackRend());
            csRends.put("Queue",             new QueueRend());
            csRends.put("Deque",             new DequeRend());
            csRends.put("Circular Queue",    new CQRend());
            csRends.put("Binary Tree",       new TreeRend(false));
            csRends.put("BST",               new TreeRend(true));
            csRends.put("Max Heap",          new HeapRend(true));
            csRends.put("Min Heap",          new HeapRend(false));
            csRends.put("Graph",             new GraphRend());
            chemRend = new ChemRenderer();
            physRend = new PhysicsRenderer();
        }

        DSRenderer activeRenderer() {
            if ("Computer Science".equals(activeFolder)) return csRends.get(csActive);
            if ("Chemistry".equals(activeFolder))        return chemRend;
            if ("Physics".equals(activeFolder))          return physRend;
            // Math
            if ("Venn Diagram".equals(mathActive))   return vennRend;
            if ("Probability Distribution".equals(mathActive))     return probRend;
            if ("Binomial Expansion".equals(mathActive))        return binomRend;
            return vennRend;
        }

        String save() {
            StringBuilder sb = new StringBuilder();
            sb.append("name=").append(name).append("\n");
            sb.append("folder=").append(activeFolder).append("\n");
            sb.append("csActive=").append(csActive).append("\n");
            sb.append("mathActive=").append(mathActive).append("\n");
            // --- CS renderers ---
            for(Map.Entry<String,DSRenderer> e : csRends.entrySet()){
                sb.append("--- CS:").append(e.getKey()).append(" ---\n");
                e.getValue().saveTo(sb);
            }
            // --- Chem ---
            sb.append("--- CHEM ---\n");
            chemRend.saveTo(sb);
            // --- Math ---
            sb.append("--- MATH ---\n");
            vennRend.saveTo(sb);
            probRend.saveTo(sb);
            binomRend.saveTo(sb);
            // --- Physics ---
            sb.append("--- PHYS ---\n");
            physRend.saveTo(sb);
            sb.append("--- END ---\n");
            return sb.toString();
        }

        static Session load(String data) {
            Session s = new Session("Untitled");
            String[] lines = data.split("\n");
            String section = "";
            String csKey = "";
            for(int i=0;i<lines.length;i++){
                String line = lines[i].trim();
                if(line.startsWith("name="))         s.name        = line.substring(5);
                else if(line.startsWith("folder="))   s.activeFolder= line.substring(7);
                else if(line.startsWith("csActive=")) s.csActive    = line.substring(9);
                else if(line.startsWith("mathActive="))s.mathActive = line.substring(10);
                else if(line.startsWith("--- CS:")){  section="CS"; csKey=line.substring(7,line.length()-4).trim(); }
                else if(line.equals("--- CHEM ---"))  section="CHEM";
                else if(line.equals("--- MATH ---"))  section="MATH";
                else if(line.equals("--- PHYS ---"))  section="PHYS";
                else if(line.equals("--- END ---"))   section="";
                else if(!line.isEmpty()){
                    if("CS".equals(section)){ DSRenderer r=s.csRends.get(csKey); if(r!=null) r.loadLine(line); }
                    else if("CHEM".equals(section)) s.chemRend.loadLine(line);
                    else if("MATH".equals(section)){ s.vennRend.loadLine(line); s.probRend.loadLine(line); s.binomRend.loadLine(line); }
                    else if("PHYS".equals(section)) s.physRend.loadLine(line);
                }
            }
            return s;
        }
    }
    
    public static void createShortcut(String appName, String className, String iconFile) {
        try {
            String home = System.getProperty("user.home");
    
            File desktopFile = new File(home + "/.local/share/applications/" + appName + ".desktop");
            File mimeDir = new File(home + "/.local/share/mime/packages/");
            mimeDir.mkdirs();
    
            File mimeFile = new File(mimeDir, appName.toLowerCase() + ".xml");
    
            String appDir = new File(".").getCanonicalPath();
            String classpath = appDir + ":" + appDir + "/+libs/*";
    
            File iconSrc = new File(appDir, iconFile);
    
            // MIME name
            String mimeName = "application/x-" + appName.toLowerCase();
            String iconName = mimeName.replace("/", "-"); // application-x-visualcanvas
    
            // --- INSTALL ICON INTO THEME ---
            File iconDestDir = new File(home + "/.local/share/icons/hicolor/256x256/mimetypes/");
            iconDestDir.mkdirs();
    
            File iconDest = new File(iconDestDir, iconName + ".png");
    
            if (iconSrc.exists()) {
                java.nio.file.Files.copy(
                    iconSrc.toPath(),
                    iconDest.toPath(),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING
                );
            }
    
            // IMPORTANT: use icon name, NOT absolute path
            String execLine = "/usr/bin/java -cp \"" + classpath + "\" " + className + " %f";
    
            // --- 1. DESKTOP ENTRY ---
            String desktop =
                    "[Desktop Entry]\n" +
                    "Version=1.0\n" +
                    "Type=Application\n" +
                    "Name=" + appName + "\n" +
                    "Exec=" + execLine + "\n" +
                    "Icon=" + iconName + "\n" +   // <-- FIXED
                    "Terminal=false\n" +
                    "StartupNotify=true\n" +
                    "Path=" + appDir + "\n" +
                    "Categories=Education;\n" +
                    "MimeType=" + mimeName + ";\n";
    
            try (FileWriter fw = new FileWriter(desktopFile)) {
                fw.write(desktop);
            }
    
            // --- 2. MIME TYPE ---
            String mime =
                    "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                    "<mime-info xmlns=\"http://www.freedesktop.org/standards/shared-mime-info\">\n" +
                    "  <mime-type type=\"" + mimeName + "\">\n" +
                    "    <comment>" + appName + " File</comment>\n" +
                    "    <glob pattern=\"*.vcanvas\"/>\n" +
                    "  </mime-type>\n" +
                    "</mime-info>\n";
    
            try (FileWriter fw = new FileWriter(mimeFile)) {
                fw.write(mime);
            }
    
            // --- 3. PERMISSIONS ---
            new ProcessBuilder("chmod", "+x", desktopFile.getAbsolutePath()).start().waitFor();
    
            // --- 4. UPDATE DATABASES ---
            new ProcessBuilder("update-mime-database", home + "/.local/share/mime")
                    .start().waitFor();
    
            new ProcessBuilder("update-desktop-database", home + "/.local/share/applications")
                    .start().waitFor();
    
            // --- 5. UPDATE ICON CACHE (CRITICAL) ---
            new ProcessBuilder("gtk-update-icon-cache", home + "/.local/share/icons/hicolor")
                    .start().waitFor();
    
            // --- 6. SET DEFAULT APP ---
            new ProcessBuilder("xdg-mime", "default",
                    appName + ".desktop",
                    mimeName)
                    .start().waitFor();
    
            // --- 7. TRUST (GNOME) ---
            new ProcessBuilder("gio", "set",
                    desktopFile.getAbsolutePath(),
                    "metadata::trusted", "true")
                    .start().waitFor();
    
            System.out.println("Shortcut + MIME + icon registered.");
    
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    // ═══════════════════════════════════════════════════════════════════════
    //  CANVAS PANEL
    // ═══════════════════════════════════════════════════════════════════════
    static class CanvasPanel extends JPanel {
        DSRenderer renderer;
        double scale=1, tx=0, ty=0;
        int dragX, dragY; boolean centred;
        Draggable dragging;
        boolean rightDragging;
        double rdSX, rdSY, rdEX, rdEY;  // right-drag world coords

        CanvasPanel() {
            setBackground(C_BG);
            setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));

            MouseAdapter ma = new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    dragX=e.getX(); dragY=e.getY();
                    double wx=wldX(e.getX()), wy=wldY(e.getY());
                    if (SwingUtilities.isRightMouseButton(e)) {
                        rdSX=wx; rdSY=wy; rdEX=wx; rdEY=wy; rightDragging=true;
                    } else {
                        dragging=null;
                        if (renderer instanceof MouseConsumer) {
                            MouseConsumer mc=(MouseConsumer)renderer;
                            if (mc.onPress(wx,wy,e,CanvasPanel.this)) return;
                        }
                        if (renderer instanceof HittableRenderer) dragging=((HittableRenderer)renderer).nodeAt(wx,wy);
                    }
                }
                public void mouseReleased(MouseEvent e) {
                    double wx=wldX(e.getX()), wy=wldY(e.getY());
                    if (SwingUtilities.isRightMouseButton(e) && rightDragging) {
                        rightDragging=false;
                        double _ddx=rdEX-rdSX,_ddy=rdEY-rdSY;
                        if(Math.sqrt(_ddx*_ddx+_ddy*_ddy)>8 && renderer instanceof MouseConsumer)
                            ((MouseConsumer)renderer).onRightDragEnd(rdSX,rdSY,rdEX,rdEY,CanvasPanel.this);
                        repaint(); return;
                    }
                    if (renderer instanceof MouseConsumer) ((MouseConsumer)renderer).onRelease(wx,wy,e,CanvasPanel.this);
                    dragging=null; repaint();
                }
                public void mouseDragged(MouseEvent e) {
                    double wx=wldX(e.getX()), wy=wldY(e.getY());
                    double pwx=wldX(dragX),   pwy=wldY(dragY);
                    if (SwingUtilities.isRightMouseButton(e)) {
                        rdEX=wx; rdEY=wy; dragX=e.getX(); dragY=e.getY(); repaint(); return;
                    }
                    if (renderer instanceof MouseConsumer) {
                        MouseConsumer mc=(MouseConsumer)renderer;
                        if (mc.onDrag(wx,wy,pwx,pwy,e,CanvasPanel.this)) { dragX=e.getX(); dragY=e.getY(); repaint(); return; }
                    }
                    if (dragging!=null) dragging.mv((e.getX()-dragX)/scale,(e.getY()-dragY)/scale);
                    else { tx+=e.getX()-dragX; ty+=e.getY()-dragY; }
                    dragX=e.getX(); dragY=e.getY(); repaint();
                }
                public void mouseClicked(MouseEvent e) {
                    if (SwingUtilities.isRightMouseButton(e) && e.getClickCount()==1 && renderer instanceof MouseConsumer)
                        ((MouseConsumer)renderer).onRightClick(wldX(e.getX()),wldY(e.getY()),e.getX(),e.getY(),CanvasPanel.this);
                }
            };
            addMouseListener(ma); addMouseMotionListener(ma);
            addMouseWheelListener(new MouseWheelListener() {
                public void mouseWheelMoved(MouseWheelEvent e) {
                    double f=e.getPreciseWheelRotation()<0?1.12:1/1.12;
                    tx=e.getX()-(e.getX()-tx)*f; ty=e.getY()-(e.getY()-ty)*f;
                    scale=Math.max(0.03,Math.min(scale*f,25)); repaint();
                }
            });
        }

        double wldX(int sx){return (sx-tx)/scale;}
        double wldY(int sy){return (sy-ty)/scale;}
        void setRend(DSRenderer r){renderer=r; repaint();}
        void resetView(){scale=1;tx=getWidth()/2.0;ty=getHeight()/2.0;repaint();}

        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (!centred){tx=getWidth()/2.0;ty=getHeight()/2.0;centred=true;}
            Graphics2D g2=(Graphics2D)g.create();
            applyHints(g2); dotGrid(g2);
            g2.translate(tx,ty); g2.scale(scale,scale);
            if (renderer!=null) renderer.draw(g2);
            if (rightDragging) {
                boolean _rxnArr = renderer instanceof ChemRenderer && "Reaction Arrow".equals(((ChemRenderer)renderer).activeTool);
                boolean _curvArr= renderer instanceof ChemRenderer && "Curved Arrow".equals(((ChemRenderer)renderer).activeTool);
                if(_rxnArr){
                    g2.setColor(Color.BLACK);
                    g2.setStroke(new BasicStroke(2f,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
                    g2.draw(new Line2D.Double(rdSX,rdSY,rdEX,rdEY));
                    ah(g2,rdSX,rdSY,rdEX,rdEY,10);
                } else if(_curvArr){
                    g2.setColor(new Color(180,30,30));
                    g2.setStroke(new BasicStroke(2f,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
                    double _mx=(rdSX+rdEX)/2,_my=(rdSY+rdEY)/2;
                    double _dx=rdEX-rdSX,_dy=rdEY-rdSY,_l=Math.max(1,Math.sqrt(_dx*_dx+_dy*_dy));
                    double _cpx=_mx-_dy/_l*50,_cpy=_my+_dx/_l*50;
                    g2.draw(new QuadCurve2D.Double(rdSX,rdSY,_cpx,_cpy,rdEX,rdEY));
                    ah(g2,_cpx,_cpy,rdEX,rdEY,9);
                } else {
                    g2.setColor(new Color(100,100,200,140));
                    g2.setStroke(new BasicStroke(1.4f,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND,10,new float[]{4,4},0));
                    g2.draw(new Line2D.Double(rdSX,rdSY,rdEX,rdEY));
                }
            }
            g2.dispose();
        }

        static void applyHints(Graphics2D g){
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,     RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_RENDERING,         RenderingHints.VALUE_RENDER_QUALITY);
        }
        void dotGrid(Graphics2D g){
            // Cap dots at ~1600 to avoid lag when zoomed out
            double sp=Math.max(20,40*scale);
            if((getWidth()/sp)*(getHeight()/sp)>1600) sp=Math.sqrt((double)getWidth()*getHeight()/1600.0);
            double ox=((tx%sp)+sp)%sp,oy=((ty%sp)+sp)%sp;
            g.setColor(new Color(210,210,210));
            for(double x=ox;x<getWidth();x+=sp) for(double y=oy;y<getHeight();y+=sp) g.fillRect((int)x,(int)y,2,2);
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  ANIMATION ENGINE
    // ═══════════════════════════════════════════════════════════════════════
    static class AnimEngine {
        final CanvasPanel canvas;
        javax.swing.Timer timer;
        boolean running=false;
        int ms=700;

        AnimEngine(CanvasPanel cv) {
            canvas=cv;
            timer=new javax.swing.Timer(ms, new ActionListener(){
                public void actionPerformed(ActionEvent e){step();}
            });
        }
        void setSpeed(int v){ms=v;timer.setDelay(v);}
        void play(){if(canvas.renderer!=null&&canvas.renderer.hasAnimation()){running=true;timer.start();}}
        void pause(){running=false;timer.stop();}
        void step(){if(canvas.renderer==null)return;canvas.renderer.animStep();canvas.repaint();if(canvas.renderer.animDone())pause();}
        void reset(){pause();if(canvas.renderer!=null)canvas.renderer.animReset();canvas.repaint();}
        void toggle(){if(running)pause();else play();}
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  WIDGET HELPERS
    // ═══════════════════════════════════════════════════════════════════════
    static JButton btn(String t){
        JButton b=new JButton(t);b.setFont(F_UI);b.setFocusPainted(false);b.setBackground(Color.WHITE);
        b.setBorder(new CompoundBorder(new LineBorder(C_BORDER,1,true),new EmptyBorder(4,10,4,10)));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));return b;
    }
    static JToggleButton tglBtn(String t){
        JToggleButton b=new JToggleButton(t);b.setFont(F_UI);b.setFocusPainted(false);b.setBackground(Color.WHITE);
        b.setBorder(new CompoundBorder(new LineBorder(C_BORDER,1,true),new EmptyBorder(4,8,4,8)));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addChangeListener(new javax.swing.event.ChangeListener(){
            public void stateChanged(javax.swing.event.ChangeEvent e){b.setBackground(b.isSelected()?new Color(215,230,255):Color.WHITE);}
        });
        return b;
    }
    static JLabel lbl(String t){JLabel l=new JLabel(t);l.setFont(F_UI);return l;}
    static JComboBox<String> combo(String... items){JComboBox<String> c=new JComboBox<>(items);c.setFont(F_UI);c.setBackground(Color.WHITE);return c;}
    static Component vsep(){JSeparator s=new JSeparator(JSeparator.VERTICAL);s.setPreferredSize(new Dimension(1,26));s.setForeground(C_BORDER);return s;}
    static Border fb(boolean red){return new CompoundBorder(new LineBorder(red?new Color(210,60,60):C_BORDER,1,true),new EmptyBorder(4,8,4,8));}
    static JTextField tf(int cols){JTextField f=new JTextField(cols);f.setFont(F_MONO);f.setBorder(fb(false));return f;}
    static void flash(JTextField f){
        f.setBorder(fb(true));
        javax.swing.Timer t=new javax.swing.Timer(600,new ActionListener(){public void actionPerformed(ActionEvent e){f.setBorder(fb(false));}});
        t.setRepeats(false);t.start();
    }
    static JMenuItem mi(String lbl, ActionListener al){JMenuItem m=new JMenuItem(lbl);m.addActionListener(al);return m;}

    // ═══════════════════════════════════════════════════════════════════════
    //  DRAWING UTILITIES
    // ═══════════════════════════════════════════════════════════════════════
    static void ctr(Graphics2D g,String s,double cx,double cy,Font f,Color c){
        g.setFont(f);g.setColor(c);FontMetrics fm=g.getFontMetrics(f);
        g.drawString(s,(int)(cx-fm.stringWidth(s)/2.0),(int)(cy+(fm.getAscent()-fm.getDescent())/2.0));
    }
    static void title(Graphics2D g,String t,int topY){g.setFont(F_TITLE);g.setColor(C_DIM);FontMetrics fm=g.getFontMetrics();g.drawString(t,-fm.stringWidth(t)/2,topY-24);}
    static void hint(Graphics2D g,String m){g.setFont(F_HINT);g.setColor(C_MUTED);FontMetrics fm=g.getFontMetrics();g.drawString(m,-fm.stringWidth(m)/2,6);}
    static void arr(Graphics2D g,double x1,double y1,double x2,double y2){g.setColor(Color.BLACK);g.setStroke(S_LINE);g.draw(new Line2D.Double(x1,y1,x2,y2));ah(g,x1,y1,x2,y2,8);}
    static void arr(Graphics2D g,double x1,double y1,double x2,double y2,Color c,float w){g.setColor(c);g.setStroke(new BasicStroke(w));g.draw(new Line2D.Double(x1,y1,x2,y2));g.setColor(c);ah(g,x1,y1,x2,y2,7);}
    static void ah(Graphics2D g,double x1,double y1,double x2,double y2,int sz){
        double a=Math.atan2(y2-y1,x2-x1);
        g.fillPolygon(new int[]{(int)x2,(int)(x2-sz*Math.cos(a-.42)),(int)(x2-sz*Math.cos(a+.42))},
                      new int[]{(int)y2,(int)(y2-sz*Math.sin(a-.42)),(int)(y2-sz*Math.sin(a+.42))},3);
    }
    static void circ(Graphics2D g,int cx,int cy,int r,String v,Color fill,Color border){
        g.setColor(fill);g.fillOval(cx-r,cy-r,r*2,r*2);g.setColor(border);g.setStroke(S_LINE);g.drawOval(cx-r,cy-r,r*2,r*2);ctr(g,v,cx,cy,F_MONO,Color.BLACK);
    }
    static void circ(Graphics2D g,int cx,int cy,int r,String v){circ(g,cx,cy,r,v,Color.WHITE,Color.BLACK);}
    static void rect(Graphics2D g,int x,int y,int w,int h,String v,Color fill){
        g.setColor(fill);g.fillRect(x,y,w,h);g.setColor(Color.BLACK);g.setStroke(S_LINE);g.drawRect(x,y,w,h);ctr(g,v,x+w/2,y+h/2,F_MONO,Color.BLACK);
    }
    static void rect(Graphics2D g,int x,int y,int w,int h,String v){rect(g,x,y,w,h,v,Color.WHITE);}
    static void nbox(Graphics2D g,int x,int y,int w,int h){g.setColor(new Color(190,190,190));g.setStroke(S_DASH);g.drawRect(x,y,w,h);ctr(g,"∅",x+w/2,y+h/2,F_HINT,C_MUTED);}

    // ═══════════════════════════════════════════════════════════════════════
    //  APP FRAME
    // ═══════════════════════════════════════════════════════════════════════
    static class AppFrame extends JFrame {
        final CanvasPanel canvas = new CanvasPanel();
        final AnimEngine  anim   = new AnimEngine(canvas);
        final List<Session> sessions = new ArrayList<>();
        int activeIdx = 0;

        // sidebar
        JPanel sidebar, sidebarContent;
        boolean sidebarExpanded = false;
        static final int SW = 210;
        javax.swing.Timer collapseTimer;
        final Map<String,JButton> folderBtns = new LinkedHashMap<>();

        // folder panels
        final Map<String,FolderPanel> folders = new LinkedHashMap<>();
        String activeFolder = "Computer Science";
        final JPanel toolbarArea = new JPanel(new BorderLayout());
        JPanel animBar;
        JButton animPlayBtn, animStepBtn, animResetBtn;

        // tab bar
        JPanel tabBar;
        JScrollPane tabScroll;
        File lastSavedFile = null; // for quick-save on close

        AppFrame() {
            super("Visual Canvas");
            setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
            addWindowListener(new java.awt.event.WindowAdapter(){
                public void windowClosing(java.awt.event.WindowEvent e){
                    Object[] opts = lastSavedFile != null
                        ? new Object[]{"Save","Save As…","Don't Save","Cancel"}
                        : new Object[]{"Save As…","Don't Save","Cancel"};
                    int r = JOptionPane.showOptionDialog(AppFrame.this,
                        "Save canvas before closing?","Visual Canvas",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,
                        null, opts, opts[0]);
                    if (lastSavedFile != null) {
                        if (r==0){saveCanvas(false);dispose();System.exit(0);}
                        else if(r==1){saveCanvas(true);dispose();System.exit(0);}
                        else if(r==2){dispose();System.exit(0);}
                        // r==3 or closed → cancel
                    } else {
                        if (r==0){saveCanvas(true);dispose();System.exit(0);}
                        else if(r==1){dispose();System.exit(0);}
                        // r==2 or closed → cancel
                    }
                }
            });
            setSize(1500,960); setLocationRelativeTo(null);
            setExtendedState(JFrame.MAXIMIZED_BOTH);
            
            sessions.add(new Session("Session 1"));

            CSFolderPanel   csP   = new CSFolderPanel(this);
            ChemFolderPanel chemP = new ChemFolderPanel(this);
            MathFolderPanel mathP = new MathFolderPanel(this);
            PhysFolderPanel physP = new PhysFolderPanel(this);
            folders.put("Computer Science", csP);
            folders.put("Chemistry",        chemP);
            folders.put("Mathematics",      mathP);
            folders.put("Physics",          physP);
            
            buildSidebar();
            buildTabBar();
            buildAnimBar();

            JPanel canvasWrap = new JPanel(new BorderLayout());
            canvasWrap.add(canvas,   BorderLayout.CENTER);
            canvasWrap.add(animBar,  BorderLayout.SOUTH);

            JPanel centre = new JPanel(new BorderLayout());
            centre.add(tabScroll,     BorderLayout.NORTH);
            centre.add(toolbarArea,BorderLayout.AFTER_LAST_LINE);
            centre.add(canvasWrap, BorderLayout.CENTER);

            JPanel botBar = buildBottomBar();

            setLayout(new BorderLayout());
            add(sidebar, BorderLayout.WEST);
            add(centre,  BorderLayout.CENTER);
            add(botBar,  BorderLayout.NORTH);
            
            switchFolder("Computer Science");
            setupKeys();
            //setupSidebarHover(); //to remove the auto collapsible sidebar mechanics
            expandSidebar();
        }

        // ── sidebar ──────────────────────────────────────────────────────────
        void buildSidebar(){
            sidebar=new JPanel(new BorderLayout());
            sidebar.setPreferredSize(new Dimension(0,0));
            sidebar.setBackground(C_SIDEBAR);
            sidebar.setBorder(new MatteBorder(0,0,0,1,C_BORDER));

            sidebarContent=new JPanel();
            sidebarContent.setLayout(new BoxLayout(sidebarContent,BoxLayout.Y_AXIS));
            sidebarContent.setBackground(C_SIDEBAR);
            sidebarContent.setBorder(new EmptyBorder(12,0,8,0));

            String[] names={"Computer Science","Chemistry","Mathematics","Physics"};
            String[] icons={"💻CS  ","⚗️   ","MA  ","⚙️   "};
            for (int i=0;i<names.length;i++){
                final String name=names[i];
                JButton fb=makeFolderBtn(icons[i]+name);
                fb.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){switchFolder(name);}});
                folderBtns.put(name,fb);
                sidebarContent.add(fb); sidebarContent.add(Box.createVerticalStrut(2));
            }
            sidebarContent.add(Box.createVerticalGlue());
            sidebar.add(sidebarContent,BorderLayout.CENTER);
        }

        void setupSidebarHover() {
            final javax.swing.Timer hoverPoll = new javax.swing.Timer(80, e -> {
                try {
                    if (!isShowing()) return;
        
                    PointerInfo pi = MouseInfo.getPointerInfo();
                    if (pi == null) return;
        
                    Point ms = pi.getLocation();
        
                    if (!sidebarExpanded) {
                        // Edge detection (window space)
                        SwingUtilities.convertPointFromScreen(ms, AppFrame.this);
                        if (ms.x <= 10) {
                            if (collapseTimer != null) collapseTimer.stop();
                            expandSidebar();
                        }
        
                    } else {
                        // Sidebar-relative detection
                        SwingUtilities.convertPointFromScreen(ms, sidebar);
        
                        boolean insideSidebar =
                                ms.x >= 0 && ms.x <= sidebar.getWidth() &&
                                ms.y >= 0 && ms.y <= sidebar.getHeight();
        
                        if (insideSidebar) {
                            if (collapseTimer != null) collapseTimer.stop();
                        } else {
                            startCollapseDelay();  // collapse ANY time cursor leaves
                        }
                    }
        
                } catch (Exception ignored) {}
            });
        
            hoverPoll.start();
        }
        void expandSidebar() {
            if (sidebarExpanded) return;
        
            sidebarExpanded = true;
            sidebar.setPreferredSize(new Dimension(SW, 0));
        
            sidebar.revalidate();
            revalidate();
            repaint();
        
            if (collapseTimer != null) collapseTimer.stop();
        }
        void startCollapseDelay() {
            if (collapseTimer == null) {
                collapseTimer = new javax.swing.Timer(100, e -> collapseSidebar());
                collapseTimer.setRepeats(false);
            }
            if (!collapseTimer.isRunning()) {
                collapseTimer.start();
            }
        }
        void collapseSidebar() {
            if (!sidebarExpanded) return;
        
            sidebarExpanded = false;
            sidebar.setPreferredSize(new Dimension(0, 0));
        
            sidebar.revalidate();
            revalidate();
            repaint();
        }

        // ── tab bar ───────────────────────────────────────────────────────────
        void buildTabBar(){
            tabBar=new JPanel(new FlowLayout(FlowLayout.LEFT,2,2));
            tabBar.setBackground(new Color(242,242,242));
            // No bottom border on the panel itself — the scroll pane wrapper carries it
            tabScroll=new JScrollPane(tabBar,
                JScrollPane.VERTICAL_SCROLLBAR_NEVER,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            tabScroll.setBorder(new MatteBorder(0,0,1,0,C_BORDER));
            tabScroll.getHorizontalScrollBar().setUnitIncrement(60);
            tabScroll.getHorizontalScrollBar().setPreferredSize(new Dimension(0,6)); // thin bar
            tabScroll.setBackground(new Color(242,242,242));
            refreshTabBar();
        }

        void refreshTabBar(){
            tabBar.removeAll();
            for (int i=0;i<sessions.size();i++){
                final int idx=i;
                Session s=sessions.get(i);
                JPanel tp=new JPanel(new FlowLayout(FlowLayout.LEFT,0,0)); tp.setOpaque(false);
                JButton tb=new JButton(s.name); tb.setFont(F_UI); tb.setFocusPainted(false);
                tb.setBorder(new CompoundBorder(new MatteBorder(0,0,idx==activeIdx?2:0,0,C_ACCENT),new EmptyBorder(6,14,6,6)));
                tb.setBackground(idx==activeIdx?Color.WHITE:new Color(242,242,242));
                tb.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){switchSession(idx);}});
                // right-click menu
                tb.addMouseListener(new MouseAdapter(){
                    public void mousePressed(MouseEvent e){
                        if (SwingUtilities.isRightMouseButton(e)){
                            JPopupMenu pm=new JPopupMenu();
                            pm.add(mi("Rename tab",   new ActionListener(){public void actionPerformed(ActionEvent ev){renameTab(idx);}}));
                            //pm.add(mi("Save tab…",    new ActionListener(){public void actionPerformed(ActionEvent ev){saveTab(idx);}}));
                            pm.add(mi("Duplicate tab",new ActionListener(){public void actionPerformed(ActionEvent ev){duplicateTab(idx);}}));
                            //pm.add(mi("Load tab from file…", new ActionListener(){public void actionPerformed(ActionEvent ev){loadTab();}}));
                            pm.addSeparator();
                            pm.add(mi("Close tab",    new ActionListener(){public void actionPerformed(ActionEvent ev){closeTab(idx);}}));
                            pm.show(tb,e.getX(),e.getY());
                        }
                    }
                });
                JButton xb=new JButton("×"); xb.setFont(F_SMALL); xb.setFocusPainted(false); xb.setContentAreaFilled(false); xb.setBorder(new EmptyBorder(2,4,2,4));
                xb.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){closeTab(idx);}});
                tp.add(tb); tp.add(xb); tabBar.add(tp);
            }
            JButton nb=btn("+"); nb.setFont(new Font("SansSerif",Font.BOLD,14)); nb.setBorder(new EmptyBorder(4,10,4,10));
            nb.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){newTab();}});
            tabBar.add(nb); tabBar.revalidate(); tabBar.repaint();
        }

        void newTab(){ sessions.add(new Session("Session "+(sessions.size()+1))); activeIdx=sessions.size()-1; refreshTabBar(); switchFolder(activeFolder); }
        void closeTab(int idx){ if(sessions.size()<=1)return;
            int confirm=JOptionPane.showConfirmDialog(AppFrame.this,"Close tab \""+sessions.get(idx).name+"\"?\nAll unsaved work in this tab will be lost.","Close Tab",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
            if(confirm!=JOptionPane.YES_OPTION)return;
            sessions.remove(idx); activeIdx=Math.min(activeIdx,sessions.size()-1); refreshTabBar(); switchFolder(activeFolder); }
        void renameTab(int idx){ String n=JOptionPane.showInputDialog(this,"Rename tab:",sessions.get(idx).name); if(n!=null&&!n.trim().isEmpty()){sessions.get(idx).name=n.trim();refreshTabBar();} }
        void duplicateTab(int idx){
            Session orig=sessions.get(idx);
            Session dup=Session.load(orig.save());
            dup.name=orig.name+" (copy)";
            sessions.add(activeIdx+1,dup);
            activeIdx=activeIdx+1;
            refreshTabBar();
            switchFolder(dup.activeFolder);
        }
        void switchSession(int idx){ activeIdx=idx; refreshTabBar(); switchFolder(sessions.get(idx).activeFolder); }

        Session curSession(){ return sessions.get(activeIdx); }

        // ── folder switching ──────────────────────────────────────────────────
        void switchFolder(String name){
            FolderPanel fp=folders.get(name); if(fp==null) return;
            activeFolder=name;
            Session s=curSession(); s.activeFolder=name;

            // update button highlights
            for (Map.Entry<String,JButton> e:folderBtns.entrySet()){
                boolean active=e.getKey().equals(name);
                e.getValue().setBackground(active?Color.WHITE:C_SIDEBAR);
                e.getValue().setFont(new Font("SansSerif",active?Font.BOLD:Font.PLAIN,13));
            }

            toolbarArea.removeAll();
            toolbarArea.add(fp.getToolbar(),BorderLayout.CENTER);
            toolbarArea.revalidate(); toolbarArea.repaint();

            fp.activate(s);
            anim.reset();
            animPlayBtn.setText("▶ Play");

            // show anim bar only for CS
            animBar.setVisible("Computer Science".equals(name));

            canvas.repaint();
        }

        // ── anim bar ─────────────────────────────────────────────────────────
        void buildAnimBar(){
            animBar=new JPanel(new FlowLayout(FlowLayout.LEFT,6,4));
            animBar.setBackground(new Color(250,250,250));
            animBar.setBorder(new MatteBorder(1,0,0,0,C_BORDER));
            animPlayBtn =btn("▶ Play"); animStepBtn=btn("⏭ Step"); animResetBtn=btn("⏮ Reset");
            animPlayBtn .addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){anim.toggle();animPlayBtn.setText(anim.running?"⏸ Pause":"▶ Play");}});
            animStepBtn .addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){anim.step();animPlayBtn.setText("▶ Play");}});
            animResetBtn.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){anim.reset();animPlayBtn.setText("▶ Play");}});
            JSlider spd=new JSlider(150,2000,700); spd.setPreferredSize(new Dimension(100,24)); spd.setBackground(new Color(250,250,250));
            spd.addChangeListener(new javax.swing.event.ChangeListener(){public void stateChanged(javax.swing.event.ChangeEvent e){anim.setSpeed(spd.getValue());}});
            animBar.add(lbl("Animation:")); animBar.add(animPlayBtn); animBar.add(animStepBtn); animBar.add(animResetBtn);
            animBar.add(vsep()); animBar.add(lbl("Speed (ms):")); animBar.add(spd);
            animBar.setVisible(false);
        }

        // ── bottom bar ────────────────────────────────────────────────────────
        JPanel buildBottomBar(){
            JButton undoBtn=btn("↩ Undo"), redoBtn=btn("↪ Redo"), svgBtn=btn("⬇ SVG");
            JButton saveBtn=btn("💾 Save Canvas"), loadBtn=btn("📂 Open Canvas");
        
            undoBtn.addActionListener(e->{curSession().undo.undo();canvas.repaint();});
            redoBtn.addActionListener(e->{curSession().undo.redo();canvas.repaint();});
            svgBtn .addActionListener(e->{exportSVG();});
            saveBtn.addActionListener(e->{saveCanvas();});
            loadBtn.addActionListener(e->{loadCanvas();});
        
            JButton rstBtn=btn("⌖ Reset View");
            rstBtn.addActionListener(e->{canvas.resetView();});
        
            JLabel hint=new JLabel("  Scroll=zoom  ·  Drag=pan/move  ·  Right-drag=bond/connect  ·  Right-click=options  ·  Alt+←/→=tabs  ·  Ctrl+S=save  ");
            hint.setFont(F_HINT); 
            hint.setForeground(C_MUTED);
        
            // LEFT GROUP
            JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT,5,5));
            left.setOpaque(false);
            left.add(loadBtn);
            left.add(saveBtn);
            left.add(vsep());
            left.add(redoBtn);
            left.add(undoBtn);
        
            // RIGHT GROUP
            JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT,5,5));
            right.setOpaque(false);
            right.add(svgBtn);
            right.add(rstBtn);
        
            // MAIN BAR
            JPanel bot = new JPanel(new BorderLayout());
            bot.setBackground(Color.WHITE); 
            bot.setBorder(new MatteBorder(0,0,1,0,C_BORDER));
        
            bot.add(left, BorderLayout.WEST);
            bot.add(right, BorderLayout.EAST);
            bot.add(hint, BorderLayout.CENTER); // optional center fill
        
            return bot;
        }

        // ── keys ──────────────────────────────────────────────────────────────
        void setupKeys(){
            // Use a global KeyEventDispatcher so shortcuts work even when text fields have focus.
            KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher(
                new KeyEventDispatcher(){
                    public boolean dispatchKeyEvent(KeyEvent e){
                        if(e.getID()!=KeyEvent.KEY_PRESSED) return false;
                        // Only intercept when this window is active
                        if(!AppFrame.this.isActive()) return false;
                        boolean ctrl=(e.getModifiersEx()&InputEvent.CTRL_DOWN_MASK)!=0;
                        boolean alt =(e.getModifiersEx()&InputEvent.ALT_DOWN_MASK)!=0;
                        boolean shift=(e.getModifiersEx()&InputEvent.SHIFT_DOWN_MASK)!=0;
                        Component fc=KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner();
                        boolean textFocused=(fc instanceof javax.swing.text.JTextComponent);
                        int k=e.getKeyCode();
                        // Alt+Left/Right: tab switch — always intercept
                        if(alt&&k==KeyEvent.VK_LEFT){if(activeIdx>0)switchSession(activeIdx-1);return true;}
                        if(alt&&k==KeyEvent.VK_RIGHT){if(activeIdx<sessions.size()-1)switchSession(activeIdx+1);return true;}
                        // Ctrl+T new tab, Ctrl+W close tab — skip if text focused
                        if(ctrl&&k==KeyEvent.VK_T&&!textFocused){newTab();return true;}
                        if(ctrl&&k==KeyEvent.VK_W&&!textFocused){closeTab(activeIdx);return true;}
                        // Ctrl+Z/Y undo/redo — skip if text field focused (let field handle its own undo)
                        if(ctrl&&k==KeyEvent.VK_Z&&!textFocused){curSession().undo.undo();canvas.repaint();return true;}
                        if(ctrl&&k==KeyEvent.VK_Y&&!textFocused){curSession().undo.redo();canvas.repaint();return true;}
                        // Ctrl+S save canvas — always intercept
                        if(ctrl&&!shift&&k==KeyEvent.VK_S){saveCanvas(false);return true;}
                        if(ctrl&&shift&&k==KeyEvent.VK_S){saveCanvas(true);return true;}
                        // Chemistry Ctrl+C/V copy/paste — only when canvas area is active
                        if(ctrl&&k==KeyEvent.VK_C&&!textFocused){
                            if("Chemistry".equals(curSession().activeFolder)) curSession().chemRend.copySelected();
                            return false; // allow system copy too
                        }
                        if(ctrl&&k==KeyEvent.VK_V&&!textFocused){
                            if("Chemistry".equals(curSession().activeFolder)){curSession().chemRend.pasteSelected();canvas.repaint();}
                            return true;
                        }
                        if(k==KeyEvent.VK_DELETE&&!textFocused){
                            if("Chemistry".equals(curSession().activeFolder)){
                                ChemRenderer cr=curSession().chemRend;
                                if(!cr.selectedIds.isEmpty()){for(String id:new HashSet<>(cr.selectedIds))cr.deleteAtom(id);cr.selectedIds.clear();canvas.repaint();}
                            }
                            return true;
                        }
                        return false;
                    }
                });
        }

        // ── save / load / export ──────────────────────────────────────────────
        static final String SAVES_DIR="saves";

        /** saveCanvas(false) = quick-save if we have a path, else chooser.
         *  saveCanvas(true)  = always show chooser (Save As). */
        void saveCanvas() { saveCanvas(false); }
        void saveCanvas(boolean forceChooser) {
            new File(SAVES_DIR).mkdirs();
            File f;
            if (!forceChooser && lastSavedFile != null) {
                f = lastSavedFile; // overwrite existing file directly
            } else {
                String base = sessions.get(0).name.replaceAll("[^a-zA-Z0-9_\\-]", "_");
                JFileChooser fc = new JFileChooser(new File(SAVES_DIR));
                fc.setFileFilter(new FileNameExtensionFilter("Visual Canvas (*.vcanvas)", "vcanvas"));
                fc.setSelectedFile(lastSavedFile != null ? lastSavedFile : new File(SAVES_DIR, base + ".vcanvas"));
                if (fc.showSaveDialog(null) != JFileChooser.APPROVE_OPTION) return;
                f = fc.getSelectedFile();
                String name = f.getName().replaceFirst("\\.[^.]*$", "");
                f = new File(f.getParent(), name + ".vcanvas");
                if (f.exists() && !f.equals(lastSavedFile)) f = safeFile(f);
            }
            try (PrintWriter pw = new PrintWriter(f, "UTF-8")) {
                pw.println("VISUAL_CANVAS_V6");
                pw.println("activeTab=" + activeIdx);
                for (Session ses : sessions) { pw.println("=== SESSION ==="); pw.print(ses.save()); }
                pw.println("=== END_ALL ===");
                lastSavedFile = f;
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            JOptionPane.showMessageDialog(null, "Saved: " + f.getAbsolutePath());
        }
        void loadCanvas() {
            new File(SAVES_DIR).mkdirs();
            // Prompt to save current work before overwriting
            int conf = JOptionPane.showConfirmDialog(this,
                "Loading a canvas will replace the current canvas.\nSave current work first?",
                "Save before loading?", JOptionPane.YES_NO_CANCEL_OPTION);
            if (conf == JOptionPane.CANCEL_OPTION) return;
            if (conf == JOptionPane.YES_OPTION) { saveCanvas(false); }
            JFileChooser fc = new JFileChooser(new File(SAVES_DIR));
            fc.setFileFilter(new FileNameExtensionFilter("Visual Canvas (*.vcanvas)", "vcanvas"));
            if (fc.showOpenDialog(null) != JFileChooser.APPROVE_OPTION) return;
        
            try {
                String data = new String(Files.readAllBytes(fc.getSelectedFile().toPath()), "UTF-8");
                if (!data.startsWith("VISUAL_CANVAS_V6")) throw new IOException("Invalid format");
        
                sessions.clear();
                for (String part : data.split("=== SESSION ===")) {
                    part = part.trim().replace("=== END_ALL ===", "");
                    if (!part.isEmpty() && !part.startsWith("VISUAL_CANVAS"))
                        sessions.add(Session.load(part));
                }
                if (sessions.isEmpty()) sessions.add(new Session("Session 1"));
        
                activeIdx = 0;
                for (String line : data.split("\n"))
                    if (line.startsWith("activeTab="))
                        try { activeIdx = Integer.parseInt(line.substring(10).trim()); } catch (Exception ignored) {}
        
                activeIdx = Math.min(activeIdx, sessions.size() - 1);
                lastSavedFile = fc.getSelectedFile();
                refreshTabBar();
                switchSession(activeIdx);
        
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        void loadCanvas(String path) {
            new File(SAVES_DIR).mkdirs();
        
            File file;
        
            // If no path → use file chooser
            if (path == null) {
                JFileChooser fc = new JFileChooser(new File(SAVES_DIR));
                fc.setFileFilter(new FileNameExtensionFilter("Visual Canvas (*.vcanvas)", "vcanvas"));
                if (fc.showOpenDialog(null) != JFileChooser.APPROVE_OPTION) return;
                file = fc.getSelectedFile();
            } else {
                file = new File(path);
            }
        
            try {
                String data = new String(Files.readAllBytes(file.toPath()), "UTF-8");
                if (!data.startsWith("VISUAL_CANVAS_V6")) throw new IOException("Invalid format");
        
                sessions.clear();
        
                for (String part : data.split("=== SESSION ===")) {
                    part = part.trim().replace("=== END_ALL ===", "");
                    if (!part.isEmpty() && !part.startsWith("VISUAL_CANVAS"))
                        sessions.add(Session.load(part));
                }
        
                if (sessions.isEmpty()) sessions.add(new Session("Session 1"));
        
                activeIdx = 0;
                for (String line : data.split("\n")) {
                    if (line.startsWith("activeTab=")) {
                        try { activeIdx = Integer.parseInt(line.substring(10).trim()); }
                        catch (Exception ignored) {}
                    }
                }
        
                activeIdx = Math.min(activeIdx, sessions.size() - 1);
        
                refreshTabBar();
                switchSession(activeIdx);
        
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
            
            lastSavedFile = file;
        }

        void exportSVG(){
            JFileChooser fc=new JFileChooser(); fc.setSelectedFile(new File("canvas.svg"));
            fc.setFileFilter(new FileNameExtensionFilter("SVG","svg"));
            if(fc.showSaveDialog(this)!=JFileChooser.APPROVE_OPTION) return;
            File f=fc.getSelectedFile(); if(!f.getName().endsWith(".svg")) f=new File(f.getAbsolutePath()+".svg");
            // Safe filename: avoid overwriting
            f = safeFile(f);
            if(!tryBatikExport(f)) fallbackSVG(f);
        }
        /** Returns a non-colliding filename: foo.svg → foo (1).svg → foo (2).svg … */
        static File safeFile(File f){
            if(!f.exists()) return f;
            String name=f.getName(); String base=name.contains(".")?name.substring(0,name.lastIndexOf('.')):"";
            String ext =name.contains(".")?name.substring(name.lastIndexOf('.')):"";
            File dir=f.getParentFile(); int n=1;
            while(true){ File c=new File(dir, base+" ("+n+")"+ext); if(!c.exists()) return c; n++; }
        }
        boolean tryBatikExport(File file) {
            try {
                // 1. Updated for Batik 1.19 (using the 'anim.dom' path that worked in your test)
                Class<?> domCl = Class.forName("org.apache.batik.anim.dom.SVGDOMImplementation");
                Class<?> g2Cl = Class.forName("org.apache.batik.svggen.SVGGraphics2D");
        
                // 2. Get the Namespace and DOM Implementation
                String ns = (String) domCl.getField("SVG_NAMESPACE_URI").get(null);
                Object domImpl = domCl.getMethod("getDOMImplementation").invoke(null);
                
                // We cast to the standard Java W3C interface
                org.w3c.dom.DOMImplementation di = (org.w3c.dom.DOMImplementation) domImpl;
                org.w3c.dom.Document doc = di.createDocument(ns, "svg", null);
        
                // 3. Create the SVG Graphics context
                Graphics2D g2 = (Graphics2D) g2Cl.getConstructor(org.w3c.dom.Document.class).newInstance(doc);
        
                // 4. Apply your canvas settings
                CanvasPanel.applyHints(g2); 
                
                // --- BACKGROUND (screen space, not world space) ---
                Rectangle clip = g2.getClipBounds();
                if (clip == null) {
                    // fallback if no clip is set
                    clip = new Rectangle(0, 0, canvas.getWidth(), canvas.getHeight());
                }
                
                g2.setColor(Color.WHITE);
                g2.fillRect(clip.x, clip.y, clip.width, clip.height);
                // --------------------------------------------------
                

                canvas.dotGrid(g2); 
                g2.translate((int)canvas.tx, (int)canvas.ty); 
                g2.scale(canvas.scale, canvas.scale);
        
                // 5. Draw the content
                if (canvas.renderer != null) {
                    canvas.renderer.draw(g2);
                }
        
                // 6. Write the file
                try (Writer w = new OutputStreamWriter(new FileOutputStream(file), "UTF-8")) {
                    // Using reflection to call: g2.stream(Writer, useCSS)
                    g2Cl.getMethod("stream", Writer.class, boolean.class).invoke(g2, w, true);
                }
        
                JOptionPane.showMessageDialog(this, "Exported (Batik): " + file.getAbsolutePath());
                return true;
        
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Batik Error: " + e.toString());
                e.printStackTrace(); 
                return false;
            }
        }
        void fallbackSVG(File file){
            int w=canvas.getWidth(),h=canvas.getHeight();
            BufferedImage img=new BufferedImage(w*2,h*2,BufferedImage.TYPE_INT_RGB);
            Graphics2D g2=img.createGraphics();
            // white background
            g2.setColor(Color.WHITE); g2.fillRect(0,0,w*2,h*2);
            g2.scale(2,2); CanvasPanel.applyHints(g2); canvas.paint(g2); g2.dispose();
            try{
                ByteArrayOutputStream baos=new ByteArrayOutputStream(); ImageIO.write(img,"PNG",baos);
                String b64=Base64.getEncoder().encodeToString(baos.toByteArray());
                try(PrintWriter pw=new PrintWriter(file)){
                    pw.println("<?xml version=\"1.0\"?>");
                    pw.println("<svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\""+w+"\" height=\""+h+"\">");
                    pw.println("  <rect width=\""+w+"\" height=\""+h+"\" fill=\"white\"/>");
                    pw.println("  <image width=\""+w+"\" height=\""+h+"\" xlink:href=\"data:image/png;base64,"+b64+"\"/></svg>");
                }
                JOptionPane.showMessageDialog(this,"Exported (PNG fallback — add Apache Batik for true SVG).\n"+file.getAbsolutePath());
            }catch(IOException ex){JOptionPane.showMessageDialog(this,ex.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);}
        }

        static JButton makeFolderBtn(String text){
            JButton b=new JButton(text); b.setFont(new Font("SansSerif",Font.PLAIN,13));
            b.setFocusPainted(false); b.setHorizontalAlignment(SwingConstants.LEFT);
            b.setBorder(new EmptyBorder(9,14,9,14)); b.setBackground(C_SIDEBAR); b.setForeground(C_DIM);
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            b.setMaximumSize(new Dimension(SW,44)); b.setPreferredSize(new Dimension(SW-10,42)); return b;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  CS FOLDER
    // ═══════════════════════════════════════════════════════════════════════
    static class CSFolderPanel implements FolderPanel {
        final AppFrame app;
        final JPanel toolbar=new JPanel(new FlowLayout(FlowLayout.LEFT,5,6));
        final JComboBox<String> sbox;
        final JTextField vf=tf(7);
        final JPanel dynArea=new JPanel(new FlowLayout(FlowLayout.LEFT,4,0));
        // per-structure panels (reused across sessions)
        final JPanel defP,dqP,cqP,gP;
        // deque / cq / graph panels have stored field refs for current session renderer
        // We delegate all calls through app.curSession()

        CSFolderPanel(AppFrame app){
            this.app=app;
            String[] structs={"Linked List","Doubly Linked List","Stack","Queue","Deque","Circular Queue","Binary Tree","BST","Max Heap","Min Heap","Graph"};
            sbox=combo(structs);

            defP=new JPanel(new FlowLayout(FlowLayout.LEFT,4,0)); defP.setOpaque(false);
            JButton da=btn("＋ Add"),dr=btn("− Remove"),dc=btn("Clear");
            da.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){doAdd();}});
            vf.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){doAdd();}});
            dr.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){csRend().removeLast();app.canvas.repaint();}});
            dc.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){csRend().clear();app.canvas.repaint();}});
            defP.add(lbl("Value:")); defP.add(vf); defP.add(da); defP.add(dr); defP.add(dc);

            // deque
            dqP=new JPanel(new FlowLayout(FlowLayout.LEFT,4,0)); dqP.setOpaque(false);
            final JTextField df=tf(6);
            JButton daf=btn("＋ Front"),dar=btn("＋ Rear"),drf=btn("− Front"),drr=btn("− Rear"),dcc=btn("Clear");
            daf.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){try{dq().addF(Integer.parseInt(df.getText().trim()));df.setText("");app.canvas.repaint();}catch(NumberFormatException ex){flash(df);}}});
            dar.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){try{dq().addR(Integer.parseInt(df.getText().trim()));df.setText("");app.canvas.repaint();}catch(NumberFormatException ex){flash(df);}}});
            drf.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){dq().remF();app.canvas.repaint();}});
            drr.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){dq().remR();app.canvas.repaint();}});
            dcc.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){dq().clear();app.canvas.repaint();}});
            dqP.add(lbl("Value:")); dqP.add(df); dqP.add(daf); dqP.add(dar); dqP.add(vsep()); dqP.add(drf); dqP.add(drr); dqP.add(dcc);

            // circular queue
            cqP=new JPanel(new FlowLayout(FlowLayout.LEFT,4,0)); cqP.setOpaque(false);
            final JTextField cqf=tf(6);
            JButton cqe=btn("Enqueue"),cqd=btn("Dequeue"),cqc=btn("Clear");
            cqe.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){try{cq().enq(Integer.parseInt(cqf.getText().trim()));cqf.setText("");app.canvas.repaint();}catch(NumberFormatException ex){flash(cqf);}}});
            cqd.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){cq().deq();app.canvas.repaint();}});
            cqc.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){cq().clear();app.canvas.repaint();}});
            cqf.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){cqe.doClick();}});
            cqP.add(lbl("Value:")); cqP.add(cqf); cqP.add(cqe); cqP.add(cqd); cqP.add(cqc);

            // graph
            gP=new JPanel(new FlowLayout(FlowLayout.LEFT,4,0)); gP.setOpaque(false);
            final JTextField gnf=tf(5),gff=tf(4),gtf=tf(4),gwf=tf(4); gwf.setEnabled(false);
            final JCheckBox dirC=new JCheckBox("Directed",true),wtC=new JCheckBox("Weighted",false);
            dirC.setFont(F_UI); dirC.setOpaque(false); wtC.setFont(F_UI); wtC.setOpaque(false);
            wtC.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){gwf.setEnabled(wtC.isSelected());}});
            JButton gan=btn("Add Node"),gae=btn("Add Edge"),grn=btn("Del Node"),gre=btn("Del Edge"),gcc=btn("Clear"),gbfs=btn("▶ BFS"),gdfs=btn("▶ DFS");
            gan.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){String t=gnf.getText().trim();if(!t.isEmpty()){gr().addNode(t);gnf.setText("");app.canvas.repaint();}}});
            gnf.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){gan.doClick();}});
            gae.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){
                String f=gff.getText().trim(),t=gtf.getText().trim();if(f.isEmpty()||t.isEmpty())return;
                int w=1;if(wtC.isSelected()&&!gwf.getText().trim().isEmpty()){try{w=Integer.parseInt(gwf.getText().trim());}catch(NumberFormatException ignored){}}
                gr().addEdge(f,t,w,dirC.isSelected(),wtC.isSelected());gff.setText("");gtf.setText("");gwf.setText("");app.canvas.repaint();}});
            grn.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){String t=gnf.getText().trim();if(!t.isEmpty()){gr().remNode(t);gnf.setText("");app.canvas.repaint();}}});
            gre.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){String f=gff.getText().trim(),t=gtf.getText().trim();if(!f.isEmpty()&&!t.isEmpty()){gr().remEdge(f,t,dirC.isSelected());gff.setText("");gtf.setText("");app.canvas.repaint();}}});
            gcc.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){gr().clear();app.canvas.repaint();}});
            gbfs.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){String s=gnf.getText().trim();if(!s.isEmpty()){gr().startBFS(s);app.canvas.repaint();}}});
            gdfs.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){String s=gnf.getText().trim();if(!s.isEmpty()){gr().startDFS(s);app.canvas.repaint();}}});
            gP.add(lbl("Node:")); gP.add(gnf); gP.add(gan); gP.add(grn); gP.add(vsep());
            gP.add(lbl("From:")); gP.add(gff); gP.add(lbl("To:")); gP.add(gtf); gP.add(lbl("Wt:")); gP.add(gwf);
            gP.add(gae); gP.add(gre); gP.add(vsep()); gP.add(dirC); gP.add(wtC); gP.add(vsep()); gP.add(gcc); gP.add(vsep()); gP.add(gbfs); gP.add(gdfs);

            sbox.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){
                String sel=(String)sbox.getSelectedItem();
                Session s=app.curSession(); s.csActive=sel;
                app.canvas.setRend(s.csRends.get(sel)); swap(sel); app.canvas.repaint();
            }});

            toolbar.setBackground(Color.WHITE); toolbar.setBorder(new MatteBorder(0,0,1,0,C_BORDER));
            dynArea.setOpaque(false); dynArea.add(defP);
            toolbar.add(lbl("Structure:")); toolbar.add(sbox); toolbar.add(vsep()); toolbar.add(dynArea);
        }

        DSRenderer csRend(){ return app.curSession().csRends.get((String)sbox.getSelectedItem()); }
        DequeRend  dq()    { return (DequeRend)app.curSession().csRends.get("Deque"); }
        CQRend     cq()    { return (CQRend)app.curSession().csRends.get("Circular Queue"); }
        GraphRend  gr()    { return (GraphRend)app.curSession().csRends.get("Graph"); }

        void doAdd(){
            String t=vf.getText().trim(); if(t.isEmpty()) return;
            try{csRend().add(Integer.parseInt(t));vf.setText("");vf.requestFocus();app.canvas.repaint();}catch(NumberFormatException ex){flash(vf);}
        }
        void swap(String s){
            dynArea.removeAll();
            if ("Deque".equals(s)) dynArea.add(dqP);
            else if ("Circular Queue".equals(s)) dynArea.add(cqP);
            else if ("Graph".equals(s)) dynArea.add(gP);
            else dynArea.add(defP);
            dynArea.revalidate(); dynArea.repaint();
        }
        public JPanel getToolbar(){ return toolbar; }
        public void activate(Session s){
            // sync combobox to session's active struct
            sbox.setSelectedItem(s.csActive);
            // wire undoMgr into every CS renderer for this session
            for(DSRenderer r:s.csRends.values()) if(r instanceof BaseRenderer)((BaseRenderer)r).undoMgr=s.undo;
            app.canvas.setRend(s.csRends.get(s.csActive));
            swap(s.csActive);
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  ANIMATION STATE HELPER
    // ═══════════════════════════════════════════════════════════════════════
    static class AnimState {
        List<int[]> stepData=new ArrayList<>();
        Set<Integer> current=new HashSet<>();
        Set<Integer> visited=new HashSet<>();
        int idx=0; boolean done=true;
        void reset(){stepData.clear();current.clear();visited.clear();idx=0;done=true;}
        void addStep(int... indices){int[]a=new int[indices.length];System.arraycopy(indices,0,a,0,a.length);stepData.add(a);done=false;}
        void advance(){
            if(idx<stepData.size()){
                current.clear();
                for(int i:stepData.get(idx)){current.add(i);visited.add(i);}
                idx++;
            }
            if(idx>=stepData.size()) done=true;
        }
        boolean isCurrent(int i){return current.contains(i);}
        boolean isVisited(int i){return visited.contains(i)&&!current.contains(i);}
        Color colorFor(int i,Color def){if(isCurrent(i))return C_ANIM_CUR;if(isVisited(i))return C_ANIM_VIS;return def;}
    }

    // Default DSRenderer stubs
    static abstract class BaseRenderer implements DSRenderer {
        UndoManager undoMgr; // set by FolderPanel.activate()
        public void add(int v){}
        public void removeLast(){}
        public void clear(){}
        public boolean hasAnimation(){return false;}
        public void animStep(){}
        public void animReset(){}
        public boolean animDone(){return true;}
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  CS RENDERERS
    // ═══════════════════════════════════════════════════════════════════════

    // Linked List
    static class LLRend extends BaseRenderer {
        final boolean dbl; final List<Integer> it=new ArrayList<>();
        AnimState anim=new AnimState();
        static final int NW=84,NH=42,GAP=40,PT=22;
        LLRend(boolean dbl){this.dbl=dbl;}
        public void draw(Graphics2D g){
            int n=it.size(); title(g,dbl?"Doubly Linked List":"Singly Linked List",-NH/2-50);
            if(n==0){hint(g,"Add values");return;}
            int sx=-(n*NW+(n-1)*GAP)/2,y=-NH/2;
            g.setFont(F_IDX);g.setColor(C_MUTED);g.drawString("HEAD",sx+NW/4-12,y-18);arr(g,sx+NW/4,y-14,sx+NW/4,y);
            for(int i=0;i<n;i++){
                int x=sx+i*(NW+GAP); Color fill=anim.colorFor(i,Color.WHITE);
                g.setColor(fill);g.fillRect(x,y,NW,NH); cell(g,x,y,NW,NH,String.valueOf(it.get(i)));
                if(i<n-1){int ax=x+NW,bx=x+NW+GAP;int fy=dbl?y+NH/2-7:y+NH/2;arr(g,ax+1,fy,bx-1,fy);if(dbl)arr(g,bx-1,y+NH/2+7,ax+1,y+NH/2+7);}
                g.setFont(F_IDX);g.setColor(C_MUTED);g.drawString("["+i+"]",x+NW/4-6,y+NH+15);
            }
            int lr=sx+(n-1)*(NW+GAP)+NW,nx=lr+GAP/2;
            arr(g,lr+1,y+NH/2-(dbl?7:0),nx,y+NH/2-(dbl?7:0));nbox(g,nx,y,30,NH);
            if(dbl){int px2=sx-GAP/2-30;arr(g,sx-1,y+NH/2+7,px2+30,y+NH/2+7);nbox(g,px2,y,30,NH);}
            if(n>1){g.setFont(F_IDX);g.setColor(C_MUTED);g.drawString("TAIL",sx+(n-1)*(NW+GAP)+NW/4-10,y-18);}
        }
        void cell(Graphics2D g,int x,int y,int w,int h,String v){
            g.setColor(Color.BLACK);g.setStroke(S_LINE);g.drawRect(x,y,w,h);
            if(dbl){int dw=w-PT*2;g.drawLine(x+PT,y,x+PT,y+h);g.drawLine(x+PT+dw,y,x+PT+dw,y+h);g.fillOval(x+PT/2-3,y+h/2-3,6,6);g.fillOval(x+PT+dw+PT/2-3,y+h/2-3,6,6);ctr(g,v,x+PT+dw/2,y+h/2,F_MONO,Color.BLACK);}
            else{int dw=w-PT;g.drawLine(x+dw,y,x+dw,y+h);g.fillOval(x+dw+PT/2-3,y+h/2-3,6,6);ctr(g,v,x+dw/2,y+h/2,F_MONO,Color.BLACK);}
        }
        public void add(int v){
            final List<Integer> before=new ArrayList<>(it);
            it.add(v);buildAnim();
            if(undoMgr!=null){final List<Integer> after=new ArrayList<>(it);undoMgr.push(new UndoableAction(){public void undo(){it.clear();it.addAll(before);buildAnim();}public void redo(){it.clear();it.addAll(after);buildAnim();}public String desc(){return "Add "+v;}});}
        }
        public void removeLast(){
            if(it.isEmpty())return;
            final List<Integer> before=new ArrayList<>(it);
            it.remove(it.size()-1);buildAnim();
            if(undoMgr!=null){final List<Integer> after=new ArrayList<>(it);undoMgr.push(new UndoableAction(){public void undo(){it.clear();it.addAll(before);buildAnim();}public void redo(){it.clear();it.addAll(after);buildAnim();}public String desc(){return "Remove from list";}});}
        }
        public void clear(){
            if(it.isEmpty())return;
            final List<Integer> before=new ArrayList<>(it);
            it.clear();anim.reset();
            if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){it.addAll(before);buildAnim();}public void redo(){it.clear();anim.reset();}public String desc(){return "Clear list";}});
        }
        public void loadLine(String line){if(line.startsWith("ll=")){loadIntList(line.substring(3),it);buildAnim();}}
        void buildAnim(){anim.reset();for(int i=0;i<it.size();i++)anim.addStep(i);}
        public boolean hasAnimation(){return !it.isEmpty();}
        public void animStep(){anim.advance();}
        public void animReset(){buildAnim();anim.current.clear();}
        public boolean animDone(){return anim.done;}
    }
    static class StackRend extends BaseRenderer {
        final List<Integer> it=new ArrayList<>(); AnimState anim=new AnimState(); static final int CW=120,CH=46;
        public void draw(Graphics2D g){
            int n=it.size();title(g,"Stack  (LIFO)",n==0?-CH/2-50:-(n*CH/2)-50);
            if(n==0){hint(g,"Add=push  |  Remove=pop");return;}
            int by=n*CH/2,x=-CW/2;g.setColor(new Color(70,70,70));g.setStroke(S_THICK);g.drawLine(x-14,by,x+CW+14,by);
            for(int i=0;i<n;i++){int y=by-(i+1)*CH;Color fill=anim.colorFor(i,Color.WHITE);rect(g,x,y,CW,CH,String.valueOf(it.get(i)),fill);g.setFont(F_IDX);g.setColor(C_MUTED);g.drawString("["+i+"]",x-28,y+CH/2+4);if(i==n-1){g.setFont(F_IDX);g.setColor(C_DIM);g.drawString("← TOP",x+CW+8,y+CH/2+4);}}
        }
        public void add(int v){
            final List<Integer> before=new ArrayList<>(it);
            it.add(v);buildAnim();
            if(undoMgr!=null){final List<Integer> after=new ArrayList<>(it);undoMgr.push(new UndoableAction(){public void undo(){it.clear();it.addAll(before);buildAnim();}public void redo(){it.clear();it.addAll(after);buildAnim();}public String desc(){return "Push "+v;}});}
        }
        public void removeLast(){
            if(it.isEmpty())return;
            final List<Integer> before=new ArrayList<>(it);
            it.remove(it.size()-1);buildAnim();
            if(undoMgr!=null){final List<Integer> after=new ArrayList<>(it);undoMgr.push(new UndoableAction(){public void undo(){it.clear();it.addAll(before);buildAnim();}public void redo(){it.clear();it.addAll(after);buildAnim();}public String desc(){return "Pop";}});}
        }
        public void clear(){
            if(it.isEmpty())return;
            final List<Integer> before=new ArrayList<>(it);
            it.clear();anim.reset();
            if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){it.addAll(before);buildAnim();}public void redo(){it.clear();anim.reset();}public String desc(){return "Clear stack";}});
        }
        public void loadLine(String line){if(line.startsWith("stack=")){loadIntList(line.substring(6),it);buildAnim();}}
        void buildAnim(){anim.reset();for(int i=it.size()-1;i>=0;i--)anim.addStep(i);}
        public boolean hasAnimation(){return !it.isEmpty();}
        public void animStep(){anim.advance();}
        public void animReset(){anim.reset();if(!it.isEmpty())buildAnim();}
        public boolean animDone(){return anim.done;}
    }

    // Queue
    static class QueueRend extends BaseRenderer {
        final List<Integer> it=new ArrayList<>(); AnimState anim=new AnimState(); static final int CW=66,CH=50;
        public void draw(Graphics2D g){
            title(g,"Queue  (FIFO)",-CH/2-50);if(it.isEmpty()){hint(g,"Add=enqueue | Remove=dequeue");return;}
            int n=it.size(),sx=-(n*CW)/2,y=-CH/2;
            for(int i=0;i<n;i++){Color fill=anim.colorFor(i,Color.WHITE);rect(g,sx+i*CW,y,CW,CH,String.valueOf(it.get(i)),fill);}
            arr(g,sx-50,0,sx-2,0,new Color(80,80,80),1.5f);g.setFont(F_IDX);g.setColor(C_MUTED);g.drawString("dequeue",sx-94,-10);
            arr(g,sx+n*CW+50,0,sx+n*CW+2,0,new Color(80,80,80),1.5f);g.drawString("enqueue",sx+n*CW+8,-10);
            g.setFont(F_IDX);g.setColor(C_DIM);g.drawString("FRONT",sx+2,y-8);g.drawString("REAR",sx+(n-1)*CW+2,y-8);
        }
        public void add(int v){
            final List<Integer> before=new ArrayList<>(it);
            it.add(v);buildAnim();
            if(undoMgr!=null){final List<Integer> after=new ArrayList<>(it);undoMgr.push(new UndoableAction(){public void undo(){it.clear();it.addAll(before);buildAnim();}public void redo(){it.clear();it.addAll(after);buildAnim();}public String desc(){return "Enqueue "+v;}});}
        }
        public void removeLast(){
            if(it.isEmpty())return;
            final List<Integer> before=new ArrayList<>(it);
            it.remove(0);buildAnim();
            if(undoMgr!=null){final List<Integer> after=new ArrayList<>(it);undoMgr.push(new UndoableAction(){public void undo(){it.clear();it.addAll(before);buildAnim();}public void redo(){it.clear();it.addAll(after);buildAnim();}public String desc(){return "Dequeue";}});}
        }
        public void clear(){
            if(it.isEmpty())return;
            final List<Integer> before=new ArrayList<>(it);
            it.clear();anim.reset();
            if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){it.addAll(before);buildAnim();}public void redo(){it.clear();anim.reset();}public String desc(){return "Clear queue";}});
        }
        public void loadLine(String line){if(line.startsWith("queue=")){loadIntList(line.substring(6),it);buildAnim();}}
        void buildAnim(){anim.reset();for(int i=0;i<it.size();i++)anim.addStep(i);}
        public boolean hasAnimation(){return !it.isEmpty();}
        public void animStep(){anim.advance();}
        public void animReset(){anim.reset();if(!it.isEmpty())buildAnim();}
        public boolean animDone(){return anim.done;}
    }

    // Deque
    static class DequeRend extends BaseRenderer {
        final LinkedList<Integer> it=new LinkedList<>(); static final int CW=66,CH=50;
        void addF(int v){
            final List<Integer> before=new ArrayList<>(it);
            it.addFirst(v);
            if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){it.clear();it.addAll(before);}public void redo(){it.addFirst(v);}public String desc(){return "Add front "+v;}});
        }
        void addR(int v){
            final List<Integer> before=new ArrayList<>(it);
            it.addLast(v);
            if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){it.clear();it.addAll(before);}public void redo(){it.addLast(v);}public String desc(){return "Add rear "+v;}});
        }
        void remF(){
            if(it.isEmpty())return;
            final List<Integer> before=new ArrayList<>(it);
            it.removeFirst();
            if(undoMgr!=null){final List<Integer> after=new ArrayList<>(it);undoMgr.push(new UndoableAction(){public void undo(){it.clear();it.addAll(before);}public void redo(){it.clear();it.addAll(after);}public String desc(){return "Remove front";}});}
        }
        void remR(){
            if(it.isEmpty())return;
            final List<Integer> before=new ArrayList<>(it);
            it.removeLast();
            if(undoMgr!=null){final List<Integer> after=new ArrayList<>(it);undoMgr.push(new UndoableAction(){public void undo(){it.clear();it.addAll(before);}public void redo(){it.clear();it.addAll(after);}public String desc(){return "Remove rear";}});}
        }
        public void add(int v){addR(v);}
        public void removeLast(){remR();}
        public void clear(){
            if(it.isEmpty())return;
            final List<Integer> before=new ArrayList<>(it);
            it.clear();
            if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){it.addAll(before);}public void redo(){it.clear();}public String desc(){return "Clear deque";}});
        }
        public void saveTo(StringBuilder sb){saveIntList(sb,"deque",new ArrayList<Integer>(it));}
        public void loadLine(String line){if(line.startsWith("deque=")){List<Integer> tmp=new ArrayList<>();loadIntList(line.substring(6),tmp);for(int v:tmp)it.addLast(v);}}
        public boolean hasAnimation(){return false;}
        public boolean animDone(){return true;}
        public void draw(Graphics2D g){
            title(g,"Deque  (Double-Ended)",-CH/2-50);if(it.isEmpty()){hint(g,"Use Front/Rear buttons");return;}
            int n=it.size(),sx=-(n*CW)/2,y=-CH/2,i=0;for(int v:it){rect(g,sx+i*CW,y,CW,CH,String.valueOf(v));i++;}
            int m=CH/2;arr(g,sx-3,m-8,sx-50,m-8);arr(g,sx-50,m+8,sx-3,m+8);arr(g,sx+n*CW+3,m-8,sx+n*CW+50,m-8);arr(g,sx+n*CW+50,m+8,sx+n*CW+3,m+8);
            g.setFont(F_IDX);g.setColor(C_DIM);g.drawString("FRONT",sx+2,y-8);g.drawString("REAR",sx+(n-1)*CW+2,y-8);
        }
    }

    // Circular Queue
    static class CQRend extends BaseRenderer {
        final LinkedList<Integer> it=new LinkedList<>(); static final int CW=62,CH=38; int cap=8;
        void enq(int v){
            if(it.size()>=cap)return;
            final List<Integer> before=new ArrayList<>(it);
            it.addLast(v);
            if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){it.clear();it.addAll(before);}public void redo(){it.addLast(v);}public String desc(){return "Enqueue "+v;}});
        }
        void deq(){
            if(it.isEmpty())return;
            final List<Integer> before=new ArrayList<>(it);
            it.removeFirst();
            if(undoMgr!=null){final List<Integer> after=new ArrayList<>(it);undoMgr.push(new UndoableAction(){public void undo(){it.clear();it.addAll(before);}public void redo(){it.clear();it.addAll(after);}public String desc(){return "Dequeue";}});}
        }
        public void add(int v){enq(v);}
        public void removeLast(){deq();}
        public void clear(){
            if(it.isEmpty())return;
            final List<Integer> before=new ArrayList<>(it);
            it.clear();
            if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){it.addAll(before);}public void redo(){it.clear();}public String desc(){return "Clear CQ";}});
        }
        public void saveTo(StringBuilder sb){sb.append("cqcap=").append(cap).append("\n");saveIntList(sb,"cq",new ArrayList<Integer>(it));}
        public void loadLine(String line){if(line.startsWith("cqcap="))try{cap=Integer.parseInt(line.substring(6));}catch(NumberFormatException ignored){}else if(line.startsWith("cq=")){List<Integer> tmp=new ArrayList<>();loadIntList(line.substring(3),tmp);for(int v:tmp)it.addLast(v);}}
        public boolean hasAnimation(){return false;} public boolean animDone(){return true;}
        public void draw(Graphics2D g){
            int used=it.size();if(used>=cap)cap=used+2;int r=44+cap*22;
            title(g,"Circular Queue  (cap="+cap+", size="+used+")",-r-CH/2-50);
            for(int i=0;i<cap;i++){
                double ang=2*Math.PI*i/cap-Math.PI/2;int nx=(int)(r*Math.cos(ang)),ny=(int)(r*Math.sin(ang));int cx=nx-CW/2,cy=ny-CH/2;boolean fi=i<used;
                g.setColor(Color.WHITE);g.fillRoundRect(cx,cy,CW,CH,8,8);g.setColor(fi?Color.BLACK:C_BORDER);g.setStroke(fi?S_LINE:S_THIN);g.drawRoundRect(cx,cy,CW,CH,8,8);
                if(fi)ctr(g,String.valueOf(it.get(i)),nx,ny,F_MONO,Color.BLACK);else ctr(g,"·",nx,ny,F_HINT,C_MUTED);
                double or=r+CH*0.9;int ix=(int)(or*Math.cos(ang)),iy=(int)(or*Math.sin(ang));g.setFont(F_IDX);g.setColor(C_MUTED);FontMetrics fm=g.getFontMetrics();String is="["+i+"]";g.drawString(is,ix-fm.stringWidth(is)/2,iy+4);
                if(!it.isEmpty()){g.setFont(new Font("SansSerif",Font.BOLD,9));g.setColor(C_DIM);if(i==0)g.drawString("F→",cx-22,ny+5);if(i==used-1)g.drawString("←R",cx+CW+4,ny+5);}
                double na=2*Math.PI*(i+1)/cap-Math.PI/2;int nx2=(int)(r*Math.cos(na)),ny2=(int)(r*Math.sin(na));
                double ddx=nx2-nx,ddy=ny2-ny,l=Math.sqrt(ddx*ddx+ddy*ddy),ux=ddx/l,uy=ddy/l,off=Math.min(CW/2.0,CH/2.0)+5;
                g.setColor(new Color(170,170,170));g.setStroke(S_THIN);g.draw(new Line2D.Double(nx+ux*off,ny+uy*off,nx2-ux*(off+2),ny2-uy*(off+2)));g.setColor(new Color(170,170,170));ah(g,nx+ux*off,ny+uy*off,nx2-ux*(off+2),ny2-uy*(off+2),6);
            }
            if(it.isEmpty())hint(g,"Enqueue rear — Dequeue front — wraps around");
        }
    }

    // Binary Tree / BST  — BFS level-order animation
    static class TreeRend extends BaseRenderer {
        final boolean bst; TNode root; AnimState anim=new AnimState(); static final int R=22,VG=72;
        List<Integer> insertLog=new ArrayList<>();
        static class TNode{int v;TNode l,r;int bfsIdx=-1;TNode(int v){this.v=v;}}
        TreeRend(boolean bst){this.bst=bst;}
        public void draw(Graphics2D g){
            int d=dep(root);int ty=root==null?-50:-(d*VG)/2;title(g,bst?"Binary Search Tree":"Binary Tree",ty);
            if(root==null){hint(g,bst?"Add values — BST order":"Add values — BFS insertion");return;}
            int sp=Math.max((int)Math.pow(2,d-1)*(R*2+20),R*2+20);dn(g,root,0,ty,sp);
        }
        void dn(Graphics2D g,TNode n,int x,int y,int sp){
            if(n==null)return;int cs=Math.max(sp/2,R*2+12);
            if(n.l!=null){int lx=x-cs,ly=y+VG;double a=Math.atan2(ly-y,lx-x);g.setColor(Color.BLACK);g.setStroke(S_LINE);g.draw(new Line2D.Double(x+R*Math.cos(a),y+R*Math.sin(a),lx-R*Math.cos(a),ly-R*Math.sin(a)));dn(g,n.l,lx,ly,cs);}
            if(n.r!=null){int rx=x+cs,ry=y+VG;double a=Math.atan2(ry-y,rx-x);g.setColor(Color.BLACK);g.setStroke(S_LINE);g.draw(new Line2D.Double(x+R*Math.cos(a),y+R*Math.sin(a),rx-R*Math.cos(a),ry-R*Math.sin(a)));dn(g,n.r,rx,ry,cs);}
            Color fill=anim.colorFor(n.bfsIdx,Color.WHITE);
            circ(g,x,y,R,String.valueOf(n.v),fill,Color.BLACK);
        }
        int dep(TNode n){return n==null?0:1+Math.max(dep(n.l),dep(n.r));}
        void rebuildTree(List<Integer> log){root=null;for(int v:log)root=bst?bi(root,v):li(root,v);}
        public void add(int v){
            final List<Integer> before=new ArrayList<>(insertLog);
            insertLog.add(v);root=bst?bi(root,v):li(root,v);buildAnim();
            if(undoMgr!=null){final List<Integer> after=new ArrayList<>(insertLog);undoMgr.push(new UndoableAction(){public void undo(){insertLog.clear();insertLog.addAll(before);rebuildTree(insertLog);buildAnim();}public void redo(){insertLog.clear();insertLog.addAll(after);rebuildTree(insertLog);buildAnim();}public String desc(){return "Add "+v+" to tree";}});}
        }
        TNode bi(TNode n,int v){if(n==null)return new TNode(v);if(v<n.v)n.l=bi(n.l,v);else if(v>n.v)n.r=bi(n.r,v);return n;}
        TNode li(TNode r,int v){TNode nn=new TNode(v);if(r==null)return nn;Queue<TNode>q=new LinkedList<>();q.add(r);while(!q.isEmpty()){TNode c=q.poll();if(c.l==null){c.l=nn;return r;}else q.add(c.l);if(c.r==null){c.r=nn;return r;}else q.add(c.r);}return r;}
        public void removeLast(){
            if(root==null)return;
            final List<Integer> before=new ArrayList<>(insertLog);
            // Remove the last BFS node from insertLog
            if(!insertLog.isEmpty())insertLog.remove(insertLog.size()-1);
            rebuildTree(insertLog);buildAnim();
            if(undoMgr!=null){final List<Integer> after=new ArrayList<>(insertLog);undoMgr.push(new UndoableAction(){public void undo(){insertLog.clear();insertLog.addAll(before);rebuildTree(insertLog);buildAnim();}public void redo(){insertLog.clear();insertLog.addAll(after);rebuildTree(insertLog);buildAnim();}public String desc(){return "Remove from tree";}});}
        }
        public void clear(){
            if(root==null&&insertLog.isEmpty())return;
            final List<Integer> before=new ArrayList<>(insertLog);
            root=null;insertLog.clear();anim.reset();
            if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){insertLog.addAll(before);rebuildTree(insertLog);buildAnim();}public void redo(){root=null;insertLog.clear();anim.reset();}public String desc(){return "Clear tree";}});
        }
        public void saveTo(StringBuilder sb){saveIntList(sb,bst?"bst":"btree",insertLog);}
        public void loadLine(String line){String key=bst?"bst=":"btree=";if(line.startsWith(key)){List<Integer>tmp=new ArrayList<>();loadIntList(line.substring(key.length()),tmp);for(int v:tmp)add(v);}}
        /** BFS level-order — visits nodes left to right, level by level */
        void buildAnim(){
            anim.reset();if(root==null)return;
            Queue<TNode>q=new LinkedList<>();q.add(root);int idx=0;
            while(!q.isEmpty()){TNode n=q.poll();n.bfsIdx=idx;anim.addStep(idx);idx++;if(n.l!=null)q.add(n.l);if(n.r!=null)q.add(n.r);}
        }
        public boolean hasAnimation(){return root!=null;}
        public void animStep(){anim.advance();}
        public void animReset(){if(root!=null)buildAnim();anim.current.clear();}
        public boolean animDone(){return anim.done;}
    }

    // Heap — level-order (BFS) traversal animation
    static class HeapRend extends BaseRenderer {
        final boolean max; final List<Integer> h=new ArrayList<>(); AnimState anim=new AnimState(); static final int R=22,VG=72;
        HeapRend(boolean max){this.max=max;}
        public void draw(Graphics2D g){
            int n=h.size(),d=n==0?1:(int)(Math.log(n)/Math.log(2))+1,ty=-(d*VG)/2;
            title(g,max?"Max Heap":"Min Heap",ty);if(n==0){hint(g,max?"Largest at root":"Smallest at root");return;}
            int sp=Math.max((int)Math.pow(2,d-1)*(R*2+20),R*2+20);da(g,0,0,ty,sp);
            int ay=ty+d*VG+44,cw=48,ch=36,ax=-(n*cw)/2;
            g.setFont(F_HINT);g.setColor(C_MUTED);g.drawString("Array (0=root, children→2i+1,2i+2):",ax,ay-10);
            for(int i=0;i<n;i++){Color fill=anim.colorFor(i,Color.WHITE);rect(g,ax+i*cw,ay,cw,ch,String.valueOf(h.get(i)),fill);ctr(g,String.valueOf(i),ax+i*cw+cw/2,ay+ch+12,F_IDX,C_MUTED);}
        }
        void da(Graphics2D g,int i,int x,int y,int sp){
            if(i>=h.size())return;int cs=Math.max(sp/2,R*2+12),l=2*i+1,r2=2*i+2;
            if(l<h.size()){int lx=x-cs,ly=y+VG;double a=Math.atan2(ly-y,lx-x);g.setColor(Color.BLACK);g.setStroke(S_LINE);g.draw(new Line2D.Double(x+R*Math.cos(a),y+R*Math.sin(a),lx-R*Math.cos(a),ly-R*Math.sin(a)));da(g,l,lx,ly,cs);}
            if(r2<h.size()){int rx=x+cs,ry=y+VG;double a=Math.atan2(ry-y,rx-x);g.setColor(Color.BLACK);g.setStroke(S_LINE);g.draw(new Line2D.Double(x+R*Math.cos(a),y+R*Math.sin(a),rx-R*Math.cos(a),ry-R*Math.sin(a)));da(g,r2,rx,ry,cs);}
            if(i==0){g.setColor(Color.BLACK);g.setStroke(new BasicStroke(2.5f));g.drawOval(x-R-4,y-R-4,(R+4)*2,(R+4)*2);}
            Color fill=anim.colorFor(i,Color.WHITE);circ(g,x,y,R,String.valueOf(h.get(i)),fill,Color.BLACK);
        }
        public void add(int v){
            final List<Integer> before=new ArrayList<>(h);
            h.add(v);su(h.size()-1);buildAnim();
            if(undoMgr!=null){final List<Integer> after=new ArrayList<>(h);undoMgr.push(new UndoableAction(){public void undo(){h.clear();h.addAll(before);buildAnim();}public void redo(){h.clear();h.addAll(after);buildAnim();}public String desc(){return "Insert "+v+" into heap";}});}
        }
        public void removeLast(){
            if(h.isEmpty())return;
            final List<Integer> before=new ArrayList<>(h);
            h.set(0,h.get(h.size()-1));h.remove(h.size()-1);if(!h.isEmpty())sd(0);buildAnim();
            if(undoMgr!=null){final List<Integer> after=new ArrayList<>(h);undoMgr.push(new UndoableAction(){public void undo(){h.clear();h.addAll(before);buildAnim();}public void redo(){h.clear();h.addAll(after);buildAnim();}public String desc(){return "Remove root from heap";}});}
        }
        public void clear(){
            if(h.isEmpty())return;
            final List<Integer> before=new ArrayList<>(h);
            h.clear();anim.reset();
            if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){h.addAll(before);buildAnim();}public void redo(){h.clear();anim.reset();}public String desc(){return "Clear heap";}});
        }
        /** Level-order (BFS) traversal — visits level by level, NOT sift-up path */
        void buildAnim(){
            anim.reset();if(h.isEmpty())return;
            // BFS order: 0, 1,2, 3,4,5,6, ...
            for(int i=0;i<h.size();i++) anim.addStep(i);
        }
        public boolean hasAnimation(){return !h.isEmpty();}
        public void animStep(){anim.advance();}
        public void animReset(){if(!h.isEmpty())buildAnim();anim.current.clear();}
        public boolean animDone(){return anim.done;}
        public void saveTo(StringBuilder sb){saveIntList(sb,max?"maxheap":"minheap",h);}
        public void loadLine(String line){String key=max?"maxheap=":"minheap=";if(line.startsWith(key)){List<Integer>tmp=new ArrayList<>();loadIntList(line.substring(key.length()),tmp);for(int v:tmp)add(v);}}
        void su(int i){while(i>0){int p=(i-1)/2;boolean sw=max?h.get(i)>h.get(p):h.get(i)<h.get(p);if(sw){Collections.swap(h,i,p);i=p;}else break;}}
        void sd(int i){while(true){int t=i,l=2*i+1,r2=2*i+2;if(l<h.size()&&(max?h.get(l)>h.get(t):h.get(l)<h.get(t)))t=l;if(r2<h.size()&&(max?h.get(r2)>h.get(t):h.get(r2)<h.get(t)))t=r2;if(t!=i){Collections.swap(h,i,t);i=t;}else break;}}
    }

    // Graph with BFS/DFS animation
    static class GraphRend extends BaseRenderer implements HittableRenderer {
        static class GN implements Draggable{String l;double x,y;int state=0;GN(String l,double x,double y){this.l=l;this.x=x;this.y=y;}public double gx(){return x;}public double gy(){return y;}public void mv(double dx,double dy){x+=dx;y+=dy;}}
        static class GE{String f,t;int w;boolean dir,wt;GE(String f,String t,int w,boolean d,boolean wt){this.f=f;this.t=t;this.w=w;this.dir=d;this.wt=wt;}}
        final Map<String,GN> ns=new LinkedHashMap<>(); final List<GE> es=new ArrayList<>(); static final int NR=24;
        List<String[]> animSteps=new ArrayList<>(); int animIdx=0; boolean animDoneF=true;
        void addNode(String l){
            if(ns.containsKey(l))return;
            int c=ns.size();double a=c*2.4,r=80+c*28;
            ns.put(l,new GN(l,r*Math.cos(a),r*Math.sin(a)));
            if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){ns.remove(l);final String fl=l;es.removeIf(e->e.f.equals(fl)||e.t.equals(fl));}public void redo(){int cc=ns.size();double aa=cc*2.4,rr=80+cc*28;ns.put(l,new GN(l,rr*Math.cos(aa),rr*Math.sin(aa)));}public String desc(){return "Add node "+l;}});
        }
        void addEdge(String f,String t,int w,boolean d,boolean wt){
            if(!ns.containsKey(f))addNode(f);if(!ns.containsKey(t))addNode(t);
            for(GE e:es)if(e.f.equals(f)&&e.t.equals(t))return;
            final GE ne=new GE(f,t,w,d,wt);es.add(ne);
            if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){es.remove(ne);}public void redo(){es.add(ne);}public String desc(){return "Add edge "+f+"→"+t;}});
        }
        void remNode(String l){
            if(!ns.containsKey(l))return;
            final GN saved=ns.get(l);
            final List<GE> savedEdges=new ArrayList<>();
            for(GE e:es) if(e.f.equals(l)||e.t.equals(l)) savedEdges.add(e);
            ns.remove(l);es.removeIf(e->e.f.equals(l)||e.t.equals(l));
            if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){ns.put(l,saved);es.addAll(savedEdges);}public void redo(){ns.remove(l);final String fl=l;es.removeIf(e->e.f.equals(fl)||e.t.equals(fl));}public String desc(){return "Remove node "+l;}});
        }
        void remEdge(String f,String t,boolean d){
            final List<GE> removed=new ArrayList<>();
            if(d) es.removeIf(e->{if(e.f.equals(f)&&e.t.equals(t)){removed.add(e);return true;}return false;});
            else  es.removeIf(e->{if((e.f.equals(f)&&e.t.equals(t))||(e.f.equals(t)&&e.t.equals(f))){removed.add(e);return true;}return false;});
            if(!removed.isEmpty()&&undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){es.addAll(removed);}public void redo(){es.removeAll(removed);}public String desc(){return "Remove edge";}});
        }
        public Draggable nodeAt(double wx,double wy){for(GN n:ns.values()){double dx=n.x-wx,dy=n.y-wy;if(dx*dx+dy*dy<=(NR+4)*(NR+4))return n;}return null;}
        public void add(int v){addNode(String.valueOf(v));}
        public void removeLast(){
            if(ns.isEmpty())return;
            String last=null;for(String k:ns.keySet())last=k;
            if(last!=null)remNode(last);
        }
        public void clear(){
            if(ns.isEmpty()&&es.isEmpty())return;
            final Map<String,GN> savedNs=new LinkedHashMap<>(ns);
            final List<GE> savedEs=new ArrayList<>(es);
            ns.clear();es.clear();
            if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){ns.putAll(savedNs);es.addAll(savedEs);}public void redo(){ns.clear();es.clear();}public String desc(){return "Clear graph";}});
        }

        void startBFS(String start){
            animSteps.clear();animIdx=0;animDoneF=false;for(GN n:ns.values())n.state=0;
            if(!ns.containsKey(start))return;
            List<String> vis=new ArrayList<>();Queue<String> q=new LinkedList<>();q.add(start);vis.add(start);
            while(!q.isEmpty()){
                String cur=q.poll();String[]step=new String[ns.size()];int i=0;
                for(String k:ns.keySet()) step[i++]=k+":"+(k.equals(cur)?"cur":vis.contains(k)?"vis":"none");
                animSteps.add(step);
                for(GE e:es){if(e.f.equals(cur)&&!vis.contains(e.t)){vis.add(e.t);q.add(e.t);}if(!e.dir&&e.t.equals(cur)&&!vis.contains(e.f)){vis.add(e.f);q.add(e.f);}}
            }
        }
        void startDFS(String start){
            animSteps.clear();animIdx=0;animDoneF=false;for(GN n:ns.values())n.state=0;
            if(!ns.containsKey(start))return;
            List<String> vis=new ArrayList<>();Deque<String> stk=new ArrayDeque<>();stk.push(start);
            while(!stk.isEmpty()){
                String cur=stk.pop();if(vis.contains(cur))continue;vis.add(cur);
                String[]step=new String[ns.size()];int i=0;for(String k:ns.keySet())step[i++]=k+":"+(k.equals(cur)?"cur":vis.contains(k)?"vis":"none");
                animSteps.add(step);
                List<String> nb=new ArrayList<>();for(GE e:es){if(e.f.equals(cur)&&!vis.contains(e.t))nb.add(e.t);if(!e.dir&&e.t.equals(cur)&&!vis.contains(e.f))nb.add(e.f);}
                Collections.reverse(nb);for(String n:nb)stk.push(n);
            }
        }

        public void saveTo(StringBuilder sb){
            for (Map.Entry<String,GN> e : ns.entrySet())
                sb.append("gn=").append(e.getKey()).append(",").append(String.format("%.1f",e.getValue().x)).append(",").append(String.format("%.1f",e.getValue().y)).append("\n");
            for (GE e : es)
                sb.append("ge=").append(e.f).append(",").append(e.t).append(",").append(e.w).append(",").append(e.dir).append(",").append(e.wt).append("\n");
        }
        public void loadLine(String line){
            if (line.startsWith("gn=")){ String[] p=line.substring(3).split(",");if(p.length>=3)try{ns.put(p[0],new GN(p[0],Double.parseDouble(p[1]),Double.parseDouble(p[2])));}catch(NumberFormatException ignored){} }
            else if (line.startsWith("ge=")){ String[]p=line.substring(3).split(",");if(p.length>=5)try{es.add(new GE(p[0],p[1],Integer.parseInt(p[2]),Boolean.parseBoolean(p[3]),Boolean.parseBoolean(p[4])));}catch(NumberFormatException ignored){} }
        }
        public boolean hasAnimation(){return !animSteps.isEmpty();}
        public void animStep(){
            if(animIdx<animSteps.size()){String[]step=animSteps.get(animIdx++);for(String entry:step){String[]kv=entry.split(":");if(kv.length==2){GN n=ns.get(kv[0]);if(n!=null){if("cur".equals(kv[1]))n.state=1;else if("vis".equals(kv[1]))n.state=2;else n.state=0;}}}}
            if(animIdx>=animSteps.size())animDoneF=true;
        }
        public void animReset(){animIdx=0;animDoneF=animSteps.isEmpty();for(GN n:ns.values())n.state=0;}
        public boolean animDone(){return animDoneF;}

        public void draw(Graphics2D g){
            title(g,"Graph",-200);if(ns.isEmpty()){hint(g,"Add nodes + edges. Drag nodes. Type start node then BFS/DFS.");return;}
            for(GE e:es){GN fn=ns.get(e.f),tn=ns.get(e.t);if(fn!=null&&tn!=null)drawE(g,fn,tn,e);}
            for(GN n:ns.values()){Color fill=n.state==1?C_ANIM_CUR:n.state==2?C_ANIM_VIS:Color.WHITE;g.setColor(fill);g.fillOval((int)(n.x-NR),(int)(n.y-NR),NR*2,NR*2);g.setColor(Color.BLACK);g.setStroke(S_LINE);g.drawOval((int)(n.x-NR),(int)(n.y-NR),NR*2,NR*2);ctr(g,n.l,(int)n.x,(int)n.y,F_MONO,Color.BLACK);}
        }
        void drawE(Graphics2D g,GN fn,GN tn,GE e){
            if(fn==tn){int lr=NR+14,lx=(int)(fn.x+NR*0.6),ly=(int)(fn.y-NR*0.6);g.setColor(Color.BLACK);g.setStroke(S_LINE);g.drawOval(lx,ly-lr,lr*2,lr*2);if(e.dir)ah(g,lx+lr,ly-lr/2,lx,ly-2,8);return;}
            double dx=tn.x-fn.x,dy=tn.y-fn.y,len=Math.sqrt(dx*dx+dy*dy),ux=dx/len,uy=dy/len;
            boolean mir=false;for(GE o:es)if(o!=e&&o.f.equals(e.t)&&o.t.equals(e.f)){mir=true;break;}
            g.setColor(Color.BLACK);g.setStroke(S_LINE);
            if(mir){double ppx=-uy*40,ppy=ux*40,mx=(fn.x+tn.x)/2+ppx,my=(fn.y+tn.y)/2+ppy;
                double aS=Math.atan2(my-fn.y,mx-fn.x),aE=Math.atan2(tn.y-my,tn.x-mx);
                double sx=fn.x+NR*Math.cos(aS),sy=fn.y+NR*Math.sin(aS),ex=tn.x-NR*Math.cos(aE),ey=tn.y-NR*Math.sin(aE);
                g.draw(new QuadCurve2D.Double(sx,sy,mx,my,ex,ey));if(e.dir)ah(g,mx,my,ex,ey,9);if(e.wt)ewt(g,(sx+2*mx+ex)/4,(sy+2*my+ey)/4,e.w,ux,uy);
            }else{double sx=fn.x+ux*NR,sy=fn.y+uy*NR,ex=tn.x-ux*(NR+1),ey=tn.y-uy*(NR+1);
                g.draw(new Line2D.Double(sx,sy,ex,ey));if(e.dir)ah(g,sx,sy,ex,ey,9);if(e.wt)ewt(g,(fn.x+tn.x)/2,(fn.y+tn.y)/2,e.w,ux,uy);}
        }
        void ewt(Graphics2D g,double wx,double wy,int w,double ux,double uy){
            double ox=-uy*14,oy=ux*14;int lx=(int)(wx+ox),ly=(int)(wy+oy);g.setFont(F_IDX);FontMetrics fm=g.getFontMetrics();String ws=String.valueOf(w);int tw=fm.stringWidth(ws);g.setColor(Color.WHITE);g.fillRoundRect(lx-tw/2-3,ly-fm.getAscent()+1,tw+6,fm.getHeight(),4,4);g.setColor(C_DIM);g.drawString(ws,lx-tw/2,ly);}
    }

    // Helper: AnimState needs a reset-current method
    // (patching AnimState to add stepIdx reset)
    // Already has reset() which clears everything. For "animReset" we want to
    // keep the step data but clear current highlights:
    static { /* AnimState.stepIdx field added inline below */ }

    // ═══════════════════════════════════════════════════════════════════════
    //  CHEMISTRY FOLDER
    // ═══════════════════════════════════════════════════════════════════════
    static class ChemFolderPanel implements FolderPanel {
        final AppFrame app;
        final JPanel toolbar=new JPanel(new FlowLayout(FlowLayout.LEFT,5,6));
        final JComboBox<String> toolBox;
        JToggleButton hideAtomsBtn;

        //static final String[] TOOLS={"Bond (Single)","Bond (Double)","Bond (Triple)","Wedge","Dash","Bond-Line","Lone Pair","+ Charge","− Charge","Delete","Select","Reaction Arrow","Curved Arrow"};
        static final String[] TOOLS={"Bond (Single)","Bond (Double)","Bond (Triple)","Wedge","Dash","Bond-Line","Select","Reaction Arrow","Curved Arrow","Plus Sign"};
        //static final String[] PREBUILTS={"H2O",...}; // replaced by category system below
        static final String[] CAT_NAMES={"Aromatic","Compounds","Acids & Bases"};
        static final String[][] CAT_ITEMS={
            {"Benzene","Phenol","Aniline","Cumene","Toluene","Nitrobenzene"},
            {"H2O","NH3","CH4","CO2","O2","O3","H2O2","HI","Ethane","Ethanol","Ethylene","Methanol","Hexane","Acetone","PCl5","Diborane"},
            {"HCl","H2SO4","HNO3","NaOH","KMnO4","Na2Cr2O7"}
        };

        ChemFolderPanel(AppFrame app){
            this.app=app;
            toolBox=combo(TOOLS);

            final JComboBox<String> catBox=combo(CAT_NAMES);
            final JComboBox<String> pb=combo(CAT_ITEMS[0]);
            catBox.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){
                int ci=catBox.getSelectedIndex(); if(ci<0)return;
                pb.removeAllItems(); for(String s:CAT_ITEMS[ci]) pb.addItem(s);
            }});
            JButton load=btn("Add to Canvas");
            load.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){
                String sel=(String)pb.getSelectedItem(); if(sel==null)return;
                ChemRenderer cr=app.curSession().chemRend;
                Set<String> before=new HashSet<>(cr.atoms.keySet());
                cr.addPrebuilt(sel);
                cr.selectedIds.clear();
                for(String id:cr.atoms.keySet()) if(!before.contains(id)) cr.selectedIds.add(id);
                cr.activeTool="Select";
                app.canvas.repaint();
            }});

            String[]elems={"H","C","N","O","F","Cl","Br","I","S","P","B","Na","K","Cr","Zn","Mn","custom"};
            JComboBox<String> elBox=combo(elems);
            final JTextField custEl=tf(3); custEl.setEnabled(false);
            elBox.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){custEl.setEnabled("custom".equals(elBox.getSelectedItem()));}});
            //final JSpinner chargeSpinner = new JSpinner(new SpinnerNumberModel(0,-4,4,1));
            //chargeSpinner.setPreferredSize(new java.awt.Dimension(50,26));
            //((JSpinner.DefaultEditor)chargeSpinner.getEditor()).getTextField().setFont(F_UI);
            JButton addAtomBtn=btn("Add Atom");
            addAtomBtn.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){
                String el="custom".equals(elBox.getSelectedItem())?custEl.getText().trim():(String)elBox.getSelectedItem();
                int ch = 0;
                try {ch = (el!=null&&!el.isEmpty()) ? ChemRenderer.VALENCE.get(el) : 0;} catch (NullPointerException err) {ChemRenderer.VALENCE.put(el,0);}
                if(el!=null&&!el.isEmpty()){app.curSession().chemRend.addAtomManual(el,ch);app.canvas.repaint();}
            }});

            toolBox.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){
                app.curSession().chemRend.setTool((String)toolBox.getSelectedItem());
            }});

            JButton clr=btn("Clear Canvas");
            clr.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){app.curSession().chemRend.clear();app.canvas.repaint();}});

            final JToggleButton hideAtomsBtn=tglBtn("◉ Hide Atoms");
            this.hideAtomsBtn=hideAtomsBtn;
            hideAtomsBtn.setToolTipText("Hide atom circles — show only coloured element labels (bond-line style)");
            hideAtomsBtn.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){
                ChemRenderer cr=app.curSession().chemRend;
                cr.hideAtoms=hideAtomsBtn.isSelected();
                app.canvas.repaint();
            }});

            toolbar.setBackground(Color.WHITE); toolbar.setBorder(new MatteBorder(0,0,1,0,C_BORDER));
            toolbar.add(lbl("Category:")); toolbar.add(catBox); toolbar.add(lbl("Molecule:")); toolbar.add(pb); toolbar.add(load); toolbar.add(vsep());
            toolbar.add(lbl("Atom:")); toolbar.add(elBox); toolbar.add(custEl); toolbar.add(addAtomBtn); toolbar.add(vsep());
            toolbar.add(lbl("Tool:")); toolbar.add(toolBox); toolbar.add(vsep()); toolbar.add(hideAtomsBtn); toolbar.add(vsep()); toolbar.add(clr);
        }
        public JPanel getToolbar(){return toolbar;}
        public void activate(Session s){
            app.canvas.setRend(s.chemRend);
            s.chemRend.undoMgr = s.undo;
            // sync Hide Atoms toggle to the session's renderer state
            hideAtomsBtn.setSelected(s.chemRend.hideAtoms);
            s.chemRend.toolChangeCB = new Runnable(){public void run(){
                String t = s.chemRend.activeTool;
                for(int i=0;i<toolBox.getItemCount();i++) if(toolBox.getItemAt(i).equals(t)){ toolBox.setSelectedIndex(i); break; }
            }};
            s.chemRend.setTool((String)toolBox.getSelectedItem());
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  CHEMISTRY RENDERER
    // ═══════════════════════════════════════════════════════════════════════
    static class ChemRenderer extends BaseRenderer implements HittableRenderer, MouseConsumer {
        static class Atom implements Draggable {
            String id,el; double x,y; int lps=0,charge=0; boolean selected=false;
            Atom(String id,String el,double x,double y){this.id=id;this.el=el;this.x=x;this.y=y;}
            public double gx(){return x;} public double gy(){return y;} public void mv(double dx,double dy){x+=dx;y+=dy;}
        }
        static class Bond{ String a,b; int order; String type; Bond(String a,String b,int o,String t){this.a=a;this.b=b;this.order=o;this.type=t;} }
        static class ChemArrow{ double x1,y1,x2,y2; boolean curved; String fromId,toId;
            ChemArrow(double x1,double y1,double x2,double y2){this.x1=x1;this.y1=y1;this.x2=x2;this.y2=y2;}
            ChemArrow(String f,String t){fromId=f;toId=t;curved=true;} }

        final Map<String,Atom> atoms=new LinkedHashMap<>(); final List<Bond> bonds=new ArrayList<>(); final List<ChemArrow> arrows=new ArrayList<>();
        final List<double[]> plusSymbols=new ArrayList<>(); // {x, y}
        int idC=0; String activeTool="Bond (Single)";
        String toolBeforeSelect="Bond (Single)"; boolean autoSwitchedSelect=false;
        boolean hideAtoms=false; // when true: circles hidden, labels coloured by element
        UndoManager undoMgr; // set by activate
        Runnable toolChangeCB; // called when tool changes so toolbar combobox can sync
        // selection
        Set<String> selectedIds=new HashSet<>();
        // move tracking for undo
        Map<String,double[]> preMovePositions=new HashMap<>();
        Atom singleDragAtom=null;
        // clipboard (static so it persists across paste)
        static Map<String,Atom> chemClipAtoms=new LinkedHashMap<>();
        static List<Bond> chemClipBonds=new ArrayList<>();
        boolean selectDragging=false; double selX0,selY0,selX1,selY1;
        boolean movingSelected=false; double moveStartX, moveStartY;

        static final Map<String,Color> ECOL=new LinkedHashMap<>();
        static{ ECOL.put("H",new Color(255,255,255));ECOL.put("C",new Color(210,210,210));ECOL.put("N",new Color(180,180,255));ECOL.put("O",new Color(255,170,170));ECOL.put("F",new Color(170,255,200));ECOL.put("Cl",new Color(150,230,150));ECOL.put("Br",new Color(200,140,120));ECOL.put("S",new Color(255,230,120));ECOL.put("P",new Color(255,190,110));ECOL.put("I",new Color(200,160,210));ECOL.put("B",new Color(255,205,160));ECOL.put("K",new Color(220,200,240));ECOL.put("Na",new Color(190,220,245));ECOL.put("Cr",new Color(195,215,200));ECOL.put("Zn",new Color(200,215,225));ECOL.put("Mn",new Color(210,185,220));ECOL.put("?",new Color(230,230,230)); }
        static final Map<String,Integer> VALENCE=new LinkedHashMap<>();
        static { VALENCE.put("H",1); VALENCE.put("C",4); VALENCE.put("N",5); VALENCE.put("O",6); VALENCE.put("F",7); VALENCE.put("Cl",7); VALENCE.put("Br",7); VALENCE.put("S",6); VALENCE.put("P",5); VALENCE.put("I",7); VALENCE.put("B",3); VALENCE.put("K",1); VALENCE.put("Na",1); VALENCE.put("Cr",6); VALENCE.put("Zn",2); VALENCE.put("Mn",7); }
        
        static final int AR=22;

        void setTool(String t){
            if(!"Select".equals(t)) toolBeforeSelect=t;
            activeTool=t; selectedIds.clear(); autoSwitchedSelect=false;
            if(toolChangeCB!=null) toolChangeCB.run();
        }
        void setToolAuto(String t){ // auto-switch (e.g. after adding prebuilt) — restores on deselect
            toolBeforeSelect=activeTool; activeTool=t; selectedIds.clear(); autoSwitchedSelect=true;
            if(toolChangeCB!=null) toolChangeCB.run();
        }

        // ── atom/bond add ────────────────────────────────────────────────────
        String at(String el,double x,double y){String id=el+(++idC);atoms.put(id,new Atom(id,el,x,y));return id;}
        String addAtomManual(String el){return addAtomManual(el,0);}
        String addAtomManual(String el,int charge){
            int n=atoms.size(); double ang=n*2.4,r=60+n*28;
            final double fx=r*Math.cos(ang),fy=r*Math.sin(ang);
            final String id=el+(++idC);
            Atom a=new Atom(id,el,fx,fy); a.charge=charge;
            atoms.put(id,a);
            if(undoMgr!=null){
                final int fCharge=charge;
                undoMgr.push(new UndoableAction(){
                    public void undo(){atoms.remove(id);bonds.removeIf(b->b.a.equals(id)||b.b.equals(id));}
                    public void redo(){Atom ra=new Atom(id,el,fx,fy);ra.charge=fCharge;atoms.put(id,ra);}
                    public String desc(){return "Add atom "+el;}
                });
            }
            return id;
        }
        void bd(String a2,String b2,int o,String t){
            if(!atoms.containsKey(a2)||!atoms.containsKey(b2)||a2.equals(b2))return;
            for(Bond bn:bonds)if((bn.a.equals(a2)&&bn.b.equals(b2))||(bn.a.equals(b2)&&bn.b.equals(a2))){
                final int oldO=bn.order; final String oldT=bn.type; final Bond fbn=bn;
                bn.order=o;bn.type=t;
                recalcCharges(a2);recalcCharges(b2);
                return;
            }
            bonds.add(new Bond(a2,b2,o,t));
            recalcCharges(a2);recalcCharges(b2);
        }
        void bdNoCharge(String a2,String b2,int o,String t){
            // Internal use: add bond without charge recalc (for prebuilts/undo)
            if(!atoms.containsKey(a2)||!atoms.containsKey(b2)||a2.equals(b2))return;
            for(Bond bn:bonds)if((bn.a.equals(a2)&&bn.b.equals(b2))||(bn.a.equals(b2)&&bn.b.equals(a2))){bn.order=o;bn.type=t;return;}
            bonds.add(new Bond(a2,b2,o,t));
        }
        
        boolean plusMoved;
        // ── MouseConsumer — selection + right-drag bond creation ─────────────
        public boolean onPress(double wx,double wy,MouseEvent e,CanvasPanel cv){
            if("Plus Sign".equals(activeTool)){
                plusMoved = false;
                return true;
            }
            if ("Select".equals(activeTool)) {
                Atom a=atomAt(wx,wy);
                if(a!=null && selectedIds.contains(a.id)){
                    movingSelected=true;moveStartX=wx;moveStartY=wy;
                    // record positions of all selected atoms for undo
                    preMovePositions.clear();
                    for(String id:selectedIds){Atom at=atoms.get(id);if(at!=null)preMovePositions.put(id,new double[]{at.x,at.y});}
                    return true;
                }
                selectDragging=true; selX0=wx; selY0=wy; selX1=wx; selY1=wy; selectedIds.clear(); return true;
            }
            // Track single-atom drag for undo
            singleDragAtom=atomAt(wx,wy);
            if(singleDragAtom!=null){preMovePositions.clear();preMovePositions.put(singleDragAtom.id,new double[]{singleDragAtom.x,singleDragAtom.y});}
            return false;
        }
        public boolean onDrag(double wx,double wy,double px,double py,MouseEvent e,CanvasPanel cv){
            if("Plus Sign".equals(activeTool)){
                plusMoved = true;
            }
            if ("Select".equals(activeTool)){
                if(movingSelected){ double ddx=wx-moveStartX,ddy=wy-moveStartY; for(String id:selectedIds){Atom a=atoms.get(id);if(a!=null){a.x+=ddx;a.y+=ddy;}} moveStartX=wx; moveStartY=wy; return true; }
                if(selectDragging){ selX1=wx; selY1=wy; updateSelection(); return true; }
            }
            return false;
        }
        public void onRelease(double wx,double wy,MouseEvent e,CanvasPanel cv){
            boolean wasDragging=selectDragging;
            boolean wasMoving=movingSelected;
            selectDragging=false; movingSelected=false;
            if("Plus Sign".equals(activeTool)){if (!plusMoved) {final double fx = wx, fy = wy; plusSymbols.add(new double[]{fx, fy}); if(undoMgr != null) undoMgr.push(new UndoableAction(){ public void undo(){ for(int i=plusSymbols.size()-1;i>=0;i--){ double[] p = plusSymbols.get(i); if(Math.abs(p[0]-fx)<1 && Math.abs(p[1]-fy)<1){ plusSymbols.remove(i); break; } } } public void redo(){ plusSymbols.add(new double[]{fx, fy}); } public String desc(){ return "Add + symbol"; } }); cv.repaint(); } }
            // Push undo for group move
            if(wasMoving && !preMovePositions.isEmpty()){
                final Map<String,double[]> before=new HashMap<>(preMovePositions);
                final Map<String,double[]> after=new HashMap<>();
                for(String id:before.keySet()){Atom at=atoms.get(id);if(at!=null)after.put(id,new double[]{at.x,at.y});}
                boolean moved=false;for(String id:before.keySet()){double[]b=before.get(id);double[]a=after.get(id);if(a!=null&&(Math.abs(a[0]-b[0])>0.5||Math.abs(a[1]-b[1])>0.5)){moved=true;break;}}
                if(moved&&undoMgr!=null) undoMgr.push(new UndoableAction(){
                    public void undo(){for(Map.Entry<String,double[]>en:before.entrySet()){Atom at=atoms.get(en.getKey());if(at!=null){at.x=en.getValue()[0];at.y=en.getValue()[1];}}}
                    public void redo(){for(Map.Entry<String,double[]>en:after.entrySet()){Atom at=atoms.get(en.getKey());if(at!=null){at.x=en.getValue()[0];at.y=en.getValue()[1];}}}
                    public String desc(){return "Move atoms";}
                });
                preMovePositions.clear();
            }
            // Push undo for single-atom drag
            if(!wasMoving && singleDragAtom!=null && !preMovePositions.isEmpty()){
                double[]bpos=preMovePositions.get(singleDragAtom.id);
                final Atom fa=singleDragAtom;
                if(bpos!=null&&(Math.abs(fa.x-bpos[0])>0.5||Math.abs(fa.y-bpos[1])>0.5)){
                    final double bx=bpos[0],by=bpos[1],ax2=fa.x,ay2=fa.y;
                    if(undoMgr!=null) undoMgr.push(new UndoableAction(){
                        public void undo(){fa.x=bx;fa.y=by;}
                        public void redo(){fa.x=ax2;fa.y=ay2;}
                        public String desc(){return "Move atom";}
                    });
                }
                preMovePositions.clear(); singleDragAtom=null;
            }
            // If we were auto-switched to Select (e.g. after adding prebuilt), restore previous tool when user ends selection
            if(autoSwitchedSelect && !wasDragging && !wasMoving){
                autoSwitchedSelect=false;
                activeTool=toolBeforeSelect;
                if(toolChangeCB!=null) toolChangeCB.run();
            }
        }
        void updateSelection(){
            double minX=Math.min(selX0,selX1),maxX=Math.max(selX0,selX1),minY=Math.min(selY0,selY1),maxY=Math.max(selY0,selY1);
            selectedIds.clear();
            for(Atom a:atoms.values()) if(a.x>=minX&&a.x<=maxX&&a.y>=minY&&a.y<=maxY) selectedIds.add(a.id);
        }
        public void onRightClick(double wx,double wy,int sx,int sy,CanvasPanel cv){
            // Check for nearby plus symbol first
            for(int i=plusSymbols.size()-1;i>=0;i--){double[]p=plusSymbols.get(i);if(Math.abs(p[0]-wx)<22&&Math.abs(p[1]-wy)<22){final int fi=i;final double[]savedP=p.clone();JPopupMenu m=new JPopupMenu();m.add(mi("Delete '+'",new ActionListener(){public void actionPerformed(ActionEvent e){plusSymbols.remove(fi);cv.repaint();if(undoMgr!=null)undoMgr.push(new UndoableAction(){public void undo(){plusSymbols.add(savedP);}public void redo(){for(int i2=plusSymbols.size()-1;i2>=0;i2--){double[]pp=plusSymbols.get(i2);if(Math.abs(pp[0]-savedP[0])<0.5&&Math.abs(pp[1]-savedP[1])<0.5){plusSymbols.remove(i2);break;}}}public String desc(){return "Delete + symbol";}});}}));m.show(cv,sx,sy);return;}}
            // Check arrows
            ChemArrow _ar=arrowAt(wx,wy); if(_ar!=null){showArrowMenu(_ar,sx,sy,cv);return;}
            Atom a=atomAt(wx,wy);
            // If clicked atom is in a multi-selection, show group menu
            if(a!=null && selectedIds.contains(a.id) && selectedIds.size()>1){showGroupMenu(sx,sy,cv);return;}
            if(a!=null){showAtomMenu(a,sx,sy,cv);return;}
            Bond b=bondAt(wx,wy); if(b!=null) showBondMenu(b,sx,sy,cv);
        }
        public void onRightDragEnd(double sx,double sy,double ex,double ey,CanvasPanel cv){
            if("Reaction Arrow".equals(activeTool)){
                final ChemArrow ar=new ChemArrow(sx,sy,ex,ey); arrows.add(ar);
                if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){arrows.remove(ar);}public void redo(){arrows.add(ar);}public String desc(){return "Add reaction arrow";}});
                cv.repaint(); return;
            }
            if("Curved Arrow".equals(activeTool)){
                Atom s2=atomAt(sx,sy),d2=atomAt(ex,ey);
                if(s2!=null&&d2!=null&&s2!=d2){
                    final ChemArrow ar=new ChemArrow(s2.id,d2.id); arrows.add(ar);
                    if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){arrows.remove(ar);}public void redo(){arrows.add(ar);}public String desc(){return "Add mechanism arrow";}});
                    cv.repaint();
                } return;
            }
            Atom src=atomAt(sx,sy), dst=atomAt(ex,ey);
            if(src==null||dst==null||src==dst) return;
            // determine bond from active tool
            int order=1; String type="single";
            if("Bond (Single)".equals(activeTool)){order=1;type="single";}
            else if("Bond (Double)".equals(activeTool)){order=2;type="double";}
            else if("Bond (Triple)".equals(activeTool)){order=3;type="triple";}
            else if("Wedge".equals(activeTool)){order=1;type="wedge";}
            else if("Dash".equals(activeTool)){order=1;type="dash";}
            else if("Bond-Line".equals(activeTool)){order=1;type="bondline";}
            else { order=1; type="single"; }
            // Find existing bond to know if this is an update or new
            Bond existing=null;
            for(Bond bn:bonds)if((bn.a.equals(src.id)&&bn.b.equals(dst.id))||(bn.a.equals(dst.id)&&bn.b.equals(src.id))){existing=bn;break;}
            final int fOrder=order; final String fType=type;
            final String fsrc=src.id,fdst=dst.id;
            if(existing!=null){
                final int oldO=existing.order; final String oldT=existing.type;
                final Bond fBond=existing;
                bd(src.id,dst.id,order,type);
                if(undoMgr!=null) undoMgr.push(new UndoableAction(){
                    public void undo(){fBond.order=oldO;fBond.type=oldT;recalcCharges(fsrc);recalcCharges(fdst);}
                    public void redo(){fBond.order=fOrder;fBond.type=fType;recalcCharges(fsrc);recalcCharges(fdst);}
                    public String desc(){return "Change bond";}
                });
            } else {
                bd(src.id,dst.id,order,type);
                if(undoMgr!=null) undoMgr.push(new UndoableAction(){
                    public void undo(){bonds.removeIf(b->((b.a.equals(fsrc)&&b.b.equals(fdst))||(b.a.equals(fdst)&&b.b.equals(fsrc))));recalcCharges(fsrc);recalcCharges(fdst);}
                    public void redo(){bd(fsrc,fdst,fOrder,fType);}
                    public String desc(){return "Add bond";}
                });
            }
            cv.repaint();
        }

        // ── context menus ─────────────────────────────────────────────────────
        ChemArrow arrowAt(double wx,double wy){
            for(ChemArrow ar:arrows){
                double mx,my;
                if(!ar.curved){mx=(ar.x1+ar.x2)/2;my=(ar.y1+ar.y2)/2;}
                else{Atom fa=atoms.get(ar.fromId),ta=atoms.get(ar.toId);if(fa==null||ta==null)continue;mx=(fa.x+ta.x)/2;my=(fa.y+ta.y)/2;}
                double dx=wx-mx,dy=wy-my; if(dx*dx+dy*dy<=28*28) return ar;
            }
            return null;
        }
        void showArrowMenu(ChemArrow ar,int sx,int sy,JComponent par){
            JPopupMenu m=new JPopupMenu();
            m.add(mi("Delete arrow",new ActionListener(){public void actionPerformed(ActionEvent e){
                arrows.remove(ar);par.repaint();
                if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){arrows.add(ar);}public void redo(){arrows.remove(ar);}public String desc(){return "Delete arrow";}});
            }}));
            m.show(par,sx,sy);
        }
        void showAtomMenu(Atom a,int sx,int sy,JComponent par){
            JPopupMenu m=new JPopupMenu();
            m.add(mi("Delete atom",new ActionListener(){public void actionPerformed(ActionEvent e){
                final Atom fa=a; final Map<String,Atom> savedAtoms=new LinkedHashMap<>(atoms); final List<Bond> savedBonds=new ArrayList<>(bonds);
                // capture neighbour ids before deletion so we can recalc after undo
                final Set<String> nbrs=new HashSet<>();for(Bond _b:bonds)if(_b.a.equals(fa.id))nbrs.add(_b.b);else if(_b.b.equals(fa.id))nbrs.add(_b.a);
                deleteAtom(a.id);par.repaint();
                if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){atoms.clear();atoms.putAll(savedAtoms);bonds.clear();bonds.addAll(savedBonds);recalcCharges(fa.id);for(String _n:nbrs)recalcCharges(_n);}public void redo(){deleteAtom(fa.id);}public String desc(){return "Delete atom "+fa.el;}});
            }}));
            m.addSeparator();
            m.add(mi("Add lone pair",new ActionListener(){public void actionPerformed(ActionEvent e){
                a.lps++;par.repaint();recalcCharges(a.id);
                if(undoMgr!=null){final int prev=a.lps-1;undoMgr.push(new UndoableAction(){public void undo(){a.lps=prev;recalcCharges(a.id);}public void redo(){a.lps=prev+1;recalcCharges(a.id);}public String desc(){return "Add lone pair";}});}
            }}));
            m.add(mi("Remove lone pair",new ActionListener(){public void actionPerformed(ActionEvent e){
                if(a.lps>0){final int prev=a.lps;a.lps--;par.repaint();recalcCharges(a.id);if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){a.lps=prev;recalcCharges(a.id);}public void redo(){a.lps=prev-1;recalcCharges(a.id);}public String desc(){return "Remove lone pair";}});}
            }}));
            m.addSeparator();
            m.add(mi("+ Charge",new ActionListener(){public void actionPerformed(ActionEvent e){
                final int prev=a.charge;a.charge++;par.repaint();
                if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){a.charge=prev;}public void redo(){a.charge=prev+1;}public String desc(){return "+ charge";}});
            }}));
            m.add(mi("− Charge",new ActionListener(){public void actionPerformed(ActionEvent e){
                final int prev=a.charge;a.charge--;par.repaint();
                if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){a.charge=prev;}public void redo(){a.charge=prev-1;}public String desc(){return "- charge";}});
            }}));
            m.add(mi("Clear charge",new ActionListener(){public void actionPerformed(ActionEvent e){
                final int prev=a.charge;a.charge=0;par.repaint();
                if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){a.charge=prev;}public void redo(){a.charge=0;}public String desc(){return "Clear charge";}});
            }}));
            m.show(par,sx,sy);
        }
        void showBondMenu(Bond b,int sx,int sy,JComponent par){
            JPopupMenu m=new JPopupMenu();
            ActionListener changeType=new ActionListener(){public void actionPerformed(ActionEvent e){
                final int oldO=b.order;final String oldT=b.type;final String newT=e.getActionCommand();final int newO=newT.equals("double")?2:newT.equals("triple")?3:1;
                b.order=newO;b.type=newT;recalcCharges(b.a);recalcCharges(b.b);par.repaint();
                if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){b.order=oldO;b.type=oldT;recalcCharges(b.a);recalcCharges(b.b);}public void redo(){b.order=newO;b.type=newT;recalcCharges(b.a);recalcCharges(b.b);}public String desc(){return "Change bond type";}});
            }};
            JMenuItem mi1=new JMenuItem("Single");mi1.setActionCommand("single");mi1.addActionListener(changeType);
            JMenuItem mi2=new JMenuItem("Double");mi2.setActionCommand("double");mi2.addActionListener(changeType);
            JMenuItem mi3=new JMenuItem("Triple");mi3.setActionCommand("triple");mi3.addActionListener(changeType);
            JMenuItem mi4=new JMenuItem("Wedge");mi4.setActionCommand("wedge");mi4.addActionListener(changeType);
            JMenuItem mi5=new JMenuItem("Dash");mi5.setActionCommand("dash");mi5.addActionListener(changeType);
            m.add(mi1);m.add(mi2);m.add(mi3);m.add(mi4);m.add(mi5);
            m.addSeparator();
            m.add(mi("Delete bond",new ActionListener(){public void actionPerformed(ActionEvent e){
                final Bond fb=b;final Map<String,Atom> savedAtomCharges=new LinkedHashMap<>();
                Atom aa=atoms.get(b.a),bb=atoms.get(b.b);
                if(aa!=null)savedAtomCharges.put(aa.id,aa);if(bb!=null)savedAtomCharges.put(bb.id,bb);
                final int savedChargeA=aa!=null?aa.charge:0,savedChargeB=bb!=null?bb.charge:0;
                deleteBondWithCharge(b);par.repaint();
                if(undoMgr!=null) undoMgr.push(new UndoableAction(){
                    public void undo(){bonds.add(fb);Atom ra=atoms.get(fb.a);Atom rb=atoms.get(fb.b);if(ra!=null)ra.charge=savedChargeA;if(rb!=null)rb.charge=savedChargeB;}
                    public void redo(){deleteBondWithCharge(fb);}
                    public String desc(){return "Delete bond";}
                });
            }}));
            m.show(par,sx,sy);
        }
        void showGroupMenu(int sx,int sy, CanvasPanel cv) {
            JPopupMenu m=new JPopupMenu();
            m.add(mi("Delete Group",new ActionListener(){public void actionPerformed(ActionEvent e){
                // undo-able delete of selected atoms+bonds
                final List<Atom> delAtoms=new ArrayList<>();
                final List<Bond> delBonds=new ArrayList<>();
                for(String id:new HashSet<>(selectedIds)){Atom a=atoms.get(id);if(a!=null)delAtoms.add(a);}
                Set<String> selCopy=new HashSet<>(selectedIds);
                for(Bond b:bonds) if(selCopy.contains(b.a)||selCopy.contains(b.b)) delBonds.add(b);
                for(Atom a:delAtoms)deleteAtom(a.id); selectedIds.clear();
                if(undoMgr!=null) undoMgr.push(new UndoableAction(){
                    public void undo(){for(Atom a:delAtoms)atoms.put(a.id,a);for(Bond b:delBonds)bonds.add(b);}
                    public void redo(){for(Atom a:delAtoms)deleteAtom(a.id);}
                    public String desc(){return "Delete group";}
                });
                cv.repaint();
            }}));
            m.add(mi("Duplicate Group",new ActionListener(){public void actionPerformed(ActionEvent e){
                pasteFromSelection();cv.repaint();
            }}));
            m.add(mi("Copy Group (Ctrl+C)",new ActionListener(){public void actionPerformed(ActionEvent e){copySelected();}}));
            m.show(cv,sx,sy);
        }
        void pasteFromSelection(){
            copySelected();pasteSelected();
        }

        void deleteAtom(String id){ java.util.Set<String> n=new java.util.HashSet<>(); for(Bond b:bonds) if(b.a.equals(id)) n.add(b.b); else if(b.b.equals(id)) n.add(b.a); atoms.remove(id); final String fid=id; bonds.removeIf(new java.util.function.Predicate<Bond>(){public boolean test(Bond b){return b.a.equals(fid)||b.b.equals(fid);}}); for(String s:n){ Atom a=atoms.get(s); if(a!=null) recalcCharges(a.id); } }
        
        /** When deleting bond: auto-assign formal charges based on valence */
        void deleteBondWithCharge(Bond b){
            bonds.remove(b);
            recalcCharges(b.a); recalcCharges(b.b);
        }
        void recalcCharges(String id){
            Atom a = atoms.get(id);
            if(a == null) return;        
            Integer valence = VALENCE.get(a.el);
            if(valence == null) return;
        
            int bondOrderSum = 0;
            for(Bond bn : bonds){
                if(bn.a.equals(id) || bn.b.equals(id)){
                    bondOrderSum += bn.order;
                }
            }
        
            int lonePairElectrons = a.lps * 2;
            
            a.charge = valence - (bondOrderSum + lonePairElectrons);
        }

        // ── hit-test ──────────────────────────────────────────────────────────
        Atom atomAt(double wx,double wy){for(Atom a:atoms.values()){double dx=a.x-wx,dy=a.y-wy;if(dx*dx+dy*dy<=AR*AR*1.6)return a;}return null;}
        Bond bondAt(double wx,double wy){for(Bond b:bonds){Atom a=atoms.get(b.a),bb=atoms.get(b.b);if(a==null||bb==null)continue;double mx=(a.x+bb.x)/2,my=(a.y+bb.y)/2,dx=wx-mx,dy=wy-my;if(dx*dx+dy*dy<=20*20)return b;}return null;}
        public Draggable nodeAt(double wx,double wy){
            if("Select".equals(activeTool)) return null;  // handled by MouseConsumer
            Atom a=atomAt(wx,wy); return a;
        }

        // ── prebuilt ──────────────────────────────────────────────────────────
        void addPrebuilt(String name){
            final Set<String> atomsBefore=new HashSet<>(atoms.keySet());
            final int bondsBefore=bonds.size();
            double ox=atoms.isEmpty()?0:atoms.values().stream().mapToDouble(new java.util.function.ToDoubleFunction<Atom>(){public double applyAsDouble(Atom a){return a.x;}}).max().orElse(0)+160;
            if("H2O".equals(name)) bH2O(ox,0); else if("NH3".equals(name)) bNH3(ox,0); else if("CH4".equals(name)) bCH4(ox,0);
            else if("CO2".equals(name)) bCO2(ox,0); else if("HCl".equals(name)) bHCl(ox,0); else if("Ethane".equals(name)) bEthane(ox,0);
            else if("Ethanol".equals(name)) bEthanol(ox,0); else if("Benzene".equals(name)) bBenzene(ox,0); else if("Hexane".equals(name)) bHexane(ox,0);
            else if("H2SO4".equals(name)) bH2SO4(ox,0); else if("H2O2".equals(name)) bH2O2(ox,0); else if("Acetone".equals(name)) bAcetone(ox,0);
            else if("HNO3".equals(name)) bHNO3(ox,0); else if("Phenol".equals(name)) bPhenol(ox,0); else if("Aniline".equals(name)) bAniline(ox,0);
            else if("Cumene".equals(name)) bCumene(ox,0); else if("Methanol".equals(name)) bMethanol(ox,0); else if("Ethylene".equals(name)) bEthylene(ox,0);
            else if("O2".equals(name)) bO2(ox,0); else if("O3".equals(name)) bO3(ox,0); else if("HI".equals(name)) bHI(ox,0);
            else if("NaOH".equals(name)) bNaOH(ox,0); else if("KMnO4".equals(name)) bKMnO4(ox,0); else if("Na2Cr2O7".equals(name)) bNa2Cr2O7(ox,0);
            else if("Diborane".equals(name)) bDiborane(ox,0); else if("Nitrobenzene".equals(name)) bNitroBenzene(ox,0);
            else if("Toluene".equals(name)) bToluene(ox,0); else if("PCl5".equals(name)) bPCl5(ox,0);
            for(String id : atoms.keySet()) recalcCharges(id);
            // build undo action
            final List<String> newIds=new ArrayList<>();
            for(String id:atoms.keySet()) if(!atomsBefore.contains(id)) newIds.add(id);
            final List<Atom> newAtomList=new ArrayList<>(); for(String id:newIds){Atom _a=atoms.get(id);if(_a!=null)newAtomList.add(_a);}
            final List<Bond> newBondList=new ArrayList<>(bonds.subList(Math.min(bondsBefore,bonds.size()),bonds.size()));
            if(undoMgr!=null&&!newIds.isEmpty()) undoMgr.push(new UndoableAction(){
                public void undo(){for(String id:newIds){atoms.remove(id);selectedIds.remove(id);}bonds.removeAll(newBondList);}
                public void redo(){for(Atom _a:newAtomList)atoms.put(_a.id,_a);bonds.addAll(newBondList);for(String id:newIds)recalcCharges(id);}
                public String desc(){return "Add prebuilt "+name;}
            });
        }
        // shorthand helpers (prebuilts use bdNoCharge to avoid noise on load)
        String a(String el,double ox,double oy,double dx,double dy){return at(el,ox+dx,oy+dy);}
        void b1(String a2,String b2){bdNoCharge(a2,b2,1,"single");} void b2(String a2,String b2){bdNoCharge(a2,b2,2,"double");} void b3(String a2,String b2){bdNoCharge(a2,b2,3,"triple");}
        void lp(String id){Atom a=atoms.get(id);if(a!=null)a.lps++;}

        void bH2O(double ox,double oy){String O=a("O",ox,oy,0,0),H1=a("H",ox,oy,-80,65),H2=a("H",ox,oy,80,65);b1(O,H1);b1(O,H2);lp(O);lp(O);}
        void bNH3(double ox,double oy){String N=a("N",ox,oy,0,0);b1(N,a("H",ox,oy,-80,80));b1(N,a("H",ox,oy,0,100));b1(N,a("H",ox,oy,80,80));lp(N);}
        void bCH4(double ox,double oy){String C=a("C",ox,oy,0,0);b1(C,a("H",ox,oy,0,-90));b1(C,a("H",ox,oy,90,45));b1(C,a("H",ox,oy,-90,45));b1(C,a("H",ox,oy,0,90));}
        void bCO2(double ox,double oy){String O1=a("O",ox,oy,-115,0),C=a("C",ox,oy,0,0),O2=a("O",ox,oy,115,0);b2(O1,C);b2(C,O2);lp(O1);lp(O1);lp(O2);lp(O2);}
        void bHCl(double ox,double oy){String H=a("H",ox,oy,-75,0),Cl=a("Cl",ox,oy,75,0);b1(H,Cl);lp(Cl);lp(Cl);lp(Cl);}
        void bEthane(double ox,double oy){String C1=a("C",ox,oy,-60,0),C2=a("C",ox,oy,60,0);b1(C1,C2);double[][]hp={{-120,-55},{-120,55},{-60,-85},{120,-55},{120,55},{60,-85}};String[]cs={C1,C1,C1,C2,C2,C2};for(int i=0;i<6;i++)b1(cs[i],a("H",ox,oy,hp[i][0],hp[i][1]));}
        void bEthanol(double ox,double oy){String C1=a("C",ox,oy,-80,0),C2=a("C",ox,oy,40,0),O=a("O",ox,oy,145,0);b1(C1,C2);b1(C2,O);b1(C1,a("H",ox,oy,-140,-55));b1(C1,a("H",ox,oy,-140,55));b1(C1,a("H",ox,oy,-80,-85));b1(C2,a("H",ox,oy,40,-85));b1(C2,a("H",ox,oy,40,85));b1(O,a("H",ox,oy,210,0));lp(O);lp(O);}
        void bBenzene(double ox,double oy){double[]xs={0,95,95,0,-95,-95},ys={-105,-52,52,105,52,-52};String[]C=new String[6];for(int i=0;i<6;i++)C[i]=a("C",ox,oy,xs[i],ys[i]);for(int i=0;i<6;i++)if(i%2==0)b2(C[i],C[(i+1)%6]);else b1(C[i],C[(i+1)%6]);double sc=1.65;for(int i=0;i<6;i++)b1(C[i],a("H",ox,oy,xs[i]*sc,ys[i]*sc));}
        void bHexane(double ox,double oy){int n=6,gap=110;String[]C=new String[n];for(int i=0;i<n;i++)C[i]=a("C",ox,oy,(i-(n-1)/2.0)*gap,0);for(int i=0;i<n-1;i++)b1(C[i],C[i+1]);double[][]ep={{-330,-55},{-330,55},{-330,-85}};for(double[]p:ep)b1(C[0],a("H",ox,oy,p[0],p[1]));double[][]ep2={{330,-55},{330,55},{330,-85}};for(double[]p:ep2)b1(C[n-1],a("H",ox,oy,p[0],p[1]));for(int i=1;i<n-1;i++){int cx=(int)((i-(n-1)/2.0)*gap);b1(C[i],a("H",ox,oy,cx,-85));b1(C[i],a("H",ox,oy,cx,85));}}
        void bH2SO4(double ox,double oy){String S=a("S",ox,oy,0,0),O1=a("O",ox,oy,0,-115),O2=a("O",ox,oy,0,115),O3=a("O",ox,oy,-115,0),O4=a("O",ox,oy,115,0);b2(S,O1);b2(S,O2);b1(S,O3);b1(S,O4);b1(O3,a("H",ox,oy,-200,0));b1(O4,a("H",ox,oy,200,0));lp(O1);lp(O1);lp(O2);lp(O2);lp(O3);lp(O3);lp(O4);lp(O4);}
        void bH2O2(double ox,double oy){String O1=a("O",ox,oy,-65,0),O2=a("O",ox,oy,65,0);b1(O1,O2);b1(O1,a("H",ox,oy,-125,-65));b1(O2,a("H",ox,oy,125,-65));lp(O1);lp(O1);lp(O2);lp(O2);}
        void bAcetone(double ox,double oy){String C1=a("C",ox,oy,-100,0),C2=a("C",ox,oy,0,0),C3=a("C",ox,oy,100,0),O=a("O",ox,oy,0,-90);b1(C1,C2);b1(C2,C3);b2(C2,O);b1(C1,a("H",ox,oy,-160,-40));b1(C1,a("H",ox,oy,-160,40));b1(C1,a("H",ox,oy,-100,-75));b1(C3,a("H",ox,oy,160,-40));b1(C3,a("H",ox,oy,160,40));b1(C3,a("H",ox,oy,100,-75));}
        void bHNO3(double ox,double oy){String N=a("N",ox,oy,0,0),O1=a("O",ox,oy,0,-110),O2=a("O",ox,oy,-95,70),O3=a("O",ox,oy,95,70);b2(N,O1);b1(N,O2);b1(N,O3);b1(O3,a("H",ox,oy,175,70));lp(O1);lp(O1);lp(O2);lp(O2);lp(O2);lp(O3);lp(O3);}
        void bPhenol(double ox,double oy){double[]xs={0,95,95,0,-95,-95},ys={-105,-52,52,105,52,-52};String[]C=new String[6];for(int i=0;i<6;i++)C[i]=a("C",ox,oy,xs[i],ys[i]);for(int i=0;i<6;i++)if(i%2==0)b2(C[i],C[(i+1)%6]);else b1(C[i],C[(i+1)%6]);String O2=a("O",ox,oy,0,-180);b1(C[0],O2);b1(O2,a("H",ox,oy,0,-250));atoms.get(O2).lps=2;double sc=1.7;for(int i=1;i<6;i++)b1(C[i],a("H",ox,oy,xs[i]*sc,ys[i]*sc));}
        void bAniline(double ox,double oy){double[]xs={0,95,95,0,-95,-95},ys={-105,-52,52,105,52,-52};String[]C=new String[6];for(int i=0;i<6;i++)C[i]=a("C",ox,oy,xs[i],ys[i]);for(int i=0;i<6;i++)if(i%2==0)b2(C[i],C[(i+1)%6]);else b1(C[i],C[(i+1)%6]);String N2=a("N",ox,oy,0,-180);b1(C[0],N2);b1(N2,a("H",ox,oy,-55,-240));b1(N2,a("H",ox,oy,55,-240));atoms.get(N2).lps=1;double sc=1.7;for(int i=1;i<6;i++)b1(C[i],a("H",ox,oy,xs[i]*sc,ys[i]*sc));}
        void bCumene(double ox,double oy){double[]xs={0,95,95,0,-95,-95},ys={-105,-52,52,105,52,-52};String[]C=new String[6];for(int i=0;i<6;i++)C[i]=a("C",ox,oy,xs[i],ys[i]);for(int i=0;i<6;i++)if(i%2==0)b2(C[i],C[(i+1)%6]);else b1(C[i],C[(i+1)%6]);String Ci=a("C",ox,oy,0,-185);b1(C[0],Ci);String Cm1=a("C",ox,oy,-70,-255),Cm2=a("C",ox,oy,70,-255);b1(Ci,Cm1);b1(Ci,Cm2);b1(Ci,a("H",ox,oy,0,-175));b1(Cm1,a("H",ox,oy,-115,-230));b1(Cm1,a("H",ox,oy,-120,-295));b1(Cm1,a("H",ox,oy,-35,-295));b1(Cm2,a("H",ox,oy,115,-230));b1(Cm2,a("H",ox,oy,120,-295));b1(Cm2,a("H",ox,oy,35,-295));double sc=1.7;for(int i=1;i<6;i++)b1(C[i],a("H",ox,oy,xs[i]*sc,ys[i]*sc));}
        void bMethanol(double ox,double oy){String C2=a("C",ox,oy,0,0),O2=a("O",ox,oy,110,0);b1(C2,O2);b1(O2,a("H",ox,oy,185,0));b1(C2,a("H",ox,oy,-55,-55));b1(C2,a("H",ox,oy,-55,55));b1(C2,a("H",ox,oy,0,-85));atoms.get(O2).lps=2;}
        void bEthylene(double ox,double oy){String C1=a("C",ox,oy,-55,0),C2=a("C",ox,oy,55,0);b2(C1,C2);b1(C1,a("H",ox,oy,-110,-55));b1(C1,a("H",ox,oy,-110,55));b1(C2,a("H",ox,oy,110,-55));b1(C2,a("H",ox,oy,110,55));}
        void bO2(double ox,double oy){String O1=a("O",ox,oy,-65,0),O2=a("O",ox,oy,65,0);b2(O1,O2);lp(O1);lp(O1);lp(O2);lp(O2);}
        void bO3(double ox,double oy){String O1=a("O",ox,oy,-90,50),O2=a("O",ox,oy,0,-30),O3=a("O",ox,oy,90,50);b2(O2,O1);b1(O2,O3);lp(O1);lp(O1);lp(O2);lp(O3);lp(O3);lp(O3);}
        void bHI(double ox,double oy){String H=a("H",ox,oy,-75,0),I=a("I",ox,oy,75,0);b1(H,I);lp(I);lp(I);lp(I);}
        void bNaOH(double ox,double oy){String Na=a("Na",ox,oy,-115,0),O=a("O",ox,oy,0,0),H=a("H",ox,oy,115,0);b1(Na,O);b1(O,H);lp(O);lp(O);}
        void bKMnO4(double ox,double oy){String Mn=a("Mn",ox,oy,0,0),K=a("K",ox,oy,-175,0),O1=a("O",ox,oy,0,-110),O2=a("O",ox,oy,105,55),O3=a("O",ox,oy,-105,55),O4=a("O",ox,oy,0,110);b1(K,Mn);b2(Mn,O1);b2(Mn,O2);b2(Mn,O3);b1(Mn,O4);lp(O1);lp(O2);lp(O3);lp(O4);lp(O4);lp(O4);}
        void bNa2Cr2O7(double ox,double oy){String Na1=a("Na",ox,oy,-295,0),Na2=a("Na",ox,oy,295,0),Cr1=a("Cr",ox,oy,-115,0),Ob=a("O",ox,oy,0,0),Cr2=a("Cr",ox,oy,115,0);String O1=a("O",ox,oy,-225,0),O2=a("O",ox,oy,-165,-90),O3=a("O",ox,oy,-65,90),O4=a("O",ox,oy,225,0),O5=a("O",ox,oy,165,-90),O6=a("O",ox,oy,65,90);b1(Na1,O1);b1(O1,Cr1);b2(Cr1,O2);b2(Cr1,O3);b1(Cr1,Ob);b1(Ob,Cr2);b2(Cr2,O5);b2(Cr2,O6);b1(Cr2,O4);b1(O4,Na2);lp(Ob);}
        void bDiborane(double ox,double oy){String B1=a("B",ox,oy,-70,0),B2=a("B",ox,oy,70,0),H1=a("H",ox,oy,-125,-60),H2=a("H",ox,oy,-125,60),H3=a("H",ox,oy,125,-60),H4=a("H",ox,oy,125,60),Hb1=a("H",ox,oy,0,-55),Hb2=a("H",ox,oy,0,55);b1(B1,H1);b1(B1,H2);b1(B2,H3);b1(B2,H4);b1(B1,Hb1);b1(B2,Hb1);b1(B1,Hb2);b1(B2,Hb2);}
        void bNitroBenzene(double ox,double oy){double[]xs={0,95,95,0,-95,-95},ys={-105,-52,52,105,52,-52};String[]C=new String[6];for(int i=0;i<6;i++)C[i]=a("C",ox,oy,xs[i],ys[i]);for(int i=0;i<6;i++)if(i%2==0)b2(C[i],C[(i+1)%6]);else b1(C[i],C[(i+1)%6]);String N=a("N",ox,oy,0,-185),NO1=a("O",ox,oy,-70,-245),NO2=a("O",ox,oy,70,-245);b1(C[0],N);b2(N,NO1);b1(N,NO2);lp(NO1);lp(NO1);lp(NO2);lp(NO2);lp(NO2);double sc=1.7;for(int i=1;i<6;i++)b1(C[i],a("H",ox,oy,xs[i]*sc,ys[i]*sc));}
        void bToluene(double ox,double oy){double[]xs={0,95,95,0,-95,-95},ys={-105,-52,52,105,52,-52};String[]C=new String[6];for(int i=0;i<6;i++)C[i]=a("C",ox,oy,xs[i],ys[i]);for(int i=0;i<6;i++)if(i%2==0)b2(C[i],C[(i+1)%6]);else b1(C[i],C[(i+1)%6]);String Cm=a("C",ox,oy,0,-185);b1(C[0],Cm);b1(Cm,a("H",ox,oy,-55,-245));b1(Cm,a("H",ox,oy,55,-245));b1(Cm,a("H",ox,oy,0,-270));double sc=1.7;for(int i=1;i<6;i++)b1(C[i],a("H",ox,oy,xs[i]*sc,ys[i]*sc));}
        void bPCl5(double ox,double oy){String P=a("P",ox,oy,0,0),Cl1=a("Cl",ox,oy,130,0),Cl2=a("Cl",ox,oy,-65,112),Cl3=a("Cl",ox,oy,-65,-112),Cl4=a("Cl",ox,oy,0,-160),Cl5=a("Cl",ox,oy,0,160);b1(P,Cl1);b1(P,Cl2);b1(P,Cl3);b1(P,Cl4);b1(P,Cl5);for(String id:new String[]{Cl1,Cl2,Cl3,Cl4,Cl5}){lp(id);lp(id);lp(id);}}

        void copySelected(){
            if (selectedIds.isEmpty()) return;
            // Will store in a static clipboard accessible to pasteSelected
            chemClipAtoms.clear(); chemClipBonds.clear();
            double cx=0,cy=0; int cnt=0;
            for (String id : selectedIds){ Atom a=atoms.get(id); if(a!=null){cx+=a.x;cy+=a.y;cnt++;} }
            if (cnt==0) return; cx/=cnt; cy/=cnt;
            Map<String,String> idMap=new HashMap<>();
            for (String id : selectedIds){ Atom a=atoms.get(id); if(a==null) continue;
                String nid=a.el+"_cp"+(++idC); Atom na=new Atom(nid,a.el,a.x-cx,a.y-cy); na.lps=a.lps; na.charge=a.charge;
                chemClipAtoms.put(nid,na); idMap.put(id,nid); }
            for (Bond b : bonds){ if(selectedIds.contains(b.a)&&selectedIds.contains(b.b)){
                String na=idMap.get(b.a),nb=idMap.get(b.b); if(na!=null&&nb!=null) chemClipBonds.add(new Bond(na,nb,b.order,b.type)); } }
        }
        void pasteSelected(){
            if (chemClipAtoms.isEmpty()) return;
            selectedIds.clear();
            Map<String,String> idMap=new HashMap<>();
            for (Map.Entry<String,Atom> e : chemClipAtoms.entrySet()){
                Atom src=e.getValue(); String nid=src.el+(++idC);
                Atom na=new Atom(nid,src.el,src.x+40,src.y+40); na.lps=src.lps; na.charge=src.charge;
                atoms.put(nid,na); selectedIds.add(nid); idMap.put(e.getKey(),nid);
            }
            for (Bond b : chemClipBonds){ String na=idMap.get(b.a),nb=idMap.get(b.b); if(na!=null&&nb!=null) bonds.add(new Bond(na,nb,b.order,b.type)); }
        }
        public void saveTo(StringBuilder sb){
            for (ChemArrow ar : arrows){
                if(!ar.curved) sb.append("ca_arr=").append(String.format("%.1f",ar.x1)).append("|").append(String.format("%.1f",ar.y1)).append("|").append(String.format("%.1f",ar.x2)).append("|").append(String.format("%.1f",ar.y2)).append("\n");
                else sb.append("ca_curv=").append(ar.fromId).append("|").append(ar.toId).append("\n");
            }
            for (Atom a : atoms.values())
                sb.append("ca=").append(a.id).append("|").append(a.el).append("|").append(String.format("%.1f",a.x)).append("|").append(String.format("%.1f",a.y)).append("|").append(a.charge).append("|").append(a.lps).append("\n");
            for (Bond b : bonds)
                sb.append("cb=").append(b.a).append("|").append(b.b).append("|").append(b.order).append("|").append(b.type).append("\n");
        }
        public void loadLine(String line){
            if (line.startsWith("ca_arr=")){
                String[]p=line.substring(7).split("\\|",-1);
                if(p.length>=4) try{arrows.add(new ChemArrow(Double.parseDouble(p[0]),Double.parseDouble(p[1]),Double.parseDouble(p[2]),Double.parseDouble(p[3])));}catch(NumberFormatException ignored){}
            } else if (line.startsWith("ca_curv=")){
                String[]p=line.substring(8).split("\\|",-1);
                if(p.length>=2) arrows.add(new ChemArrow(p[0],p[1]));
            } else if (line.startsWith("cplus=")){
                String[]p=line.substring(6).split("\\|",-1);
                if(p.length>=2) try{plusSymbols.add(new double[]{Double.parseDouble(p[0]),Double.parseDouble(p[1])});}catch(NumberFormatException ignored){}
            } else if (line.startsWith("ca=")){
                String[]p=line.substring(3).split("\\|",-1);
                if(p.length>=6) try{Atom a=new Atom(p[0],p[1],Double.parseDouble(p[2]),Double.parseDouble(p[3]));a.charge=Integer.parseInt(p[4]);a.lps=Integer.parseInt(p[5]);atoms.put(p[0],a);try{int n=Integer.parseInt(p[0].replaceAll("[^0-9]",""));if(n>idC)idC=n;}catch(NumberFormatException ignored){}}catch(NumberFormatException ignored){}
            } else if (line.startsWith("cb=")){
                String[]p=line.substring(3).split("\\|",-1);
                if(p.length>=4) try{bonds.add(new Bond(p[0],p[1],Integer.parseInt(p[2]),p[3]));}catch(NumberFormatException ignored){}
            }
        }
        public void add(int v){addAtomManual("C");}
        public void removeLast(){if(atoms.isEmpty())return;String last=null;for(String k:atoms.keySet())last=k;if(last!=null)deleteAtom(last);}
        public void clear(){
            if(atoms.isEmpty()&&bonds.isEmpty()&&arrows.isEmpty())return;
            final Map<String,Atom> savedAtoms=new LinkedHashMap<>(atoms);
            final List<Bond> savedBonds=new ArrayList<>(bonds);
            final List<ChemArrow> savedArrows=new ArrayList<>(arrows);
            final List<double[]> savedPlus=new ArrayList<>(plusSymbols);
            atoms.clear();bonds.clear();arrows.clear();selectedIds.clear();plusSymbols.clear();
            if(undoMgr!=null) undoMgr.push(new UndoableAction(){
                public void undo(){atoms.putAll(savedAtoms);bonds.addAll(savedBonds);arrows.addAll(savedArrows);plusSymbols.addAll(savedPlus);}
                public void redo(){atoms.clear();bonds.clear();arrows.clear();selectedIds.clear();plusSymbols.clear();}
                public String desc(){return "Clear chemistry canvas";}
            });
        }

        public void draw(Graphics2D g){
            title(g,"Chemistry — Molecule Canvas",-280);
            if(atoms.isEmpty()){hint(g,"Load prebuilt  ·  Add atoms  ·  Right-drag between atoms = bond  ·  Right-click = options  ·  Select tool = group move");return;}
            for(Bond b:bonds){Atom aa=atoms.get(b.a),bb=atoms.get(b.b);if(aa!=null&&bb!=null)drawBond(g,aa,bb,b);}
            for(Atom a:atoms.values()) drawAtom(g,a);
            for(ChemArrow ar:arrows) drawArrow(g,ar);
            
            // The '+' symbol
            g.setColor(Color.BLACK);int size = 6; for (double[] p : plusSymbols) { int x = (int) p[0]; int y = (int) p[1]; g.drawLine(x - size, y, x + size, y); g.drawLine(x, y - size, x, y + size); }
            
            // selection rect
            if(selectDragging){g.setColor(new Color(100,150,255,60));g.fill(new Rectangle2D.Double(Math.min(selX0,selX1),Math.min(selY0,selY1),Math.abs(selX1-selX0),Math.abs(selY1-selY0)));g.setColor(new Color(100,150,255,180));g.setStroke(S_THIN);g.draw(new Rectangle2D.Double(Math.min(selX0,selX1),Math.min(selY0,selY1),Math.abs(selX1-selX0),Math.abs(selY1-selY0)));}
        }

        /** Returns the display text-colour for an atom in "hide circles" mode. */
        Color atomTextColor(String el){
            // C and H fade to near-invisible grey so organic skeletons read cleanly
            if("C".equals(el)||"H".equals(el)) return new Color(50,50,50);
            Color fill=ECOL.getOrDefault(el,ECOL.get("?"));
            // darken the pastel fill twice so it reads well on a white canvas
            return fill.darker().darker();
        }
        void drawAtom(Graphics2D g,Atom a){
            Color fill=ECOL.getOrDefault(a.el,ECOL.get("?"));
            Color border=selectedIds.contains(a.id)?C_ACCENT:Color.BLACK;
            if(!hideAtoms){
                g.setColor(fill);g.fillOval((int)(a.x-AR),(int)(a.y-AR),AR*2,AR*2);
                g.setColor(border);g.setStroke(selectedIds.contains(a.id)?S_THICK:S_LINE);g.drawOval((int)(a.x-AR),(int)(a.y-AR),AR*2,AR*2);
            } else if(selectedIds.contains(a.id)){
                // selection indicator: subtle tinted ring even when circles are hidden
                g.setColor(new Color(C_ACCENT.getRed(),C_ACCENT.getGreen(),C_ACCENT.getBlue(),60));
                g.fillOval((int)(a.x-AR),(int)(a.y-AR),AR*2,AR*2);
                g.setColor(C_ACCENT);g.setStroke(S_THICK);g.drawOval((int)(a.x-AR),(int)(a.y-AR),AR*2,AR*2);
            }
            // label
            Color textCol=hideAtoms?atomTextColor(a.el):Color.BLACK;
            Font ef=new Font("SansSerif",Font.BOLD,a.el.length()>1?10:13);
            g.setFont(ef);g.setColor(textCol);FontMetrics fm=g.getFontMetrics();
            g.drawString(a.el,(int)(a.x-fm.stringWidth(a.el)/2.0),(int)(a.y+fm.getAscent()/2-2));
            // lone pairs (always visible)
            double[]angs={Math.PI/2,-Math.PI/2,0,Math.PI,Math.PI/4,-Math.PI/4,3*Math.PI/4,-3*Math.PI/4};
            Color lpCol=hideAtoms?textCol:Color.BLACK;
            for(int i=0;i<a.lps&&i<angs.length;i++){double ang=angs[i],dist=AR+14,cx=a.x+dist*Math.cos(ang),cy=a.y+dist*Math.sin(ang),ppx=-Math.sin(ang)*5,ppy=Math.cos(ang)*5;g.setColor(lpCol);g.fillOval((int)(cx+ppx-2),(int)(cy+ppy-2),4,4);g.fillOval((int)(cx-ppx-2),(int)(cy-ppy-2),4,4);}
            // charge
            if(a.charge!=0){g.setFont(F_SMALL);g.setColor(hideAtoms?textCol:C_DIM);String cs=a.charge>0?"+"+a.charge:String.valueOf(a.charge);g.drawString(cs,(int)(a.x+AR-2),(int)(a.y-AR+4));}
        }


        void drawArrow(Graphics2D g, ChemArrow ar){
            g.setColor(Color.BLACK); g.setStroke(new BasicStroke(2f,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
            if(!ar.curved){
                g.draw(new Line2D.Double(ar.x1,ar.y1,ar.x2,ar.y2));
                ah(g,ar.x1,ar.y1,ar.x2,ar.y2,10);
            } else {
                Atom fa=atoms.get(ar.fromId),ta=atoms.get(ar.toId); if(fa==null||ta==null) return;
                double dx=ta.x-fa.x,dy=ta.y-fa.y,len=Math.max(1,Math.sqrt(dx*dx+dy*dy));
                double ux=dx/len,uy=dy/len;
                double cpx=(fa.x+ta.x)/2-uy*50,cpy=(fa.y+ta.y)/2+ux*50;
                double sx=fa.x+ux*AR,sy=fa.y+uy*AR,ex=ta.x-ux*AR,ey=ta.y-uy*AR;
                g.setColor(new Color(180,30,30)); // red for curved (mechanism arrows)
                g.draw(new QuadCurve2D.Double(sx,sy,cpx,cpy,ex,ey));
                double tdx=ex-cpx,tdy=ey-cpy,tl=Math.max(1,Math.sqrt(tdx*tdx+tdy*tdy));
                ah(g,cpx,cpy,ex,ey,9);
            }
        }
        void drawBond(Graphics2D g,Atom a,Atom b,Bond bond){
            double dx=b.x-a.x,dy=b.y-a.y,len=Math.sqrt(dx*dx+dy*dy);if(len<1)return;
            double ux=dx/len,uy=dy/len,ppx=-uy,ppy=ux;
            double sx=a.x+ux*AR,sy=a.y+uy*AR,ex=b.x-ux*AR,ey=b.y-uy*AR;
            g.setColor(Color.BLACK); g.setStroke(S_BOND);
            String t=bond.type;
            if("wedge".equals(t)){ double w=6;g.fillPolygon(new int[]{(int)sx,(int)(ex+ppx*w),(int)(ex-ppx*w)},new int[]{(int)sy,(int)(ey+ppy*w),(int)(ey-ppy*w)},3);}
            else if("dash".equals(t)){ int steps=6;for(int i=1;i<=steps;i++){double tt=(double)i/steps,cx2=sx+ux*len*(tt-1.0/steps),cy2=sy+uy*len*(tt-1.0/steps),hw=3.0*i/steps;g.setStroke(new BasicStroke(1.6f,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));g.draw(new Line2D.Double(cx2-ppx*hw,cy2-ppy*hw,cx2+ppx*hw,cy2+ppy*hw));}}
            else if("bondline".equals(t)){ g.setStroke(new BasicStroke(2f));g.draw(new Line2D.Double(sx,sy,ex,ey));for(double tt=0.25;tt<=0.75;tt+=0.25){double cx2=sx+ux*(ex-sx)*tt,cy2=sy+uy*(ey-sy)*tt;g.draw(new Line2D.Double(cx2-ppx*4,cy2-ppy*4,cx2+ppx*4,cy2+ppy*4));}}
            else if(bond.order==3){ g.draw(new Line2D.Double(sx,sy,ex,ey));g.draw(new Line2D.Double(sx+ppx*5.5,sy+ppy*5.5,ex+ppx*5.5,ey+ppy*5.5));g.draw(new Line2D.Double(sx-ppx*5.5,sy-ppy*5.5,ex-ppx*5.5,ey-ppy*5.5));}
            else if(bond.order==2){ g.draw(new Line2D.Double(sx+ppx*4,sy+ppy*4,ex+ppx*4,ey+ppy*4));g.draw(new Line2D.Double(sx-ppx*4,sy-ppy*4,ex-ppx*4,ey-ppy*4));}
            else { g.draw(new Line2D.Double(sx,sy,ex,ey)); }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  MATHEMATICS FOLDER  (Venn + Probability + Binomial)
    // ═══════════════════════════════════════════════════════════════════════
    static class MathFolderPanel implements FolderPanel {
        final AppFrame app;
        final JPanel toolbar=new JPanel(new FlowLayout(FlowLayout.LEFT,5,6));
        final JComboBox<String> sbox;
        final JPanel dynArea=new JPanel(new FlowLayout(FlowLayout.LEFT,4,0));
        // panels stored as fields so activate() can reference them
        JPanel vennP, probP, binomP;

        MathFolderPanel(AppFrame app){
            this.app=app;
            sbox=combo("Venn Diagram","Probability Distribution","Binomial Expansion");

            // Venn controls
            vennP=new JPanel(new FlowLayout(FlowLayout.LEFT,4,0)); vennP.setOpaque(false);
            final JTextField vsf=tf(8),vif=tf(10);
            JButton vas=btn("Add Set"),vai=btn("Add Item"),vclr=btn("Clear");
            vas.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){String t=vsf.getText().trim();if(!t.isEmpty()){venn().addSet(t);app.canvas.repaint();}}});
            vai.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){String s=vsf.getText().trim(),it=vif.getText().trim();if(!it.isEmpty()){venn().addItem(it,s.split(","));vif.setText("");app.canvas.repaint();}}});
            vclr.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){venn().clear();app.canvas.repaint();}});
            vennP.add(lbl("Set(s):")); vennP.add(vsf); vennP.add(lbl("Item:")); vennP.add(vif); vennP.add(vas); vennP.add(vai); vennP.add(vclr);

            // Probability controls
            probP=new JPanel(new FlowLayout(FlowLayout.LEFT,4,0)); probP.setOpaque(false);
            final JComboBox<String> distBox=combo("Normal","Binomial","Poisson");
            final JTextField p1f=tf(6),p2f=tf(6);
            JButton probPlot=btn("Plot"),probClr=btn("Clear");
            probPlot.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){
                try{double pa=Double.parseDouble(p1f.getText().trim()),pb=Double.parseDouble(p2f.getText().trim());
                    prob().setDist((String)distBox.getSelectedItem(),pa,pb);app.canvas.repaint();}catch(NumberFormatException ex){flash(p1f);}
            }});
            probClr.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){prob().clear();app.canvas.repaint();}});
            probP.add(lbl("Dist:")); probP.add(distBox); probP.add(lbl("μ/n:")); probP.add(p1f); probP.add(lbl("σ/p:")); probP.add(p2f); probP.add(probPlot); probP.add(probClr);

            // Binomial controls
            binomP=new JPanel(new FlowLayout(FlowLayout.LEFT,4,0)); binomP.setOpaque(false);
            final JTextField bnf=tf(4); bnf.setText("5");
            final JComboBox<String> btypeBox=combo("(a+b)^n","(a-b)^n","(a+b+c)^n","(1+x)^n","(1-x)^n","(a+b)^-n approx");
            JButton bnPlot=btn("Expand"),bnClr=btn("Clear");
            bnPlot.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){try{binom().setType((String)btypeBox.getSelectedItem());binom().setN(Integer.parseInt(bnf.getText().trim()));app.canvas.repaint();}catch(NumberFormatException ex){flash(bnf);}}});
            bnClr.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){binom().clear();app.canvas.repaint();}});
            binomP.add(lbl("n=")); binomP.add(bnf); binomP.add(lbl("Type:")); binomP.add(btypeBox); binomP.add(bnPlot); binomP.add(bnClr);

            sbox.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){
                String sel=(String)sbox.getSelectedItem(); Session s=app.curSession(); s.mathActive=sel;
                dynArea.removeAll();
                if("Venn Diagram".equals(sel)) dynArea.add(vennP);
                else if("Probability Distribution".equals(sel)) dynArea.add(probP);
                else dynArea.add(binomP);
                dynArea.revalidate(); dynArea.repaint();
                app.canvas.setRend(s.activeRenderer()); app.canvas.repaint();
            }});
            toolbar.setBackground(Color.WHITE); toolbar.setBorder(new MatteBorder(0,0,1,0,C_BORDER));
            dynArea.setOpaque(false); dynArea.add(vennP);
            toolbar.add(lbl("Math:")); toolbar.add(sbox); toolbar.add(vsep()); toolbar.add(dynArea);
        }
        VennRend    venn(){ return app.curSession().vennRend; }
        ProbDistRend prob(){ return app.curSession().probRend; }
        BinomRend  binom(){ return app.curSession().binomRend; }
        public JPanel getToolbar(){return toolbar;}
        public void activate(Session s){
            // Sync combobox to session state without re-triggering the listener side-effects
            if (!s.mathActive.equals(sbox.getSelectedItem())) {
                sbox.setSelectedItem(s.mathActive);
            }
            // Always sync dynArea to current mathActive
            dynArea.removeAll();
            if ("Venn Diagram".equals(s.mathActive))             dynArea.add(vennP);
            else if ("Probability Distribution".equals(s.mathActive)) dynArea.add(probP);
            else                                                  dynArea.add(binomP);
            dynArea.revalidate(); dynArea.repaint();
            app.canvas.setRend(s.activeRenderer());
            app.canvas.repaint();
        }
    }

    // ── Venn Diagram ─────────────────────────────────────────────────────────
    static class VennRend extends BaseRenderer {
        static class VSet{String name;List<String>items=new ArrayList<>();VSet(String n){name=n;}}
        final List<VSet> sets=new ArrayList<>(); final Map<String,Set<String>> isets=new LinkedHashMap<>();
        void addSet(String n){for(VSet s:sets)if(s.name.equals(n))return;sets.add(new VSet(n));}
        void addItem(String item,String[]sns){Set<String>ss=isets.computeIfAbsent(item,new java.util.function.Function<String,Set<String>>(){public Set<String> apply(String k){return new LinkedHashSet<>();}});for(String sn:sns){ss.add(sn.trim());addSet(sn.trim());for(VSet vs:sets)if(vs.name.equals(sn.trim())&&!vs.items.contains(item))vs.items.add(item);}}
        public void clear(){sets.clear();isets.clear();}
        public void saveTo(StringBuilder sb){
            for(VSet s:sets) sb.append("vs=").append(s.name).append("\n");
            for(Map.Entry<String,Set<String>>e:isets.entrySet()) sb.append("vi=").append(e.getKey()).append("=").append(String.join(",",e.getValue())).append("\n");
        }
        public void loadLine(String line){
            if(line.startsWith("vs="))addSet(line.substring(3));
            else if(line.startsWith("vi=")){String rest=line.substring(3);int eq=rest.indexOf('=');if(eq>0)addItem(rest.substring(0,eq),rest.substring(eq+1).split(","));}
        }
        public void add(int v){addSet("Set"+v);}
        public void removeLast(){if(!sets.isEmpty())sets.remove(sets.size()-1);}
        static final Color[]SC={new Color(100,150,255,55),new Color(255,100,100,55),new Color(100,220,100,55),new Color(255,200,50,55)};
        public void draw(Graphics2D g){
            title(g,"Venn Diagram",-280);if(sets.isEmpty()){hint(g,"Add sets and items (comma-separate set names for intersections)");return;}
            int n=sets.size(); double r=130;
            double[][]cen=new double[n][2];for(int i=0;i<n;i++){double ang=2*Math.PI*i/n-Math.PI/2;cen[i][0]=Math.cos(ang)*r*0.7;cen[i][1]=Math.sin(ang)*r*0.7;}
            for(int i=0;i<n;i++){g.setColor(SC[i%SC.length]);g.fillOval((int)(cen[i][0]-r),(int)(cen[i][1]-r),(int)(r*2),(int)(r*2));g.setColor(new Color(80,80,180,120));g.setStroke(S_LINE);g.drawOval((int)(cen[i][0]-r),(int)(cen[i][1]-r),(int)(r*2),(int)(r*2));ctr(g,sets.get(i).name,(int)cen[i][0],(int)(cen[i][1]-r-16),F_HINT,C_DIM);}
            Map<String,List<String>>byRegion=new LinkedHashMap<>();for(Map.Entry<String,Set<String>>e:isets.entrySet()){String key=String.join(",",e.getValue());if(!byRegion.containsKey(key))byRegion.put(key,new ArrayList<>());byRegion.get(key).add(e.getKey());}
            for(Map.Entry<String,List<String>>e:byRegion.entrySet()){String[]sns=e.getKey().split(",");double cx=0,cy=0;for(String sn:sns){for(int i=0;i<n;i++)if(sets.get(i).name.equals(sn)){cx+=cen[i][0]/sns.length;cy+=cen[i][1]/sns.length;}}List<String>items=e.getValue();for(int li=0;li<items.size();li++){g.setFont(F_MONO);g.setColor(Color.BLACK);ctr(g,items.get(li),(int)cx,(int)(cy+(li-items.size()/2)*16),F_MONO,Color.BLACK);}}
        }
    }

    // ── Probability Distribution ──────────────────────────────────────────────
    static class ProbDistRend extends BaseRenderer {
        String distName=""; double param1=0,param2=1; boolean active=false;
        void setDist(String d,double p1,double p2){distName=d;param1=p1;param2=p2;active=true;}
        public void clear(){active=false;}
        public void saveTo(StringBuilder sb){
            if(active) sb.append("prob=").append(distName).append(",").append(param1).append(",").append(param2).append("\n");
        }
        public void loadLine(String line){
            if(line.startsWith("prob=")){String[]p=line.substring(5).split(",");if(p.length>=3)try{setDist(p[0],Double.parseDouble(p[1]),Double.parseDouble(p[2]));}catch(NumberFormatException ignored){}}
        }

        public void draw(Graphics2D g){
            title(g,"Probability Distribution",-300);
            if(!active){hint(g,"Choose distribution type, set parameters, press Plot");return;}
            int W=540,H=260; g.setColor(new Color(180,180,180));g.setStroke(S_THIN);g.draw(new Line2D.Double(-W/2,0,W/2,0));g.draw(new Line2D.Double(-W/2,-H,-W/2,0));
            if("Normal".equals(distName)) drawNormal(g,W,H);
            else if("Binomial".equals(distName)) drawBinomial(g,W,H);
            else if("Poisson".equals(distName)) drawPoisson(g,W,H);
            g.setFont(F_HINT);g.setColor(C_DIM);g.drawString(distName+" (μ/n="+param1+", σ/p="+param2+")",-W/2,20);
        }
        void drawNormal(Graphics2D g,int W,int H){
            double mu=param1,sig=Math.max(0.01,param2);
            double xmin=mu-4*sig,xmax=mu+4*sig,scale=(double)W/(xmax-xmin);
            double ymax=1/(sig*Math.sqrt(2*Math.PI));
            g.setColor(new Color(60,100,200));g.setStroke(new BasicStroke(2f));
            Path2D path=new Path2D.Double();boolean first=true;
            int steps=400;
            for(int i=0;i<=steps;i++){double x=xmin+i*(xmax-xmin)/steps;double y=Math.exp(-0.5*Math.pow((x-mu)/sig,2))/(sig*Math.sqrt(2*Math.PI));
                double sx=(x-xmin)*scale-W/2,sy=-y/ymax*H;if(first){path.moveTo(sx,sy);first=false;}else path.lineTo(sx,sy);}
            g.draw(path);
            // shade ±1σ
            g.setColor(new Color(60,100,200,40));
            Path2D fill=new Path2D.Double();fill.moveTo((mu-sig-xmin)*scale-W/2,0);
            for(int i=0;i<=100;i++){double x=(mu-sig)+i*2*sig/100;double y=Math.exp(-0.5*Math.pow((x-mu)/sig,2))/(sig*Math.sqrt(2*Math.PI));fill.lineTo((x-xmin)*scale-W/2,-y/ymax*H);}
            fill.lineTo((mu+sig-xmin)*scale-W/2,0);fill.closePath();g.fill(fill);
            // axis labels
            g.setFont(F_IDX);g.setColor(C_MUTED);g.drawString(String.format("%.1f",mu),(int)((mu-xmin)*scale-W/2)-4,14);g.drawString("μ±σ shaded",-W/2+4,14);
        }
        void drawBinomial(Graphics2D g,int W,int H){
            int n=(int)Math.max(1,param1); double pp=Math.min(1,Math.max(0,param2));
            double[]probs=new double[n+1]; for(int k=0;k<=n;k++) probs[k]=binomCoeff(n,k)*Math.pow(pp,k)*Math.pow(1-pp,n-k);
            double barW=(double)W/Math.max(n+1,2),maxP=0;for(double p:probs)maxP=Math.max(maxP,p);
            g.setColor(new Color(60,100,200,160));
            for(int k=0;k<=n;k++){double bh=probs[k]/maxP*H;int bx=(int)(-W/2+k*barW),by=(int)(-bh);g.fillRect(bx+2,by,(int)(barW-4),(int)bh);g.setColor(new Color(40,60,180));g.setStroke(S_THIN);g.drawRect(bx+2,by,(int)(barW-4),(int)bh);g.setColor(new Color(60,100,200,160));}
            g.setFont(F_IDX);g.setColor(C_MUTED);for(int k=0;k<=n&&k<15;k++) g.drawString(String.valueOf(k),(int)(-W/2+k*barW+(barW-10)/2),14);
        }
        void drawPoisson(Graphics2D g,int W,int H){
            double lam=Math.max(0.1,param1); int kmax=Math.min(30,(int)(lam*3+5));
            double[]probs=new double[kmax+1]; for(int k=0;k<=kmax;k++) probs[k]=Math.exp(-lam)*Math.pow(lam,k)/factorial(k);
            double barW=(double)W/Math.max(kmax+1,2),maxP=0;for(double p:probs)maxP=Math.max(maxP,p);
            g.setColor(new Color(100,60,200,160));
            for(int k=0;k<=kmax;k++){double bh=probs[k]/maxP*H;int bx=(int)(-W/2+k*barW),by=(int)(-bh);g.fillRect(bx+2,by,(int)(barW-4),(int)bh);g.setColor(new Color(70,40,160));g.setStroke(S_THIN);g.drawRect(bx+2,by,(int)(barW-4),(int)bh);g.setColor(new Color(100,60,200,160));}
            g.setFont(F_IDX);g.setColor(C_MUTED);for(int k=0;k<=Math.min(kmax,14);k++) g.drawString(String.valueOf(k),(int)(-W/2+k*barW+(barW-10)/2),14);
        }
        static double binomCoeff(int n,int k){double r=1;for(int i=0;i<k;i++){r*=(n-i);r/=(i+1);}return r;}
        static double factorial(int n){double f=1;for(int i=2;i<=n;i++)f*=i;return f;}
    }

    // ── Binomial Expansion ─────────────────────────────────────────────────────
    static class BinomRend extends BaseRenderer {
        int N=-1; String binomType="(a+b)^n";
        void setN(int n){N=Math.min(n,14);}
        void setType(String t){binomType=t;}
        public void clear(){N=-1;}
        public void saveTo(StringBuilder sb){ if(N>=0) sb.append("binom=").append(N).append(",").append(binomType).append("\n"); }
        public void loadLine(String line){ if(line.startsWith("binom=")){String[]p=line.substring(6).split(",",2);try{setN(Integer.parseInt(p[0].trim()));}catch(NumberFormatException ignored){}if(p.length>1)binomType=p[1].trim();} }

        public void draw(Graphics2D g){
            title(g,"Binomial Expansion — Pascal's Triangle",-300);
            if(N<0){hint(g,"Enter n and select expansion type, then Expand");return;}
            // Pascal's triangle
            int CW=52,CH=36,startY=-N*CH/2;
            for(int row=0;row<=N;row++){
                int startX=-(row*CW)/2;
                for(int col=0;col<=row;col++){
                    long c=binC(row,col);
                    Color fill=row==N?new Color(220,235,255):new Color(245,245,245);
                    g.setColor(fill);g.fillRoundRect(startX+col*CW,startY+row*CH,CW-4,CH-4,6,6);
                    g.setColor(row==N?C_ACCENT:Color.BLACK);g.setStroke(S_THIN);g.drawRoundRect(startX+col*CW,startY+row*CH,CW-4,CH-4,6,6);
                    ctr(g,String.valueOf(c),startX+col*CW+(CW-4)/2,startY+row*CH+(CH-4)/2,row==N?new Font("Monospaced",Font.BOLD,11):F_IDX,row==N?C_ACCENT:Color.BLACK);
                }
            }
            int fy=startY+N*CH+50;g.setFont(F_HINT);g.setColor(C_DIM);
            String formula=buildFormula();
            FontMetrics fm=g.getFontMetrics(F_HINT);
            // Word-wrap if too long
            if(fm.stringWidth(formula)>900){
                String[] words=formula.split("\\+ ");
                StringBuilder line1=new StringBuilder(),line2=new StringBuilder();
                for(int i=0;i<words.length;i++){ if(i<(words.length+1)/2) line1.append(i>0?"+ ":"").append(words[i]); else line2.append(i>0?"+ ":"").append(words[i]); }
                g.drawString(line1.toString(),-fm.stringWidth(line1.toString())/2,fy);
                g.drawString(line2.toString(),-fm.stringWidth(line2.toString())/2,fy+20);
            } else {
                g.drawString(formula,-fm.stringWidth(formula)/2,fy);
            }
        }
        String buildFormula(){
            if("(a+b+c)^n".equals(binomType)){
                // Trinomial: show first few terms
                StringBuilder sb=new StringBuilder("(a+b+c)^"+N+" = ");
                if(N<=4){ sb.append("sum of C("+N+";i,j,k)*a^i*b^j*c^k where i+j+k="+N); }
                else sb.append("Multinomial expansion ("+N+" terms)");
                return sb.toString();
            }
            if("(a+b)^-n approx".equals(binomType)){
                StringBuilder sb=new StringBuilder("(1+x)^(-"+N+") ≈ ");
                for(int k=0;k<=Math.min(N,5);k++){
                    if(k>0) sb.append(" + ");
                    if(k==0){sb.append("1");}
                    else{ sb.append("C(-"+N+","+k+")*x");if(k>1)sb.append("^"+k);}
                }
                sb.append(" + ...");
                return sb.toString();
            }
            char a2='a', b2='b'; String sign="+";
            if("(a-b)^n".equals(binomType)){sign="-";}
            else if("(1+x)^n".equals(binomType)||"(1-x)^n".equals(binomType)){a2='1';b2='x';sign="(1+x)^n".equals(binomType)?"+":"-";}
            StringBuilder sb=new StringBuilder();
            sb.append("(").append(a2).append(sign).append(b2).append(")^").append(N).append(" = ");
            for(int k=0;k<=N;k++){
                long c=binC(N,k); int ae=N-k,be=k;
                if(k>0) sb.append(" + ");
                boolean neg="-".equals(sign)&&be%2==1;
                if(neg) sb.append("-");
                if(c>1) sb.append(c);
                if(ae>0&&a2!='1'){sb.append(a2);if(ae>1)sb.append("^").append(ae);}
                if(be>0){sb.append(b2);if(be>1)sb.append("^").append(be);}
                if(c==1&&ae==0&&be==0) sb.append("1");
            }
            return sb.toString();
        }
        static long binC(int n,int k){long r=1;for(int i=0;i<k;i++){r*=(n-i);r/=(i+1);}return r;}
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  PHYSICS FOLDER
    // ═══════════════════════════════════════════════════════════════════════
    static class PhysFolderPanel implements FolderPanel {
        final AppFrame app;
        final JPanel toolbar=new JPanel(new FlowLayout(FlowLayout.LEFT,5,6));
        final JComboBox<String> objBox=combo("Mass Block","Mass Cylinder","Pulley","Wall / Fixed Anchor","Wedge");
        final JComboBox<String> connBox=combo("Spring","Rope","Rod","String");
        JToggleButton runBtn;

        PhysFolderPanel(AppFrame app){
            this.app=app;
            connBox.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){phys().connectorType=(String)connBox.getSelectedItem();}});
            JButton addObj=btn("Add Object"),clr=btn("Clear");
            runBtn=tglBtn("▶ Run Simulation");
            JButton rst=btn("⏮ Reset");

            addObj.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){
                String type=(String)objBox.getSelectedItem(); phys().addObj(type);app.canvas.repaint();
            }});
            runBtn.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){
                if(runBtn.isSelected()){phys().startSim();runBtn.setText("⏸ Pause Simulation");}
                else{phys().pauseSim();runBtn.setText("▶ Run Simulation");}
            }});
            rst.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){phys().resetSim();runBtn.setSelected(false);runBtn.setText("▶ Run Simulation");app.canvas.repaint();}});
            clr.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent e){phys().clear();runBtn.setSelected(false);runBtn.setText("▶ Run Simulation");app.canvas.repaint();}});
            
            toolbar.setBackground(Color.WHITE); toolbar.setBorder(new MatteBorder(0,0,1,0,C_BORDER));
            toolbar.add(lbl("Object:")); toolbar.add(objBox); toolbar.add(lbl("Connect with:")); toolbar.add(connBox);
            toolbar.add(vsep()); toolbar.add(addObj); toolbar.add(vsep()); toolbar.add(runBtn); toolbar.add(rst); toolbar.add(clr);
            toolbar.add(vsep()); toolbar.add(lbl("Right-drag between objects to connect  ·  Right-click to edit parameters"));
        }
        PhysicsRenderer phys(){return app.curSession().physRend;}
        public JPanel getToolbar(){return toolbar;}
        public void activate(Session s){
            app.canvas.setRend(s.physRend);
            s.physRend.undoMgr = s.undo;
            // Sync combo to what this session last had (prevents stale connector type)
            connBox.setSelectedItem(s.physRend.connectorType);
            final CanvasPanel cv=app.canvas;
            s.physRend.setRepaintCB(new Runnable(){public void run(){cv.repaint();}});
            app.canvas.repaint();
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  PHYSICS RENDERER  — stable Verlet with sub-stepping
    // ═══════════════════════════════════════════════════════════════════════
    static class PhysicsRenderer extends BaseRenderer implements HittableRenderer, MouseConsumer {
        static class PObj implements Draggable {
            String id,type,label; double x,y,vx=0,vy=0,mass=1; boolean fixed; double w=52,h=52;
            double angle=0,angularVel=0; // rotation (radians)
            double friction=0.3,restitution=0.3; // surface properties
            boolean wedgeFlipped=false; // mirror wedge horizontally
            boolean lockRotation=true;  // blocks & cylinders don't spin by default
            PObj(String id,String type,String label,double x,double y,boolean fixed){this.id=id;this.type=type;this.label=label;this.x=x;this.y=y;this.fixed=fixed;}
            public double gx(){return x;} public double gy(){return y;}
            public void mv(double dx,double dy){if(!fixed){x+=dx;y+=dy;}}
            double radius(){ return w/2; } // for cylinders
            /** Returns vertices in world coordinates (polygon approximation) */
            double[][] getVertices(){
                double ca=Math.cos(angle),sa=Math.sin(angle);
                if(type.startsWith("Wedge")){
                    double hw=w/2,hh=h/2;
                    double[][] local = wedgeFlipped
                        ? new double[][]{{-hw,hh},{hw,hh},{-hw,-hh}}
                        : new double[][]{{-hw,hh},{hw,hh},{hw,-hh}};
                    double[][] world=new double[local.length][2];
                    for(int i=0;i<local.length;i++){world[i][0]=x+local[i][0]*ca-local[i][1]*sa;world[i][1]=y+local[i][0]*sa+local[i][1]*ca;}
                    return world;
                } else if(type.startsWith("Pulley")||type.startsWith("Mass Cylinder")){
                    // Circle — 12-gon approximation for SAT
                    double r=w/2; int N=12; double[][]v=new double[N][2];
                    for(int i=0;i<N;i++){v[i][0]=x+r*Math.cos(i*2*Math.PI/N);v[i][1]=y+r*Math.sin(i*2*Math.PI/N);}
                    return v;
                } else {
                    // Rectangle (always axis-aligned when lockRotation=true)
                    double hw=w/2,hh=h/2;
                    if(lockRotation||Math.abs(angle)<0.001){
                        return new double[][]{{x-hw,y-hh},{x+hw,y-hh},{x+hw,y+hh},{x-hw,y+hh}};
                    }
                    double[][] local={{-hw,-hh},{hw,-hh},{hw,hh},{-hw,hh}};
                    double[][] world=new double[4][2];
                    for(int i=0;i<4;i++){world[i][0]=x+local[i][0]*ca-local[i][1]*sa;world[i][1]=y+local[i][0]*sa+local[i][1]*ca;}
                    return world;
                }
            }
        }
        static class Conn {
            String a,b,type; double rest,k=60,maxLen; boolean broken=false;
            double ropeMass=0; // kg, distributed to endpoints; 0=massless
            Conn(String a,String b,String t,double r){
                this.a=a;this.b=b;this.type=t;this.rest=r;
                // Springs break at 10x rest length; ropes/strings become taut at rest length (inextensible)
                this.maxLen="Spring".equals(t)?r*10.0:r;
                this.k=t.equals("Rod")?200:60;
            }
        }
        /** Atwood-style rope over a pulley: lenA + lenB = totalLength */
        static class PulleyConn {
            String massA,pulleyId,massB; double totalLength; boolean broken=false;
            PulleyConn(String a,String p,String b,double tl){massA=a;pulleyId=p;massB=b;totalLength=tl;}
        }

        final Map<String,PObj> objs=new LinkedHashMap<>(); final List<Conn> conns=new ArrayList<>();
        final List<PulleyConn> pulleyConns=new ArrayList<>();
        final Map<String,double[]> simSavedState=new LinkedHashMap<>();
        int idC=0; String connectorType="Spring";
        static final double G=900,DT=0.0014;static final int SUBSTEPS=10;static final double FLOOR=380;
        static final double MAX_VEL=700; // px/s cap
        static final double INTEGSCALE=40.0; // position integration: x += vx*dt*INTEGSCALE
        javax.swing.Timer simTimer; boolean simRunning=false;
        // move-undo tracking
        Map<String,double[]> physPreMovePos=new HashMap<>();
        PObj physDragObj=null;

        PhysicsRenderer(){
            simTimer=new javax.swing.Timer(16,new ActionListener(){public void actionPerformed(ActionEvent e){simStep();}});
        }
        void addObj(String type){
            int n=objs.size(); double ang=n*1.1,r=70+n*18;
            boolean fixed=type.startsWith("Wall");
            String id=type.toLowerCase().replaceAll("[^a-z]","")+(++idC);
            String label=type+" "+idC;
            PObj o=new PObj(id,type,label,r*Math.cos(ang),Math.min(r*Math.sin(ang),FLOOR-80),fixed);
            if(type.startsWith("Wall")){o.w=20;o.h=80;o.lockRotation=false;}
            else if(type.startsWith("Pulley")){o.w=80;o.h=80;o.lockRotation=false;}
            else if(type.startsWith("Wedge")){o.w=100;o.h=70;o.fixed=true;o.lockRotation=false;}
            else if(type.startsWith("Mass Cylinder")){o.w=52;o.h=52;o.lockRotation=false;}
            else{ o.lockRotation=false; } // Mass Block
            objs.put(id,o);
            if(undoMgr!=null) undoMgr.push(new UndoableAction(){
                public void undo(){objs.remove(id);conns.removeIf(c->c.a.equals(id)||c.b.equals(id));}
                public void redo(){objs.put(id,o);}
                public String desc(){return "Add "+type;}
            });
        }
        public Draggable nodeAt(double wx,double wy){for(PObj o:objs.values()){double dx=o.x-wx,dy=o.y-wy;double r=Math.max(o.w,o.h)/2;if(dx*dx+dy*dy<=r*r*1.5)return o;}return null;}

        public boolean onPress(double wx,double wy,MouseEvent e,CanvasPanel cv){
            // Record position for move-undo
            physDragObj=hitObj(wx,wy);
            if(physDragObj!=null&&!physDragObj.fixed){physPreMovePos.put(physDragObj.id,new double[]{physDragObj.x,physDragObj.y});}
            return false;
        }
        public boolean onDrag(double wx,double wy,double px,double py,MouseEvent e,CanvasPanel cv){return false;}
        public void onRelease(double wx,double wy,MouseEvent e,CanvasPanel cv){
            if(physDragObj!=null&&physPreMovePos.containsKey(physDragObj.id)){
                double[]bp=physPreMovePos.get(physDragObj.id);
                final PObj fo=physDragObj;
                if(Math.abs(fo.x-bp[0])>1||Math.abs(fo.y-bp[1])>1){
                    final double bx=bp[0],by=bp[1],ax=fo.x,ay=fo.y;
                    if(undoMgr!=null) undoMgr.push(new UndoableAction(){
                        public void undo(){fo.x=bx;fo.y=by;}
                        public void redo(){fo.x=ax;fo.y=ay;}
                        public String desc(){return "Move "+fo.label;}
                    });
                }
                physPreMovePos.clear(); physDragObj=null;
            }
        }
        public void onRightDragEnd(double sx,double sy,double ex,double ey,CanvasPanel cv){
            PObj a=hitObj(sx,sy),b=hitObj(ex,ey); if(a==null||b==null||a==b) return;
            // Pulley-to-pulley: let the user set up a pulley system using the first pulley as overhead
            if(a.type.startsWith("Pulley")&&b.type.startsWith("Pulley")){
                // b becomes a "hanging pulley" with a rope over a (the overhead pulley)
                // Show dialog to configure: which objects hang on each side of pulley a
                showObjMenu(a, (int)(sx),(int)(sy), cv); // re-use the pulley menu so user can "Create Pulley System" with b as one mass
                return;
            }
            // Rope/spring/rod connector — normal path
            double dx=b.x-a.x,dy=b.y-a.y,dist=Math.sqrt(dx*dx+dy*dy);
            final Conn nc=new Conn(a.id,b.id,connectorType,dist);
            conns.add(nc);
            if(undoMgr!=null) undoMgr.push(new UndoableAction(){
                public void undo(){conns.remove(nc);}
                public void redo(){conns.add(nc);}
                public String desc(){return "Connect "+nc.type;}
            });
            cv.repaint();
        }
        public void onRightClick(double wx,double wy,int sx,int sy,CanvasPanel cv){
            PObj o=hitObj(wx,wy); if(o!=null){showObjMenu(o,sx,sy,cv);return;}
            Conn c=hitConn(wx,wy); if(c!=null) showConnMenu(c,sx,sy,cv);
        }
        PObj hitObj(double wx,double wy){for(PObj o:objs.values()){double dx=o.x-wx,dy=o.y-wy;double r=Math.max(o.w,o.h)/2+5;if(dx*dx+dy*dy<=r*r)return o;}return null;}
        Conn hitConn(double wx,double wy){for(Conn c:conns){PObj a=objs.get(c.a),b=objs.get(c.b);if(a==null||b==null)continue;double mx=(a.x+b.x)/2,my=(a.y+b.y)/2,dx=wx-mx,dy=wy-my;if(dx*dx+dy*dy<=30*30)return c;}return null;}

        void showObjMenu(PObj o,int sx,int sy,JComponent par){
            JPopupMenu m=new JPopupMenu();
            m.add(mi("Delete",new ActionListener(){public void actionPerformed(ActionEvent e){
                final PObj fo=o;
                final List<Conn> savedConns=new ArrayList<>();
                for(Conn c:conns) if(c.a.equals(fo.id)||c.b.equals(fo.id)) savedConns.add(c);
                objs.remove(fo.id); conns.removeAll(savedConns); par.repaint();
                if(undoMgr!=null) undoMgr.push(new UndoableAction(){
                    public void undo(){objs.put(fo.id,fo);conns.addAll(savedConns);}
                    public void redo(){objs.remove(fo.id);conns.removeAll(savedConns);}
                    public String desc(){return "Delete "+fo.label;}
                });
            }}));
            m.add(mi(o.fixed?"Unfix (make movable)":"Fix in place",new ActionListener(){public void actionPerformed(ActionEvent e){
                final boolean prev=o.fixed; o.fixed=!o.fixed;o.vx=0;o.vy=0;par.repaint();
                if(undoMgr!=null) undoMgr.push(new UndoableAction(){
                    public void undo(){o.fixed=prev;}
                    public void redo(){o.fixed=!prev;}
                    public String desc(){return (prev?"Unfix":"Fix")+" "+o.label;}
                });
            }}));
            if(!o.type.startsWith("Wall")){
                m.add(mi("Set mass…",new ActionListener(){public void actionPerformed(ActionEvent e){
                    String v=JOptionPane.showInputDialog(par,"Mass (kg):",o.mass);
                    try{if(v!=null){final double prev=o.mass;double nv=Math.max(0.1,Double.parseDouble(v));o.mass=nv;
                        if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){o.mass=prev;}public void redo(){o.mass=nv;}public String desc(){return "Set mass";}});
                    }}catch(NumberFormatException ex){}
                }}));
            }
            if(o.type.startsWith("Mass Block")){
                m.add(mi("Set size (W × H)…",new ActionListener(){public void actionPerformed(ActionEvent e){
                    String v=JOptionPane.showInputDialog(par,"Width Height (e.g. 60 50):",((int)o.w)+" "+((int)o.h));
                    if(v==null)return; String[]p=v.trim().split("[ ,x×]+");
                    try{if(p.length>=2){final double pw=o.w,ph=o.h;double nw=Math.max(10,Double.parseDouble(p[0])),nh=Math.max(10,Double.parseDouble(p[1]));o.w=nw;o.h=nh;par.repaint();
                        if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){o.w=pw;o.h=ph;}public void redo(){o.w=nw;o.h=nh;}public String desc(){return "Resize block";}});
                    }}catch(NumberFormatException ex){}
                }}));
            }
            if(o.type.startsWith("Mass Cylinder")){
                m.add(mi("Set radius…",new ActionListener(){public void actionPerformed(ActionEvent e){
                    String v=JOptionPane.showInputDialog(par,"Radius (px):",(int)(o.w/2));
                    try{if(v!=null){final double pr=o.w;double nr=Math.max(8,Double.parseDouble(v));o.w=nr*2;o.h=nr*2;par.repaint();
                        if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){o.w=pr;o.h=pr;}public void redo(){o.w=nr*2;o.h=nr*2;}public String desc(){return "Set cylinder radius";}});
                    }}catch(NumberFormatException ex){}
                }}));
            }
            m.add(mi("Set friction…",new ActionListener(){public void actionPerformed(ActionEvent e){
                String v=JOptionPane.showInputDialog(par,"Coefficient of friction (0-1):",String.format("%.2f",o.friction));
                try{if(v!=null){final double prev=o.friction;double nv=Math.max(0,Math.min(1,Double.parseDouble(v)));o.friction=nv;
                    if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){o.friction=prev;}public void redo(){o.friction=nv;}public String desc(){return "Set friction";}});
                }}catch(NumberFormatException ex){}
            }}));
            m.add(mi("Set restitution (bounciness)…",new ActionListener(){public void actionPerformed(ActionEvent e){
                String v=JOptionPane.showInputDialog(par,"Restitution (0=inelastic, 1=elastic):",String.format("%.2f",o.restitution));
                try{if(v!=null){final double prev=o.restitution;double nv=Math.max(0,Math.min(1,Double.parseDouble(v)));o.restitution=nv;
                    if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){o.restitution=prev;}public void redo(){o.restitution=nv;}public String desc(){return "Set restitution";}});
                }}catch(NumberFormatException ex){}
            }}));
            m.add(mi("Set rotation (degrees)…",new ActionListener(){public void actionPerformed(ActionEvent e){
                String v=JOptionPane.showInputDialog(par,"Rotation (degrees):",String.format("%.1f",Math.toDegrees(o.angle)));
                try{if(v!=null){final double prev=o.angle;double nv=Math.toRadians(Double.parseDouble(v));o.angle=nv;par.repaint();
                    if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){o.angle=prev;}public void redo(){o.angle=nv;}public String desc(){return "Set rotation";}});
                }}catch(NumberFormatException ex){}
            }}));
            if(o.type.startsWith("Pulley")){
                m.addSeparator();
                m.add(mi("Set radius…",new ActionListener(){public void actionPerformed(ActionEvent e){
                    String v=JOptionPane.showInputDialog(par,"Radius (px):",(int)(o.w/2));
                    try{if(v!=null){final double pr2=o.w;double nr=Math.max(10,Double.parseDouble(v));o.w=nr*2;o.h=nr*2;par.repaint();
                        if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){o.w=pr2;o.h=pr2;}public void redo(){o.w=nr*2;o.h=nr*2;}public String desc(){return "Set pulley radius";}});
                    }}catch(NumberFormatException ex){}
                }}));
                m.add(mi("Create Pulley System…",new ActionListener(){public void actionPerformed(ActionEvent e2){
                    // All objects (including other pulleys) can be masses
                    List<String> ids=new ArrayList<>(),lbls=new ArrayList<>();
                    for(PObj p2:objs.values()) if(!p2.id.equals(o.id)){ids.add(p2.id);lbls.add(p2.label);}
                    if(ids.size()<2){JOptionPane.showMessageDialog(par,"Need at least 2 other objects.");return;}
                    String[]la=lbls.toArray(new String[0]);
                    JComboBox<String> cbA=new JComboBox<>(la),cbB=new JComboBox<>(la);
                    if(la.length>1) cbB.setSelectedIndex(1);
                    // helper to recalculate rope length from current selection
                    final JTextField lenFld=new JTextField("250",8);
                    Runnable updateLen=new Runnable(){public void run(){
                        int ia=cbA.getSelectedIndex(),ib=cbB.getSelectedIndex();
                        if(ia<0||ib<0||ia==ib) return;
                        PObj _mA=objs.get(ids.get(ia)),_mB=objs.get(ids.get(ib));
                        if(_mA==null||_mB==null) return;
                        double _dA=Math.sqrt((_mA.x-o.x)*(_mA.x-o.x)+(_mA.y-o.y)*(_mA.y-o.y));
                        double _dB=Math.sqrt((_mB.x-o.x)*(_mB.x-o.x)+(_mB.y-o.y)*(_mB.y-o.y));
                        lenFld.setText(String.format("%.0f",_dA+_dB+Math.PI*o.w/2));
                    }};
                    updateLen.run();
                    cbA.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent ev){updateLen.run();}});
                    cbB.addActionListener(new ActionListener(){public void actionPerformed(ActionEvent ev){updateLen.run();}});
                    JPanel dlg=new JPanel(new GridLayout(0,2,4,4));
                    dlg.add(new JLabel("Mass A (left):")); dlg.add(cbA);
                    dlg.add(new JLabel("Mass B (right):")); dlg.add(cbB);
                    dlg.add(new JLabel("Total rope length (px):")); dlg.add(lenFld);
                    if(JOptionPane.showConfirmDialog(par,dlg,"Create Pulley System",JOptionPane.OK_CANCEL_OPTION)!=JOptionPane.OK_OPTION) return;
                    String idA=ids.get(cbA.getSelectedIndex()),idB=ids.get(cbB.getSelectedIndex());
                    if(idA.equals(idB)){JOptionPane.showMessageDialog(par,"Select two different objects.");return;}
                    double tl=250; try{tl=Double.parseDouble(lenFld.getText().trim());}catch(NumberFormatException ignored){}
                    final PulleyConn pc=new PulleyConn(idA,o.id,idB,tl);
                    pulleyConns.add(pc); par.repaint();
                    if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){pulleyConns.remove(pc);}public void redo(){pulleyConns.add(pc);}public String desc(){return "Create pulley system";}});
                }}));
                if(pulleyConns.stream().anyMatch(pc->pc.pulleyId.equals(o.id))){
                    m.add(mi("Remove Pulley Systems on this pulley",new ActionListener(){public void actionPerformed(ActionEvent e2){
                        final List<PulleyConn> removed=new ArrayList<>();
                        java.util.Iterator<PulleyConn> it=pulleyConns.iterator();
                        while(it.hasNext()){PulleyConn pc=it.next();if(pc.pulleyId.equals(o.id)){removed.add(pc);it.remove();}}
                        par.repaint();
                        if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){pulleyConns.addAll(removed);}public void redo(){pulleyConns.removeAll(removed);}public String desc(){return "Remove pulley system";}});
                    }}));
                }
            }
            if(o.type.startsWith("Wedge")){
                m.addSeparator();
                m.add(mi("Set wedge W x H...",new ActionListener(){public void actionPerformed(ActionEvent e){
                    String v=JOptionPane.showInputDialog(par,"Width Height (e.g. 120 80):",((int)o.w)+" "+((int)o.h));
                    if(v==null)return; String[]p=v.trim().split("[ ,]+");
                    try{if(p.length>=2){final double pw=o.w,ph=o.h;double nw=Math.max(20,Double.parseDouble(p[0])),nh=Math.max(10,Double.parseDouble(p[1]));o.w=nw;o.h=nh;par.repaint();
                        if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){o.w=pw;o.h=ph;}public void redo(){o.w=nw;o.h=nh;}public String desc(){return "Resize wedge";}});
                    }}catch(NumberFormatException ex){}
                }}));
                m.add(mi("Reflect wedge horizontally",new ActionListener(){public void actionPerformed(ActionEvent e){
                    o.wedgeFlipped=!o.wedgeFlipped;par.repaint();
                    if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){o.wedgeFlipped=!o.wedgeFlipped;}public void redo(){o.wedgeFlipped=!o.wedgeFlipped;}public String desc(){return "Flip wedge";}});
                }}));
            }
            m.show(par,sx,sy);
        }
        void showConnMenu(Conn c,int sx,int sy,JComponent par){
            JPopupMenu m=new JPopupMenu();
            m.add(mi("Delete",new ActionListener(){public void actionPerformed(ActionEvent e){
                conns.remove(c);par.repaint();
                if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){conns.add(c);}public void redo(){conns.remove(c);}public String desc(){return "Delete connector";}});
            }}));
            if("Spring".equals(c.type)){
                m.add(mi("Set spring k…",new ActionListener(){public void actionPerformed(ActionEvent e){
                    String v=JOptionPane.showInputDialog(par,"Spring constant k:",c.k);
                    try{if(v!=null){final double prev=c.k;double nv=Double.parseDouble(v);c.k=nv;
                        if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){c.k=prev;}public void redo(){c.k=nv;}public String desc(){return "Set spring k";}});
                    }}catch(NumberFormatException ex){}
                }}));
            }
            if("Rope".equals(c.type)||"String".equals(c.type)){
                m.add(mi("Set rope mass…",new ActionListener(){public void actionPerformed(ActionEvent e){
                    String v=JOptionPane.showInputDialog(par,"Rope/string mass (kg), 0 = massless.\nWeight will be distributed evenly to connected objects.",c.ropeMass);
                    try{if(v!=null){final double prev=c.ropeMass;double nv=Math.max(0,Double.parseDouble(v));c.ropeMass=nv;
                        if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){c.ropeMass=prev;}public void redo(){c.ropeMass=nv;}public String desc(){return "Set rope mass";}});
                    }}catch(NumberFormatException ex){}
                }}));
            }
            m.add(mi("Set rest length…",new ActionListener(){public void actionPerformed(ActionEvent e){
                String v=JOptionPane.showInputDialog(par,"Rest length (px):",(int)c.rest);
                try{if(v!=null){final double prev=c.rest;double nv=Double.parseDouble(v);c.rest=nv;c.maxLen="Spring".equals(c.type)?c.rest*5.0:c.rest;
                    if(undoMgr!=null) undoMgr.push(new UndoableAction(){public void undo(){c.rest=prev;c.maxLen="Spring".equals(c.type)?prev*5.0:prev;}public void redo(){c.rest=nv;c.maxLen="Spring".equals(c.type)?nv*5.0:nv;}public String desc(){return "Set rest length";}});
                }}catch(NumberFormatException ex){}
            }}));
            m.show(par,sx,sy);
        }

        void startSim(){
            simSavedState.clear();
            for(Map.Entry<String,PObj> e:objs.entrySet()){PObj o=e.getValue();simSavedState.put(e.getKey(),new double[]{o.x,o.y,o.vx,o.vy,o.angle,o.angularVel});}
            for(Conn c:conns) c.broken=false;
            for(PulleyConn pc:pulleyConns) pc.broken=false;
            simRunning=true;simTimer.start();
        }
        void pauseSim(){simRunning=false;simTimer.stop();}
        void resetSim(){
            pauseSim();
            if(!simSavedState.isEmpty()){
                for(Map.Entry<String,double[]> e:simSavedState.entrySet()){
                    PObj o=objs.get(e.getKey());
                    if(o!=null){double[]st=e.getValue();o.x=st[0];o.y=st[1];o.vx=st[2];o.vy=st[3];o.angle=st[4];o.angularVel=st[5];}
                }
            } else {
                for(PObj o:objs.values()){o.vx=0;o.vy=0;}
            }
            for(Conn c:conns) c.broken=false;
            for(PulleyConn pc:pulleyConns) pc.broken=false;
            if(repaintCB!=null) repaintCB.run();
        }
        public void clear(){
            pauseSim();
            if(objs.isEmpty()&&conns.isEmpty()&&pulleyConns.isEmpty())return;
            final Map<String,PObj> savedObjs=new LinkedHashMap<>(objs);
            final List<Conn> savedConns=new ArrayList<>(conns);
            final List<PulleyConn> savedPulleys=new ArrayList<>(pulleyConns);
            objs.clear();conns.clear();pulleyConns.clear();
            if(undoMgr!=null) undoMgr.push(new UndoableAction(){
                public void undo(){objs.putAll(savedObjs);conns.addAll(savedConns);pulleyConns.addAll(savedPulleys);}
                public void redo(){objs.clear();conns.clear();pulleyConns.clear();}
                public String desc(){return "Clear physics";}
            });
        }

        // ── Rigid-body helpers ─────────────────────────────────────────────────
        /** Moment of inertia (mass * px²). Rectangle: 1/12*m*(w²+h²). Cylinder: 1/2*m*r². */
        static double momentOfInertia(PObj o){
            if(o.type.startsWith("Mass Cylinder")||o.type.startsWith("Pulley")){
                double r=o.w/2; return 0.5*o.mass*r*r;
            }
            return o.mass*(o.w*o.w+o.h*o.h)/12.0;
        }
        /** Velocity at world point (cx,cy) due to object's linear+angular motion, in physical px/s. */
        static double[] contactVelPhys(PObj o,double cx,double cy){
            double rx=cx-o.x,ry=cy-o.y;
            // v_contact = v_cm  +  ω×r  (y-down screen, clockwise positive ω)
            // ω×r in y-down clockwise: (-ω*ry, ω*rx)
            return new double[]{o.vx*INTEGSCALE - o.angularVel*ry,
                                o.vy*INTEGSCALE + o.angularVel*rx};
        }
        /** Apply linear+angular impulse at contact offset (rx,ry) from body centre. j in physical units. */
        static void applyImpulsePhys(PObj o,double jx,double jy,double rx,double ry,double I){
            if(o.fixed) return;
            o.vx+=jx/(o.mass*INTEGSCALE);
            o.vy+=jy/(o.mass*INTEGSCALE);
            // Δω = (r × j) / I  →  r × j = rx*jy - ry*jx  (y-down clockwise)
            o.angularVel+=(rx*jy-ry*jx)/I;
        }
        /** Find centroid of all vertices of vA that lie on the penetrating side of normal n (from A into B). */
        static double[] findContactPoint(double[][]vA,double[][]vB,double nx,double ny){
            // collect vertices of each body that are inside the other (approximate)
            double cx=0,cy=0; int cnt=0;
            // use deepest vertices of vB in normal direction (they are closest to vA)
            double minD=Double.MAX_VALUE;
            for(double[]v:vB){ double d=v[0]*nx+v[1]*ny; if(d<minD) minD=d; }
            for(double[]v:vB){ if(v[0]*nx+v[1]*ny<minD+2.0){cx+=v[0];cy+=v[1];cnt++;} }
            if(cnt==0){ for(double[]v:vB){cx+=v[0];cy+=v[1];}cnt=vB.length; }
            return new double[]{cx/cnt,cy/cnt};
        }

        /** SAT overlap test. Returns {nx,ny,depth} (normal from B→A) or null if separated. */
        static double[] satTest(double[][]vA,double[][]vB){
            double minDep=Double.MAX_VALUE; double bestNx=0,bestNy=0;
            for(int pass=0;pass<2;pass++){
                double[][]v=pass==0?vA:vB;
                for(int i=0;i<v.length;i++){
                    double ex=v[(i+1)%v.length][0]-v[i][0],ey=v[(i+1)%v.length][1]-v[i][1];
                    double nx=-ey,ny=ex,l=Math.sqrt(nx*nx+ny*ny);
                    if(l<1e-9) continue; nx/=l;ny/=l;
                    double mnA=Double.MAX_VALUE,mxA=-Double.MAX_VALUE;
                    for(double[]p:vA){double d=p[0]*nx+p[1]*ny;if(d<mnA)mnA=d;if(d>mxA)mxA=d;}
                    double mnB=Double.MAX_VALUE,mxB=-Double.MAX_VALUE;
                    for(double[]p:vB){double d=p[0]*nx+p[1]*ny;if(d<mnB)mnB=d;if(d>mxB)mxB=d;}
                    double dep=Math.min(mxA,mxB)-Math.max(mnA,mnB);
                    if(dep<=0) return null;
                    if(dep<minDep){minDep=dep;bestNx=nx;bestNy=ny;}
                }
            }
            return new double[]{bestNx,bestNy,minDep};
        }

        void simStep(){
            final double DT_SUB = DT;
            for(int s=0;s<SUBSTEPS;s++){
                // 1. Gravity, linear damping, angular damping
                for(PObj o:objs.values()){
                    if(o.fixed){o.vx=0;o.vy=0;o.angularVel=0;continue;}
                    o.vx*=0.9995; o.vy+=G*DT_SUB;
                    o.angularVel*=0.999; // small angular damping
                    double spd=Math.sqrt(o.vx*o.vx+o.vy*o.vy);
                    if(spd>MAX_VEL){o.vx=o.vx/spd*MAX_VEL;o.vy=o.vy/spd*MAX_VEL;}
                }
                // 2. Rope/string distributed mass gravity
                for(Conn c:conns){
                    if(c.ropeMass<=0||c.broken) continue;
                    if(!"Rope".equals(c.type)&&!"String".equals(c.type)) continue;
                    PObj a=objs.get(c.a),b=objs.get(c.b); if(a==null||b==null) continue;
                    double halfWt=c.ropeMass*G*DT_SUB/2;
                    if(!a.fixed) a.vy+=halfWt/a.mass;
                    if(!b.fixed) b.vy+=halfWt/b.mass;
                }
                // 3. Spring forces
                for(Conn c:conns){
                    if(c.broken) continue;
                    PObj a=objs.get(c.a),b=objs.get(c.b); if(a==null||b==null) continue;
                    if(!"Spring".equals(c.type)) continue;
                    double dx=b.x-a.x,dy=b.y-a.y,dist=Math.max(0.1,Math.sqrt(dx*dx+dy*dy));
                    if(dist>c.maxLen){c.broken=true;continue;}
                    double ux=dx/dist,uy=dy/dist;
                    double force=c.k*(dist-c.rest);
                    double relV=(b.vx-a.vx)*ux+(b.vy-a.vy)*uy;
                    double damp=Math.min(2*Math.sqrt(c.k*(a.mass+b.mass)*0.5),8)*0.3*relV;
                    double tf=force+damp;
                    if(!a.fixed){a.vx+=tf*ux/a.mass*DT_SUB;a.vy+=tf*uy/a.mass*DT_SUB;}
                    if(!b.fixed){b.vx-=tf*ux/b.mass*DT_SUB;b.vy-=tf*uy/b.mass*DT_SUB;}
                }
                // 4. Integrate positions and angles
                for(PObj o:objs.values()) if(!o.fixed){
                    o.x+=o.vx*DT_SUB*INTEGSCALE;
                    o.y+=o.vy*DT_SUB*INTEGSCALE;
                    o.angle+=o.angularVel*DT_SUB; // ω in rad/s, angle in radians
                }
                // 5. Rope/string/rod positional constraints
                for(Conn c:conns){
                    if(c.broken) continue;
                    String t=c.type; if("Spring".equals(t)) continue;
                    PObj a=objs.get(c.a),b=objs.get(c.b); if(a==null||b==null) continue;
                    double dx=b.x-a.x,dy=b.y-a.y,dist=Math.max(0.001,Math.sqrt(dx*dx+dy*dy));
                    boolean isRod="Rod".equals(t);
                    double correction=0;
                    if(isRod) correction=dist-c.rest;
                    else if(dist>c.rest) correction=dist-c.rest;
                    if(Math.abs(correction)<0.001) continue;
                    double ux=dx/dist,uy=dy/dist;
                    double wA=a.fixed?0:1.0/a.mass,wB=b.fixed?0:1.0/b.mass,wT=wA+wB;
                    if(wT<1e-9) continue;
                    double moveA=correction*wA/wT,moveB=correction*wB/wT;
                    if(!a.fixed){a.x+=ux*moveA;a.y+=uy*moveA;}
                    if(!b.fixed){b.x-=ux*moveB;b.y-=uy*moveB;}
                    double relV=(b.vx-a.vx)*ux+(b.vy-a.vy)*uy;
                    if(isRod||relV>0){
                        double imp=relV/wT;
                        if(!a.fixed){a.vx+=imp*ux*wA;a.vy+=imp*uy*wA;}
                        if(!b.fixed){b.vx-=imp*ux*wB;b.vy-=imp*uy*wB;}
                    }
                }
                // 6. Pulley constraints (inextensible rope over pulley)
                for(PulleyConn pc:pulleyConns){
                    if(pc.broken) continue;
                    PObj pully=objs.get(pc.pulleyId),mA=objs.get(pc.massA),mB=objs.get(pc.massB);
                    if(pully==null||mA==null||mB==null) continue;
                    double pr=pully.w/2;
                    // anchor points on pulley rim
                    double ancAx=pully.x-pr,ancAy=pully.y;
                    double ancBx=pully.x+pr,ancBy=pully.y;
                    double dAx=ancAx-mA.x,dAy=ancAy-mA.y;
                    double dBx=ancBx-mB.x,dBy=ancBy-mB.y;
                    double lenA=Math.max(1,Math.sqrt(dAx*dAx+dAy*dAy));
                    double lenB=Math.max(1,Math.sqrt(dBx*dBx+dBy*dBy));
                    double uAx=dAx/lenA,uAy=dAy/lenA;
                    double uBx=dBx/lenB,uBy=dBy/lenB;
                    double invMA=mA.fixed?0:1.0/mA.mass,invMB=mB.fixed?0:1.0/mB.mass;
                    double denom=invMA+invMB; if(denom<1e-9) continue;
                    double excess=lenA+lenB-pc.totalLength;
                    if(excess>0){
                        double lambda=excess*0.9/denom;
                        if(!mA.fixed){mA.x+=uAx*lambda*invMA;mA.y+=uAy*lambda*invMA;}
                        if(!mB.fixed){mB.x+=uBx*lambda*invMB;mB.y+=uBy*lambda*invMB;}
                    }
                    if(excess>=-1){
                        double relV=-(mA.vx*uAx+mA.vy*uAy)-(mB.vx*uBx+mB.vy*uBy);
                        double T=relV/denom;
                        if(!mA.fixed){mA.vx+=uAx*T*invMA;mA.vy+=uAy*T*invMA;}
                        if(!mB.fixed){mB.vx+=uBx*T*invMB;mB.vy+=uBy*T*invMB;}
                    }
                }
                // 7. Floor collisions — proper impulse with angular response
                List<PObj> objList=new ArrayList<>(objs.values());
                for(PObj o:objList){
                    if(o.fixed) continue;
                    double I=momentOfInertia(o);
                    boolean isCyl=o.type.startsWith("Mass Cylinder")||o.type.startsWith("Pulley");
                    if(isCyl){
                        double r=o.w/2, pen=o.y+r-FLOOR;
                        if(pen>0){
                            o.y-=pen;
                            // contact point at bottom of cylinder
                            double cx=o.x, cy=FLOOR;
                            double rnx=0,rny=-1; // floor normal (up)
                            double[]vc=contactVelPhys(o,cx,cy);
                            double vn=vc[0]*rnx+vc[1]*rny;
                            if(vn<0){
                                // Normal impulse
                                double rCrossN_sq=0; // r=(0,r) cross (0,-1) = 0*(-1)-r*0=0 → no angular from normal
                                double denomN=1.0/o.mass+rCrossN_sq/I;
                                double e=o.restitution;
                                double jn=-(1+e)*vn/denomN;
                                applyImpulsePhys(o, rnx*jn,rny*jn, cx-o.x,cy-o.y, I);
                            }
                            // Friction (tangential impulse → angular)
                            double[]vc2=contactVelPhys(o,cx,cy);
                            double vt=vc2[0]; // tangential = x component on horizontal floor
                            double rx2=cx-o.x, ry2=cy-o.y; // (0, r)
                            // denominator for tangential: 1/m + (r×t)²/I, t=(1,0), r×t = rx*ty-ry*tx = rx*0-ry*1 = -ry
                            double rCrossT=-ry2;
                            double denomT=1.0/o.mass+rCrossT*rCrossT/I;
                            double jnMag=Math.abs(o.vy*INTEGSCALE)*o.mass;
                            double jt=-vt/denomT;
                            jt=Math.max(-o.friction*jnMag,Math.min(o.friction*jnMag,jt));
                            applyImpulsePhys(o, jt,0, rx2,ry2, I);
                            if(Math.abs(o.vy)<0.5/INTEGSCALE) o.vy=0;
                        }
                    } else {
                        // Polygon floor collision: find all vertices below floor
                        double[][] verts=o.getVertices();
                        // find max penetration
                        double maxPen=0;
                        for(double[]v:verts) maxPen=Math.max(maxPen,v[1]-FLOOR);
                        if(maxPen<=0||maxPen>Math.max(o.w,o.h)*2) continue;
                        // push out
                        o.y-=maxPen;
                        // recalculate contact point: centroid of vertices that were below floor
                        double cpx=0,cpy=0; int cnt=0;
                        double[][] vertsNew=o.getVertices();
                        for(double[]v:vertsNew){ if(v[1]>=FLOOR-2){ cpx+=v[0];cpy+=v[1];cnt++; } }
                        if(cnt==0){ cpx=o.x; cpy=FLOOR; }
                        else{ cpx/=cnt; cpy=FLOOR; }
                        double rnx=0,rny=-1; // floor normal
                        double rx=cpx-o.x,ry2=cpy-o.y;
                        double rCrossN=rx*rny-ry2*rnx; // for denominator
                        double[]vc=contactVelPhys(o,cpx,cpy);
                        double vn=vc[0]*rnx+vc[1]*rny;
                        if(vn<0){
                            double denomN=1.0/o.mass+rCrossN*rCrossN/I;
                            double jn=-(1+o.restitution)*vn/denomN;
                            applyImpulsePhys(o, rnx*jn,rny*jn, rx,ry2, I);
                        }
                        // Friction tangential impulse
                        double[]vc2=contactVelPhys(o,cpx,cpy);
                        double vt=vc2[0];
                        double rCrossT=rx*0-ry2*1; // t=(1,0): r×t = rx*0 - ry*1 = -ry
                        double denomT=1.0/o.mass+rCrossT*rCrossT/I;
                        double jnMag=Math.abs(o.vy*INTEGSCALE)*o.mass;
                        double jt=-vt/denomT;
                        double mu=o.friction;
                        jt=Math.max(-mu*jnMag,Math.min(mu*jnMag,jt));
                        applyImpulsePhys(o, jt,0, rx,ry2, I);
                        // small velocity threshold to settle
                        if(Math.abs(o.vy)<0.5/INTEGSCALE) o.vy=0;
                        // Very small angular velocity → damp quickly when nearly flat
                        double flatness=Math.abs(Math.cos(o.angle*2)); // 1 when angle≈0 or π/2
                        if(maxPen>0.5&&flatness>0.95) o.angularVel*=0.85;
                    }
                }
                // 8. Object-object collisions — full rigid body impulse with angular
                for(int i=0;i<objList.size();i++){
                    PObj oa=objList.get(i); if(oa.type.startsWith("Pulley")) continue;
                    for(int j=i+1;j<objList.size();j++){
                        PObj ob=objList.get(j); if(ob.type.startsWith("Pulley")) continue;
                        if(oa.fixed&&ob.fixed) continue;
                        boolean aCyl=oa.type.startsWith("Mass Cylinder");
                        boolean bCyl=ob.type.startsWith("Mass Cylinder");
                        if(aCyl&&bCyl){ resolveCircleCircle(oa,ob); continue; }
                        // Broad-phase
                        double broadA=Math.sqrt(oa.w*oa.w+oa.h*oa.h)/2+4;
                        double broadB=Math.sqrt(ob.w*ob.w+ob.h*ob.h)/2+4;
                        double cdx=oa.x-ob.x,cdy=oa.y-ob.y;
                        if(cdx*cdx+cdy*cdy>(broadA+broadB)*(broadA+broadB)) continue;
                        double[][]vA=oa.getVertices(),vB=ob.getVertices();
                        double[]col=satTest(vA,vB);
                        if(col==null) continue;
                        double nx=col[0],ny=col[1],dep=col[2];
                        if((oa.x-ob.x)*nx+(oa.y-ob.y)*ny<0){nx=-nx;ny=-ny;}
                        double invMA=oa.fixed?0:1.0/oa.mass, invMB=ob.fixed?0:1.0/ob.mass;
                        double wT=invMA+invMB; if(wT<1e-9) continue;
                        // Positional correction
                        double slop=0.5,corr=Math.max(dep-slop,0)*0.8/wT;
                        if(!oa.fixed){oa.x+=nx*corr*invMA;oa.y+=ny*corr*invMA;}
                        if(!ob.fixed){ob.x-=nx*corr*invMB;ob.y-=ny*corr*invMB;}
                        // Contact point
                        double[]cp=findContactPoint(vA,vB,nx,ny);
                        double cpx=cp[0],cpy=cp[1];
                        double rAx=cpx-oa.x,rAy=cpy-oa.y;
                        double rBx=cpx-ob.x,rBy=cpy-ob.y;
                        double IA=Math.max(1.0,momentOfInertia(oa));
                        double IB=Math.max(1.0,momentOfInertia(ob));
                        // Relative velocity at contact (physical units)
                        double[]vcA=contactVelPhys(oa,cpx,cpy);
                        double[]vcB=contactVelPhys(ob,cpx,cpy);
                        double rvx=vcA[0]-vcB[0],rvy=vcA[1]-vcB[1];
                        double rvn=rvx*nx+rvy*ny;
                        if(rvn>=0) continue; // separating
                        // Impulse denominator including angular terms
                        double rACrossN=rAx*ny-rAy*nx;
                        double rBCrossN=rBx*ny-rBy*nx;
                        double denomN=invMA+invMB+(oa.fixed?0:rACrossN*rACrossN/IA)+(ob.fixed?0:rBCrossN*rBCrossN/IB);
                        if(denomN<1e-9) continue;
                        double e=Math.min(oa.restitution,ob.restitution)*0.5;
                        double jn=-(1+e)*rvn/denomN;
                        // Apply normal impulse
                        applyImpulsePhys(oa, nx*jn,ny*jn, rAx,rAy, IA);
                        applyImpulsePhys(ob,-nx*jn,-ny*jn, rBx,rBy, IB);
                        // Friction (tangential) impulse
                        double[]vcA2=contactVelPhys(oa,cpx,cpy);
                        double[]vcB2=contactVelPhys(ob,cpx,cpy);
                        double tx=-ny,ty=nx;
                        double rvt=(vcA2[0]-vcB2[0])*tx+(vcA2[1]-vcB2[1])*ty;
                        double rACrossT=rAx*ty-rAy*tx;
                        double rBCrossT=rBx*ty-rBy*tx;
                        double denomT=invMA+invMB+(oa.fixed?0:rACrossT*rACrossT/IA)+(ob.fixed?0:rBCrossT*rBCrossT/IB);
                        if(denomT<1e-9) continue;
                        double fric=(oa.friction+ob.friction)*0.5;
                        double jt=-rvt/denomT;
                        jt=Math.max(-Math.abs(jn)*fric,Math.min(Math.abs(jn)*fric,jt));
                        applyImpulsePhys(oa, tx*jt,ty*jt, rAx,rAy, IA);
                        applyImpulsePhys(ob,-tx*jt,-ty*jt, rBx,rBy, IB);
                    }
                }
            }
            repaintTarget();
        }

        /** Circle-circle collision resolution with full angular impulse */
        void resolveCircleCircle(PObj oa, PObj ob){
            double ra=oa.w/2,rb=ob.w/2;
            double dx=oa.x-ob.x,dy=oa.y-ob.y;
            double dist=Math.sqrt(dx*dx+dy*dy);
            double pen=ra+rb-dist;
            if(pen<=0) return;
            if(dist<0.001){dx=1;dy=0;dist=1;}
            double nx=dx/dist,ny=dy/dist;
            double invMA=oa.fixed?0:1.0/oa.mass,invMB=ob.fixed?0:1.0/ob.mass;
            double wT=invMA+invMB; if(wT<1e-9) return;
            // positional correction
            double corr=pen*0.8/wT;
            if(!oa.fixed){oa.x+=nx*corr*invMA;oa.y+=ny*corr*invMA;}
            if(!ob.fixed){ob.x-=nx*corr*invMB;ob.y-=ny*corr*invMB;}
            // contact point on surface of ob
            double cpx=ob.x+nx*rb, cpy=ob.y+ny*rb;
            double rAx=cpx-oa.x,rAy=cpy-oa.y;
            double rBx=cpx-ob.x,rBy=cpy-ob.y;
            double IA=Math.max(1.0,momentOfInertia(oa));
            double IB=Math.max(1.0,momentOfInertia(ob));
            double[]vcA=contactVelPhys(oa,cpx,cpy);
            double[]vcB=contactVelPhys(ob,cpx,cpy);
            double rvx=vcA[0]-vcB[0],rvy=vcA[1]-vcB[1];
            double rvn=rvx*nx+rvy*ny;
            if(rvn>=0) return;
            double rACrossN=rAx*ny-rAy*nx, rBCrossN=rBx*ny-rBy*nx;
            double denomN=invMA+invMB+(oa.fixed?0:rACrossN*rACrossN/IA)+(ob.fixed?0:rBCrossN*rBCrossN/IB);
            if(denomN<1e-9) return;
            double e=Math.min(oa.restitution,ob.restitution)*0.5;
            double jn=-(1+e)*rvn/denomN;
            applyImpulsePhys(oa, nx*jn,ny*jn, rAx,rAy, IA);
            applyImpulsePhys(ob,-nx*jn,-ny*jn, rBx,rBy, IB);
            // Friction
            double[]vcA2=contactVelPhys(oa,cpx,cpy);
            double[]vcB2=contactVelPhys(ob,cpx,cpy);
            double tx=-ny,ty=nx;
            double rvt=(vcA2[0]-vcB2[0])*tx+(vcA2[1]-vcB2[1])*ty;
            double rACrossT=rAx*ty-rAy*tx,rBCrossT=rBx*ty-rBy*tx;
            double denomT=invMA+invMB+(oa.fixed?0:rACrossT*rACrossT/IA)+(ob.fixed?0:rBCrossT*rBCrossT/IB);
            if(denomT<1e-9) return;
            double fric=(oa.friction+ob.friction)*0.5;
            double jt=-rvt/denomT;
            jt=Math.max(-Math.abs(jn)*fric,Math.min(Math.abs(jn)*fric,jt));
            applyImpulsePhys(oa, tx*jt,ty*jt, rAx,rAy, IA);
            applyImpulsePhys(ob,-tx*jt,-ty*jt, rBx,rBy, IB);
        }
        Runnable repaintCB;
        void repaintTarget(){if(repaintCB!=null)repaintCB.run();}

        public void draw(Graphics2D g){
            title(g,"Physics Simulation",-340);
            // floor — wide enough that objects can't escape horizontally
            g.setColor(new Color(150,120,90));g.setStroke(S_THICK);g.draw(new Line2D.Double(-2000,FLOOR,2000,FLOOR));
            g.setColor(new Color(180,155,120));for(int x=-2000;x<2000;x+=14)g.draw(new Line2D.Double(x,FLOOR,x-8,FLOOR+14));
            // connectors (all black)
            for(Conn c:conns){PObj a=objs.get(c.a),b=objs.get(c.b);if(a==null||b==null)continue;drawConn(g,a,b,c);}
            // pulley system ropes — left anchor to mA, semicircle over top, right anchor to mB
            for(PulleyConn pc:pulleyConns){
                PObj pully=objs.get(pc.pulleyId),mA=objs.get(pc.massA),mB=objs.get(pc.massB);
                if(pully==null||mA==null||mB==null) continue;
                double pr=pully.w/2;
                double ancAx=pully.x-pr, ancAy=pully.y; // left anchor
                double ancBx=pully.x+pr, ancBy=pully.y; // right anchor
                g.setColor(Color.BLACK);
                g.setStroke(new BasicStroke(2.4f,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
                // mA → left anchor (straight rope going up)
                g.draw(new Line2D.Double(mA.x, mA.y, ancAx, ancAy));
                // Semicircle wrap over top (0° = right, sweep CCW 180° to left)
                g.draw(new Arc2D.Double(pully.x-pr, pully.y-pr, pr*2, pr*2, 0, 180, Arc2D.OPEN));
                // right anchor → mB
                g.draw(new Line2D.Double(ancBx, ancBy, mB.x, mB.y));
                // Label: show total length and individual rope segments
                double dA=Math.sqrt((mA.x-ancAx)*(mA.x-ancAx)+(mA.y-ancAy)*(mA.y-ancAy));
                double dB=Math.sqrt((mB.x-ancBx)*(mB.x-ancBx)+(mB.y-ancBy)*(mB.y-ancBy));
                g.setFont(F_SMALL); g.setColor(C_MUTED);
                g.drawString(String.format("L=%.0f (%.0f+%.0f)",pc.totalLength,dA,dB),
                    (int)(pully.x+pr+6),(int)(pully.y-6));
            }
            // objects
            for(PObj o:objs.values()) drawObj(g,o);
            if(objs.isEmpty()) hint(g,"Add objects from dropdown. Right-drag between objects to connect. Right-click to edit. ▶ to simulate.");
            if(simRunning){g.setFont(F_HINT);g.setColor(new Color(160,50,50));g.drawString("▶ SIMULATING",-38,(int)(FLOOR+30));}
        }

        void drawObj(Graphics2D g,PObj o){
            AffineTransform saved=g.getTransform();
            if(Math.abs(o.angle)>0.0001){
                g.translate(o.x,o.y); g.rotate(o.angle); g.translate(-o.x,-o.y);
            }
            if(o.type.startsWith("Mass Cylinder")){
                int r=(int)(o.w/2);
                g.setColor(o.fixed?new Color(160,160,160):new Color(210,230,255));
                g.fillOval((int)(o.x-r),(int)(o.y-r),r*2,r*2);
                g.setColor(Color.BLACK);g.setStroke(S_LINE);
                g.drawOval((int)(o.x-r),(int)(o.y-r),r*2,r*2);
                // cross hairs
                g.setColor(new Color(120,140,180));g.setStroke(S_THIN);
                g.drawLine((int)(o.x-r/2),(int)o.y,(int)(o.x+r/2),(int)o.y);
                g.drawLine((int)o.x,(int)(o.y-r/2),(int)o.x,(int)(o.y+r/2));
                ctr(g,o.label,o.x,o.y-5,F_SMALL,C_DIM);
                ctr(g,o.mass+"kg",o.x,o.y+9,F_IDX,C_MUTED);
            } else if(o.type.startsWith("Wedge")){
                double hw=o.w/2,hh=o.h/2;
                int[] xs=o.wedgeFlipped
                    ? new int[]{(int)(o.x-hw),(int)(o.x+hw),(int)(o.x-hw)}
                    : new int[]{(int)(o.x-hw),(int)(o.x+hw),(int)(o.x+hw)};
                int[] ys=o.wedgeFlipped
                    ? new int[]{(int)(o.y+hh),(int)(o.y+hh),(int)(o.y-hh)}
                    : new int[]{(int)(o.y+hh),(int)(o.y+hh),(int)(o.y-hh)};
                g.setColor(o.fixed?new Color(160,160,160):new Color(225,225,245));
                g.fillPolygon(xs,ys,3);
                g.setColor(Color.BLACK);g.setStroke(S_LINE);
                g.drawPolygon(xs,ys,3);
                g.setFont(F_IDX);g.setColor(C_DIM);
                g.drawString(o.label,(int)(o.x),(int)(o.y+hh+14));
                g.setFont(F_IDX);g.setColor(C_MUTED);
                g.drawString("µ="+String.format("%.2f",o.friction),(int)(o.x-hw+2),(int)(o.y));
            } else if(o.type.startsWith("Pulley")){
                int r=(int)(o.w/2);
                g.setColor(new Color(200,200,200));g.fillOval((int)(o.x-r),(int)(o.y-r),r*2,r*2);g.setColor(Color.BLACK);g.setStroke(S_LINE);g.drawOval((int)(o.x-r),(int)(o.y-r),r*2,r*2);
                g.setColor(new Color(140,140,140));g.fillOval((int)(o.x-9),(int)(o.y-9),18,18);g.setColor(Color.BLACK);g.setStroke(S_THIN);g.drawOval((int)(o.x-9),(int)(o.y-9),18,18);
                // spokes
                for(int i=0;i<4;i++){double ang=i*Math.PI/4;g.draw(new Line2D.Double(o.x+9*Math.cos(ang),o.y+9*Math.sin(ang),o.x+r*Math.cos(ang),o.y+r*Math.sin(ang)));}
                ctr(g,o.label,o.x,o.y+r+14,F_SMALL,C_MUTED);
            } else if(o.type.startsWith("Wall")){
                g.setColor(o.fixed?new Color(100,100,100):new Color(160,100,80));
                g.fillRect((int)(o.x-o.w/2),(int)(o.y-o.h/2),(int)o.w,(int)o.h);
                g.setColor(Color.BLACK);g.setStroke(S_LINE);g.drawRect((int)(o.x-o.w/2),(int)(o.y-o.h/2),(int)o.w,(int)o.h);
                g.setColor(new Color(60,60,60));g.setStroke(S_THIN);for(int i=0;i<4;i++)g.drawLine((int)(o.x-o.w/2),(int)(o.y-o.h/2+20+i*14),(int)(o.x+o.w/2),(int)(o.y-o.h/2+6+i*14));
                ctr(g,o.label,o.x,o.y+o.h/2+12,F_SMALL,C_MUTED);
            } else {
                // Mass Block
                g.setColor(o.fixed?new Color(160,160,160):new Color(225,225,245));
                g.fillRect((int)(o.x-o.w/2),(int)(o.y-o.h/2),(int)o.w,(int)o.h);
                g.setColor(Color.BLACK);g.setStroke(S_LINE);g.drawRect((int)(o.x-o.w/2),(int)(o.y-o.h/2),(int)o.w,(int)o.h);
                ctr(g,o.label,o.x,o.y-6,F_SMALL,C_DIM);
                ctr(g,o.mass+"kg",o.x,o.y+8,F_IDX,C_MUTED);
            }
            g.setTransform(saved);
        }

        void drawConn(Graphics2D g,PObj a,PObj b,Conn c){
            g.setColor(Color.BLACK);
            // for pulleys: connect to circumference edge, not centre
            double ax=a.x,ay=a.y,bx=b.x,by=b.y;
            if(a.type.startsWith("Pulley")){double dx=bx-ax,dy=by-ay,l=Math.sqrt(dx*dx+dy*dy),r=a.w/2;ax+=dx/l*r;ay+=dy/l*r;}
            if(b.type.startsWith("Pulley")){double dx=ax-bx,dy=ay-by,l=Math.sqrt(dx*dx+dy*dy),r=b.w/2;bx+=dx/l*r;by+=dy/l*r;}

            if(c.broken){ g.setColor(new Color(200,80,80));g.setStroke(S_DASH);g.draw(new Line2D.Double(ax,ay,bx,by));g.setFont(F_SMALL);g.drawString("BROKEN",(int)((ax+bx)/2)+4,(int)((ay+by)/2));return; }

            if("Spring".equals(c.type)){
                double dx=bx-ax,dy=by-ay,len=Math.sqrt(dx*dx+dy*dy);if(len<1)return;
                double ux=dx/len,uy=dy/len,ppx=-uy,ppy=ux,coils=8,cw=7;
                g.setStroke(new BasicStroke(1.8f));
                Path2D sp=new Path2D.Double();sp.moveTo(ax,ay);
                for(int i=0;i<=(int)(coils*2);i++){double t=(double)i/(coils*2);double sd=i%2==0?cw:-cw;sp.lineTo(ax+ux*len*t+ppx*sd,ay+uy*len*t+ppy*sd);}
                sp.lineTo(bx,by);g.draw(sp);
                // length label
                g.setFont(F_IDX);g.setColor(C_MUTED);double dist=Math.sqrt((bx-ax)*(bx-ax)+(by-ay)*(by-ay));String lbl="k="+c.k+" L="+(int)dist;g.drawString(lbl,(int)((ax+bx)/2+ppx*14),(int)((ay+by)/2+ppy*14));
            } else if("Rope".equals(c.type)||"String".equals(c.type)){
                double rdx=bx-ax,rdy=by-ay;
                double curLen=Math.sqrt(rdx*rdx+rdy*rdy);
                // sag only when slack (current length < rest length)
                double slack=Math.max(0, c.rest-curLen);
                double sag=slack*0.4;
                double mx=(ax+bx)/2,my=(ay+by)/2+sag;
                g.setStroke(new BasicStroke("Rope".equals(c.type)?2.8f:1.4f,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
                if(sag<1.0){
                    g.draw(new Line2D.Double(ax,ay,bx,by));
                } else {
                    g.draw(new QuadCurve2D.Double(ax,ay,mx,my,bx,by));
                }
                g.setFont(F_IDX);g.setColor(C_MUTED);g.drawString(c.type,(int)(mx+4),(int)(my-6));
            } else { // rod
                g.setStroke(new BasicStroke(4,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));g.draw(new Line2D.Double(ax,ay,bx,by));
                g.setColor(new Color(80,80,80));g.setStroke(new BasicStroke(1.8f));g.draw(new Line2D.Double(ax,ay,bx,by));
            }
        }


        public void saveTo(StringBuilder sb){
            for(PObj o:objs.values())
                sb.append("po=").append(o.id).append("|").append(o.type).append("|").append(o.label).append("|").append(String.format("%.1f",o.x)).append("|").append(String.format("%.1f",o.y)).append("|").append(o.mass).append("|").append(o.fixed).append("|").append(String.format("%.1f",o.w)).append("|").append(String.format("%.1f",o.h)).append("|").append(String.format("%.3f",o.angle)).append("|").append(String.format("%.2f",o.friction)).append("|").append(String.format("%.2f",o.restitution)).append("|").append(o.wedgeFlipped).append("|").append(o.lockRotation).append("\n");
            for(Conn c:conns)
                sb.append("pc=").append(c.a).append("|").append(c.b).append("|").append(c.type).append("|").append(String.format("%.1f",c.rest)).append("|").append(c.k).append("|").append(c.ropeMass).append("\n");
            for(PulleyConn pc:pulleyConns)
                sb.append("ppc=").append(pc.massA).append("|").append(pc.pulleyId).append("|").append(pc.massB).append("|").append(String.format("%.1f",pc.totalLength)).append("\n");
        }
        public void loadLine(String line){
            if(line.startsWith("po=")){String[]p=line.substring(3).split("\\|",-1);if(p.length>=9)try{PObj o=new PObj(p[0],p[1],p[2],Double.parseDouble(p[3]),Double.parseDouble(p[4]),Boolean.parseBoolean(p[6]));o.mass=Double.parseDouble(p[5]);o.w=Double.parseDouble(p[7]);o.h=Double.parseDouble(p[8]);if(p.length>9)try{o.angle=Double.parseDouble(p[9]);o.friction=Double.parseDouble(p[10]);o.restitution=Double.parseDouble(p[11]);o.wedgeFlipped=Boolean.parseBoolean(p[12]);if(p.length>13)o.lockRotation=Boolean.parseBoolean(p[13]);}catch(Exception ignored2){}objs.put(p[0],o);try{int n=Integer.parseInt(p[0].replaceAll("[^0-9]",""));if(n>idC)idC=n;}catch(NumberFormatException ignored){}}catch(NumberFormatException ignored){}}
            else if(line.startsWith("pc=")){String[]p=line.substring(3).split("\\|",-1);if(p.length>=5)try{Conn c=new Conn(p[0],p[1],p[2],Double.parseDouble(p[3]));c.k=Double.parseDouble(p[4]);if(p.length>5)try{c.ropeMass=Double.parseDouble(p[5]);}catch(Exception ig){}conns.add(c);}catch(NumberFormatException ignored){}}
            else if(line.startsWith("ppc=")){String[]p=line.substring(4).split("\\|",-1);if(p.length>=4)try{pulleyConns.add(new PulleyConn(p[0],p[1],p[2],Double.parseDouble(p[3])));}catch(NumberFormatException ignored){}}
        }
        // Repaint hook — set by activate
        void setRepaintCB(Runnable r){repaintCB=r;}
    }


    // ── Integer-list serialization helpers ──────────────────────────────────
    static void saveIntList(StringBuilder sb, String key, List<Integer> lst) {
        sb.append(key).append("=");
        for (int i = 0; i < lst.size(); i++) { if (i>0) sb.append(','); sb.append(lst.get(i)); }
        sb.append("\n");
    }
    static void loadIntList(String csv, List<Integer> out) {
        if (csv == null || csv.trim().isEmpty()) return;
        for (String v : csv.split(",")) { try { out.add(Integer.parseInt(v.trim())); } catch (NumberFormatException ignored) {} }
    }

}

// ── Patch AnimState to have a stepIdx field ────────────────────────────────
// (AnimState is defined as a top-level inner static class above, methods below
//  are wired at the call sites with .stepIdx = 0 replaced by separate reset calls)

// AnimState.stepIdx is already accessed as anim.stepIdx in animReset()
// We need to add it to the class. It's added inline via the List index tracking.
// The field `idx` in AnimState is the step index.